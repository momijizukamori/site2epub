/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JJWXCLogic": () => (/* binding */ JJWXCLogic)
/* harmony export */ });
/* harmony import */ var _generic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var _fontData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3);


var CryptoJS = __webpack_require__(122);

class JJWXCLogic extends _generic__WEBPACK_IMPORTED_MODULE_0__.SiteLogic {
    processMetadata(index_html) {
        let metadata = null;

        try {
            let author = document.querySelector('span[itemprop="author"]').innerText;
            let title = document.querySelector('h1[itemprop="name"]').innerText;
            let id = document.querySelector('#clickNovelid').innerText;
            let genre = document.querySelector('span[itemprop="genre"]').innerText;
            let cover = document.querySelector('img[itemprop="image"]').getAttribute('src');

            this.css = "p {font-family: 'Microsoft YaHei', PingFangSC-Regular, HelveticaNeue-Light, 'Helvetica Neue Light', sans-serif !important;}";

            metadata = {
                id: id,
                title: title,
                author: author,
                genre: genre,
                images: [],
                contents: 'Table of Contents',
                language: 'zh'
            };
        } catch (err) {
            console.debug(err);
        } finally {
            return metadata;
        }
    }

    MD5process(input_str, offset) {
        console.debug("MD5input is", input_str);
        var warray = CryptoJS.enc.Utf8.parse(input_str);
        var hash = CryptoJS.MD5(warray);
        var hex = CryptoJS.enc.Hex.stringify(hash);
        console.debug(hex);

        var start = offset;
        var end = offset + 16;
        var utf8_iv = "";
        var utf8_key = "";
        if (offset > 16) {
            end = end % 16;
            utf8_key = hex.slice(end, start);
            utf8_iv = hex.slice(start) + hex.slice(0, end);

        } else {
            utf8_iv = hex.slice(start, end);
            utf8_key = hex.slice(end) + hex.slice(0, start);
        }
        console.debug(utf8_iv, utf8_key);
        return { key: utf8_key, iv: utf8_iv };

    }

    DESDecode(input, cfg) {
        // console.debug("DES input is", input);
        // console.debug("DES cfg is", cfg);
        var key = CryptoJS.enc.Utf8.parse(cfg.key); //("9f952d5041805f3a");
        var iv = CryptoJS.enc.Utf8.parse(cfg.iv); //("7f15f12258e0e853");

        var decrypted = CryptoJS.DES.decrypt(input, key, { iv: iv });
        return CryptoJS.enc.Utf8.stringify(decrypted);
    }

    async decryptChapter(page_html) {
        var novelid = page_html.querySelector('input[name=novelid').value;
        var chapterid = page_html.querySelector('input[name=chapterid').value;
        var cryptinfo = page_html.querySelector('input[name=cryptInfo').value;
        var accesskey = page_html.querySelector('input[name=accessKey').value;
        var content = page_html.querySelector('input[name=content').value;
        var cookie = await browser.cookies.get({ name: "JJEVER", url: "http://www.jjwxc.net/" });
        console.debug(cookie);

        let cookie_val = decodeURIComponent(cookie.value);
        let parsed_cookie = JSON.parse(cookie_val);
        var readerid = parsed_cookie.foreverreader;
        console.debug(novelid, chapterid, cryptinfo, accesskey, readerid);

        let ch_content = null;



        // The position at which the MD5 hashes are split into the key and iv varies
        // per load. I haven't figured out the deterministic way to find it, but it's short
        // enough to bruteforce by running through all the split positions and seeing what
        // gives us good data.
        for (let i = 0; i < 33; i++) {

            var input1 = `${novelid}.${chapterid}.${readerid}.${accesskey}`;
            var params1 = this.MD5process(input1, i);
            try {
                var output1 = JSON.parse(atob(this.DESDecode(cryptinfo, params1)));
                console.debug(output1); // should look like { time: 1666289067, key: "RwUpuyA", ver: "20220527" };

                var input2 = `${output1.key}${output1.time}${readerid}`;
                var params2 = this.MD5process(input2, i);
                var params2swap = { key: params2.iv, iv: params2.key };

                ch_content = this.DESDecode(content, params2swap);

                break;
            } catch {
                continue;
            }
        }

        console.debug(ch_content);
        if (ch_content) {
            let ch_body = page_html.querySelector('.noveltext');
            ch_body.innerHTML = ch_content;
            return ch_body;
        } else {
            return null;
        }

    }

    getChapterlist(index_html) {
        let chapters = [];
        let rows = index_html.querySelectorAll('tr[itemprop="chapter"], tr[itemprop="chapter newestChapter"]');
        rows.forEach(row => {
            let info = row.querySelector('a[itemprop="url"]');
            if (info) {
                let ch_title = info.innerText;
                let url = info.getAttribute('href');
                if (!url) {
                    // Try the VIP link
                    url = info.getAttribute('rel');
                }
                url = url.replace("http://", "https://");
                let num = row.querySelector('td:nth-child(1)').innerText;
                let sum = row.querySelector('td:nth-child(3)').innerText;
                let ch = { title: ch_title, url: url, num: num, summary: sum };
                chapters.push({ title: ch_title, url: url, num: num, summary: sum });
            }
        });
        return chapters;
    }

    async getChapter(page_html) {
        let ch_text = [];
        let ch_body = page_html.querySelector('.novelbody div');
        let ch_note = page_html.querySelector('.readsmall');
        let encrypted_ch = page_html.querySelector('input[name=content]');
        let hasFont = false;
        let clean_note = "";

        if (encrypted_ch) {
            ch_body = await this.decryptChapter(page_html);
        }
        console.debug(ch_body);

        if (ch_body) {
            console.debug("got chapter body");
            ch_body.classList.forEach((token) => {
                if (token.startsWith("jjwxcfont_")) {
                    hasFont = `http://static.jjwxc.net/tmp/fonts/${token}.woff2?h=my.jjwxc.net`;
                }
            });

            ch_body.childNodes.forEach(function(node) {
                if (node.nodeType == 3) {
                    let content = node.textContent.trim();
                    if (content.length > 0) {
                        ch_text.push(node.textContent);
                    }
                }

            });

            if (ch_note) {
                let note = [];
                ch_note.childNodes.forEach(function (node) {
                    if (node.nodeType == 3) {
                        let content = node.textContent.trim();
                        if (content.length > 0) {
                            note.push(node.textContent);
                        }
                    } else if (node.nodeType == 1 && node.nodeName != 'input' && node.childNodes.length > 0) {
                        node.childNodes.forEach(function (node) {
                            if (node.nodeType == 3) {
                                let content = node.textContent.trim();
                                if (content.length > 0) {
                                    note.push(node.textContent);
                                }
                            }
                        });
                    }
                });
                clean_note = "<hr /><p>" + note.join('</p><p>') + "</p>";
            }

            console.debug(ch_text);

            if (hasFont) {
                console.debug("hasFont");
                let fontResp = await fetch(hasFont);
                let buff = await fontResp.arrayBuffer();
                return await (0,_fontData__WEBPACK_IMPORTED_MODULE_1__.fontRemap)(buff, "<p>" + ch_text.join('</p><p>') + "</p>") + clean_note;

            } else {
                return "<p>" + ch_text.join('</p><p>') + "</p>" + clean_note;
            }
        } else {
            return null;
        }
    }

    async chapterXHR(chapter) {
        console.debug(chapter);
        let xhr = new XMLHttpRequest();
        xhr.overrideMimeType('text/html; charset=gb18030');
        xhr.open("GET", chapter.url, false);
        xhr.send(null);
        console.debug(xhr.responseText);
        const parser = new DOMParser();
        let chapter_frag = parser.parseFromString(xhr.responseText, "text/html");

        let ch_content = await this.getChapter(chapter_frag);
        if (ch_content) {
            console.debug(ch_content);
            return this.buildChapter(chapter.title, chapter.num, chapter.summary, ch_content);
        } else {
            return null;
        }

    }

    chapterTab(chapter, data) {
        const parser = new DOMParser();
        let chapter_frag = parser.parseFromString(data, "text/html");
        let ch_content = this.getChapter(chapter_frag);
        return ch_content.then(data => {
            if (data) {
                return this.buildChapter(chapter.title, chapter.num, chapter.summary, data);
            } else {
                return null;
            }
        });
    }

    buildChapter(title, number, summary, content) {
        let ch_title = `${number} - ${title}`;
        let ch_body = `<h1>${ch_title}</h1><p><i>${summary}</i></p><hr />${content}`
        return { title: ch_title, content: ch_body };
    }

    loadURL(url) {
        const regex = new RegExp(/.*jjwxc\.net\/onebook\.php\?novelid=\d+$/);
        return regex.test(url);
    }

}

/***/ }),
/* 2 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SiteLogic": () => (/* binding */ SiteLogic)
/* harmony export */ });
class SiteLogic {
    constructor() {
        this.css = "";
    }
    processMetadata(index_html) {
        // Take a novel index page and build basic epub metadata out of it
        var metadata = {
            id: '278-123456789',
            title: 'My Title',
            series: 'My Series',
            sequence: 1,
            author: 'My Author',
            fileAs: 'Cartlidge,KA',
            genre: 'Non-Fiction',
            tags: 'Sample,Example,Test',
            copyright: 'Anonymous, 1980',
            publisher: 'My Fake Publisher',
            published: '2000-12-31',
            language: 'en',
            description: 'A test book.',
            contents: 'Table of Contents',
            source: 'http://www.kcartlidge.com',
        };
        return metadata;
    }

    getChapterlist(index_html) {
        // Take a novel index and return a list of objects representing a chapter
        // These should be in the form {title: chapter title, url: chapter url, num: chapter number, summary: summary}
        var chapters = [{title: "chapter title", url: "http://example.com", num: 1, summary: null}];
        return chapters
    }

    getChapter(page_html) {
        // Take page html and return the cleaned chapter content for it.
        return '<p>some text</p>'
    }

    buildChapter(title, number, summary, content) {
        // Take chapter data components and return formatted chapter title and content
        return {title: title, content: content}
    }

    buildTitle(title, number){
        // build a string for chapter title out of the string and number
        return `${number} - ${title}`;
    }

    canXHR() {
        // return true if chapters can be fetched via XHR, or false if they must be fully loaded in a tab
        // XHR is faster, so prefer that when you can
        return true;
    }

    chapterXHR(chapter) {
        // Take chapter data and return finished chapter, or null if chapter could not be fetched.
        // This should use synchronous XHR
        return null;
    }

    chapterTab(chapter, data) {
        // Take document and return cleaned content, or null if not fetchable
        // This will be run in an injected script
        return window.location.href;
    }

    getCSS() {
        return this.css
    }

    loadURL(url) {
        // return true if the page action should become active, false if not.
        return true;
    }
}


/***/ }),
/* 3 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fontData": () => (/* binding */ fontData),
/* harmony export */   "fontRemap": () => (/* binding */ fontRemap)
/* harmony export */ });
const Font = __webpack_require__(4).Font;
const woff2 = __webpack_require__(4).woff2;

const fontData = [
    { "xMin": 0, "yMin": -76, "xMax": 944, "yMax": 837, "contours": 7, "unicode": "真" },
{ "xMin": 0, "yMin": -74, "xMax": 954, "yMax": 764, "contours": 2, "unicode": "不" },
{ "xMin": 0, "yMin": -71, "xMax": 960, "yMax": 832, "contours": 1, "unicode": "人" },
{ "xMin": 0, "yMin": -74, "xMax": 914, "yMax": 794, "contours": 4, "unicode": "回" },
{ "xMin": 0, "yMin": -59, "xMax": 923, "yMax": 840, "contours": 5, "unicode": "的" },
{ "xMin": 0, "yMin": -73, "xMax": 934, "yMax": 833, "contours": 4, "unicode": "种" },
{ "xMin": 0, "yMin": -74, "xMax": 897, "yMax": 836, "contours": 3, "unicode": "中" },
{ "xMin": 0, "yMin": -81, "xMax": 882, "yMax": 764, "contours": 5, "unicode": "用" },
{ "xMin": 0, "yMin": -77, "xMax": 968, "yMax": 818, "contours": 4, "unicode": "还" },
{ "xMin": 0, "yMin": -64, "xMax": 826, "yMax": 766, "contours": 3, "unicode": "日" },
{ "xMin": 0, "yMin": -77, "xMax": 950, "yMax": 832, "contours": 7, "unicode": "得" },
{ "xMin": 0, "yMin": -54, "xMax": 945, "yMax": 791, "contours": 9, "unicode": "思" },
{ "xMin": 0, "yMin": -75, "xMax": 958, "yMax": 836, "contours": 6, "unicode": "能" },
{ "xMin": 0, "yMin": -72, "xMax": 934, "yMax": 768, "contours": 4, "unicode": "西" },
{ "xMin": 0, "yMin": -75, "xMax": 920, "yMax": 835, "contours": 7, "unicode": "神" },
{ "xMin": 0, "yMin": -42, "xMax": 945, "yMax": 831, "contours": 1, "unicode": "主" },
{ "xMin": 0, "yMin": -50, "xMax": 959, "yMax": 833, "contours": 4, "unicode": "过" },
{ "xMin": 0, "yMin": -72, "xMax": 949, "yMax": 834, "contours": 1, "unicode": "手" },
{ "xMin": 0, "yMin": -75, "xMax": 946, "yMax": 834, "contours": 5, "unicode": "将" },
{ "xMin": 0, "yMin": -76, "xMax": 887, "yMax": 759, "contours": 1, "unicode": "了" },
{ "xMin": 0, "yMin": -55, "xMax": 948, "yMax": 834, "contours": 1, "unicode": "也" },
{ "xMin": 0, "yMin": -62, "xMax": 966, "yMax": 835, "contours": 2, "unicode": "此" },
{ "xMin": 0, "yMin": -66, "xMax": 958, "yMax": 841, "contours": 3, "unicode": "这" },
{ "xMin": 0, "yMin": -74, "xMax": 957, "yMax": 834, "contours": 2, "unicode": "会" },
{ "xMin": 0, "yMin": -43, "xMax": 945, "yMax": 829, "contours": 5, "unicode": "重" },
{ "xMin": 0, "yMin": -75, "xMax": 845, "yMax": 838, "contours": 2, "unicode": "名" },
{ "xMin": 0, "yMin": -77, "xMax": 942, "yMax": 791, "contours": 6, "unicode": "要" },
{ "xMin": 0, "yMin": -77, "xMax": 910, "yMax": 789, "contours": 4, "unicode": "国" },
{ "xMin": 0, "yMin": -74, "xMax": 948, "yMax": 835, "contours": 4, "unicode": "少" },
{ "xMin": 0, "yMin": -72, "xMax": 944, "yMax": 841, "contours": 6, "unicode": "前" },
{ "xMin": 0, "yMin": -79, "xMax": 950, "yMax": 836, "contours": 4, "unicode": "行" },
{ "xMin": 0, "yMin": -77, "xMax": 906, "yMax": 821, "contours": 6, "unicode": "间" },
{ "xMin": 0, "yMin": -72, "xMax": 935, "yMax": 835, "contours": 2, "unicode": "在" },
{ "xMin": 0, "yMin": -77, "xMax": 953, "yMax": 823, "contours": 3, "unicode": "所" },
{ "xMin": 0, "yMin": -83, "xMax": 965, "yMax": 835, "contours": 2, "unicode": "起" },
{ "xMin": 0, "yMin": -76, "xMax": 959, "yMax": 803, "contours": 9, "unicode": "最" },
{ "xMin": 0, "yMin": -75, "xMax": 948, "yMax": 834, "contours": 1, "unicode": "十" },
{ "xMin": 0, "yMin": -31, "xMax": 946, "yMax": 760, "contours": 1, "unicode": "正" },
{ "xMin": 0, "yMin": -72, "xMax": 923, "yMax": 836, "contours": 5, "unicode": "相" },
{ "xMin": 0, "yMin": -67, "xMax": 956, "yMax": 830, "contours": 5, "unicode": "时" },
{ "xMin": 0, "yMin": -82, "xMax": 960, "yMax": 797, "contours": 3, "unicode": "以" },
{ "xMin": 0, "yMin": -73, "xMax": 945, "yMax": 834, "contours": 6, "unicode": "其" },
{ "xMin": 0, "yMin": -75, "xMax": 953, "yMax": 834, "contours": 1, "unicode": "大" },
{ "xMin": 0, "yMin": 0, "xMax": 928, "yMax": 738, "contours": 3, "unicode": "三" },
{ "xMin": 0, "yMin": -78, "xMax": 966, "yMax": 834, "contours": 1, "unicode": "太" },
{ "xMin": 0, "yMin": -76, "xMax": 961, "yMax": 834, "contours": 1, "unicode": "本" },
{ "xMin": 0, "yMin": -74, "xMax": 935, "yMax": 835, "contours": 4, "unicode": "法" },
{ "xMin": 0, "yMin": -56, "xMax": 957, "yMax": 839, "contours": 2, "unicode": "之" },
{ "xMin": 0, "yMin": -76, "xMax": 952, "yMax": 836, "contours": 3, "unicode": "特" },
{ "xMin": 0, "yMin": -71, "xMax": 943, "yMax": 763, "contours": 1, "unicode": "于" },
{ "xMin": 0, "yMin": -62, "xMax": 934, "yMax": 836, "contours": 1, "unicode": "才" },
{ "xMin": 0, "yMin": -47, "xMax": 944, "yMax": 795, "contours": 5, "unicode": "里" },
{ "xMin": 0, "yMin": -77, "xMax": 929, "yMax": 840, "contours": 4, "unicode": "着" },
{ "xMin": 0, "yMin": -79, "xMax": 959, "yMax": 839, "contours": 3, "unicode": "发" },
{ "xMin": 0, "yMin": -51, "xMax": 906, "yMax": 842, "contours": 2, "unicode": "它" },
{ "xMin": 0, "yMin": -74, "xMax": 958, "yMax": 834, "contours": 2, "unicode": "他" },
{ "xMin": 0, "yMin": -74, "xMax": 901, "yMax": 837, "contours": 3, "unicode": "向" },
{ "xMin": 0, "yMin": -77, "xMax": 876, "yMax": 836, "contours": 3, "unicode": "当" },
{ "xMin": 0, "yMin": -81, "xMax": 951, "yMax": 835, "contours": 1, "unicode": "先" },
{ "xMin": 0, "yMin": -75, "xMax": 913, "yMax": 836, "contours": 2, "unicode": "却" },
{ "xMin": 0, "yMin": -75, "xMax": 942, "yMax": 838, "contours": 3, "unicode": "样" },
{ "xMin": 0, "yMin": -76, "xMax": 852, "yMax": 839, "contours": 3, "unicode": "白" },
{ "xMin": 0, "yMin": -77, "xMax": 955, "yMax": 843, "contours": 7, "unicode": "然" },
{ "xMin": 0, "yMin": -71, "xMax": 954, "yMax": 839, "contours": 6, "unicode": "新" },
{ "xMin": 0, "yMin": -78, "xMax": 958, "yMax": 773, "contours": 5, "unicode": "再" },
{ "xMin": 0, "yMin": -79, "xMax": 908, "yMax": 816, "contours": 5, "unicode": "別" },
{ "xMin": 0, "yMin": -75, "xMax": 958, "yMax": 834, "contours": 4, "unicode": "何" },
{ "xMin": 0, "yMin": -76, "xMax": 954, "yMax": 828, "contours": 4, "unicode": "话" },
{ "xMin": 0, "yMin": -75, "xMax": 957, "yMax": 832, "contours": 2, "unicode": "作" },
{ "xMin": 0, "yMin": -73, "xMax": 961, "yMax": 840, "contours": 3, "unicode": "文" },
{ "xMin": 0, "yMin": -75, "xMax": 954, "yMax": 831, "contours": 2, "unicode": "关" },
{ "xMin": 0, "yMin": -65, "xMax": 941, "yMax": 823, "contours": 2, "unicode": "么" },
{ "xMin": 0, "yMin": -50, "xMax": 951, "yMax": 834, "contours": 4, "unicode": "些" },
{ "xMin": 0, "yMin": -76, "xMax": 940, "yMax": 767, "contours": 6, "unicode": "面" },
{ "xMin": 0, "yMin": -82, "xMax": 945, "yMax": 838, "contours": 3, "unicode": "并" },
{ "xMin": 0, "yMin": -42, "xMax": 963, "yMax": 789, "contours": 6, "unicode": "理" },
{ "xMin": 0, "yMin": -79, "xMax": 950, "yMax": 833, "contours": 6, "unicode": "给" },
{ "xMin": 0, "yMin": -78, "xMax": 930, "yMax": 840, "contours": 2, "unicode": "方" },
{ "xMin": 0, "yMin": -76, "xMax": 950, "yMax": 838, "contours": 2, "unicode": "年" },
{ "xMin": 0, "yMin": -76, "xMax": 957, "yMax": 794, "contours": 2, "unicode": "儿" },
{ "xMin": 0, "yMin": -77, "xMax": 901, "yMax": 821, "contours": 5, "unicode": "问" },
{ "xMin": 0, "yMin": -42, "xMax": 905, "yMax": 748, "contours": 2, "unicode": "四" },
{ "xMin": 0, "yMin": -79, "xMax": 956, "yMax": 816, "contours": 3, "unicode": "分" },
{ "xMin": 0, "yMin": -50, "xMax": 871, "yMax": 730, "contours": 2, "unicode": "口" },
{ "xMin": 0, "yMin": -76, "xMax": 939, "yMax": 837, "contours": 2, "unicode": "多" },
{ "xMin": 0, "yMin": -77, "xMax": 953, "yMax": 832, "contours": 4, "unicode": "你" },
{ "xMin": 0, "yMin": -78, "xMax": 949, "yMax": 826, "contours": 3, "unicode": "后" },
{ "xMin": 0, "yMin": -53, "xMax": 906, "yMax": 818, "contours": 4, "unicode": "到" },
{ "xMin": 0, "yMin": -76, "xMax": 907, "yMax": 836, "contours": 3, "unicode": "门" },
{ "xMin": 0, "yMin": -77, "xMax": 954, "yMax": 835, "contours": 5, "unicode": "说" },
{ "xMin": 0, "yMin": -75, "xMax": 934, "yMax": 838, "contours": 6, "unicode": "高" },
{ "xMin": 0, "yMin": -75, "xMax": 953, "yMax": 812, "contours": 2, "unicode": "从" },
{ "xMin": 0, "yMin": -81, "xMax": 927, "yMax": 838, "contours": 4, "unicode": "声" },
{ "xMin": 0, "yMin": -75, "xMax": 943, "yMax": 785, "contours": 4, "unicode": "那" },
{ "xMin": 0, "yMin": -72, "xMax": 954, "yMax": 839, "contours": 1, "unicode": "美" },
{ "xMin": 0, "yMin": -53, "xMax": 971, "yMax": 837, "contours": 4, "unicode": "论" },
{ "xMin": 0, "yMin": -77, "xMax": 955, "yMax": 767, "contours": 1, "unicode": "无" },
{ "xMin": 0, "yMin": -79, "xMax": 956, "yMax": 841, "contours": 2, "unicode": "定" },
{ "xMin": 0, "yMin": -47, "xMax": 947, "yMax": 772, "contours": 1, "unicode": "已" },
{ "xMin": 0, "yMin": -76, "xMax": 945, "yMax": 836, "contours": 2, "unicode": "物" },
{ "xMin": 0, "yMin": -75, "xMax": 946, "yMax": 831, "contours": 3, "unicode": "书" },
{ "xMin": 0, "yMin": -47, "xMax": 961, "yMax": 835, "contours": 4, "unicode": "经" },
{ "xMin": 0, "yMin": -79, "xMax": 940, "yMax": 760, "contours": 4, "unicode": "只" },
{ "xMin": 0, "yMin": -74, "xMax": 961, "yMax": 841, "contours": 2, "unicode": "家" },
{ "xMin": 0, "yMin": -75, "xMax": 941, "yMax": 847, "contours": 2, "unicode": "女" },
{ "xMin": 0, "yMin": -67, "xMax": 960, "yMax": 812, "contours": 3, "unicode": "公" },
{ "xMin": 0, "yMin": -76, "xMax": 958, "yMax": 791, "contours": 7, "unicode": "眼" },
{ "xMin": 0, "yMin": -74, "xMax": 953, "yMax": 835, "contours": 7, "unicode": "情" },
{ "xMin": 0, "yMin": -74, "xMax": 947, "yMax": 830, "contours": 3, "unicode": "听" },
{ "xMin": 0, "yMin": -77, "xMax": 919, "yMax": 835, "contours": 4, "unicode": "如" },
{ "xMin": 0, "yMin": -61, "xMax": 957, "yMax": 839, "contours": 6, "unicode": "道" },
{ "xMin": 0, "yMin": -81, "xMax": 915, "yMax": 792, "contours": 6, "unicode": "明" },
{ "xMin": 0, "yMin": -79, "xMax": 945, "yMax": 769, "contours": 2, "unicode": "开" },
{ "xMin": 0, "yMin": -66, "xMax": 884, "yMax": 813, "contours": 2, "unicode": "与" },
{ "xMin": 0, "yMin": -8, "xMax": 947, "yMax": 831, "contours": 2, "unicode": "世" },
{ "xMin": 0, "yMin": -52, "xMax": 959, "yMax": 836, "contours": 2, "unicode": "地" },
{ "xMin": 0, "yMin": -53, "xMax": 952, "yMax": 776, "contours": 1, "unicode": "己" },
{ "xMin": 0, "yMin": -75, "xMax": 942, "yMax": 839, "contours": 6, "unicode": "部" },
{ "xMin": 0, "yMin": -67, "xMax": 963, "yMax": 765, "contours": 2, "unicode": "又" },
{ "xMin": 0, "yMin": -73, "xMax": 898, "yMax": 826, "contours": 3, "unicode": "和" },
{ "xMin": 0, "yMin": -75, "xMax": 942, "yMax": 843, "contours": 2, "unicode": "学" },
{ "xMin": 0, "yMin": -75, "xMax": 936, "yMax": 835, "contours": 3, "unicode": "有" },
{ "xMin": 0, "yMin": -72, "xMax": 942, "yMax": 762, "contours": 1, "unicode": "下" },
{ "xMin": 0, "yMin": -76, "xMax": 947, "yMax": 780, "contours": 1, "unicode": "而" },
{ "xMin": 0, "yMin": -79, "xMax": 964, "yMax": 836, "contours": 2, "unicode": "教" },
{ "xMin": 0, "yMin": -75, "xMax": 961, "yMax": 756, "contours": 1, "unicode": "天" },
{ "xMin": 0, "yMin": -78, "xMax": 946, "yMax": 840, "contours": 3, "unicode": "笑" },
{ "xMin": 0, "yMin": -59, "xMax": 959, "yMax": 816, "contours": 4, "unicode": "进" },
{ "xMin": 0, "yMin": -75, "xMax": 942, "yMax": 835, "contours": 4, "unicode": "者" },
{ "xMin": 0, "yMin": -79, "xMax": 960, "yMax": 827, "contours": 2, "unicode": "我" },
{ "xMin": 0, "yMin": -80, "xMax": 967, "yMax": 837, "contours": 4, "unicode": "使" },
{ "xMin": 0, "yMin": 0, "xMax": 953, "yMax": 425, "contours": 1, "unicode": "一" },
{ "xMin": 0, "yMin": -75, "xMax": 964, "yMax": 835, "contours": 2, "unicode": "个" },
{ "xMin": 0, "yMin": -78, "xMax": 938, "yMax": 827, "contours": 4, "unicode": "看" },
{ "xMin": 0, "yMin": -65, "xMax": 918, "yMax": 780, "contours": 3, "unicode": "写" },
{ "xMin": 0, "yMin": -80, "xMax": 954, "yMax": 783, "contours": 3, "unicode": "民" },
{ "xMin": 0, "yMin": -75, "xMax": 963, "yMax": 835, "contours": 3, "unicode": "来" },
{ "xMin": 0, "yMin": -76, "xMax": 941, "yMax": 778, "contours": 3, "unicode": "见" },
{ "xMin": 0, "yMin": -78, "xMax": 949, "yMax": 786, "contours": 3, "unicode": "现" },
{ "xMin": 0, "yMin": -70, "xMax": 957, "yMax": 835, "contours": 2, "unicode": "打" },
{ "xMin": 0, "yMin": -74, "xMax": 963, "yMax": 832, "contours": 5, "unicode": "但" },
{ "xMin": 0, "yMin": -76, "xMax": 918, "yMax": 834, "contours": 4, "unicode": "们" },
{ "xMin": 0, "yMin": -82, "xMax": 954, "yMax": 834, "contours": 2, "unicode": "成" },
{ "xMin": 0, "yMin": -75, "xMax": 962, "yMax": 835, "contours": 5, "unicode": "被" },
{ "xMin": 0, "yMin": -58, "xMax": 960, "yMax": 797, "contours": 4, "unicode": "心" },
{ "xMin": 0, "yMin": -71, "xMax": 963, "yMax": 830, "contours": 2, "unicode": "长" },
{ "xMin": 0, "yMin": -77, "xMax": 972, "yMax": 825, "contours": 3, "unicode": "代" },
{ "xMin": 0, "yMin": -75, "xMax": 959, "yMax": 836, "contours": 2, "unicode": "外" },
{ "xMin": 0, "yMin": -76, "xMax": 949, "yMax": 770, "contours": 1, "unicode": "子" },
{ "xMin": 0, "yMin": -75, "xMax": 956, "yMax": 839, "contours": 3, "unicode": "社" },
{ "xMin": 0, "yMin": -75, "xMax": 958, "yMax": 838, "contours": 3, "unicode": "气" },
{ "xMin": 0, "yMin": -74, "xMax": 967, "yMax": 833, "contours": 2, "unicode": "体" },
{ "xMin": 0, "yMin": -78, "xMax": 959, "yMax": 834, "contours": 1, "unicode": "走" },
{ "xMin": 0, "yMin": -28, "xMax": 943, "yMax": 819, "contours": 1, "unicode": "上" },
{ "xMin": 0, "yMin": -54, "xMax": 946, "yMax": 833, "contours": 9, "unicode": "想" },
{ "xMin": 0, "yMin": -76, "xMax": 965, "yMax": 836, "contours": 8, "unicode": "就" },
{ "xMin": 0, "yMin": -72, "xMax": 932, "yMax": 841, "contours": 5, "unicode": "实" },
{ "xMin": 0, "yMin": -77, "xMax": 957, "yMax": 793, "contours": 4, "unicode": "是" },
{ "xMin": 0, "yMin": -75, "xMax": 882, "yMax": 835, "contours": 5, "unicode": "由" },
{ "xMin": 0, "yMin": -75, "xMax": 957, "yMax": 839, "contours": 2, "unicode": "义" },
{ "xMin": 0, "yMin": -67, "xMax": 951, "yMax": 837, "contours": 8, "unicode": "感" },
{ "xMin": 0, "yMin": -84, "xMax": 934, "yMax": 838, "contours": 4, "unicode": "身" },
{ "xMin": 0, "yMin": -77, "xMax": 957, "yMax": 835, "contours": 3, "unicode": "她" },
{ "xMin": 0, "yMin": -75, "xMax": 941, "yMax": 819, "contours": 3, "unicode": "动" },
{ "xMin": 0, "yMin": -77, "xMax": 938, "yMax": 765, "contours": 2, "unicode": "两" },
{ "xMin": 0, "yMin": -77, "xMax": 955, "yMax": 835, "contours": 3, "unicode": "好" },
{ "xMin": 0, "yMin": -78, "xMax": 910, "yMax": 783, "contours": 4, "unicode": "同" },
{ "xMin": 0, "yMin": -76, "xMax": 951, "yMax": 832, "contours": 2, "unicode": "什" },
{ "xMin": 0, "yMin": -65, "xMax": 947, "yMax": 836, "contours": 1, "unicode": "去" },
{ "xMin": 0, "yMin": -78, "xMax": 964, "yMax": 832, "contours": 6, "unicode": "便" },
{ "xMin": 0, "yMin": -74, "xMax": 944, "yMax": 764, "contours": 3, "unicode": "可" },
{ "xMin": 0, "yMin": -61, "xMax": 945, "yMax": 836, "contours": 2, "unicode": "老" },
{ "xMin": 0, "yMin": -76, "xMax": 966, "yMax": 835, "contours": 4, "unicode": "把" },
{ "xMin": 0, "yMin": -76, "xMax": 946, "yMax": 836, "contours": 6, "unicode": "点" },
{ "xMin": 0, "yMin": -76, "xMax": 958, "yMax": 827, "contours": 5, "unicode": "都" },
{ "xMin": 0, "yMin": -68, "xMax": 896, "yMax": 834, "contours": 3, "unicode": "为" },
{ "xMin": 0, "yMin": -76, "xMax": 959, "yMax": 832, "contours": 5, "unicode": "很" },
{ "xMin": 0, "yMin": -67, "xMax": 930, "yMax": 843, "contours": 8, "unicode": "意" },
{ "xMin": 0, "yMin": -76, "xMax": 960, "yMax": 822, "contours": 6, "unicode": "没" },
{ "xMin": 0, "yMin": -80, "xMax": 903, "yMax": 834, "contours": 1, "unicode": "力" },
{ "xMin": 0, "yMin": -76, "xMax": 957, "yMax": 835, "contours": 2, "unicode": "化" },
{ "xMin": 0, "yMin": -78, "xMax": 960, "yMax": 775, "contours": 1, "unicode": "几" },
{ "xMin": 0, "yMin": -75, "xMax": 958, "yMax": 832, "contours": 3, "unicode": "史" },
{ "xMin": 0, "yMin": -74, "xMax": 915, "yMax": 794, "contours": 3, "unicode": "因" },
{ "xMin": 0, "yMin": -74, "xMax": 943, "yMax": 836, "contours": 4, "unicode": "性" },
{ "xMin": 0, "yMin": 0, "xMax": 941, "yMax": 692, "contours": 2, "unicode": "二" },
{ "xMin": 0, "yMin": -44, "xMax": 945, "yMax": 835, "contours": 1, "unicode": "生" },
{ "xMin": 0, "yMin": -73, "xMax": 903, "yMax": 836, "contours": 3, "unicode": "知" },
{ "xMin": 0, "yMin": -76, "xMax": 967, "yMax": 820, "contours": 3, "unicode": "小" },
{ "xMin": 0, "yMin": -74, "xMax": 955, "yMax": 833, "contours": 3, "unicode": "对" },
{ "xMin": 0, "yMin": -74, "xMax": 890, "yMax": 835, "contours": 1, "unicode": "出" },
{ "xMin": 0, "yMin": -79, "xMax": 950, "yMax": 835, "contours": 5, "unicode": "事" },
{ "xMin": 0, "yMin": -75, "xMax": 960, "yMax": 787, "contours": 5, "unicode": "果" },
{ "xMin": 0, "yMin": -78, "xMax": 942, "yMax": 840, "contours": 5, "unicode": "第" },
{ "xMin": 0, "yMin": -77, "xMax": 847, "yMax": 837, "contours": 4, "unicode": "自" },
{ "xMin": 0, "yMin": -47, "xMax": 972, "yMax": 846, "contours": 2, "unicode": "全" },
{ "xMin": 0, "yMin": -72, "xMax": 942, "yMax": 824, "contours": 4, "unicode": "头" },
{ "xMin": 0, "yMin": -75, "xMax": 952, "yMax": 840, "contours": 3, "unicode": "等" },
{ "xMin": 0, "yMin": -77, "xMax": 964, "yMax": 781, "contours": 5, "unicode": "更" },
{ "xMin": 0, "yMin": -60, "xMax": 957, "yMax": 772, "contours": 1, "unicode": "死" }];

function compare_glyph(a, b) {
    return a.xMin === b.xMin && a.yMin === b.yMin && a.xMax === b.xMax && a.yMax === b.yMax && a.contours.length === b.contours;
}

function remap(text, mapping){
    let temp_text = null;
    mapping.forEach(entry => {
        let esc = String.fromCodePoint(entry[0]);
        if (temp_text) {
            temp_text = temp_text.replaceAll(esc, entry[1]);
        } else {
            temp_text = text.replaceAll(esc, entry[1]);
        }


    });

    console.debug(temp_text);
    return temp_text;
}

function fontRemap(fontbuff, text) {
    // console.debug(text);
    let fontarray = new Uint8Array(fontbuff);
    return woff2.init('addon/woff2.wasm').then(() => {
        console.debug("inited");
        let font = Font.create(fontarray, {
            type: 'woff2'
        });
        font.sort();
        let fontObject = font.get();
        let mappings = [];

        let data = [];

        fontObject['glyf'].forEach((glyph) => {
            console.debug(glyph);
            fontData.forEach((glyph2) => {
                if (compare_glyph(glyph, glyph2)) {
                    mappings.push([glyph.unicode[0],  glyph2.unicode]);
                }
            })
        });
        console.debug(mappings);
        return remap(text, mappings);
    });
}


/***/ }),
/* 4 */
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Font": () => (/* reexport safe */ _ttf_font__WEBPACK_IMPORTED_MODULE_0__.default),
/* harmony export */   "woff2": () => (/* reexport default from dynamic */ _woff2_index__WEBPACK_IMPORTED_MODULE_18___default.a),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ttf_font__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5);
/* harmony import */ var _ttf_ttf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11);
/* harmony import */ var _ttf_ttfreader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87);
/* harmony import */ var _ttf_ttfwriter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(100);
/* harmony import */ var _ttf_ttf2eot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(102);
/* harmony import */ var _ttf_eot2ttf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(67);
/* harmony import */ var _ttf_ttf2woff__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(103);
/* harmony import */ var _ttf_woff2ttf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(27);
/* harmony import */ var _ttf_ttf2svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(104);
/* harmony import */ var _ttf_svg2ttfobject__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(68);
/* harmony import */ var _ttf_reader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(28);
/* harmony import */ var _ttf_writer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(33);
/* harmony import */ var _ttf_otfreader__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(35);
/* harmony import */ var _ttf_otf2ttfobject__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(34);
/* harmony import */ var _ttf_ttf2base64__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(115);
/* harmony import */ var _ttf_ttf2icon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(121);
/* harmony import */ var _ttf_ttftowoff2__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(109);
/* harmony import */ var _ttf_woff2tottf__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(114);
/* harmony import */ var _woff2_index__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(110);
/* harmony import */ var _woff2_index__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_woff2_index__WEBPACK_IMPORTED_MODULE_18__);
/* module decorator */ module = __webpack_require__.hmd(module);
/**
 * @file 主函数
 * @author mengke01(kekee000@gmail.com)
 */
























const modules = {
    Font: _ttf_font__WEBPACK_IMPORTED_MODULE_0__.default,
    TTF: _ttf_ttf__WEBPACK_IMPORTED_MODULE_1__.default,
    TTFReader: _ttf_ttfreader__WEBPACK_IMPORTED_MODULE_2__.default,
    TTFWriter: _ttf_ttfwriter__WEBPACK_IMPORTED_MODULE_3__.default,
    ttf2eot: _ttf_ttf2eot__WEBPACK_IMPORTED_MODULE_4__.default,
    eot2ttf: _ttf_eot2ttf__WEBPACK_IMPORTED_MODULE_5__.default,
    ttf2woff: _ttf_ttf2woff__WEBPACK_IMPORTED_MODULE_6__.default,
    woff2ttf: _ttf_woff2ttf__WEBPACK_IMPORTED_MODULE_7__.default,
    ttf2svg: _ttf_ttf2svg__WEBPACK_IMPORTED_MODULE_8__.default,
    svg2ttfobject: _ttf_svg2ttfobject__WEBPACK_IMPORTED_MODULE_9__.default,
    Reader: _ttf_reader__WEBPACK_IMPORTED_MODULE_10__.default,
    Writer: _ttf_writer__WEBPACK_IMPORTED_MODULE_11__.default,
    OTFReader: _ttf_otfreader__WEBPACK_IMPORTED_MODULE_12__.default,
    otf2ttfobject: _ttf_otf2ttfobject__WEBPACK_IMPORTED_MODULE_13__.default,
    ttf2base64: _ttf_ttf2base64__WEBPACK_IMPORTED_MODULE_14__.default,
    ttf2icon: _ttf_ttf2icon__WEBPACK_IMPORTED_MODULE_15__.default,
    ttftowoff2: _ttf_ttftowoff2__WEBPACK_IMPORTED_MODULE_16__.default,
    woff2tottf: _ttf_woff2tottf__WEBPACK_IMPORTED_MODULE_17__.default,
    woff2: (_woff2_index__WEBPACK_IMPORTED_MODULE_18___default())
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (modules);

if (typeof exports !== 'undefined') {
    // eslint-disable-next-line import/no-commonjs
    module.exports = modules;
}


/***/ }),
/* 5 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Font)
/* harmony export */ });
/* harmony import */ var _nodejs_buffer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6);
/* harmony import */ var _getEmptyttfObject__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7);
/* harmony import */ var _ttf__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11);
/* harmony import */ var _woff2ttf__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(27);
/* harmony import */ var _otf2ttfobject__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(34);
/* harmony import */ var _eot2ttf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(67);
/* harmony import */ var _svg2ttfobject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(68);
/* harmony import */ var _ttfreader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(87);
/* harmony import */ var _ttfwriter__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(100);
/* harmony import */ var _ttf2eot__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(102);
/* harmony import */ var _ttf2woff__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(103);
/* harmony import */ var _ttf2svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(104);
/* harmony import */ var _ttf2symbol__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(108);
/* harmony import */ var _ttftowoff2__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(109);
/* harmony import */ var _woff2tottf__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(114);
/* harmony import */ var _ttf2base64__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(115);
/* harmony import */ var _eot2base64__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(117);
/* harmony import */ var _woff2base64__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(118);
/* harmony import */ var _svg2base64__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(119);
/* harmony import */ var _util_bytes2base64__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(116);
/* harmony import */ var _woff2tobase64__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(120);
/* harmony import */ var _util_optimizettf__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(24);
/* provided dependency */ var process = __webpack_require__(112);
/**
 * @file 字体管理对象，处理字体相关的读取、查询、转换
 *
 * @author mengke01(kekee000@gmail.com)
 */





























// 必须是nodejs环境下的Buffer对象才能触发buffer转换
const SUPPORT_BUFFER = typeof process === 'object'
    && typeof process.versions === 'object'
    && typeof process.versions.node !== 'undefined'
    && typeof Buffer === 'function';

class Font {

    /**
     * 字体对象构造函数
     *
     * @param {ArrayBuffer|Buffer|string} buffer  字体数据
     * @param {Object} options  读取参数
     */
    constructor(buffer, options = {type: 'ttf'}) {
        // 字形对象
        if (typeof buffer === 'object' && buffer.glyf) {
            this.set(buffer);
        }
        // buffer
        else if (buffer) {
            this.read(buffer, options);
        }
        // 空
        else {
            this.readEmpty();
        }
    }

    /**
     * 创建一个空的ttfObject对象
     *
     * @return {Font}
     */
    readEmpty() {
        this.data = (0,_getEmptyttfObject__WEBPACK_IMPORTED_MODULE_1__.default)();
        return this;
    }

    /**
     * 读取字体数据
     *
     * @param {ArrayBuffer|Buffer|string} buffer  字体数据
     * @param {Object} options  读取参数
     * @param {string} options.type 字体类型
     *
     * ttf, woff , eot 读取配置
     * @param {boolean} options.hinting 保留hinting信息
     * @param {boolean} options.compound2simple 复合字形转简单字形
     *
     * woff 读取配置
     * @param {Function} options.inflate 解压相关函数
     *
     * svg 读取配置
     * @param {boolean} options.combinePath 是否合并成单个字形，仅限于普通svg导入
     * @return {Font}
     */
    read(buffer, options) {
        // nodejs buffer
        if (SUPPORT_BUFFER) {
            if (buffer instanceof Buffer) {
                buffer = _nodejs_buffer__WEBPACK_IMPORTED_MODULE_0__.default.toArrayBuffer(buffer);
            }
        }

        if (options.type === 'ttf') {
            this.data = new _ttfreader__WEBPACK_IMPORTED_MODULE_7__.default(options).read(buffer);
        }
        else if (options.type === 'otf') {
            this.data = (0,_otf2ttfobject__WEBPACK_IMPORTED_MODULE_4__.default)(buffer, options);
        }
        else if (options.type === 'eot') {
            buffer = (0,_eot2ttf__WEBPACK_IMPORTED_MODULE_5__.default)(buffer, options);
            this.data = new _ttfreader__WEBPACK_IMPORTED_MODULE_7__.default(options).read(buffer);
        }
        else if (options.type === 'woff') {
            buffer = (0,_woff2ttf__WEBPACK_IMPORTED_MODULE_3__.default)(buffer, options);
            this.data = new _ttfreader__WEBPACK_IMPORTED_MODULE_7__.default(options).read(buffer);
        }
        else if (options.type === 'woff2') {
            buffer = (0,_woff2tottf__WEBPACK_IMPORTED_MODULE_14__.default)(buffer, options);
            this.data = new _ttfreader__WEBPACK_IMPORTED_MODULE_7__.default(options).read(buffer);
        }
        else if (options.type === 'svg') {
            this.data = (0,_svg2ttfobject__WEBPACK_IMPORTED_MODULE_6__.default)(buffer, options);
        }
        else {
            throw new Error('not support font type' + options.type);
        }

        this.type = options.type;
        return this;
    }

    /**
     * 写入字体数据
     *
     * @param {Object} options  写入参数
     * @param {string} options.type   字体类型, 默认 ttf
     * @param {boolean} options.toBuffer nodejs 环境中返回 Buffer 对象, 默认 true
     *
     * ttf 字体参数
     * @param {boolean} options.hinting 保留hinting信息
     *
     * svg,woff 字体参数
     * @param {Object} options.metadata 字体相关的信息
     *
     * woff 字体参数
     * @param {Function} options.deflate 压缩相关函数
     * @return {Buffer|ArrayBuffer|string}
     */
    write(options = {}) {
        if (!options.type) {
            options.type = this.type;
        }

        let buffer = null;
        if (options.type === 'ttf') {
            buffer = new _ttfwriter__WEBPACK_IMPORTED_MODULE_8__.default(options).write(this.data);
        }
        else if (options.type === 'eot') {
            buffer = new _ttfwriter__WEBPACK_IMPORTED_MODULE_8__.default(options).write(this.data);
            buffer = (0,_ttf2eot__WEBPACK_IMPORTED_MODULE_9__.default)(buffer, options);
        }
        else if (options.type === 'woff') {
            buffer = new _ttfwriter__WEBPACK_IMPORTED_MODULE_8__.default(options).write(this.data);
            buffer = (0,_ttf2woff__WEBPACK_IMPORTED_MODULE_10__.default)(buffer, options);
        }
        else if (options.type === 'woff2') {
            buffer = new _ttfwriter__WEBPACK_IMPORTED_MODULE_8__.default(options).write(this.data);
            buffer = (0,_ttftowoff2__WEBPACK_IMPORTED_MODULE_13__.default)(buffer, options);
        }
        else if (options.type === 'svg') {
            buffer = (0,_ttf2svg__WEBPACK_IMPORTED_MODULE_11__.default)(this.data, options);
        }
        else if (options.type === 'symbol') {
            buffer = (0,_ttf2symbol__WEBPACK_IMPORTED_MODULE_12__.default)(this.data, options);
        }
        else {
            throw new Error('not support font type' + options.type);
        }

        if (SUPPORT_BUFFER) {
            if (false !== options.toBuffer && buffer instanceof ArrayBuffer) {
                buffer = _nodejs_buffer__WEBPACK_IMPORTED_MODULE_0__.default.toBuffer(buffer);
            }
        }

        return buffer;
    }

    /**
     * 转换成 base64编码
     *
     * @param {Object} options  写入参数
     * @param {string} options.type   字体类型, 默认 ttf
     * 其他 options参数, 参考 write
     * @see write
     *
     * @param {ArrayBuffer} buffer  如果提供了buffer数据则使用 buffer数据, 否则转换现有的 font
     * @return {string}
     */
    toBase64(options, buffer) {
        if (!options.type) {
            options.type = this.type;
        }

        if (buffer) {
            if (SUPPORT_BUFFER) {
                if (buffer instanceof Buffer) {
                    buffer = _nodejs_buffer__WEBPACK_IMPORTED_MODULE_0__.default.toArrayBuffer(buffer);
                }
            }
        }
        else {
            options.toBuffer = false;
            buffer = this.write(options);
        }

        let base64Str;
        if (options.type === 'ttf') {
            base64Str = (0,_ttf2base64__WEBPACK_IMPORTED_MODULE_15__.default)(buffer);
        }
        else if (options.type === 'eot') {
            base64Str = (0,_eot2base64__WEBPACK_IMPORTED_MODULE_16__.default)(buffer);
        }
        else if (options.type === 'woff') {
            base64Str = (0,_woff2base64__WEBPACK_IMPORTED_MODULE_17__.default)(buffer);
        }
        else if (options.type === 'woff2') {
            base64Str = (0,_woff2tobase64__WEBPACK_IMPORTED_MODULE_20__.default)(buffer);
        }
        else if (options.type === 'svg') {
            base64Str = (0,_svg2base64__WEBPACK_IMPORTED_MODULE_18__.default)(buffer);
        }
        else if (options.type === 'symbol') {
            base64Str = (0,_svg2base64__WEBPACK_IMPORTED_MODULE_18__.default)(buffer, 'image/svg+xml');
        }
        else {
            throw new Error('not support font type' + options.type);
        }

        return base64Str;
    }

    /**
     * 设置 font 对象
     *
     * @param {Object} data font的ttfObject对象
     * @return {this}
     */
    set(data) {
        this.data = data;
        return this;
    }

    /**
     * 获取 font 数据
     *
     * @return {Object} ttfObject 对象
     */
    get() {
        return this.data;
    }

    /**
     * 对字形数据进行优化
     *
     * @param  {Object} out  输出结果
     * @param  {boolean|Object} out.result `true` 或者有问题的地方
     * @return {Font}
     */
    optimize(out) {
        const result = (0,_util_optimizettf__WEBPACK_IMPORTED_MODULE_21__.default)(this.data);
        if (out) {
            out.result = result;
        }
        return this;
    }

    /**
     * 将字体中的复合字形转为简单字形
     *
     * @return {this}
     */
    compound2simple() {
        const ttf = new _ttf__WEBPACK_IMPORTED_MODULE_2__.default(this.data);
        ttf.compound2simple();
        this.data = ttf.get();
        return this;
    }

    /**
     * 对字形按照unicode编码排序
     *
     * @return {this}
     */
    sort() {
        const ttf = new _ttf__WEBPACK_IMPORTED_MODULE_2__.default(this.data);
        ttf.sortGlyf();
        this.data = ttf.get();
        return this;
    }

    /**
     * 查找相关字形
     *
     * @param  {Object} condition 查询条件
     * @param  {Array|number} condition.unicode unicode编码列表或者单个unicode编码
     * @param  {string} condition.name glyf名字，例如`uniE001`, `uniE`
     * @param  {Function} condition.filter 自定义过滤器
     * @example
     *     condition.filter(glyf) {
     *         return glyf.name === 'logo';
     *     }
     * @return {Array}  glyf字形列表
     */
    find(condition) {
        const ttf = new _ttf__WEBPACK_IMPORTED_MODULE_2__.default(this.data);
        const indexList = ttf.findGlyf(condition);
        return indexList.length ? ttf.getGlyf(indexList) : indexList;
    }

    /**
     * 合并 font 到当前的 font
     *
     * @param {Object} font Font 对象
     * @param {Object} options 参数选项
     * @param {boolean} options.scale 是否自动缩放
     * @param {boolean} options.adjustGlyf 是否调整字形以适应边界
     *                                     (和 options.scale 参数互斥)
     *
     * @return {Font}
     */
    merge(font, options) {
        const ttf = new _ttf__WEBPACK_IMPORTED_MODULE_2__.default(this.data);
        ttf.mergeGlyf(font.get(), options);
        this.data = ttf.get();
        return this;
    }
}

/**
 * 读取字体数据
 *
 * @param {ArrayBuffer|Buffer|string} buffer 字体数据
 * @param {Object} options  读取参数
 * @return {Font}
 */
Font.create = function (buffer, options) {
    return new Font(buffer, options);
};

/**
 * base64序列化buffer 数据
 *
 * @param {ArrayBuffer|Buffer|string} buffer 字体数据
 * @return {Font}
 */
Font.toBase64 = function (buffer) {
    if (typeof buffer === 'string') {
        // node 环境中没有 btoa 函数
        if (typeof btoa === 'undefined') {
            return Buffer.from(buffer, 'binary').toString('base64');
        }

        return btoa(buffer);
    }
    return (0,_util_bytes2base64__WEBPACK_IMPORTED_MODULE_19__.default)(buffer);
};


/***/ }),
/* 6 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file Buffer和ArrayBuffer转换
 * @author mengke01(kekee000@gmail.com)
 */

/* eslint-disable no-undef */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({

    /**
     * Buffer转换成ArrayBuffer
     *
     * @param {Buffer} buffer 缓冲数组
     * @return {ArrayBuffer}
     */
    toArrayBuffer(buffer) {
        const length = buffer.length;
        const view = new DataView(new ArrayBuffer(length), 0, length);
        for (let i = 0, l = length; i < l; i++) {
            view.setUint8(i, buffer[i], false);
        }
        return view.buffer;
    },

    /**
     * ArrayBuffer转换成Buffer
     *
     * @param {ArrayBuffer} arrayBuffer 缓冲数组
     * @return {Buffer}
     */
    toBuffer(arrayBuffer) {
        if (Array.isArray(arrayBuffer)) {
            return Buffer.from(arrayBuffer);
        }

        const length = arrayBuffer.byteLength;
        const view = new DataView(arrayBuffer, 0, length);
        const buffer = Buffer.alloc(length);
        for (let i = 0, l = length; i < l; i++) {
            buffer[i] = view.getUint8(i, false);
        }
        return buffer;
    }
});


/***/ }),
/* 7 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getEmpty)
/* harmony export */ });
/* harmony import */ var _common_lang__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8);
/* harmony import */ var _data_empty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _data_default__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(10);
/**
 * @file 获取空的ttf对象
 * @author mengke01(kekee000@gmail.com)
 */






function getEmpty() {
    const ttf = (0,_common_lang__WEBPACK_IMPORTED_MODULE_0__.clone)(_data_empty__WEBPACK_IMPORTED_MODULE_1__.default);
    Object.assign(ttf.name, _data_default__WEBPACK_IMPORTED_MODULE_2__.default.name);
    ttf.head.created = ttf.head.modified = Date.now();
    return ttf;
}


/***/ }),
/* 8 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isArray": () => (/* binding */ isArray),
/* harmony export */   "isObject": () => (/* binding */ isObject),
/* harmony export */   "isString": () => (/* binding */ isString),
/* harmony export */   "isFunction": () => (/* binding */ isFunction),
/* harmony export */   "isDate": () => (/* binding */ isDate),
/* harmony export */   "isEmptyObject": () => (/* binding */ isEmptyObject),
/* harmony export */   "curry": () => (/* binding */ curry),
/* harmony export */   "generic": () => (/* binding */ generic),
/* harmony export */   "overwrite": () => (/* binding */ overwrite),
/* harmony export */   "clone": () => (/* binding */ clone),
/* harmony export */   "throttle": () => (/* binding */ throttle),
/* harmony export */   "debounce": () => (/* binding */ debounce),
/* harmony export */   "equals": () => (/* binding */ equals)
/* harmony export */ });
/**
 * @file 语言相关函数
 * @author mengke01(kekee000@gmail.com)
 */


function isArray(obj) {
    return obj != null && toString.call(obj).slice(8, -1) === 'Array';
}

function isObject(obj) {
    return obj != null && toString.call(obj).slice(8, -1) === 'Object';
}

function isString(obj) {
    return obj != null && toString.call(obj).slice(8, -1) === 'String';
}

function isFunction(obj) {
    return obj != null && toString.call(obj).slice(8, -1) === 'Function';
}

function isDate(obj) {
    return obj != null && toString.call(obj).slice(8, -1) === 'Date';
}

function isEmptyObject(object) {
    for (const name in object) {
        // eslint-disable-next-line no-prototype-builtins
        if (object.hasOwnProperty(name)) {
            return false;
        }
    }
    return true;
}

/**
 * 为函数提前绑定前置参数（柯里化）
 *
 * @see http://en.wikipedia.org/wiki/Currying
 * @param {Function} fn 要绑定的函数
 * @param {...Array} cargs cargs
 * @return {Function}
 */
function curry(fn, ...cargs) {
    return function (...rargs) {
        const args = cargs.concat(rargs);
        // eslint-disable-next-line no-invalid-this
        return fn.apply(this, args);
    };
}


/**
 * 方法静态化, 反绑定、延迟绑定
 *
 * @param {Function} method 待静态化的方法
 * @return {Function} 静态化包装后方法
 */
function generic(method) {
    return function (...fargs) {
        return Function.call.apply(method, fargs);
    };
}


/**
 * 设置覆盖相关的属性值
 *
 * @param {Object} thisObj 覆盖对象
 * @param {Object} thatObj 值对象
 * @param {Array.<string>} fields 字段
 * @return {Object} thisObj
 */
function overwrite(thisObj, thatObj, fields) {

    if (!thatObj) {
        return thisObj;
    }

    // 这里`fields`未指定则仅overwrite自身可枚举的字段，指定`fields`则不做限制
    fields = fields || Object.keys(thatObj);
    fields.forEach(field => {
        // 拷贝对象
        if (
            thisObj[field] && typeof thisObj[field] === 'object'
            && thatObj[field] && typeof thatObj[field] === 'object'
        ) {
            overwrite(thisObj[field], thatObj[field]);
        }
        else {
            thisObj[field] = thatObj[field];
        }
    });

    return thisObj;
}

/**
 * 深复制对象，仅复制数据
 *
 * @param {Object} source 源数据
 * @return {Object} 复制的数据
 */
function clone(source) {
    if (!source || typeof source !== 'object') {
        return source;
    }

    let cloned = source;

    if (isArray(source)) {
        cloned = source.slice().map(clone);
    }
    else if (isObject(source) && 'isPrototypeOf' in source) {
        cloned = {};
        for (const key of Object.keys(source)) {
            cloned[key] = clone(source[key]);
        }
    }

    return cloned;
}


// Returns a function, that, when invoked, will only be triggered at most once
// during a given window of time.
// @see underscore.js
function throttle(func, wait) {
    let context;
    let args;
    let timeout;
    let result;
    let previous = 0;
    const later = function () {
        previous = new Date();
        timeout = null;
        result = func.apply(context, args);
    };

    return function (...args) {
        const now = new Date();
        const remaining = wait - (now - previous);
        // eslint-disable-next-line no-invalid-this
        context = this;
        if (remaining <= 0) {
            clearTimeout(timeout);
            timeout = null;
            previous = now;
            result = func.apply(context, args);
        }
        else if (!timeout) {
            timeout = setTimeout(later, remaining);
        }
        return result;
    };
}

// Returns a function, that, as long as it continues to be invoked, will not
// be triggered. The function will be called after it stops being called for
// N milliseconds. If `immediate` is passed, trigger the function on the
// leading edge, instead of the trailing.
// @see underscore.js
function debounce(func, wait, immediate) {
    let timeout;
    let result;

    return function (...args) {
        // eslint-disable-next-line no-invalid-this
        const context = this;
        const later = function () {
            timeout = null;
            if (!immediate) {
                result = func.apply(context, args);
            }
        };

        const callNow = immediate && !timeout;

        clearTimeout(timeout);
        timeout = setTimeout(later, wait);

        if (callNow) {
            result = func.apply(context, args);
        }

        return result;
    };
}

/**
 * 判断两个对象的字段是否相等
 *
 * @param  {Object} thisObj 要比较的对象
 * @param  {Object} thatObj 参考对象
 * @param  {Array} fields 指定字段
 * @return {boolean}  是否相等
 */
function equals(thisObj, thatObj, fields) {

    if (thisObj === thatObj) {
        return true;
    }

    if (thisObj == null && thatObj == null) {
        return true;
    }

    if (thisObj == null && thatObj != null || thisObj != null && thatObj == null) {
        return false;
    }

    // 这里`fields`未指定则仅overwrite自身可枚举的字段，指定`fields`则不做限制
    fields = fields || (typeof thisObj === 'object'
        ? Object.keys(thisObj)
        : []);

    if (!fields.length) {
        return thisObj === thatObj;
    }

    let equal = true;
    for (let i = 0, l = fields.length, field; equal && i < l; i++) {
        field = fields[i];

        if (
            thisObj[field] && typeof thisObj[field] === 'object'
            && thatObj[field] && typeof thatObj[field] === 'object'
        ) {
            equal = equal && equals(thisObj[field], thatObj[field]);
        }
        else {
            equal = equal && (thisObj[field] === thatObj[field]);
        }
    }

    return equal;
}


/***/ }),
/* 9 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file 空的ttf格式json对象
 * @author mengke01(kekee000@gmail.com)
 */

/* eslint-disable  */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    "version": 1,
    "numTables": 10,
    "searchRange": 128,
    "entrySelector": 3,
    "rangeShift": 64,
    "head": {
        "version": 1,
        "fontRevision": 1,
        "checkSumAdjustment": 0,
        "magickNumber": 1594834165,
        "flags": 11,
        "unitsPerEm": 1024,
        "created": 1428940800000,
        "modified": 1428940800000,
        "xMin": 34,
        "yMin": 0,
        "xMax": 306,
        "yMax": 682,
        "macStyle": 0,
        "lowestRecPPEM": 8,
        "fontDirectionHint": 2,
        "indexToLocFormat": 0,
        "glyphDataFormat": 0
    },
    "glyf": [{
        "contours": [
            [{
                "x": 34,
                "y": 0,
                "onCurve": true
            }, {
                "x": 34,
                "y": 682,
                "onCurve": true
            }, {
                "x": 306,
                "y": 682,
                "onCurve": true
            }, {
                "x": 306,
                "y": 0,
                "onCurve": true
            }],
            [{
                "x": 68,
                "y": 34,
                "onCurve": true
            }, {
                "x": 272,
                "y": 34,
                "onCurve": true
            }, {
                "x": 272,
                "y": 648,
                "onCurve": true
            }, {
                "x": 68,
                "y": 648,
                "onCurve": true
            }]
        ],
        "xMin": 34,
        "yMin": 0,
        "xMax": 306,
        "yMax": 682,
        "advanceWidth": 374,
        "leftSideBearing": 34,
        "name": ".notdef"
    }],
    "cmap": {},
    "name": {
        "fontFamily": "fonteditor",
        "fontSubFamily": "Medium",
        "uniqueSubFamily": "FontEditor 1.0 : fonteditor",
        "version": "Version 1.0 ; FontEditor (v0.0.1)",
        "postScriptName": "fonteditor",
        "fullName": "fonteditor"
    },
    "hhea": {
        "version": 1,
        "ascent": 812,
        "descent": -212,
        "lineGap": 92,
        "advanceWidthMax": 374,
        "minLeftSideBearing": 34,
        "minRightSideBearing": 68,
        "xMaxExtent": 306,
        "caretSlopeRise": 1,
        "caretSlopeRun": 0,
        "caretOffset": 0,
        "reserved0": 0,
        "reserved1": 0,
        "reserved2": 0,
        "reserved3": 0,
        "metricDataFormat": 0,
        "numOfLongHorMetrics": 1
    },
    "post": {
        "italicAngle": 0,
        "postoints": 65411,
        "underlinePosition": 50,
        "underlineThickness": 0,
        "isFixedPitch": 0,
        "minMemType42": 0,
        "maxMemType42": 0,
        "minMemType1": 0,
        "maxMemType1": 1,
        "format": 2
    },
    "maxp": {
        "version": 1.0,
        "numGlyphs": 0,
        "maxPoints": 0,
        "maxContours": 0,
        "maxCompositePoints": 0,
        "maxCompositeContours": 0,
        "maxZones": 0,
        "maxTwilightPoints": 0,
        "maxStorage": 0,
        "maxFunctionDefs": 0,
        "maxStackElements": 0,
        "maxSizeOfInstructions": 0,
        "maxComponentElements": 0,
        "maxComponentDepth": 0
    },
    "OS/2": {
        "version": 4,
        "xAvgCharWidth": 1031,
        "usWeightClass": 400,
        "usWidthClass": 5,
        "fsType": 0,
        "ySubscriptXSize": 665,
        "ySubscriptYSize": 716,
        "ySubscriptXOffset": 0,
        "ySubscriptYOffset": 143,
        "ySuperscriptXSize": 665,
        "ySuperscriptYSize": 716,
        "ySuperscriptXOffset": 0,
        "ySuperscriptYOffset": 491,
        "yStrikeoutSize": 51,
        "yStrikeoutPosition": 265,
        "sFamilyClass": 0,
        "bFamilyType": 2,
        "bSerifStyle": 0,
        "bWeight": 6,
        "bProportion": 3,
        "bContrast": 0,
        "bStrokeVariation": 0,
        "bArmStyle": 0,
        "bLetterform": 0,
        "bMidline": 0,
        "bXHeight": 0,
        "ulUnicodeRange1": 1,
        "ulUnicodeRange2": 268435456,
        "ulUnicodeRange3": 0,
        "ulUnicodeRange4": 0,
        "achVendID": "PfEd",
        "fsSelection": 192,
        "usFirstCharIndex": 65535,
        "usLastCharIndex": -1,
        "sTypoAscender": 812,
        "sTypoDescender": -212,
        "sTypoLineGap": 92,
        "usWinAscent": 812,
        "usWinDescent": 212,
        "ulCodePageRange1": 1,
        "ulCodePageRange2": 0,
        "sxHeight": 792,
        "sCapHeight": 0,
        "usDefaultChar": 0,
        "usBreakChar": 32,
        "usMaxContext": 1
    }
});


/***/ }),
/* 10 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file 默认的ttf字体配置
 * @author mengke01(kekee000@gmail.com)
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    // 默认的字体编码
    fontId: 'fonteditor',

    // 默认的名字集合
    name: {
        // 默认的字体家族
        fontFamily: 'fonteditor',
        fontSubFamily: 'Medium',
        uniqueSubFamily: 'FontEditor 1.0 : fonteditor',
        version: 'Version 1.0; FontEditor (v1.0)',
        postScriptName: 'fonteditor'
    }
});


/***/ }),
/* 11 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ TTF)
/* harmony export */ });
/* harmony import */ var _common_lang__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8);
/* harmony import */ var _util_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12);
/* harmony import */ var _graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15);
/* harmony import */ var _graphics_pathCeil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16);
/* harmony import */ var _graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17);
/* harmony import */ var _util_compound2simpleglyf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19);
/* harmony import */ var _util_glyfAdjust__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23);
/* harmony import */ var _util_optimizettf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(24);
/* harmony import */ var _data_default__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(10);
/**
 * @file ttf相关处理对象
 * @author mengke01(kekee000@gmail.com)
 */











/**
 * 缩放到EM框
 *
 * @param {Array} glyfList glyf列表
 * @param {number} ascent 上升
 * @param {number} descent 下降
 * @param {number} ajdustToEmPadding  顶部和底部留白
 * @return {Array} glyfList
 */
function adjustToEmBox(glyfList, ascent, descent, ajdustToEmPadding) {

    glyfList.forEach((g) => {

        if (g.contours && g.contours.length) {
            const rightSideBearing = g.advanceWidth - g.xMax;
            const bound = (0,_graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_4__.computePath)(...g.contours);
            const scale = (ascent - descent - ajdustToEmPadding) / bound.height;
            const center = (ascent + descent) / 2;
            const yOffset = center - (bound.y + bound.height / 2) * scale;

            g.contours.forEach((contour) => {
                if (scale !== 1) {
                    (0,_graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_2__.default)(contour, scale, scale);
                }

                (0,_graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_2__.default)(contour, 1, 1, 0, yOffset);
                (0,_graphics_pathCeil__WEBPACK_IMPORTED_MODULE_3__.default)(contour);
            });

            const box = (0,_graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_4__.computePathBox)(...g.contours);

            g.xMin = box.x;
            g.xMax = box.x + box.width;
            g.yMin = box.y;
            g.yMax = box.y + box.height;

            g.leftSideBearing = g.xMin;
            g.advanceWidth = g.xMax + rightSideBearing;

        }

    });

    return glyfList;
}

/**
 * 调整字形位置
 *
 * @param {Array} glyfList 字形列表
 * @param {number=} leftSideBearing 左边距
 * @param {number=} rightSideBearing 右边距
 * @param {number=} verticalAlign 垂直对齐
 *
 * @return {Array} 改变的列表
 */
function adjustPos(glyfList, leftSideBearing, rightSideBearing, verticalAlign) {

    let changed = false;

    // 左边轴
    if (null != leftSideBearing) {
        changed = true;

        glyfList.forEach((g) => {
            if (g.leftSideBearing !== leftSideBearing) {
                (0,_util_glyfAdjust__WEBPACK_IMPORTED_MODULE_6__.default)(g, 1, 1, leftSideBearing - g.leftSideBearing);
            }
        });
    }

    // 右边轴
    if (null != rightSideBearing) {
        changed = true;

        glyfList.forEach((g) => {
            g.advanceWidth = g.xMax + rightSideBearing;
        });
    }

    // 基线高度
    if (null != verticalAlign) {
        changed = true;

        glyfList.forEach(g => {
            if (g.contours && g.contours.length) {
                const bound = (0,_graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_4__.computePath)(...g.contours);
                const offset = verticalAlign - bound.y;
                (0,_util_glyfAdjust__WEBPACK_IMPORTED_MODULE_6__.default)(g, 1, 1, 0, offset);
            }
        });
    }

    return changed ? glyfList : [];
}



/**
 * 合并两个ttfObject，此处仅合并简单字形
 *
 * @param {Object} ttf ttfObject
 * @param {Object} imported ttfObject
 * @param {Object} options 参数选项
 * @param {boolean} options.scale 是否自动缩放，默认true
 * @param {boolean} options.adjustGlyf 是否调整字形以适应边界
 *                                     (与 options.scale 互斥)
 *
 * @return {Object} 合并后的ttfObject
 */
function merge(ttf, imported, options = {scale: true}) {

    const list = imported.glyf.filter((g) =>
        // 简单轮廓
        g.contours && g.contours.length
            // 非预定义字形
            && g.name !== '.notdef' && g.name !== '.null' && g.name !== 'nonmarkingreturn'
    );

    // 调整字形以适应边界
    if (options.adjustGlyf) {
        const ascent = ttf.hhea.ascent;
        const descent = ttf.hhea.descent;
        const ajdustToEmPadding = 16;
        adjustPos(list, 16, 16);
        adjustToEmBox(list, ascent, descent, ajdustToEmPadding);

        list.forEach((g) => {
            ttf.glyf.push(g);
        });
    }
    // 根据unitsPerEm 进行缩放
    else if (options.scale) {

        let scale = 1;

        // 调整glyf对导入的轮廓进行缩放处理
        if (imported.head.unitsPerEm && imported.head.unitsPerEm !== ttf.head.unitsPerEm) {
            scale = ttf.head.unitsPerEm / imported.head.unitsPerEm;
        }

        list.forEach((g) => {
            (0,_util_glyfAdjust__WEBPACK_IMPORTED_MODULE_6__.default)(g, scale, scale);
            ttf.glyf.push(g);
        });
    }

    return list;
}

class TTF {

    /**
     * ttf读取函数
     *
     * @constructor
     * @param {Object} ttf ttf文件结构
     */
    constructor(ttf) {
        this.ttf = ttf;
    }

    /**
     * 获取所有的字符信息
     *
     * @return {Object} 字符信息
     */
    codes() {
        return Object.keys(this.ttf.cmap);
    }

    /**
     * 根据编码获取字形索引
     *
     * @param {string} c 字符或者字符编码
     *
     * @return {?number} 返回glyf索引号
     */
    getGlyfIndexByCode(c) {
        const charCode = typeof c === 'number' ? c : c.codePointAt(0);
        const glyfIndex = this.ttf.cmap[charCode] || -1;
        return glyfIndex;
    }

    /**
     * 根据索引获取字形
     *
     * @param {number} glyfIndex glyf的索引
     *
     * @return {?Object} 返回glyf对象
     */
    getGlyfByIndex(glyfIndex) {
        const glyfList = this.ttf.glyf;
        const glyf = glyfList[glyfIndex];
        return glyf;
    }

    /**
     * 根据编码获取字形
     *
     * @param {string} c 字符或者字符编码
     *
     * @return {?Object} 返回glyf对象
     */
    getGlyfByCode(c) {
        const glyfIndex = this.getGlyfIndexByCode(c);
        return this.getGlyfByIndex(glyfIndex);
    }

    /**
     * 设置ttf对象
     *
     * @param {Object} ttf ttf对象
     * @return {this}
     */
    set(ttf) {
        this.ttf = ttf;
        return this;
    }

    /**
     * 获取ttf对象
     *
     * @return {ttfObject} ttf ttf对象
     */
    get() {
        return this.ttf;
    }

    /**
     * 添加glyf
     *
     * @param {Object} glyf glyf对象
     *
     * @return {number} 添加的glyf
     */
    addGlyf(glyf) {
        return this.insertGlyf(glyf);
    }

    /**
     * 插入glyf
     *
     * @param {Object} glyf glyf对象
     * @param {Object} insertIndex 插入的索引
     * @return {number} 添加的glyf
     */
    insertGlyf(glyf, insertIndex) {
        if (insertIndex >= 0 && insertIndex < this.ttf.glyf.length) {
            this.ttf.glyf.splice(insertIndex, 0, glyf);
        }
        else {
            this.ttf.glyf.push(glyf);
        }

        return [glyf];
    }

    /**
     * 合并两个ttfObject，此处仅合并简单字形
     *
     * @param {Object} imported ttfObject
     * @param {Object} options 参数选项
     * @param {boolean} options.scale 是否自动缩放
     * @param {boolean} options.adjustGlyf 是否调整字形以适应边界
     *                                     (和 options.scale 参数互斥)
     *
     * @return {Array} 添加的glyf
     */
    mergeGlyf(imported, options) {
        const list = merge(this.ttf, imported, options);
        return list;
    }


    /**
     * 删除指定字形
     *
     * @param {Array} indexList 索引列表
     * @return {Array} 删除的glyf
     */
    removeGlyf(indexList) {
        const glyf = this.ttf.glyf;
        const removed = [];
        for (let i = glyf.length - 1; i >= 0; i--) {
            if (indexList.indexOf(i) >= 0) {
                removed.push(glyf[i]);
                glyf.splice(i, 1);
            }
        }
        return removed;
    }


    /**
     * 设置unicode代码
     *
     * @param {string} unicode unicode代码 $E021, $22
     * @param {Array=} indexList 索引列表
     * @param {boolean} isGenerateName 是否生成name
     * @return {Array} 改变的glyf
     */
    setUnicode(unicode, indexList, isGenerateName) {
        const glyf = this.ttf.glyf;
        let list = [];
        if (indexList && indexList.length) {
            const first = indexList.indexOf(0);
            if (first >= 0) {
                indexList.splice(first, 1);
            }
            list = indexList.map((item) => glyf[item]);
        }
        else {
            list = glyf.slice(1);
        }

        // 需要选出 unicode >32 的glyf
        if (list.length > 1) {
            const less32 = function (u) {
                return u < 33;
            };
            list = list.filter((g) => !g.unicode || !g.unicode.some(less32));
        }

        if (list.length) {
            unicode = Number('0x' + unicode.slice(1));
            list.forEach((g) => {
                // 空格有可能会放入 nonmarkingreturn 因此不做编码
                if (unicode === 0xA0 || unicode === 0x3000) {
                    unicode++;
                }

                g.unicode = [unicode];

                if (isGenerateName) {
                    g.name = _util_string__WEBPACK_IMPORTED_MODULE_1__.default.getUnicodeName(unicode);
                }
                unicode++;
            });
        }

        return list;
    }

    /**
     * 生成字形名称
     *
     * @param {Array=} indexList 索引列表
     * @return {Array} 改变的glyf
     */
    genGlyfName(indexList) {
        const glyf = this.ttf.glyf;
        let list = [];
        if (indexList && indexList.length) {
            list = indexList.map((item) => glyf[item]);
        }
        else {
            list = glyf;
        }

        if (list.length) {
            const first = this.ttf.glyf[0];

            list.forEach((g) => {
                if (g === first) {
                    g.name = '.notdef';
                }
                else if (g.unicode && g.unicode.length) {
                    g.name = _util_string__WEBPACK_IMPORTED_MODULE_1__.default.getUnicodeName(g.unicode[0]);
                }
                else {
                    g.name = '.notdef';
                }
            });
        }

        return list;
    }

    /**
     * 清除字形名称
     *
     * @param {Array=} indexList 索引列表
     * @return {Array} 改变的glyf
     */
    clearGlyfName(indexList) {
        const glyf = this.ttf.glyf;
        let list = [];
        if (indexList && indexList.length) {
            list = indexList.map((item) => glyf[item]);
        }
        else {
            list = glyf;
        }

        if (list.length) {

            list.forEach((g) => {
                delete g.name;
            });
        }

        return list;
    }

    /**
     * 添加并体替换指定的glyf
     *
     * @param {Array} glyfList 添加的列表
     * @param {Array=} indexList 需要替换的索引列表
     * @return {Array} 改变的glyf
     */
    appendGlyf(glyfList, indexList) {
        const glyf = this.ttf.glyf;
        const result = glyfList.slice(0);

        if (indexList && indexList.length) {
            const l = Math.min(glyfList.length, indexList.length);
            for (let i = 0; i < l; i++) {
                glyf[indexList[i]] = glyfList[i];
            }
            glyfList = glyfList.slice(l);
        }

        if (glyfList.length) {
            Array.prototype.splice.apply(glyf, [glyf.length, 0, ...glyfList]);
        }

        return result;
    }


    /**
     * 调整glyf位置
     *
     * @param {Array=} indexList 索引列表
     * @param {Object} setting 选项
     * @param {number=} setting.leftSideBearing 左边距
     * @param {number=} setting.rightSideBearing 右边距
     * @param {number=} setting.verticalAlign 垂直对齐
     * @return {Array} 改变的glyf
     */
    adjustGlyfPos(indexList, setting) {

        const glyfList = this.getGlyf(indexList);
        return adjustPos(
            glyfList,
            setting.leftSideBearing,
            setting.rightSideBearing,
            setting.verticalAlign
        );
    }


    /**
     * 调整glyf
     *
     * @param {Array=} indexList 索引列表
     * @param {Object} setting 选项
     * @param {boolean=} setting.reverse 字形反转操作
     * @param {boolean=} setting.mirror 字形镜像操作
     * @param {number=} setting.scale 字形缩放
     * @param {boolean=} setting.ajdustToEmBox  是否调整字形到 em 框
     * @param {number=} setting.ajdustToEmPadding 调整到 em 框的留白
     * @return {boolean}
     */
    adjustGlyf(indexList, setting) {

        const glyfList = this.getGlyf(indexList);
        let changed = false;

        if (setting.reverse || setting.mirror) {

            changed = true;

            glyfList.forEach((g) => {
                if (g.contours && g.contours.length) {
                    const offsetX = g.xMax + g.xMin;
                    const offsetY = g.yMax + g.yMin;
                    g.contours.forEach((contour) => {
                        (0,_graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_2__.default)(contour, setting.mirror ? -1 : 1, setting.reverse ? -1 : 1);
                        (0,_graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_2__.default)(contour, 1, 1, setting.mirror ? offsetX : 0, setting.reverse ? offsetY : 0);
                    });
                }
            });
        }


        if (setting.scale && setting.scale !== 1) {

            changed = true;

            const scale = setting.scale;
            glyfList.forEach((g) => {
                if (g.contours && g.contours.length) {
                    (0,_util_glyfAdjust__WEBPACK_IMPORTED_MODULE_6__.default)(g, scale, scale);
                }
            });
        }
        // 缩放到embox
        else if (setting.ajdustToEmBox) {

            changed = true;
            const ascent = this.ttf.hhea.ascent;
            const descent = this.ttf.hhea.descent;
            const ajdustToEmPadding = 2 * (setting.ajdustToEmPadding || 0);

            adjustToEmBox(glyfList, ascent, descent, ajdustToEmPadding);
        }

        return changed ? glyfList : [];
    }

    /**
     * 获取glyf列表
     *
     * @param {Array=} indexList 索引列表
     * @return {Array} glyflist
     */
    getGlyf(indexList) {
        const glyf = this.ttf.glyf;
        if (indexList && indexList.length) {
            return indexList.map((item) => glyf[item]);
        }

        return glyf;
    }


    /**
     * 查找相关字形
     *
     * @param  {Object} condition 查询条件
     * @param  {Array|number} condition.unicode unicode编码列表或者单个unicode编码
     * @param  {string} condition.name glyf名字，例如`uniE001`, `uniE`
     * @param  {Function} condition.filter 自定义过滤器
     * @example
     *     condition.filter = function (glyf) {
     *         return glyf.name === 'logo';
     *     }
     * @return {Array}  glyf字形索引列表
     */
    findGlyf(condition) {
        if (!condition) {
            return [];
        }


        const filters = [];

        // 按unicode数组查找
        if (condition.unicode) {
            const unicodeList = Array.isArray(condition.unicode) ? condition.unicode : [condition.unicode];
            const unicodeHash = {};
            unicodeList.forEach((unicode) => {
                if (typeof unicode === 'string') {
                    unicode = Number('0x' + unicode.slice(1));
                }
                unicodeHash[unicode] = true;
            });

            filters.push((glyf) => {
                if (!glyf.unicode || !glyf.unicode.length) {
                    return false;
                }

                for (let i = 0, l = glyf.unicode.length; i < l; i++) {
                    if (unicodeHash[glyf.unicode[i]]) {
                        return true;
                    }
                }
            });
        }

        // 按名字查找
        if (condition.name) {
            const name = condition.name;
            filters.push((glyf) => glyf.name && glyf.name.indexOf(name) === 0);
        }

        // 按筛选函数查找
        if (typeof condition.filter === 'function') {
            filters.push(condition.filter);
        }

        const indexList = [];
        this.ttf.glyf.forEach((glyf, index) => {
            for (let filterIndex = 0, filter; (filter = filters[filterIndex++]);) {
                if (true === filter(glyf)) {
                    indexList.push(index);
                    break;
                }
            }
        });

        return indexList;
    }


    /**
     * 更新指定的glyf
     *
     * @param {Object} glyf glyfobject
     * @param {string} index 需要替换的索引列表
     * @return {Array} 改变的glyf
     */
    replaceGlyf(glyf, index) {
        if (index >= 0 && index < this.ttf.glyf.length) {
            this.ttf.glyf[index] = glyf;
            return [glyf];
        }
        return [];
    }

    /**
     * 设置glyf
     *
     * @param {Array} glyfList glyf列表
     * @return {Array} 设置的glyf列表
     */
    setGlyf(glyfList) {
        delete this.glyf;
        this.ttf.glyf = glyfList || [];
        return this.ttf.glyf;
    }

    /**
     * 对字形按照unicode编码排序，此处不对复合字形进行排序，如果存在复合字形, 不进行排序
     *
     * @param {Array} glyfList glyf列表
     * @return {Array} 设置的glyf列表
     */
    sortGlyf() {
        const glyf = this.ttf.glyf;
        if (glyf.length > 1) {

            // 如果存在复合字形则退出
            if (glyf.some((a) => a.compound)) {
                return -2;
            }

            const notdef = glyf.shift();
            // 按代码点排序, 首先将空字形排到最后，然后按照unicode第一个编码进行排序
            glyf.sort((a, b) => {
                if ((!a.unicode || !a.unicode.length) && (!b.unicode || !b.unicode.length)) {
                    return 0;
                }
                else if ((!a.unicode || !a.unicode.length) && b.unicode) {
                    return 1;
                }
                else if (a.unicode && (!b.unicode || !b.unicode.length)) {
                    return -1;
                }
                return Math.min.apply(null, a.unicode) - Math.min.apply(null, b.unicode);
            });

            glyf.unshift(notdef);
            return glyf;
        }

        return -1;
    }



    /**
     * 设置名字
     *
     * @param {string} name 名字字段
     * @return {Object} 名字对象
     */
    setName(name) {

        if (name) {
            this.ttf.name.fontFamily = this.ttf.name.fullName = name.fontFamily || _data_default__WEBPACK_IMPORTED_MODULE_8__.default.name.fontFamily;
            this.ttf.name.fontSubFamily = name.fontSubFamily || _data_default__WEBPACK_IMPORTED_MODULE_8__.default.name.fontSubFamily;
            this.ttf.name.uniqueSubFamily = name.uniqueSubFamily || '';
            this.ttf.name.postScriptName = name.postScriptName || '';
        }

        return this.ttf.name;
    }

    /**
     * 设置head信息
     *
     * @param {Object} head 头部信息
     * @return {Object} 头对象
     */
    setHead(head) {
        if (head) {
            // unitsperem
            if (head.unitsPerEm && head.unitsPerEm >= 64 && head.unitsPerEm <= 16384) {
                this.ttf.head.unitsPerEm = head.unitsPerEm;
            }

            // lowestrecppem
            if (head.lowestRecPPEM && head.lowestRecPPEM >= 8 && head.lowestRecPPEM <= 16384) {
                this.ttf.head.lowestRecPPEM = head.lowestRecPPEM;
            }
            // created
            if (head.created) {
                this.ttf.head.created = head.created;
            }
            if (head.modified) {
                this.ttf.head.modified = head.modified;
            }
        }
        return this.ttf.head;
    }

    /**
     * 设置hhea信息
     *
     * @param {Object} fields 字段值
     * @return {Object} 头对象
     */
    setHhea(fields) {
        (0,_common_lang__WEBPACK_IMPORTED_MODULE_0__.overwrite)(this.ttf.hhea, fields, ['ascent', 'descent', 'lineGap']);
        return this.ttf.hhea;
    }

    /**
     * 设置OS2信息
     *
     * @param {Object} fields 字段值
     * @return {Object} 头对象
     */
    setOS2(fields) {
        (0,_common_lang__WEBPACK_IMPORTED_MODULE_0__.overwrite)(
            this.ttf['OS/2'], fields,
            [
                'usWinAscent', 'usWinDescent',
                'sTypoAscender', 'sTypoDescender', 'sTypoLineGap',
                'sxHeight', 'bXHeight', 'usWeightClass', 'usWidthClass',
                'yStrikeoutPosition', 'yStrikeoutSize',
                'achVendID',
                // panose
                'bFamilyType', 'bSerifStyle', 'bWeight', 'bProportion', 'bContrast',
                'bStrokeVariation', 'bArmStyle', 'bLetterform', 'bMidline', 'bXHeight'
            ]
        );
        return this.ttf['OS/2'];
    }

    /**
     * 设置post信息
     *
     * @param {Object} fields 字段值
     * @return {Object} 头对象
     */
    setPost(fields) {
        (0,_common_lang__WEBPACK_IMPORTED_MODULE_0__.overwrite)(
            this.ttf.post, fields,
            [
                'underlinePosition', 'underlineThickness'
            ]
        );
        return this.ttf.post;
    }


    /**
     * 计算度量信息
     *
     * @return {Object} 度量信息
     */
    calcMetrics() {
        let ascent = -16384;
        let descent = 16384;
        const uX = 0x78;
        const uH = 0x48;
        let sxHeight;
        let sCapHeight;
        this.ttf.glyf.forEach((g) => {

            if (g.yMax > ascent) {
                ascent = g.yMax;
            }

            if (g.yMin < descent) {
                descent = g.yMin;
            }

            if (g.unicode) {
                if (g.unicode.indexOf(uX) >= 0) {
                    sxHeight = g.yMax;
                }
                if (g.unicode.indexOf(uH) >= 0) {
                    sCapHeight = g.yMax;
                }
            }
        });

        ascent = Math.round(ascent);
        descent = Math.round(descent);

        return {

            // 此处非必须自动设置
            ascent,
            descent,
            sTypoAscender: ascent,
            sTypoDescender: descent,

            // 自动设置项目
            usWinAscent: ascent,
            usWinDescent: -descent,
            sxHeight: sxHeight || 0,
            sCapHeight: sCapHeight || 0
        };
    }


    /**
     * 优化ttf字形信息
     *
     * @return {Array} 改变的glyf
     */
    optimize() {
        return (0,_util_optimizettf__WEBPACK_IMPORTED_MODULE_7__.default)(this.ttf);
    }

    /**
     * 复合字形转简单字形
     *
     * @param {Array=} indexList 索引列表
     * @return {Array} 改变的glyf
     */
    compound2simple(indexList) {

        const ttf = this.ttf;
        if (ttf.maxp && !ttf.maxp.maxComponentElements) {
            return [];
        }

        let i;
        let l;
        // 全部的compound glyf
        if (!indexList || !indexList.length) {
            indexList = [];
            for (i = 0, l = ttf.glyf.length; i < l; ++i) {
                if (ttf.glyf[i].compound) {
                    indexList.push(i);
                }
            }
        }

        const list = [];
        for (i = 0, l = indexList.length; i < l; ++i) {
            const glyfIndex = indexList[i];
            if (ttf.glyf[glyfIndex] && ttf.glyf[glyfIndex].compound) {
                (0,_util_compound2simpleglyf__WEBPACK_IMPORTED_MODULE_5__.default)(glyfIndex, ttf, true);
                list.push(ttf.glyf[glyfIndex]);
            }
        }

        return list;
    }
}


/***/ }),
/* 12 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _enum_unicodeName__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(13);
/* harmony import */ var _enum_postName__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14);
/**
 * @file ttf字符串相关函数
 * @author mengke01(kekee000@gmail.com)
 *
 * references:
 * 1. svg2ttf @ github
 */




/**
 * 将unicode编码转换成js内部编码，
 * 有时候单子节的字符会编码成类似`\u0020`, 这里还原单字节
 *
 * @param {string} str str字符串
 * @return {string} 转换后字符串
 */
function stringify(str) {
    if (!str) {
        return str;
    }

    let newStr = '';
    for (let i = 0, l = str.length, ch; i < l; i++) {
        ch = str.charCodeAt(i);
        if (ch === 0) {
            continue;
        }
        newStr += String.fromCharCode(ch);
    }
    return newStr;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({

    stringify,

    /**
     * 将双字节编码字符转换成`\uxxxx`形式
     *
     * @param {string} str str字符串
     * @return {string} 转换后字符串
     */
    escape(str) {
        if (!str) {
            return str;
        }
        return String(str).replace(/[\uff-\uffff]/g, c => escape(c).replace('%', '\\'));
    },

    /**
     * bytes to string
     *
     * @param  {Array} bytes 字节数组
     * @return {string}       string
     */
    getString(bytes) {
        let s = '';
        for (let i = 0, l = bytes.length; i < l; i++) {
            s += String.fromCharCode(bytes[i]);
        }
        return s;
    },

    /**
     * 获取unicode的名字值
     *
     * @param {number} unicode unicode
     * @return {string} 名字
     */
    getUnicodeName(unicode) {
        const unicodeNameIndex = _enum_unicodeName__WEBPACK_IMPORTED_MODULE_0__.default[unicode];
        if (undefined !== unicodeNameIndex) {
            return _enum_postName__WEBPACK_IMPORTED_MODULE_1__.default[unicodeNameIndex];
        }

        return 'uni' + unicode.toString(16).toUpperCase();
    },

    /**
     * 转换成utf8的字节数组
     *
     * @param {string} str 字符串
     * @return {Array.<byte>} 字节数组
     */
    toUTF8Bytes(str) {
        str = stringify(str);
        const byteArray = [];
        for (let i = 0, l = str.length; i < l; i++) {
            if (str.charCodeAt(i) <= 0x7F) {
                byteArray.push(str.charCodeAt(i));
            }
            else {
                const codePoint = str.codePointAt(i);
                if (codePoint > 0xffff) {
                    i++;
                }
                const h = encodeURIComponent(String.fromCodePoint(codePoint)).slice(1).split('%');
                for (let j = 0; j < h.length; j++) {
                    byteArray.push(parseInt(h[j], 16));
                }
            }
        }
        return byteArray;
    },

    /**
     * 转换成usc2的字节数组
     *
     * @param {string} str 字符串
     * @return {Array.<byte>} 字节数组
     */
    toUCS2Bytes(str) {
        str = stringify(str);
        const byteArray = [];

        for (let i = 0, l = str.length, ch; i < l; i++) {
            ch = str.charCodeAt(i);
            byteArray.push(ch >> 8);
            byteArray.push(ch & 0xFF);
        }

        return byteArray;
    },


    /**
     * 获取pascal string 字节数组
     *
     * @param {string} str 字符串
     * @return {Array.<byte>} byteArray byte数组
     */
    toPascalStringBytes(str) {
        const bytes = [];
        const length = str ? (str.length < 256 ? str.length : 255) : 0;
        bytes.push(length);

        for (let i = 0, l = str.length; i < l; i++) {
            const c = str.charCodeAt(i);
            // non-ASCII characters are substituted with '*'
            bytes.push(c < 128 ? c : 42);
        }

        return bytes;
    },

    /**
     * utf8字节转字符串
     *
     * @param {Array} bytes 字节
     * @return {string} 字符串
     */
    getUTF8String(bytes) {
        let str = '';
        for (let i = 0, l = bytes.length; i < l; i++) {
            if (bytes[i] < 0x7F) {
                str += String.fromCharCode(bytes[i]);
            }
            else {
                str += '%' + (256 + bytes[i]).toString(16).slice(1);
            }
        }

        return unescape(str);
    },

    /**
     * ucs2字节转字符串
     *
     * @param {Array} bytes 字节
     * @return {string} 字符串
     */
    getUCS2String(bytes) {
        let str = '';
        for (let i = 0, l = bytes.length; i < l; i += 2) {
            str += String.fromCharCode((bytes[i] << 8) + bytes[i + 1]);
        }
        return str;
    },

    /**
     * 读取 pascal string
     *
     * @param {Array.<byte>} byteArray byte数组
     * @return {Array.<string>} 读取后的字符串数组
     */
    getPascalString(byteArray) {
        const strArray = [];
        let i = 0;
        const l = byteArray.length;

        while (i < l) {
            let strLength = byteArray[i++];
            let str = '';

            while (strLength-- > 0 && i < l) {
                str += String.fromCharCode(byteArray[i++]);
            }
            // 这里需要将unicode转换成js编码
            str = stringify(str);
            strArray.push(str);
        }

        return strArray;
    }
});


/***/ }),
/* 13 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file unicode 编码与postName对照表
 * @author mengke01(kekee000@gmail.com)
 *
 * see:
 * http://www.microsoft.com/typography/otspec/WGL4.htm
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    0: 1,
    1: 1,
    2: 1,
    3: 1,
    4: 1,
    5: 1,
    6: 1,
    7: 1,
    8: 1,
    9: 2,
    10: 1,
    11: 1,
    12: 1,
    13: 2,
    14: 1,
    15: 1,
    16: 1,
    17: 1,
    18: 1,
    19: 1,
    20: 1,
    21: 1,
    22: 1,
    23: 1,
    24: 1,
    25: 1,
    26: 1,
    27: 1,
    28: 1,
    29: 1,
    30: 1,
    31: 1,
    32: 3,
    33: 4,
    34: 5,
    35: 6,
    36: 7,
    37: 8,
    38: 9,
    39: 10,
    40: 11,
    41: 12,
    42: 13,
    43: 14,
    44: 15,
    45: 16,
    46: 17,
    47: 18,
    48: 19,
    49: 20,
    50: 21,
    51: 22,
    52: 23,
    53: 24,
    54: 25,
    55: 26,
    56: 27,
    57: 28,
    58: 29,
    59: 30,
    60: 31,
    61: 32,
    62: 33,
    63: 34,
    64: 35,
    65: 36,
    66: 37,
    67: 38,
    68: 39,
    69: 40,
    70: 41,
    71: 42,
    72: 43,
    73: 44,
    74: 45,
    75: 46,
    76: 47,
    77: 48,
    78: 49,
    79: 50,
    80: 51,
    81: 52,
    82: 53,
    83: 54,
    84: 55,
    85: 56,
    86: 57,
    87: 58,
    88: 59,
    89: 60,
    90: 61,
    91: 62,
    92: 63,
    93: 64,
    94: 65,
    95: 66,
    96: 67,
    97: 68,
    98: 69,
    99: 70,
    100: 71,
    101: 72,
    102: 73,
    103: 74,
    104: 75,
    105: 76,
    106: 77,
    107: 78,
    108: 79,
    109: 80,
    110: 81,
    111: 82,
    112: 83,
    113: 84,
    114: 85,
    115: 86,
    116: 87,
    117: 88,
    118: 89,
    119: 90,
    120: 91,
    121: 92,
    122: 93,
    123: 94,
    124: 95,
    125: 96,
    126: 97,
    160: 172,
    161: 163,
    162: 132,
    163: 133,
    164: 189,
    165: 150,
    166: 232,
    167: 134,
    168: 142,
    169: 139,
    170: 157,
    171: 169,
    172: 164,
    174: 138,
    175: 218,
    176: 131,
    177: 147,
    178: 242,
    179: 243,
    180: 141,
    181: 151,
    182: 136,
    184: 222,
    185: 241,
    186: 158,
    187: 170,
    188: 245,
    189: 244,
    190: 246,
    191: 162,
    192: 173,
    193: 201,
    194: 199,
    195: 174,
    196: 98,
    197: 99,
    198: 144,
    199: 100,
    200: 203,
    201: 101,
    202: 200,
    203: 202,
    204: 207,
    205: 204,
    206: 205,
    207: 206,
    208: 233,
    209: 102,
    210: 211,
    211: 208,
    212: 209,
    213: 175,
    214: 103,
    215: 240,
    216: 145,
    217: 214,
    218: 212,
    219: 213,
    220: 104,
    221: 235,
    222: 237,
    223: 137,
    224: 106,
    225: 105,
    226: 107,
    227: 109,
    228: 108,
    229: 110,
    230: 160,
    231: 111,
    232: 113,
    233: 112,
    234: 114,
    235: 115,
    236: 117,
    237: 116,
    238: 118,
    239: 119,
    240: 234,
    241: 120,
    242: 122,
    243: 121,
    244: 123,
    245: 125,
    246: 124,
    247: 184,
    248: 161,
    249: 127,
    250: 126,
    251: 128,
    252: 129,
    253: 236,
    254: 238,
    255: 186,
    262: 253,
    263: 254,
    268: 255,
    269: 256,
    273: 257,
    286: 248,
    287: 249,
    304: 250,
    305: 215,
    321: 226,
    322: 227,
    338: 176,
    339: 177,
    350: 251,
    351: 252,
    352: 228,
    353: 229,
    376: 187,
    381: 230,
    382: 231,
    402: 166,
    710: 216,
    711: 225,
    728: 219,
    729: 220,
    730: 221,
    731: 224,
    733: 223,
    960: 155,
    8211: 178,
    8212: 179,
    8216: 182,
    8217: 183,
    8218: 196,
    8220: 180,
    8221: 181,
    8222: 197,
    8224: 130,
    8225: 194,
    8226: 135,
    8230: 171,
    8240: 198,
    8249: 190,
    8250: 191,
    8355: 247,
    8482: 140,
    8486: 159,
    8706: 152,
    8710: 168,
    8719: 154,
    8721: 153,
    8722: 239,
    8725: 188,
    8729: 195,
    8730: 165,
    8734: 146,
    8747: 156,
    8776: 167,
    8800: 143,
    8804: 148,
    8805: 149,
    9674: 185,
    61441: 192,
    61442: 193,
    64257: 192,
    64258: 193,
    65535: 0 // 0xFFFF指向.notdef
});


/***/ }),
/* 14 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file Mac glyf命名表
 * @author mengke01(kekee000@gmail.com)
 *
 * see:
 * http://www.microsoft.com/typography/otspec/WGL4.htm
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    0: '.notdef',
    1: '.null',
    2: 'nonmarkingreturn',
    3: 'space',
    4: 'exclam',
    5: 'quotedbl',
    6: 'numbersign',
    7: 'dollar',
    8: 'percent',
    9: 'ampersand',
    10: 'quotesingle',
    11: 'parenleft',
    12: 'parenright',
    13: 'asterisk',
    14: 'plus',
    15: 'comma',
    16: 'hyphen',
    17: 'period',
    18: 'slash',
    19: 'zero',
    20: 'one',
    21: 'two',
    22: 'three',
    23: 'four',
    24: 'five',
    25: 'six',
    26: 'seven',
    27: 'eight',
    28: 'nine',
    29: 'colon',
    30: 'semicolon',
    31: 'less',
    32: 'equal',
    33: 'greater',
    34: 'question',
    35: 'at',
    36: 'A',
    37: 'B',
    38: 'C',
    39: 'D',
    40: 'E',
    41: 'F',
    42: 'G',
    43: 'H',
    44: 'I',
    45: 'J',
    46: 'K',
    47: 'L',
    48: 'M',
    49: 'N',
    50: 'O',
    51: 'P',
    52: 'Q',
    53: 'R',
    54: 'S',
    55: 'T',
    56: 'U',
    57: 'V',
    58: 'W',
    59: 'X',
    60: 'Y',
    61: 'Z',
    62: 'bracketleft',
    63: 'backslash',
    64: 'bracketright',
    65: 'asciicircum',
    66: 'underscore',
    67: 'grave',
    68: 'a',
    69: 'b',
    70: 'c',
    71: 'd',
    72: 'e',
    73: 'f',
    74: 'g',
    75: 'h',
    76: 'i',
    77: 'j',
    78: 'k',
    79: 'l',
    80: 'm',
    81: 'n',
    82: 'o',
    83: 'p',
    84: 'q',
    85: 'r',
    86: 's',
    87: 't',
    88: 'u',
    89: 'v',
    90: 'w',
    91: 'x',
    92: 'y',
    93: 'z',
    94: 'braceleft',
    95: 'bar',
    96: 'braceright',
    97: 'asciitilde',
    98: 'Adieresis',
    99: 'Aring',
    100: 'Ccedilla',
    101: 'Eacute',
    102: 'Ntilde',
    103: 'Odieresis',
    104: 'Udieresis',
    105: 'aacute',
    106: 'agrave',
    107: 'acircumflex',
    108: 'adieresis',
    109: 'atilde',
    110: 'aring',
    111: 'ccedilla',
    112: 'eacute',
    113: 'egrave',
    114: 'ecircumflex',
    115: 'edieresis',
    116: 'iacute',
    117: 'igrave',
    118: 'icircumflex',
    119: 'idieresis',
    120: 'ntilde',
    121: 'oacute',
    122: 'ograve',
    123: 'ocircumflex',
    124: 'odieresis',
    125: 'otilde',
    126: 'uacute',
    127: 'ugrave',
    128: 'ucircumflex',
    129: 'udieresis',
    130: 'dagger',
    131: 'degree',
    132: 'cent',
    133: 'sterling',
    134: 'section',
    135: 'bullet',
    136: 'paragraph',
    137: 'germandbls',
    138: 'registered',
    139: 'copyright',
    140: 'trademark',
    141: 'acute',
    142: 'dieresis',
    143: 'notequal',
    144: 'AE',
    145: 'Oslash',
    146: 'infinity',
    147: 'plusminus',
    148: 'lessequal',
    149: 'greaterequal',
    150: 'yen',
    151: 'mu',
    152: 'partialdiff',
    153: 'summation',
    154: 'product',
    155: 'pi',
    156: 'integral',
    157: 'ordfeminine',
    158: 'ordmasculine',
    159: 'Omega',
    160: 'ae',
    161: 'oslash',
    162: 'questiondown',
    163: 'exclamdown',
    164: 'logicalnot',
    165: 'radical',
    166: 'florin',
    167: 'approxequal',
    168: 'Delta',
    169: 'guillemotleft',
    170: 'guillemotright',
    171: 'ellipsis',
    172: 'nonbreakingspace',
    173: 'Agrave',
    174: 'Atilde',
    175: 'Otilde',
    176: 'OE',
    177: 'oe',
    178: 'endash',
    179: 'emdash',
    180: 'quotedblleft',
    181: 'quotedblright',
    182: 'quoteleft',
    183: 'quoteright',
    184: 'divide',
    185: 'lozenge',
    186: 'ydieresis',
    187: 'Ydieresis',
    188: 'fraction',
    189: 'currency',
    190: 'guilsinglleft',
    191: 'guilsinglright',
    192: 'fi',
    193: 'fl',
    194: 'daggerdbl',
    195: 'periodcentered',
    196: 'quotesinglbase',
    197: 'quotedblbase',
    198: 'perthousand',
    199: 'Acircumflex',
    200: 'Ecircumflex',
    201: 'Aacute',
    202: 'Edieresis',
    203: 'Egrave',
    204: 'Iacute',
    205: 'Icircumflex',
    206: 'Idieresis',
    207: 'Igrave',
    208: 'Oacute',
    209: 'Ocircumflex',
    210: 'apple',
    211: 'Ograve',
    212: 'Uacute',
    213: 'Ucircumflex',
    214: 'Ugrave',
    215: 'dotlessi',
    216: 'circumflex',
    217: 'tilde',
    218: 'macron',
    219: 'breve',
    220: 'dotaccent',
    221: 'ring',
    222: 'cedilla',
    223: 'hungarumlaut',
    224: 'ogonek',
    225: 'caron',
    226: 'Lslash',
    227: 'lslash',
    228: 'Scaron',
    229: 'scaron',
    230: 'Zcaron',
    231: 'zcaron',
    232: 'brokenbar',
    233: 'Eth',
    234: 'eth',
    235: 'Yacute',
    236: 'yacute',
    237: 'Thorn',
    238: 'thorn',
    239: 'minus',
    240: 'multiply',
    241: 'onesuperior',
    242: 'twosuperior',
    243: 'threesuperior',
    244: 'onehalf',
    245: 'onequarter',
    246: 'threequarters',
    247: 'franc',
    248: 'Gbreve',
    249: 'gbreve',
    250: 'Idotaccent',
    251: 'Scedilla',
    252: 'scedilla',
    253: 'Cacute',
    254: 'cacute',
    255: 'Ccaron',
    256: 'ccaron',
    257: 'dcroat'
});


/***/ }),
/* 15 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ pathAdjust)
/* harmony export */ });
/**
 * @file 调整路径缩放和平移
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 对path坐标进行调整
 *
 * @param {Object} contour 坐标点
 * @param {number} scaleX x缩放比例
 * @param {number} scaleY y缩放比例
 * @param {number} offsetX x偏移
 * @param {number} offsetY y偏移
 *
 * @return {Object} contour 坐标点
 */
function pathAdjust(contour, scaleX, scaleY, offsetX, offsetY) {
    scaleX = scaleX === undefined ? 1 : scaleX;
    scaleY = scaleY === undefined ? 1 : scaleY;
    const x = offsetX || 0;
    const y = offsetY || 0;
    let p;
    for (let i = 0, l = contour.length; i < l; i++) {
        p = contour[i];
        p.x = scaleX * (p.x + x);
        p.y = scaleY * (p.y + y);
    }
    return contour;
}


/***/ }),
/* 16 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ pathCeil)
/* harmony export */ });
/**
 * @file 对路径进行四舍五入
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 对path坐标进行调整
 *
 * @param {Array} contour 轮廓点数组
 * @param {number} point 四舍五入的点数
 * @return {Object} contour 坐标点
 */
function pathCeil(contour, point) {
    let p;
    for (let i = 0, l = contour.length; i < l; i++) {
        p = contour[i];
        if (!point) {
            p.x = Math.round(p.x);
            p.y = Math.round(p.y);
        }
        else {
            p.x = Number(p.x.toFixed(point));
            p.y = Number(p.y.toFixed(point));
        }
    }
    return contour;
}


/***/ }),
/* 17 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "computePathBox": () => (/* binding */ computePathBox),
/* harmony export */   "computeBounding": () => (/* binding */ computeBounding),
/* harmony export */   "quadraticBezier": () => (/* binding */ quadraticBezier),
/* harmony export */   "computePath": () => (/* binding */ computePath)
/* harmony export */ });
/* harmony import */ var _pathIterator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18);
/**
 * @file 计算曲线包围盒
 * @author mengke01(kekee000@gmail.com)
 *
 * modify from:
 * zrender
 * https://github.com/ecomfe/zrender/blob/master/src/tool/computeBoundingBox.js
 */


/**
 * 计算包围盒
 *
 * @param {Array} points 点集
 * @return {Object} bounding box
 */
function computeBoundingBox(points) {

    if (points.length === 0) {
        return false;
    }

    let left = points[0].x;
    let right = points[0].x;
    let top = points[0].y;
    let bottom = points[0].y;

    for (let i = 1; i < points.length; i++) {
        const p = points[i];

        if (p.x < left) {
            left = p.x;
        }

        if (p.x > right) {
            right = p.x;
        }

        if (p.y < top) {
            top = p.y;
        }

        if (p.y > bottom) {
            bottom = p.y;
        }
    }

    return {
        x: left,
        y: top,
        width: right - left,
        height: bottom - top
    };
}

/**
 * 计算二阶贝塞尔曲线的包围盒
 * http://pissang.net/blog/?p=91
 *
 * @param {Object} p0 p0
 * @param {Object} p1 p1
 * @param {Object} p2 p2
 * @return {Object} bound对象
 */
function computeQuadraticBezierBoundingBox(p0, p1, p2) {
    // Find extremities, where derivative in x dim or y dim is zero
    let tmp = (p0.x + p2.x - 2 * p1.x);
    // p1 is center of p0 and p2 in x dim
    let t1;
    if (tmp === 0) {
        t1 = 0.5;
    }
    else {
        t1 = (p0.x - p1.x) / tmp;
    }

    tmp = (p0.y + p2.y - 2 * p1.y);
    // p1 is center of p0 and p2 in y dim
    let t2;
    if (tmp === 0) {
        t2 = 0.5;
    }
    else {
        t2 = (p0.y - p1.y) / tmp;
    }

    t1 = Math.max(Math.min(t1, 1), 0);
    t2 = Math.max(Math.min(t2, 1), 0);

    const ct1 = 1 - t1;
    const ct2 = 1 - t2;

    const x1 = ct1 * ct1 * p0.x + 2 * ct1 * t1 * p1.x + t1 * t1 * p2.x;
    const y1 = ct1 * ct1 * p0.y + 2 * ct1 * t1 * p1.y + t1 * t1 * p2.y;

    const x2 = ct2 * ct2 * p0.x + 2 * ct2 * t2 * p1.x + t2 * t2 * p2.x;
    const y2 = ct2 * ct2 * p0.y + 2 * ct2 * t2 * p1.y + t2 * t2 * p2.y;

    return computeBoundingBox(
        [
            p0,
            p2,
            {
                x: x1,
                y: y1
            },
            {
                x: x2,
                y: y2
            }
        ]
    );
}

/**
 * 计算曲线包围盒
 *
 * @private
 * @param {...Array} args 坐标点集, 支持多个path
 * @return {Object} {x, y, width, height}
 */
function computePathBoundingBox(...args) {

    const points = [];
    const iterator = function (c, p0, p1, p2) {
        if (c === 'L') {
            points.push(p0);
            points.push(p1);
        }
        else if (c === 'Q') {
            const bound = computeQuadraticBezierBoundingBox(p0, p1, p2);

            points.push(bound);
            points.push({
                x: bound.x + bound.width,
                y: bound.y + bound.height
            });
        }
    };

    if (args.length === 1) {
        (0,_pathIterator__WEBPACK_IMPORTED_MODULE_0__.default)(args[0], (c, p0, p1, p2) => {
            if (c === 'L') {
                points.push(p0);
                points.push(p1);
            }
            else if (c === 'Q') {
                const bound = computeQuadraticBezierBoundingBox(p0, p1, p2);

                points.push(bound);
                points.push({
                    x: bound.x + bound.width,
                    y: bound.y + bound.height
                });
            }
        });
    }
    else {
        for (let i = 0, l = args.length; i < l; i++) {
            (0,_pathIterator__WEBPACK_IMPORTED_MODULE_0__.default)(args[i], iterator);
        }
    }

    return computeBoundingBox(points);
}


/**
 * 计算曲线点边界
 *
 * @private
 * @param {...Array} args path对象, 支持多个path
 * @return {Object} {x, y, width, height}
 */
function computePathBox(...args) {
    let points = [];
    if (args.length === 1) {
        points = args[0];
    }
    else {
        for (let i = 0, l = args.length; i < l; i++) {
            Array.prototype.splice.apply(points, [points.length, 0].concat(args[i]));
        }
    }
    return computeBoundingBox(points);
}

const computeBounding = computeBoundingBox;
const quadraticBezier = computeQuadraticBezierBoundingBox;
const computePath = computePathBoundingBox;


/***/ }),
/* 18 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ pathIterator)
/* harmony export */ });
/**
 * @file 遍历路径的路径集合，包括segment和 bezier curve
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 遍历路径的路径集合
 *
 * @param {Array} contour 坐标点集
 * @param {Function} callBack 回调函数，参数集合：command, p0, p1, p2, i
 * p0, p1, p2 直线或者贝塞尔曲线参数
 * i 当前遍历的点
 * 其中command = L 或者 Q，表示直线或者贝塞尔曲线
 */
function pathIterator(contour, callBack) {

    let curPoint;
    let prevPoint;
    let nextPoint;
    let cursorPoint; // cursorPoint 为当前单个绘制命令的起点

    for (let i = 0, l = contour.length; i < l; i++) {
        curPoint = contour[i];
        prevPoint = i === 0 ? contour[l - 1] : contour[i - 1];
        nextPoint = i === l - 1 ? contour[0] : contour[i + 1];

        // 起始坐标
        if (i === 0) {
            if (curPoint.onCurve) {
                cursorPoint = curPoint;
            }
            else if (prevPoint.onCurve) {
                cursorPoint = prevPoint;
            }
            else {
                cursorPoint = {
                    x: (prevPoint.x + curPoint.x) / 2,
                    y: (prevPoint.y + curPoint.y) / 2
                };
            }

        }

        // 直线
        if (curPoint.onCurve && nextPoint.onCurve) {
            if (false === callBack('L', curPoint, nextPoint, 0, i)) {
                break;
            }
            cursorPoint = nextPoint;
        }
        else if (!curPoint.onCurve) {

            if (nextPoint.onCurve) {
                if (false === callBack('Q', cursorPoint, curPoint, nextPoint, i)) {
                    break;
                }
                cursorPoint = nextPoint;
            }
            else {
                const last = {
                    x: (curPoint.x + nextPoint.x) / 2,
                    y: (curPoint.y + nextPoint.y) / 2
                };
                if (false === callBack('Q', cursorPoint, curPoint, last, i)) {
                    break;
                }
                cursorPoint = last;
            }
        }
    }
}


/***/ }),
/* 19 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ compound2simpleglyf)
/* harmony export */ });
/* harmony import */ var _transformGlyfContours__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20);
/* harmony import */ var _compound2simple__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(22);
/**
 * @file ttf复合字形转简单字形
 * @author mengke01(kekee000@gmail.com)
 */





/**
 * ttf复合字形转简单字形
 *
 * @param  {Object|number} glyf glyf对象或者glyf索引
 * @param  {Object} ttf ttfObject对象
 * @param  {boolean} recrusive 是否递归的进行转换，如果复合字形为嵌套字形，则转换每一个复合字形
 * @return {Object} 转换后的对象
 */
function compound2simpleglyf(glyf, ttf, recrusive) {

    let glyfIndex;
    // 兼容索引和对象传入
    if (typeof glyf === 'number') {
        glyfIndex = glyf;
        glyf = ttf.glyf[glyfIndex];
    }
    else {
        glyfIndex = ttf.glyf.indexOf(glyf);
        if (-1 === glyfIndex) {
            return glyf;
        }
    }

    if (!glyf.compound || !glyf.glyfs) {
        return glyf;
    }

    const contoursList = {};
    (0,_transformGlyfContours__WEBPACK_IMPORTED_MODULE_0__.default)(glyf, ttf, contoursList, glyfIndex);

    if (recrusive) {
        Object.keys(contoursList).forEach((index) => {
            (0,_compound2simple__WEBPACK_IMPORTED_MODULE_1__.default)(ttf.glyf[index], contoursList[index]);
        });
    }
    else {
        (0,_compound2simple__WEBPACK_IMPORTED_MODULE_1__.default)(glyf, contoursList[glyfIndex]);
    }

    return glyf;
}


/***/ }),
/* 20 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ transformGlyfContours)
/* harmony export */ });
/* harmony import */ var _graphics_pathCeil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16);
/* harmony import */ var _graphics_pathTransform__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21);
/* harmony import */ var _common_lang__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8);
/**
 * @file 转换复合字形的contours，以便于显示
 * @author mengke01(kekee000@gmail.com)
 */






/**
 * 转换复合字形轮廓，结果保存在contoursList中，并返回当前glyf的轮廓
 *
 * @param  {Object} glyf glyf对象
 * @param  {Object} ttf ttfObject对象
 * @param  {Object=} contoursList 保存转换中间生成的contours
 * @param  {number} glyfIndex glyf对象当前的index
 * @return {Array} 转换后的轮廓
 */
function transformGlyfContours(glyf, ttf, contoursList = {}, glyfIndex) {

    if (!glyf.glyfs) {
        return glyf;
    }

    const compoundContours = [];
    glyf.glyfs.forEach(g => {
        const glyph = ttf.glyf[g.glyphIndex];

        if (!glyph || glyph === glyf) {
            return;
        }

        // 递归转换contours
        if (glyph.compound && !contoursList[g.glyphIndex]) {
            transformGlyfContours(glyph, ttf, contoursList, g.glyphIndex);
        }

        // 这里需要进行matrix变换，需要复制一份
        const contours = (0,_common_lang__WEBPACK_IMPORTED_MODULE_2__.clone)(glyph.compound ? (contoursList[g.glyphIndex] || []) : glyph.contours);
        const transform = g.transform;
        for (let i = 0, l = contours.length; i < l; i++) {
            (0,_graphics_pathTransform__WEBPACK_IMPORTED_MODULE_1__.default)(
                contours[i],
                transform.a,
                transform.b,
                transform.c,
                transform.d,
                transform.e,
                transform.f
            );
            compoundContours.push((0,_graphics_pathCeil__WEBPACK_IMPORTED_MODULE_0__.default)(contours[i]));
        }
    });

    // eslint-disable-next-line eqeqeq
    if (null != glyfIndex) {
        contoursList[glyfIndex] = compoundContours;
    }

    return compoundContours;
}


/***/ }),
/* 21 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ transform)
/* harmony export */ });
/**
 * @file 对轮廓进行transform变换
 * @author mengke01(kekee000@gmail.com)
 *
 * 参考资料：
 * http://blog.csdn.net/henren555/article/details/9699449
 *
 *  |X|    |a      c       e|    |x|
 *  |Y| =  |b      d       f| *  |y|
 *  |1|    |0      0       1|    |1|
 *
 *  X = x * a + y * c + e
 *  Y = x * b + y * d + f
 */

/**
 * 图形仿射矩阵变换
 *
 * @param {Array.<Object>} contour 轮廓点
 * @param {number} a m11
 * @param {number} b m12
 * @param {number} c m21
 * @param {number} d m22
 * @param {number} e dx
 * @param {number} f dy
 * @return {Array.<Object>} contour 轮廓点
 */
function transform(contour, a, b, c, d, e, f) {
    let x;
    let y;
    let p;
    for (let i = 0, l = contour.length; i < l; i++) {
        p = contour[i];
        x = p.x;
        y = p.y;
        p.x = x * a + y * c + e;
        p.y = x * b + y * d + f;
    }
    return contour;
}


/***/ }),
/* 22 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ compound2simple)
/* harmony export */ });
/**
 * @file 复合字形设置轮廓，转化为简单字形
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 复合字形转简单字形
 *
 * @param  {Object} glyf glyf对象
 * @param  {Array} contours 轮廓数组
 * @return {Object} 转换后对象
 */
function compound2simple(glyf, contours) {
    glyf.contours = contours;
    delete glyf.compound;
    delete glyf.glyfs;
    // 这里hinting信息会失效，删除hinting信息
    delete glyf.instructions;
    return glyf;
}


/***/ }),
/* 23 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ glyfAdjust)
/* harmony export */ });
/* harmony import */ var _graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15);
/* harmony import */ var _graphics_pathCeil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16);
/* harmony import */ var _graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17);
/**
 * @file glyf的缩放和平移调整
 * @author mengke01(kekee000@gmail.com)
 */






/**
 * 简单字形的缩放和平移调整
 *
 * @param {Object} g glyf对象
 * @param {number} scaleX x缩放比例
 * @param {number} scaleY y缩放比例
 * @param {number} offsetX x偏移
 * @param {number} offsetY y偏移
 * @param {boolan} useCeil 是否对字形设置取整，默认取整
 *
 * @return {Object} 调整后的glyf对象
 */
function glyfAdjust(g, scaleX = 1, scaleY = 1, offsetX = 0, offsetY = 0, useCeil = true) {

    if (g.contours && g.contours.length) {
        if (scaleX !== 1 || scaleY !== 1) {
            g.contours.forEach((contour) => {
                (0,_graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_0__.default)(contour, scaleX, scaleY);
            });
        }

        if (offsetX !== 0 || offsetY !== 0) {
            g.contours.forEach((contour) => {
                (0,_graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_0__.default)(contour, 1, 1, offsetX, offsetY);
            });
        }

        if (false !== useCeil) {
            g.contours.forEach((contour) => {
                (0,_graphics_pathCeil__WEBPACK_IMPORTED_MODULE_1__.default)(contour);
            });
        }
    }

    // 重新计算xmin，xmax，ymin，ymax
    const advanceWidth = g.advanceWidth;
    if (
        undefined === g.xMin
        || undefined === g.yMax
        || undefined === g.leftSideBearing
        || undefined === g.advanceWidth
    ) {
        // 有的字形没有形状，需要特殊处理一下
        let bound;
        if (g.contours && g.contours.length) {
            // eslint-disable-next-line no-invalid-this
            bound = _graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_2__.computePathBox.apply(this, g.contours);
        }
        else {
            bound = {
                x: 0,
                y: 0,
                width: 0,
                height: 0
            };
        }

        g.xMin = bound.x;
        g.xMax = bound.x + bound.width;
        g.yMin = bound.y;
        g.yMax = bound.y + bound.height;

        g.leftSideBearing = g.xMin;

        // 如果设置了advanceWidth就是用默认的，否则为xMax + abs(xMin)
        if (undefined !== advanceWidth) {
            g.advanceWidth = Math.round(advanceWidth * scaleX + offsetX);
        }
        else {
            g.advanceWidth = g.xMax + Math.abs(g.xMin);
        }
    }
    else {
        g.xMin = Math.round(g.xMin * scaleX + offsetX);
        g.xMax = Math.round(g.xMax * scaleX + offsetX);
        g.yMin = Math.round(g.yMin * scaleY + offsetY);
        g.yMax = Math.round(g.yMax * scaleY + offsetY);
        g.leftSideBearing = Math.round(g.leftSideBearing * scaleX + offsetX);
        g.advanceWidth = Math.round(advanceWidth * scaleX + offsetX);
    }

    return g;
}


/***/ }),
/* 24 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ optimizettf)
/* harmony export */ });
/* harmony import */ var _reduceGlyf__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25);
/* harmony import */ var _graphics_pathCeil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16);
/**
 * @file 对ttf对象进行优化，查找错误，去除冗余点
 * @author mengke01(kekee000@gmail.com)
 */




/**
 * 对ttf对象进行优化
 *
 * @param  {Object} ttf ttf对象
 * @return {true|Object} 错误信息
 */
function optimizettf(ttf) {

    const checkUnicodeRepeat = {}; // 检查是否有重复代码点
    const repeatList = [];

    ttf.glyf.forEach((glyf, index) => {
        if (glyf.unicode) {
            glyf.unicode = glyf.unicode.sort();

            // 将glyf的代码点按小到大排序
            glyf.unicode.sort((a, b) => a - b).forEach((u) => {
                if (checkUnicodeRepeat[u]) {
                    repeatList.push(index);
                }
                else {
                    checkUnicodeRepeat[u] = true;
                }
            });

        }

        if (!glyf.compound && glyf.contours) {
            // 整数化
            glyf.contours.forEach((contour) => {
                (0,_graphics_pathCeil__WEBPACK_IMPORTED_MODULE_1__.default)(contour);
            });
            // 缩减glyf
            (0,_reduceGlyf__WEBPACK_IMPORTED_MODULE_0__.default)(glyf);
        }

        // 整数化
        glyf.xMin = Math.round(glyf.xMin || 0);
        glyf.xMax = Math.round(glyf.xMax || 0);
        glyf.yMin = Math.round(glyf.yMin || 0);
        glyf.yMax = Math.round(glyf.yMax || 0);
        glyf.leftSideBearing = Math.round(glyf.leftSideBearing || 0);
        glyf.advanceWidth = Math.round(glyf.advanceWidth || 0);
    });

    // 过滤无轮廓字体，如果存在复合字形不进行过滤
    if (!ttf.glyf.some((a) => a.compound)) {
        ttf.glyf = ttf.glyf.filter((glyf, index) => index === 0 || glyf.contours && glyf.contours.length);
    }

    if (!repeatList.length) {
        return true;
    }

    return {
        repeat: repeatList
    };
}


/***/ }),
/* 25 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ reduceGlyf)
/* harmony export */ });
/* harmony import */ var _graphics_reducePath__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(26);
/**
 * @file 缩减glyf大小，去除冗余节点
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * 缩减glyf，去除冗余节点
 *
 * @param {Object} glyf glyf对象
 * @return {Object} glyf对象
 */
function reduceGlyf(glyf) {

    const contours = glyf.contours;
    let contour;
    for (let j = contours.length - 1; j >= 0; j--) {
        contour = (0,_graphics_reducePath__WEBPACK_IMPORTED_MODULE_0__.default)(contours[j]);

        // 空轮廓
        if (contour.length <= 2) {
            contours.splice(j, 1);
            continue;
        }
    }

    if (0 === glyf.contours.length) {
        delete glyf.contours;
    }

    return glyf;
}


/***/ }),
/* 26 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ reducePath)
/* harmony export */ });
/**
 * @file 缩减path大小，去除冗余节点
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 判断点是否多余的点
 *
 * @param {Object} prev 上一个
 * @param {Object} p 当前
 * @param {Object} next 下一个
 * @return {boolean}
 */
function redundant(prev, p, next) {

    // 是否重合的点, 只有两个点同在曲线上或者同不在曲线上移出
    if (
        (p.onCurve && next.onCurve || !p.onCurve && !next.onCurve)
        && Math.pow(p.x - next.x, 2) + Math.pow(p.y - next.y, 2) <= 1
    ) {
        return true;
    }

    // 三点同线 检查直线点
    if (
        (p.onCurve && prev.onCurve && next.onCurve)
        && Math.abs((next.y - p.y) * (prev.x - p.x) - (prev.y - p.y) * (next.x - p.x)) <= 0.001
    ) {
        return true;
    }

    // 三点同线 检查控制点
    if (
        (!p.onCurve && prev.onCurve && next.onCurve)
        && Math.abs((next.y - p.y) * (prev.x - p.x) - (prev.y - p.y) * (next.x - p.x)) <= 0.001
    ) {
        return true;
    }

    return false;
}

/**
 * 缩减glyf，去除冗余节点
 *
 * @param {Array} contour 路径对象
 * @return {Array} 路径对象
 */
function reducePath(contour) {

    if (!contour.length) {
        return contour;
    }

    let prev;
    let next;
    let p;
    for (let i = contour.length - 1, last = i; i >= 0; i--) {

        // 这里注意逆序
        p = contour[i];
        next = i === last ? contour[0] : contour[i + 1];
        prev = i === 0 ? contour[last] : contour[i - 1];

        if (redundant(prev, p, next)) {
            contour.splice(i, 1);
            last--;
            continue;
        }
    }

    return contour;
}


/***/ }),
/* 27 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ woff2ttf)
/* harmony export */ });
/* harmony import */ var _reader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(28);
/* harmony import */ var _writer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(33);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(29);
/**
 * @file woff转换ttf
 * @author mengke01(kekee000@gmail.com)
 */





/**
 * woff格式转换成ttf字体格式
 *
 * @param {ArrayBuffer} woffBuffer woff缓冲数组
 * @param {Object} options 选项
 * @param {Object} options.inflate 解压相关函数
 *
 * @return {ArrayBuffer} ttf格式byte流
 */
function woff2ttf(woffBuffer, options = {}) {
    const reader = new _reader__WEBPACK_IMPORTED_MODULE_0__.default(woffBuffer);
    const signature = reader.readUint32(0);
    const flavor = reader.readUint32(4);

    if (signature !== 0x774F4646 || (flavor !== 0x10000 && flavor !== 0x4f54544f)) {
        reader.dispose();
        _error__WEBPACK_IMPORTED_MODULE_2__.default.raise(10102);
    }

    const numTables = reader.readUint16(12);
    const ttfSize =  reader.readUint32(16);
    const tableEntries = [];
    let tableEntry;
    let i;
    let l;

    // 读取woff表索引信息
    for (i = 0; i < numTables; ++i) {
        reader.seek(44 + i * 20);
        tableEntry = {
            tag: reader.readString(reader.offset, 4),
            offset: reader.readUint32(),
            compLength: reader.readUint32(),
            length: reader.readUint32(),
            checkSum: reader.readUint32()
        };

        // ttf 表数据
        const deflateData = reader.readBytes(tableEntry.offset, tableEntry.compLength);
        // 需要解压
        if (deflateData.length < tableEntry.length) {

            if (!options.inflate) {
                reader.dispose();
                _error__WEBPACK_IMPORTED_MODULE_2__.default.raise(10105);
            }

            tableEntry.data = options.inflate(deflateData);
        }
        else {
            tableEntry.data = deflateData;
        }

        tableEntry.length = tableEntry.data.length;
        tableEntries.push(tableEntry);
    }


    const writer = new _writer__WEBPACK_IMPORTED_MODULE_1__.default(new ArrayBuffer(ttfSize));
    // 写头部
    const entrySelector = Math.floor(Math.log(numTables) / Math.LN2);
    const searchRange = Math.pow(2, entrySelector) * 16;
    const rangeShift = numTables * 16 - searchRange;

    writer.writeUint32(flavor);
    writer.writeUint16(numTables);
    writer.writeUint16(searchRange);
    writer.writeUint16(entrySelector);
    writer.writeUint16(rangeShift);

    // 写ttf表索引
    let tblOffset = 12 + 16 * tableEntries.length;
    for (i = 0, l = tableEntries.length; i < l; ++i) {
        tableEntry = tableEntries[i];
        writer.writeString(tableEntry.tag);
        writer.writeUint32(tableEntry.checkSum);
        writer.writeUint32(tblOffset);
        writer.writeUint32(tableEntry.length);
        tblOffset += tableEntry.length
            + (tableEntry.length % 4 ? 4 - tableEntry.length % 4 : 0);
    }

    // 写ttf表数据
    for (i = 0, l = tableEntries.length; i < l; ++i) {
        tableEntry = tableEntries[i];
        writer.writeBytes(tableEntry.data);
        if (tableEntry.length % 4) {
            writer.writeEmpty(4 - tableEntry.length % 4);
        }
    }

    return writer.getBuffer();
}


/***/ }),
/* 28 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Reader)
/* harmony export */ });
/* harmony import */ var _common_lang__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29);
/**
 * @file 数据读取器
 * @author mengke01(kekee000@gmail.com)
 *
 * thanks to：
 * ynakajima/ttf.js
 * https://github.com/ynakajima/ttf.js
 */




// 检查数组支持情况
if (typeof ArrayBuffer === 'undefined' || typeof DataView === 'undefined') {
    throw new Error('not support ArrayBuffer and DataView');
}

// 数据类型
const dataType = {
    Int8: 1,
    Int16: 2,
    Int32: 4,
    Uint8: 1,
    Uint16: 2,
    Uint32: 4,
    Float32: 4,
    Float64: 8
};

class Reader {

    /**
     * 读取器
     *
     * @constructor
     * @param {Array.<byte>} buffer 缓冲数组
     * @param {number} offset 起始偏移
     * @param {number} length 数组长度
     * @param {boolean} littleEndian 是否小尾
     */
    constructor(buffer, offset, length, littleEndian) {

        const bufferLength = buffer.byteLength || buffer.length;

        this.offset = offset || 0;
        this.length = length || (bufferLength - this.offset);
        this.littleEndian = littleEndian || false;

        this.view = new DataView(buffer, this.offset, this.length);
    }

    /**
     * 读取指定的数据类型
     *
     * @param {string} type 数据类型
     * @param {number=} offset 位移
     * @param {boolean=} littleEndian 是否小尾
     * @return {number} 返回值
     */
    read(type, offset, littleEndian) {

        // 使用当前位移
        if (undefined === offset) {
            offset = this.offset;
        }

        // 使用小尾
        if (undefined === littleEndian) {
            littleEndian = this.littleEndian;
        }

        // 扩展方法
        if (undefined === dataType[type]) {
            return this['read' + type](offset, littleEndian);
        }

        const size = dataType[type];
        this.offset = offset + size;
        return this.view['get' + type](offset, littleEndian);
    }

    /**
     * 获取指定的字节数组
     *
     * @param {number} offset 偏移
     * @param {number} length 字节长度
     * @return {Array} 字节数组
     */
    readBytes(offset, length = null) {

        if (length == null) {
            length = offset;
            offset = this.offset;
        }

        if (length < 0 || offset + length > this.length) {
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10001, this.length, offset + length);
        }

        const buffer = [];
        for (let i = 0; i < length; ++i) {
            buffer.push(this.view.getUint8(offset + i));
        }

        this.offset = offset + length;
        return buffer;
    }

    /**
     * 读取一个string
     *
     * @param {number} offset 偏移
     * @param {number} length 长度
     * @return {string} 字符串
     */
    readString(offset, length = null) {

        if (length == null) {
            length = offset;
            offset = this.offset;
        }

        if (length < 0 || offset + length > this.length) {
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10001, this.length, offset + length);
        }

        let value = '';
        for (let i = 0; i < length; ++i) {
            const c = this.readUint8(offset + i);
            value += String.fromCharCode(c);
        }

        this.offset = offset + length;

        return value;
    }

    /**
     * 读取一个字符
     *
     * @param {number} offset 偏移
     * @return {string} 字符串
     */
    readChar(offset) {
        return this.readString(offset, 1);
    }

    /**
     * 读取一个uint24整形
     *
     * @param {number} offset 偏移
     * @return {number}
     */
    readUint24(offset) {
        const [i, j, k] = this.readBytes(offset || this.offset, 3);
        return (i << 16) + (j << 8) + k;
    }

    /**
     * 读取fixed类型
     *
     * @param {number} offset 偏移
     * @return {number} float
     */
    readFixed(offset) {
        if (undefined === offset) {
            offset = this.offset;
        }
        const val = this.readInt32(offset, false) / 65536.0;
        return Math.ceil(val * 100000) / 100000;
    }

    /**
     * 读取长日期
     *
     * @param {number} offset 偏移
     * @return {Date} Date对象
     */
    readLongDateTime(offset) {
        if (undefined === offset) {
            offset = this.offset;
        }

        // new Date(1970, 1, 1).getTime() - new Date(1904, 1, 1).getTime();
        const delta = -2077545600000;
        const time = this.readUint32(offset + 4, false);
        const date = new Date();
        date.setTime(time * 1000 + delta);
        return date;
    }

    /**
     * 跳转到指定偏移
     *
     * @param {number} offset 偏移
     * @return {Object} this
     */
    seek(offset) {
        if (undefined === offset) {
            this.offset = 0;
        }

        if (offset < 0 || offset > this.length) {
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10001, this.length, offset);
        }

        this.offset = offset;

        return this;
    }

    /**
     * 注销
     */
    dispose() {
        delete this.view;
    }
}

// 直接支持的数据类型
Object.keys(dataType).forEach((type) => {
    Reader.prototype['read' + type] = (0,_common_lang__WEBPACK_IMPORTED_MODULE_0__.curry)(Reader.prototype.read, type);
});


/***/ }),
/* 29 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_string__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30);
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31);
/**
 * @file ttf 相关错误号定义
 * @author mengke01(kekee000@gmail.com)
 */




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({

    /**
     * 抛出一个异常
     *
     * @param  {Object} e 异常号或者异常对象
     * @param  {...Array} fargs args 参数
     *
     * 例如：
     * e = 1001
     * e = {
     *     number: 1001,
     *     data: 错误数据
     * }
     */
    raise(e, ...fargs) {
        let number;
        let data;
        if (typeof e === 'object') {
            number = e.number || 0;
            data = e.data;
        }
        else {
            number = e;
        }

        let message = _i18n__WEBPACK_IMPORTED_MODULE_1__.default.lang[number];
        if (fargs.length > 0) {
            const args = typeof fargs[0] === 'object'
                ? fargs[0]
                : fargs;
            message = _common_string__WEBPACK_IMPORTED_MODULE_0__.default.format(message, args);
        }

        const event = new Error(message);
        event.number = number;
        if (data) {
            event.data = data;
        }

        throw event;
    }
});




/***/ }),
/* 30 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file 字符串相关的函数
 * @author mengke01(kekee000@gmail.com)
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({

    /**
     * HTML解码字符串
     *
     * @param {string} source 源字符串
     * @return {string}
     */
    decodeHTML(source) {

        const str = String(source)
            .replace(/&quot;/g, '"')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&amp;/g, '&');

        // 处理转义的中文和实体字符
        return str.replace(/&#([\d]+);/g, ($0, $1) => String.fromCodePoint(parseInt($1, 10)));
    },

    /**
     * HTML编码字符串
     *
     * @param {string} source 源字符串
     * @return {string}
     */
    encodeHTML(source) {
        return String(source)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    },

    /**
     * 获取string字节长度
     *
     * @param {string} source 源字符串
     * @return {number} 长度
     */
    getLength(source) {
        // eslint-disable-next-line no-control-regex
        return String(source).replace(/[^\x00-\xff]/g, '11').length;
    },

    /**
     * 字符串格式化，支持如 ${xxx.xxx} 的语法
     *
     * @param {string} source 模板字符串
     * @param {Object} data 数据
     * @return {string} 格式化后字符串
     */
    format(source, data) {
        return source.replace(/\$\{([\w.]+)\}/g, ($0, $1) => {
            const ref = $1.split('.');
            let refObject = data;
            let level;

            while (refObject != null && (level = ref.shift())) {
                refObject = refObject[level];
            }

            return refObject != null ? refObject : '';
        });
    },

    /**
     * 使用指定字符填充字符串,默认`0`
     *
     * @param {string} str 字符串
     * @param {number} size 填充到的大小
     * @param {string=} ch 填充字符
     * @return {string} 字符串
     */
    pad(str, size, ch) {
        str = String(str);
        if (str.length > size) {
            return str.slice(str.length - size);
        }
        return new Array(size - str.length + 1).join(ch || '0') + str;
    },

    /**
     * 获取字符串哈希编码
     *
     * @param {string} str 字符串
     * @return {number} 哈希值
     */
    hashcode(str) {
        if (!str) {
            return 0;
        }

        let hash = 0;
        for (let i = 0, l = str.length; i < l; i++) {
            hash = 0x7FFFFFFFF & (hash * 31 + str.charCodeAt(i));
        }
        return hash;
    }
});


/***/ }),
/* 31 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_I18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32);
/**
 * @file 语言字符串管理
 * @author mengke01(kekee000@gmail.com)
 */



const zh = {
    // error define
    10001: '超出读取范围：${0}, ${1}',
    10002: '超出写入范围：${0}, ${1}',
    10003: '未知数据类型：${0}, ${1}',
    10004: '不支持svg解析',

    10101: '错误的ttf文件',
    10102: '错误的woff文件',
    10103: '错误的svg文件',
    10104: '读取ttf文件错误',
    10105: '读取woff文件错误',
    10106: '读取svg文件错误',
    10107: '写入ttf文件错误',
    10108: '写入woff文件错误',
    10109: '写入svg文件错误',
    10112: '写入svg symbol 错误',

    10110: '读取eot文件错误',
    10111: '读取eot字体错误',

    10200: '重复的unicode代码点，字形序号：${0}',
    10201: 'ttf字形轮廓数据为空',
    10202: '不支持标志位：ARGS_ARE_XY_VALUES',
    10203: '未找到表：${0}',
    10204: '读取ttf表错误',
    10205: '未找到解压函数',

    10301: '错误的otf文件',
    10302: '读取otf表错误',
    10303: 'otf字形轮廓数据为空'
};


const en = {
    // error define
    10001: 'Reading index out of range: ${0}, ${1}',
    10002: 'Writing index out of range: ${0}, ${1}',
    10003: 'Unknown datatype: ${0}, ${1}',
    10004: 'No svg parser',

    10101: 'ttf file damaged',
    10102: 'woff file damaged',
    10103: 'svg file damaged',
    10104: 'Read ttf error',
    10105: 'Read woff error',
    10106: 'Read svg error',
    10107: 'Write ttf error',
    10108: 'Write woff error',
    10109: 'Write svg error',
    10112: 'Write svg symbol error',

    10110: 'Read eot error',
    10111: 'Write eot error',

    10200: 'Repeat unicode, glyph index: ${0}',
    10201: 'ttf `glyph` data is empty',
    10202: 'Not support compound glyph flag: ARGS_ARE_XY_VALUES',
    10203: 'No ttf table: ${0}',
    10204: 'Read ttf table data error',
    10205: 'No zip deflate function',

    10301: 'otf file damaged',
    10302: 'Read otf table error',
    10303: 'otf `glyph` data is empty'
};


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new _common_I18n__WEBPACK_IMPORTED_MODULE_0__.default(
    [
        ['zh-cn', zh],
        ['en-us', en]
    ],
    typeof window !== 'undefined' ? window.language : 'en-us'
));


/***/ }),
/* 32 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ I18n)
/* harmony export */ });
/**
 * @file 用于国际化的字符串管理类
 * @author mengke01(kekee000@gmail.com)
 */

function appendLanguage(store, languageList) {
    languageList.forEach(item => {
        const language = item[0];
        store[language] = Object.assign(store[language] || {}, item[1]);
    });
    return store;
}

/**
 * 管理国际化字符，根据lang切换语言版本
 *
 * @class I18n
 * @param {Array} languageList 当前支持的语言列表
 * @param {string=} defaultLanguage 默认语言
 * languageList = [
 *     'en-us', // 语言名称
 *     langObject // 语言字符串列表
 * ]
 */
class I18n {
    constructor(languageList, defaultLanguage) {
        this.store = appendLanguage({}, languageList);
        this.setLanguage(
            defaultLanguage
            || typeof navigator !== 'undefined' && navigator.language && navigator.language.toLowerCase()
            || 'en-us'
        );
    }

    /**
     * 设置语言
     *
     * @param {string} language 语言
     * @return {this}
     */
    setLanguage(language) {
        if (!this.store[language]) {
            language = 'en-us';
        }
        this.lang = this.store[this.language = language];
        return this;
    }

    /**
     * 添加一个语言字符串
     *
     * @param {string} language 语言
     * @param {Object} langObject 语言对象
     * @return {this}
     */
    addLanguage(language, langObject) {
        appendLanguage(this.store, [[language, langObject]]);
        return this;
    }

    /**
     * 获取当前语言字符串
     *
     * @param  {string} path 语言路径
     * @return {string}      语言字符串
     */
    get(path) {
        const ref = path.split('.');
        let refObject = this.lang;
        let level;
        while (refObject != null && (level = ref.shift())) {
            refObject = refObject[level];
        }
        return refObject != null ? refObject : '';
    }
}


/***/ }),
/* 33 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_lang__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29);
/**
 * @file 数据写入器
 * @author mengke01(kekee000@gmail.com)
 */




// 检查数组支持情况
if (typeof ArrayBuffer === 'undefined' || typeof DataView === 'undefined') {
    throw new Error('not support ArrayBuffer and DataView');
}

// 数据类型
const dataType = {
    Int8: 1,
    Int16: 2,
    Int32: 4,
    Uint8: 1,
    Uint16: 2,
    Uint32: 4,
    Float32: 4,
    Float64: 8
};


/**
 * 读取器
 *
 * @constructor
 * @param {Array.<byte>} buffer 缓冲数组
 * @param {number} offset 起始偏移
 * @param {number=} length 数组长度
 * @param {boolean=} littleEndian 是否小尾
 */
class Writer {
    constructor(buffer, offset, length, littleEndian) {
        const bufferLength = buffer.byteLength || buffer.length;
        this.offset = offset || 0;
        this.length = length || (bufferLength - this.offset);
        this.littleEndian = littleEndian || false;
        this.view = new DataView(buffer, this.offset, this.length);
    }

    /**
     * 读取指定的数据类型
     *
     * @param {string} type 数据类型
     * @param {number} value value值
     * @param {number=} offset 位移
     * @param {boolean=} littleEndian 是否小尾
     *
     * @return {this}
     */
    write(type, value, offset, littleEndian) {

        // 使用当前位移
        if (undefined === offset) {
            offset = this.offset;
        }

        // 使用小尾
        if (undefined === littleEndian) {
            littleEndian = this.littleEndian;
        }

        // 扩展方法
        if (undefined === dataType[type]) {
            return this['write' + type](value, offset, littleEndian);
        }

        const size = dataType[type];
        this.offset = offset + size;
        this.view['set' + type](offset, value, littleEndian);
        return this;
    }

    /**
     * 写入指定的字节数组
     *
     * @param {ArrayBuffer} value 写入值
     * @param {number=} length 数组长度
     * @param {number=} offset 起始偏移
     * @return {this}
     */
    writeBytes(value, length, offset) {

        length = length || value.byteLength || value.length;
        let i;

        if (!length) {
            return this;
        }

        if (undefined === offset) {
            offset = this.offset;
        }

        if (length < 0 || offset + length > this.length) {
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10002, this.length, offset + length);
        }

        const littleEndian = this.littleEndian;
        if (value instanceof ArrayBuffer) {
            const view = new DataView(value, 0, length);
            for (i = 0; i < length; ++i) {
                this.view.setUint8(offset + i, view.getUint8(i, littleEndian), littleEndian);
            }
        }
        else {
            for (i = 0; i < length; ++i) {
                this.view.setUint8(offset + i, value[i], littleEndian);
            }
        }

        this.offset = offset + length;

        return this;
    }

    /**
     * 写空数据
     *
     * @param {number} length 长度
     * @param {number=} offset 起始偏移
     * @return {this}
     */
    writeEmpty(length, offset) {

        if (length < 0) {
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10002, this.length, length);
        }

        if (undefined === offset) {
            offset = this.offset;
        }

        const littleEndian = this.littleEndian;
        for (let i = 0; i < length; ++i) {
            this.view.setUint8(offset + i, 0, littleEndian);
        }

        this.offset = offset + length;

        return this;
    }

    /**
     * 写入一个string
     *
     * @param {string} str 字符串
     * @param {number=} length 长度
     * @param {number=} offset 偏移
     *
     * @return {this}
     */
    writeString(str = '', length, offset) {

        if (undefined === offset) {
            offset = this.offset;
        }

        // eslint-disable-next-line no-control-regex
        length = length || str.replace(/[^\x00-\xff]/g, '11').length;

        if (length < 0 || offset + length > this.length) {
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10002, this.length, offset + length);
        }

        this.seek(offset);

        for (let i = 0, l = str.length, charCode; i < l; ++i) {
            charCode = str.charCodeAt(i) || 0;
            if (charCode > 127) {
                // unicode编码可能会超出2字节,
                // 写入与编码有关系，此处不做处理
                this.writeUint16(charCode);
            }
            else {
                this.writeUint8(charCode);
            }
        }

        this.offset = offset + length;

        return this;
    }

    /**
     * 写入一个字符
     *
     * @param {string} value 字符
     * @param {number=} offset 偏移
     * @return {this}
     */
    writeChar(value, offset) {
        return this.writeString(value, offset);
    }

    /**
     * 写入fixed类型
     *
     * @param {number} value 写入值
     * @param {number=} offset 偏移
     * @return {number} float
     */
    writeFixed(value, offset) {
        if (undefined === offset) {
            offset = this.offset;
        }
        this.writeInt32(Math.round(value * 65536), offset);

        return this;
    }

    /**
     * 写入长日期
     *
     * @param {Date} value 日期对象
     * @param {number=} offset 偏移
     *
     * @return {Date} Date对象
     */
    writeLongDateTime(value, offset) {

        if (undefined === offset) {
            offset = this.offset;
        }

        // new Date(1970, 1, 1).getTime() - new Date(1904, 1, 1).getTime();
        const delta = -2077545600000;

        if (typeof value === 'undefined') {
            value = delta;
        }
        else if (typeof value.getTime === 'function') {
            value = value.getTime();
        }
        else if (/^\d+$/.test(value)) {
            value = +value;
        }
        else {
            value = Date.parse(value);
        }

        const time = Math.round((value - delta) / 1000);
        this.writeUint32(0, offset);
        this.writeUint32(time, offset + 4);

        return this;
    }

    /**
     * 跳转到指定偏移
     *
     * @param {number=} offset 偏移
     * @return {this}
     */
    seek(offset) {
        if (undefined === offset) {
            this.offset = 0;
        }

        if (offset < 0 || offset > this.length) {
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10002, this.length, offset);
        }

        this._offset = this.offset;
        this.offset = offset;

        return this;
    }

    /**
     * 跳转到写入头部位置
     *
     * @return {this}
     */
    head() {
        this.offset = this._offset || 0;
        return this;
    }

    /**
     * 获取缓存的byte数组
     *
     * @return {ArrayBuffer}
     */
    getBuffer() {
        return this.view.buffer;
    }

    /**
     * 注销
     */
    dispose() {
        delete this.view;
    }
}

// 直接支持的数据类型
Object.keys(dataType).forEach(type => {
    Writer.prototype['write' + type] = (0,_common_lang__WEBPACK_IMPORTED_MODULE_0__.curry)(Writer.prototype.write, type);
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Writer);


/***/ }),
/* 34 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ otf2ttfobject)
/* harmony export */ });
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(29);
/* harmony import */ var _otfreader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35);
/* harmony import */ var _util_otfContours2ttfContours__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65);
/* harmony import */ var _graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(17);
/**
 * @file otf格式转ttf格式对象
 * @author mengke01(kekee000@gmail.com)
 */






/**
 * otf格式转ttf格式对象
 *
 * @param  {ArrayBuffer|otfObject} otfBuffer 原始数据或者解析后的otf数据
 * @param  {Object} options   参数
 * @return {Object}          ttfObject对象
 */
function otf2ttfobject(otfBuffer, options) {
    let otfObject;
    if (otfBuffer instanceof ArrayBuffer) {
        const otfReader = new _otfreader__WEBPACK_IMPORTED_MODULE_1__.default(options);
        otfObject = otfReader.read(otfBuffer);
        otfReader.dispose();
    }
    else if (otfBuffer.head && otfBuffer.glyf && otfBuffer.cmap) {
        otfObject = otfBuffer;
    }
    else {
        _error__WEBPACK_IMPORTED_MODULE_0__.default.raise(10111);
    }

    // 转换otf轮廓
    otfObject.glyf.forEach((g) => {
        g.contours = (0,_util_otfContours2ttfContours__WEBPACK_IMPORTED_MODULE_2__.default)(g.contours);
        const box = (0,_graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_3__.computePathBox)(...g.contours);
        if (box) {
            g.xMin = box.x;
            g.xMax = box.x + box.width;
            g.yMin = box.y;
            g.yMax = box.y + box.height;
            g.leftSideBearing = g.xMin;
        }
        else {
            g.xMin = 0;
            g.xMax = 0;
            g.yMin = 0;
            g.yMax = 0;
            g.leftSideBearing = 0;
        }
    });

    otfObject.version = 0x1;

    // 修改maxp相关配置
    otfObject.maxp.version = 1.0;
    otfObject.maxp.maxZones = otfObject.maxp.maxTwilightPoints ? 2 : 1;

    delete otfObject.CFF;
    delete otfObject.VORG;

    return otfObject;
}


/***/ }),
/* 35 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ OTFReader)
/* harmony export */ });
/* harmony import */ var _table_directory__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36);
/* harmony import */ var _table_support_otf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39);
/* harmony import */ var _reader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(28);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(29);
/**
 * @file otf字体读取
 * @author mengke01(kekee000@gmail.com)
 */






class OTFReader {

    /**
     * OTF读取函数
     *
     * @param {Object} options 写入参数
     * @constructor
     */
    constructor(options = {}) {
        options.subset = options.subset || [];
        this.options = options;
    }

    /**
     * 初始化
     *
     * @param {ArrayBuffer} buffer buffer对象
     * @return {Object} ttf对象
     */
    readBuffer(buffer) {

        const reader = new _reader__WEBPACK_IMPORTED_MODULE_2__.default(buffer, 0, buffer.byteLength, false);
        const font = {};

        // version
        font.version = reader.readString(0, 4);

        if (font.version !== 'OTTO') {
            _error__WEBPACK_IMPORTED_MODULE_3__.default.raise(10301);
        }

        // num tables
        font.numTables = reader.readUint16();

        if (font.numTables <= 0 || font.numTables > 100) {
            _error__WEBPACK_IMPORTED_MODULE_3__.default.raise(10302);
        }

        // searchRange
        font.searchRange = reader.readUint16();

        // entrySelector
        font.entrySelector = reader.readUint16();

        // rangeShift
        font.rangeShift = reader.readUint16();

        font.tables = new _table_directory__WEBPACK_IMPORTED_MODULE_0__.default(reader.offset).read(reader, font);

        if (!font.tables.head || !font.tables.cmap || !font.tables.CFF) {
            _error__WEBPACK_IMPORTED_MODULE_3__.default.raise(10302);
        }

        font.readOptions = this.options;

        // 读取支持的表数据
        Object.keys(_table_support_otf__WEBPACK_IMPORTED_MODULE_1__.default).forEach((tableName) => {
            if (font.tables[tableName]) {
                const offset = font.tables[tableName].offset;
                font[tableName] = new _table_support_otf__WEBPACK_IMPORTED_MODULE_1__.default[tableName](offset).read(reader, font);
            }
        });

        if (!font.CFF.glyf) {
            _error__WEBPACK_IMPORTED_MODULE_3__.default.raise(10303);
        }

        reader.dispose();

        return font;
    }

    /**
     * 关联glyf相关的信息
     *
     * @param {Object} font font对象
     */
    resolveGlyf(font) {

        const codes = font.cmap;
        let glyf = font.CFF.glyf;
        const subsetMap = font.readOptions.subset ? font.subsetMap : null; // 当前ttf的子集列表
        // unicode
        Object.keys(codes).forEach((c) => {
            const i = codes[c];
            if (subsetMap && !subsetMap[i]) {
                return;
            }
            if (!glyf[i].unicode) {
                glyf[i].unicode = [];
            }
            glyf[i].unicode.push(+c);
        });

        // leftSideBearing
        font.hmtx.forEach((item, i) => {
            if (subsetMap && !subsetMap[i]) {
                return;
            }
            glyf[i].advanceWidth = glyf[i].advanceWidth || item.advanceWidth || 0;
            glyf[i].leftSideBearing = item.leftSideBearing;
        });

        // 设置了subsetMap之后需要选取subset中的字形
        if (subsetMap) {
            const subGlyf = [];
            Object.keys(subsetMap).forEach((i) => {
                subGlyf.push(glyf[+i]);
            });
            glyf = subGlyf;
        }

        font.glyf = glyf;
    }

    /**
     * 清除非必须的表
     *
     * @param {Object} font font对象
     */
    cleanTables(font) {
        delete font.readOptions;
        delete font.tables;
        delete font.hmtx;
        delete font.post.glyphNameIndex;
        delete font.post.names;
        delete font.subsetMap;

        // 删除无用的表
        const cff = font.CFF;
        delete cff.glyf;
        delete cff.charset;
        delete cff.encoding;
        delete cff.gsubrs;
        delete cff.gsubrsBias;
        delete cff.subrs;
        delete cff.subrsBias;
    }

    /**
     * 获取解析后的ttf文档
     *
     * @param {ArrayBuffer} buffer buffer对象
     *
     * @return {Object} ttf文档
     */
    read(buffer) {
        this.font = this.readBuffer(buffer);
        this.resolveGlyf(this.font);
        this.cleanTables(this.font);
        return this.font;
    }

    /**
     * 注销
     */
    dispose() {
        delete this.font;
        delete this.options;
    }
}


/***/ }),
/* 36 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/**
 * @file directory 表, 读取和写入ttf表索引
 * @author mengke01(kekee000@gmail.com)
 *
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6.html
 */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'directory',
    [],
    {
        read(reader, ttf) {
            const tables = {};
            const numTables = ttf.numTables;
            const offset = this.offset;

            for (let i = offset, l = numTables * 16; i < l; i += 16) {
                const name = reader.readString(i, 4).trim();

                tables[name] = {
                    name,
                    checkSum: reader.readUint32(i + 4),
                    offset: reader.readUint32(i + 8),
                    length: reader.readUint32(i + 12)
                };
            }

            return tables;
        },

        write(writer, ttf) {

            const tables = ttf.support.tables;
            for (let i = 0, l = tables.length; i < l; i++) {
                writer.writeString((tables[i].name + '    ').slice(0, 4));
                writer.writeUint32(tables[i].checkSum);
                writer.writeUint32(tables[i].offset);
                writer.writeUint32(tables[i].length);
            }

            return writer;
        },

        size(ttf) {
            return ttf.numTables * 16;
        }
    }
));


/***/ }),
/* 37 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _struct__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(38);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29);
/**
 * @file ttf表基类
 * @author mengke01(kekee000@gmail.com)
 */



/* eslint-disable no-invalid-this */
/**
 * 读取表结构
 *
 * @param {Reader} reader reader对象
 * @return {Object} 当前对象
 */
function read(reader) {

    const offset = this.offset;

    if (undefined !== offset) {
        reader.seek(offset);
    }

    const me = this;

    this.struct.forEach((item) => {
        const name = item[0];
        const type = item[1];
        let typeName = null;
        switch (type) {
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Int8:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Uint8:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Int16:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Uint16:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Int32:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Uint32:
            typeName = _struct__WEBPACK_IMPORTED_MODULE_0__.default.names[type];
            me[name] = reader.read(typeName);
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Fixed:
            me[name] = reader.readFixed();
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.LongDateTime:
            me[name] = reader.readLongDateTime();
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Bytes:
            me[name] = reader.readBytes(reader.offset, item[2] || 0);
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Char:
            me[name] = reader.readChar();
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.String:
            me[name] = reader.readString(reader.offset, item[2] || 0);
            break;

        default:
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10003, name, type);
        }
    });

    return this.valueOf();
}

/**
 * 写表结构
 *
 * @param {Object} writer writer对象
 * @param {Object} ttf 已解析的ttf对象
 *
 * @return {Writer} 返回writer对象
 */
function write(writer, ttf) {
    const table = ttf[this.name];

    if (!table) {
        _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10203, this.name);
    }

    this.struct.forEach((item) => {
        const name = item[0];
        const type = item[1];
        let typeName = null;
        switch (type) {
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Int8:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Uint8:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Int16:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Uint16:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Int32:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Uint32:
            typeName = _struct__WEBPACK_IMPORTED_MODULE_0__.default.names[type];
            writer.write(typeName, table[name]);
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Fixed:
            writer.writeFixed(table[name]);
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.LongDateTime:
            writer.writeLongDateTime(table[name]);
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Bytes:
            writer.writeBytes(table[name], item[2] || 0);
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Char:
            writer.writeChar(table[name]);
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.String:
            writer.writeString(table[name], item[2] || 0);
            break;

        default:
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10003, name, type);
        }
    });

    return writer;
}

/**
 * 获取ttf表的size大小
 *
 * @param {string} name 表名
 * @return {number} 表大小
 */
function size() {

    let sz = 0;
    this.struct.forEach((item) => {
        const type = item[1];
        switch (type) {
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Int8:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Uint8:
            sz += 1;
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Int16:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Uint16:
            sz += 2;
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Int32:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Uint32:
        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Fixed:
            sz += 4;
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.LongDateTime:
            sz += 8;
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Bytes:
            sz += item[2] || 0;
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.Char:
            sz += 1;
            break;

        case _struct__WEBPACK_IMPORTED_MODULE_0__.default.String:
            sz += item[2] || 0;
            break;

        default:
            _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10003, name, type);
        }
    });

    return sz;
}

/**
 * 获取对象的值
 *
 * @return {*} 当前对象的值
 */
function valueOf() {
    const val = {};
    const me = this;
    this.struct.forEach(item => {
        val[item[0]] = me[item[0]];
    });

    return val;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    read,
    write,
    size,
    valueOf,

    /**
     * 创建一个表结构
     *
     * @param {string} name 表名
     * @param {Object} struct 表结构
     * @param {Object} prototype 原型
     * @return {Function} 表构造函数
     */
    create(name, struct, prototype) {
        class Table {
            constructor(offset) {
                this.name = name;
                this.struct = struct;
                this.offset = offset;
            }
        }

        Table.prototype.read = read;
        Table.prototype.write = write;
        Table.prototype.size = size;
        Table.prototype.valueOf = valueOf;
        Object.assign(Table.prototype, prototype);
        return Table;
    }
});



/***/ }),
/* 38 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file ttf基本数据结构
 * @author mengke01(kekee000@gmail.com)
 *
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6.html
 */

const struct = {
    Int8: 1,
    Uint8: 2,
    Int16: 3,
    Uint16: 4,
    Int32: 5,
    Uint32: 6,
    Fixed: 7, // 32-bit signed fixed-point number (16.16)
    FUnit: 8, // Smallest measurable distance in the em space
    // 16-bit signed fixed number with the low 14 bits of fraction
    F2Dot14: 11,
    // The long internal format of a date in seconds since 12:00 midnight,
    // January 1, 1904. It is represented as a signed 64-bit integer.
    LongDateTime: 12,

    // extend data type
    Char: 13,
    String: 14,
    Bytes: 15,
    Uint24: 20
};

// 反转名字查找
const names = {};
Object.keys(struct).forEach((key) => {
    names[struct[key]] = key;
});

struct.names = names;

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (struct);


/***/ }),
/* 39 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(40);
/* harmony import */ var _maxp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41);
/* harmony import */ var _cmap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42);
/* harmony import */ var _name__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(47);
/* harmony import */ var _hhea__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(51);
/* harmony import */ var _hmtx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(52);
/* harmony import */ var _post__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53);
/* harmony import */ var _OS2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(54);
/* harmony import */ var _CFF__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(55);
/* harmony import */ var _GPOS__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(63);
/* harmony import */ var _kern__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(64);
/**
 * @file otf字体格式支持的表
 * @author mengke01(kekee000@gmail.com)
 */













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    head: _head__WEBPACK_IMPORTED_MODULE_0__.default,
    maxp: _maxp__WEBPACK_IMPORTED_MODULE_1__.default,
    cmap: _cmap__WEBPACK_IMPORTED_MODULE_2__.default,
    name: _name__WEBPACK_IMPORTED_MODULE_3__.default,
    hhea: _hhea__WEBPACK_IMPORTED_MODULE_4__.default,
    hmtx: _hmtx__WEBPACK_IMPORTED_MODULE_5__.default,
    post: _post__WEBPACK_IMPORTED_MODULE_6__.default,
    'OS/2': _OS2__WEBPACK_IMPORTED_MODULE_7__.default,
    CFF: _CFF__WEBPACK_IMPORTED_MODULE_8__.default,
    GPOS: _GPOS__WEBPACK_IMPORTED_MODULE_9__.default,
    kern: _kern__WEBPACK_IMPORTED_MODULE_10__.default
});


/***/ }),
/* 40 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _struct__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38);
/**
 * @file head表
 * @author mengke01(kekee000@gmail.com)
 */




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'head',
    [
        ['version', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Fixed],
        ['fontRevision', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Fixed],
        ['checkSumAdjustment', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['magickNumber', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['flags', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['unitsPerEm', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['created', _struct__WEBPACK_IMPORTED_MODULE_1__.default.LongDateTime],
        ['modified', _struct__WEBPACK_IMPORTED_MODULE_1__.default.LongDateTime],
        ['xMin', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['yMin', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['xMax', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['yMax', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['macStyle', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['lowestRecPPEM', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['fontDirectionHint', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['indexToLocFormat', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['glyphDataFormat', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16]
    ]
));


/***/ }),
/* 41 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _struct__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38);
/**
 * @file maxp 表
 * @author mengke01(kekee000@gmail.com)
 */




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'maxp',
    [
        ['version', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Fixed],
        ['numGlyphs', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxPoints', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxContours', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxCompositePoints', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxCompositeContours', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxZones', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxTwilightPoints', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxStorage', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxFunctionDefs', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxInstructionDefs', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxStackElements', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxSizeOfInstructions', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxComponentElements', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['maxComponentDepth', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16]
    ],
    {

        write(writer, ttf) {
            _table__WEBPACK_IMPORTED_MODULE_0__.default.write.call(this, writer, ttf.support);
            return writer;
        },

        size() {
            return 32;
        }
    }
));


/***/ }),
/* 42 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _cmap_parse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43);
/* harmony import */ var _cmap_write__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45);
/* harmony import */ var _cmap_sizeof__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(46);
/**
 * @file cmap 表
 * @author mengke01(kekee000@gmail.com)
 *
 * @see
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6cmap.html
 */






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'cmap',
    [],
    {
        write: _cmap_write__WEBPACK_IMPORTED_MODULE_2__.default,
        read: _cmap_parse__WEBPACK_IMPORTED_MODULE_1__.default,
        size: _cmap_sizeof__WEBPACK_IMPORTED_MODULE_3__.default
    }
));



/***/ }),
/* 43 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ parse)
/* harmony export */ });
/* harmony import */ var _util_readWindowsAllCodes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44);
/**
 * @file 解析cmap表
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * 读取cmap子表
 *
 * @param {Reader} reader Reader对象
 * @param {Object} ttf ttf对象
 * @param {Object} subTable 子表对象
 * @param {number} cmapOffset 子表的偏移
 */
function readSubTable(reader, ttf, subTable, cmapOffset) {
    let i;
    let l;
    let glyphIdArray;
    const startOffset = cmapOffset + subTable.offset;
    let glyphCount;
    subTable.format = reader.readUint16(startOffset);

    // 0～256 紧凑排列
    if (subTable.format === 0) {
        const format0 = subTable;
        // 跳过format字段
        format0.length = reader.readUint16();
        format0.language = reader.readUint16();
        glyphIdArray = [];
        for (i = 0, l = format0.length - 6; i < l; i++) {
            glyphIdArray.push(reader.readUint8());
        }
        format0.glyphIdArray = glyphIdArray;
    }
    else if (subTable.format === 2) {
        const format2 = subTable;
        // 跳过format字段
        format2.length = reader.readUint16();
        format2.language = reader.readUint16();

        const subHeadKeys = [];
        let maxSubHeadKey = 0;// 最大索引
        let maxPos = -1; // 最大位置
        for (let i = 0, l = 256; i < l; i++) {
            subHeadKeys[i] = reader.readUint16() / 8;
            if (subHeadKeys[i] > maxSubHeadKey) {
                maxSubHeadKey = subHeadKeys[i];
                maxPos = i;
            }
        }

        const subHeads = [];
        for (i = 0; i <= maxSubHeadKey; i++) {
            subHeads[i] = {
                firstCode: reader.readUint16(),
                entryCount: reader.readUint16(),
                idDelta: reader.readUint16(),
                idRangeOffset: (reader.readUint16() - (maxSubHeadKey - i) * 8 - 2) / 2
            };
        }

        glyphCount = (startOffset + format2.length - reader.offset) / 2;
        const glyphs = [];
        for (i = 0; i < glyphCount; i++) {
            glyphs[i] = reader.readUint16();
        }

        format2.subHeadKeys = subHeadKeys;
        format2.maxPos = maxPos;
        format2.subHeads = subHeads;
        format2.glyphs = glyphs;

    }
    // 双字节编码，非紧凑排列
    else if (subTable.format === 4) {
        const format4 = subTable;
        // 跳过format字段
        format4.length = reader.readUint16();
        format4.language = reader.readUint16();
        format4.segCountX2 = reader.readUint16();
        format4.searchRange = reader.readUint16();
        format4.entrySelector = reader.readUint16();
        format4.rangeShift = reader.readUint16();

        const segCount = format4.segCountX2 / 2;

        // end code
        const endCode = [];
        for (i = 0; i < segCount; ++i) {
            endCode.push(reader.readUint16());
        }
        format4.endCode = endCode;

        format4.reservedPad = reader.readUint16();

        // start code
        const startCode = [];
        for (i = 0; i < segCount; ++i) {
            startCode.push(reader.readUint16());
        }
        format4.startCode = startCode;

        // idDelta
        const idDelta = [];
        for (i = 0; i < segCount; ++i) {
            idDelta.push(reader.readUint16());
        }
        format4.idDelta = idDelta;


        format4.idRangeOffsetOffset = reader.offset;

        // idRangeOffset
        const idRangeOffset = [];
        for (i = 0; i < segCount; ++i) {
            idRangeOffset.push(reader.readUint16());
        }
        format4.idRangeOffset = idRangeOffset;

        // 总长度 - glyphIdArray起始偏移/2
        glyphCount = (format4.length - (reader.offset - startOffset)) / 2;

        // 记录array offset
        format4.glyphIdArrayOffset = reader.offset;

        // glyphIdArray
        glyphIdArray = [];
        for (i = 0; i < glyphCount; ++i) {
            glyphIdArray.push(reader.readUint16());
        }

        format4.glyphIdArray = glyphIdArray;
    }

    else if (subTable.format === 6) {
        const format6 = subTable;

        format6.length = reader.readUint16();
        format6.language = reader.readUint16();
        format6.firstCode = reader.readUint16();
        format6.entryCount = reader.readUint16();

        // 记录array offset
        format6.glyphIdArrayOffset = reader.offset;

        const glyphIndexArray = [];
        const entryCount = format6.entryCount;
        // 读取字符分组
        for (i = 0; i < entryCount; ++i) {
            glyphIndexArray.push(reader.readUint16());
        }
        format6.glyphIdArray = glyphIndexArray;

    }
    // defines segments for sparse representation in 4-byte character space
    else if (subTable.format === 12) {
        const format12 = subTable;

        format12.reserved = reader.readUint16();
        format12.length = reader.readUint32();
        format12.language = reader.readUint32();
        format12.nGroups = reader.readUint32();

        const groups = [];
        const nGroups = format12.nGroups;
        // 读取字符分组
        for (i = 0; i < nGroups; ++i) {
            const group = {};
            group.start = reader.readUint32();
            group.end = reader.readUint32();
            group.startId = reader.readUint32();
            groups.push(group);
        }
        format12.groups = groups;
    }
    // format 14
    else if (subTable.format === 14) {
        const format14 = subTable;
        format14.length = reader.readUint32();
        const numVarSelectorRecords = reader.readUint32();
        const groups = [];
        for (let i = 0; i < numVarSelectorRecords; i++) {
            const varSelector = reader.readUint24();
            const defaultUVSOffset = reader.readUint32();
            const nonDefaultUVSOffset = reader.readUint32();

            if (defaultUVSOffset) {
                const numUnicodeValueRanges = reader.readUint32(startOffset + defaultUVSOffset);
                for (let j = 0; j < numUnicodeValueRanges; j++) {
                    const startUnicode = reader.readUint24();
                    const additionalCount = reader.readUint8();
                    groups.push({
                        start: startUnicode,
                        end: startUnicode + additionalCount,
                        varSelector
                    });
                }
            }
            if (nonDefaultUVSOffset) {
                const numUVSMappings = reader.readUint32(startOffset + nonDefaultUVSOffset);
                for (let j = 0; j < numUVSMappings; j++) {
                    const unicode = reader.readUint24();
                    const glyphId = reader.readUint16();
                    groups.push({
                        unicode,
                        glyphId,
                        varSelector
                    });
                }
            }
        }
        format14.groups = groups;
    }
    else {
        console.warn('not support cmap format:' + subTable.format);
    }
}


function parse(reader, ttf) {
    const tcmap = {};
    // eslint-disable-next-line no-invalid-this
    const cmapOffset = this.offset;

    reader.seek(cmapOffset);

    tcmap.version = reader.readUint16(); // 编码方式
    const numberSubtables = tcmap.numberSubtables = reader.readUint16(); // 表个数


    const subTables = tcmap.tables = []; // 名字表
    let offset = reader.offset;

    // 使用offset读取，以便于查找
    for (let i = 0, l = numberSubtables; i < l; i++) {
        const subTable = {};
        subTable.platformID = reader.readUint16(offset);
        subTable.encodingID = reader.readUint16(offset + 2);
        subTable.offset = reader.readUint32(offset + 4);

        readSubTable(reader, ttf, subTable, cmapOffset);
        subTables.push(subTable);

        offset += 8;
    }

    const cmap = (0,_util_readWindowsAllCodes__WEBPACK_IMPORTED_MODULE_0__.default)(subTables, ttf);

    return cmap;
}


/***/ }),
/* 44 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ readWindowsAllCodes)
/* harmony export */ });
/* eslint-disable */

/**
 * @file 读取windows支持的字符集
 * @author mengke01(kekee000@gmail.com)
 *
 * @see
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6cmap.html
 */

/**
 * 读取ttf中windows字符表的字符
 *
 * @param {Array} tables cmap表结构
 * @param {Object} ttf ttf对象
 * @return {Object} 字符字典索引，unicode => glyf index
 */
function readWindowsAllCodes(tables, ttf) {

    let codes = {};

    // 读取windows unicode 编码段
    let format0 = tables.find(function (item) {
        return item.format === 0;
    });

    // 读取windows unicode 编码段
    let format12 = tables.find(function (item) {
        return item.platformID === 3
            && item.encodingID === 10
            && item.format === 12;
    });

    let format4 = tables.find(function (item) {
        return item.platformID === 3
            && item.encodingID === 1
            && item.format === 4;
    });

    let format2 = tables.find(function (item) {
        return item.platformID === 3
            && item.encodingID === 3
            && item.format === 2;
    });

    let format14 = tables.find(function (item) {
        return item.platformID === 0
            && item.encodingID === 5
            && item.format === 14;
    });

    if (format0) {
        for (let i = 0, l = format0.glyphIdArray.length; i < l; i++) {
            if (format0.glyphIdArray[i]) {
                codes[i] = format0.glyphIdArray[i];
            }
        }
    }

    // format 14 support
    if (format14) {
        for (let i = 0, l = format14.groups.length; i < l; i++) {
            let {unicode, glyphId} = format14.groups[i];
            if (unicode) {
                codes[unicode] = glyphId;
            }
        }
    }

    // 读取format12表
    if (format12) {
        for (let i = 0, l = format12.nGroups; i < l; i++) {
            let group = format12.groups[i];
            let startId = group.startId;
            let start = group.start;
            let end = group.end;
            for (;start <= end;) {
                codes[start++] = startId++;
            }
        }
    }
    // 读取format4表
    else if (format4) {
        let segCount = format4.segCountX2 / 2;
        // graphIdArray 和idRangeOffset的偏移量
        let graphIdArrayIndexOffset = (format4.glyphIdArrayOffset - format4.idRangeOffsetOffset) / 2;

        for (let i = 0; i < segCount; ++i) {
            // 读取单个字符
            for (let start = format4.startCode[i], end = format4.endCode[i]; start <= end; ++start) {
                // range offset = 0
                if (format4.idRangeOffset[i] === 0) {
                    codes[start] = (start + format4.idDelta[i]) % 0x10000;
                }
                // rely on to glyphIndexArray
                else {
                    let index = i + format4.idRangeOffset[i] / 2
                        + (start - format4.startCode[i])
                        - graphIdArrayIndexOffset;

                    let graphId = format4.glyphIdArray[index];
                    if (graphId !== 0) {
                        codes[start] = (graphId + format4.idDelta[i]) % 0x10000;
                    }
                    else {
                        codes[start] = 0;
                    }

                }
            }
        }

        delete codes[65535];
    }
    // 读取format2表
    // see https://github.com/fontforge/fontforge/blob/master/fontforge/parsettf.c
    else if (format2) {
        let subHeadKeys = format2.subHeadKeys;
        let subHeads = format2.subHeads;
        let glyphs = format2.glyphs;
        let numGlyphs = ttf.maxp.numGlyphs;
        let index = 0;

        for (let i = 0; i < 256; i++) {
            // 单字节编码
            if (subHeadKeys[i] === 0) {
                if (i >= format2.maxPos) {
                    index = 0;
                }
                else if (i < subHeads[0].firstCode
                    || i >= subHeads[0].firstCode + subHeads[0].entryCount
                    || subHeads[0].idRangeOffset + (i - subHeads[0].firstCode) >= glyphs.length) {
                    index = 0;
                }
                else if ((index = glyphs[subHeads[0].idRangeOffset + (i - subHeads[0].firstCode)]) !== 0) {
                    index = index + subHeads[0].idDelta;
                }

                // 单字节解码
                if (index !== 0 && index < numGlyphs) {
                    codes[i] = index;
                }
            }
            else {
                let k = subHeadKeys[i];
                for (let j = 0, entryCount = subHeads[k].entryCount; j < entryCount; j++) {
                    if (subHeads[k].idRangeOffset + j >= glyphs.length) {
                        index = 0;
                    }
                    else if ((index = glyphs[subHeads[k].idRangeOffset + j]) !== 0) {
                        index = index + subHeads[k].idDelta;
                    }

                    if (index !== 0 && index < numGlyphs) {
                        let unicode = ((i << 8) | (j + subHeads[k].firstCode)) % 0xffff;
                        codes[unicode] = index;
                    }

                }
            }
        }
    }

    return codes;
}


/***/ }),
/* 45 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ write)
/* harmony export */ });
/**
 * @file 写cmap表
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 创建`子表0`
 *
 * @param {Writer} writer 写对象
 * @param {Array} unicodes unicodes列表
 * @return {Writer}
 */
function writeSubTable0(writer, unicodes) {

    writer.writeUint16(0); // format
    writer.writeUint16(262); // length
    writer.writeUint16(0); // language

    // Array of unicodes 0..255
    let i = -1;
    let unicode;
    while ((unicode = unicodes.shift())) {
        while (++i < unicode[0]) {
            writer.writeUint8(0);
        }

        writer.writeUint8(unicode[1]);
        i = unicode[0];
    }

    while (++i < 256) {
        writer.writeUint8(0);
    }

    return writer;
}


/**
 * 创建`子表4`
 *
 * @param {Writer} writer 写对象
 * @param {Array} segments 分块编码列表
 * @return {Writer}
 */
function writeSubTable4(writer, segments) {

    writer.writeUint16(4); // format
    writer.writeUint16(24 + segments.length * 8); // length
    writer.writeUint16(0); // language

    const segCount = segments.length + 1;
    const maxExponent = Math.floor(Math.log(segCount) / Math.LN2);
    const searchRange = 2 * Math.pow(2, maxExponent);

    writer.writeUint16(segCount * 2); // segCountX2
    writer.writeUint16(searchRange); // searchRange
    writer.writeUint16(maxExponent); // entrySelector
    writer.writeUint16(2 * segCount - searchRange); // rangeShift

    // end list
    segments.forEach((segment) => {
        writer.writeUint16(segment.end);
    });
    writer.writeUint16(0xFFFF); // end code
    writer.writeUint16(0); // reservedPad


    // start list
    segments.forEach((segment) => {
        writer.writeUint16(segment.start);
    });
    writer.writeUint16(0xFFFF); // start code

    // id delta
    segments.forEach((segment) => {
        writer.writeUint16(segment.delta);
    });
    writer.writeUint16(1);

    // Array of range offsets, it doesn't matter when deltas present
    for (let i = 0, l = segments.length; i < l; i++) {
        writer.writeUint16(0);
    }
    writer.writeUint16(0); // rangeOffsetArray should be finished with 0

    return writer;
}

/**
 * 创建`子表12`
 *
 * @param {Writer} writer 写对象
 * @param {Array} segments 分块编码列表
 * @return {Writer}
 */
function writeSubTable12(writer, segments) {

    writer.writeUint16(12); // format
    writer.writeUint16(0); // reserved
    writer.writeUint32(16 + segments.length * 12); // length
    writer.writeUint32(0); // language
    writer.writeUint32(segments.length); // nGroups

    segments.forEach((segment) => {
        writer.writeUint32(segment.start);
        writer.writeUint32(segment.end);
        writer.writeUint32(segment.startId);
    });

    return writer;
}

/**
 * 写subtableheader
 *
 * @param {Writer} writer Writer对象
 * @param {number} platform 平台
 * @param {number} encoding 编码
 * @param {number} offset 偏移
 * @return {Writer}
 */
function writeSubTableHeader(writer, platform, encoding, offset) {
    writer.writeUint16(platform); // platform
    writer.writeUint16(encoding); // encoding
    writer.writeUint32(offset); // offset
    return writer;
}


/**
 * 写cmap表数据
 *
 * @param  {Object} writer 写入器
 * @param  {Object} ttf    ttf对象
 * @return {Object}        写入器
 */
function write(writer, ttf) {
    const hasGLyphsOver2Bytes = ttf.support.cmap.hasGLyphsOver2Bytes;

    // write table header.
    writer.writeUint16(0); // version
    writer.writeUint16(hasGLyphsOver2Bytes ? 4 : 3); // count

    // header size
    const subTableOffset = 4 + (hasGLyphsOver2Bytes ? 32 : 24);
    const format4Size = ttf.support.cmap.format4Size;
    const format0Size = ttf.support.cmap.format0Size;

    // subtable 4, unicode
    writeSubTableHeader(writer, 0, 3, subTableOffset);

    // subtable 0, mac standard
    writeSubTableHeader(writer, 1, 0, subTableOffset + format4Size);

    // subtable 4, windows standard
    writeSubTableHeader(writer, 3, 1, subTableOffset);

    if (hasGLyphsOver2Bytes) {
        writeSubTableHeader(writer, 3, 10, subTableOffset + format4Size + format0Size);
    }

    // write tables, order of table seem to be magic, it is taken from TTX tool
    writeSubTable4(writer, ttf.support.cmap.format4Segments);
    writeSubTable0(writer, ttf.support.cmap.format0Segments);

    if (hasGLyphsOver2Bytes) {
        writeSubTable12(writer, ttf.support.cmap.format12Segments);
    }

    return writer;
}


/***/ }),
/* 46 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ sizeof)
/* harmony export */ });
/**
 * @file 获取cmap表的大小
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 获取format4 delta值
 * Delta is saved in signed int in cmap format 4 subtable,
 * but can be in -0xFFFF..0 interval.
 * -0x10000..-0x7FFF values are stored with offset.
 *
 * @param {number} delta delta值
 * @return {number} delta值
 */
function encodeDelta(delta) {
    return delta > 0x7FFF
        ? delta - 0x10000
        : (delta < -0x7FFF ? delta + 0x10000 : delta);
}

/**
 * 根据bound获取glyf segment
 *
 * @param {Array} glyfUnicodes glyf编码集合
 * @param {number} bound 编码范围
 * @return {Array} 码表
 */
function getSegments(glyfUnicodes, bound) {

    let prevGlyph = null;
    const result = [];
    let segment = {};

    glyfUnicodes.forEach((glyph) => {

        if (bound === undefined || glyph.unicode <= bound) {
            // 初始化编码头部，这里unicode和graph id 都必须连续
            if (prevGlyph === null
                || glyph.unicode !== prevGlyph.unicode + 1
                || glyph.id !== prevGlyph.id + 1
            ) {
                if (prevGlyph !== null) {
                    segment.end = prevGlyph.unicode;
                    result.push(segment);
                    segment = {
                        start: glyph.unicode,
                        startId: glyph.id,
                        delta: encodeDelta(glyph.id - glyph.unicode)
                    };
                }
                else {
                    segment.start = glyph.unicode;
                    segment.startId = glyph.id;
                    segment.delta = encodeDelta(glyph.id - glyph.unicode);
                }
            }

            prevGlyph = glyph;
        }
    });

    // need to finish the last segment
    if (prevGlyph !== null) {
        segment.end = prevGlyph.unicode;
        result.push(segment);
    }

    // 返回编码范围
    return result;
}

/**
 * 获取format0编码集合
 *
 * @param {Array} glyfUnicodes glyf编码集合
 * @return {Array} 码表
 */
function getFormat0Segment(glyfUnicodes) {
    const unicodes = [];
    glyfUnicodes.forEach((u) => {
        if (u.unicode !== undefined && u.unicode < 256) {
            unicodes.push([u.unicode, u.id]);
        }
    });

    // 按编码排序
    unicodes.sort((a, b) => a[0] - b[0]);

    return unicodes;
}

/**
 * 对cmap数据进行预处理，获取大小
 *
 * @param  {Object} ttf ttf对象
 * @return {number} 大小
 */
function sizeof(ttf) {
    ttf.support.cmap = {};
    let glyfUnicodes = [];
    ttf.glyf.forEach((glyph, index) => {

        let unicodes = glyph.unicode;

        if (typeof glyph.unicode === 'number') {
            unicodes = [glyph.unicode];
        }

        if (unicodes && unicodes.length) {
            unicodes.forEach((unicode) => {
                glyfUnicodes.push({
                    unicode,
                    id: unicode !== 0xFFFF ? index : 0
                });
            });
        }

    });

    glyfUnicodes = glyfUnicodes.sort((a, b) => a.unicode - b.unicode);

    ttf.support.cmap.unicodes = glyfUnicodes;

    const unicodes2Bytes = glyfUnicodes;

    ttf.support.cmap.format4Segments = getSegments(unicodes2Bytes, 0xFFFF);
    ttf.support.cmap.format4Size = 24
        + ttf.support.cmap.format4Segments.length * 8;

    ttf.support.cmap.format0Segments = getFormat0Segment(glyfUnicodes);
    ttf.support.cmap.format0Size = 262;

    // we need subtable 12 only if found unicodes with > 2 bytes.
    const hasGLyphsOver2Bytes = unicodes2Bytes.some((glyph) => glyph.unicode > 0xFFFF);

    if (hasGLyphsOver2Bytes) {
        ttf.support.cmap.hasGLyphsOver2Bytes = hasGLyphsOver2Bytes;

        const unicodes4Bytes = glyfUnicodes;

        ttf.support.cmap.format12Segments = getSegments(unicodes4Bytes);
        ttf.support.cmap.format12Size = 16
            + ttf.support.cmap.format12Segments.length * 12;
    }

    const size = 4 + (hasGLyphsOver2Bytes ? 32 : 24) // cmap header
        + ttf.support.cmap.format0Size // format 0
        + ttf.support.cmap.format4Size // format 4
        + (hasGLyphsOver2Bytes ? ttf.support.cmap.format12Size : 0); // format 12

    return size;
}



/***/ }),
/* 47 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _enum_nameId__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48);
/* harmony import */ var _util_string__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12);
/* harmony import */ var _enum_platform__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(49);
/* harmony import */ var _enum_encoding__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50);
/**
 * @file name表
 * @author mengke01(kekee000@gmail.com)
 */







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'name',
    [],
    {

        read(reader) {
            let offset = this.offset;
            reader.seek(offset);

            const nameTbl = {};
            nameTbl.format = reader.readUint16();
            nameTbl.count = reader.readUint16();
            nameTbl.stringOffset = reader.readUint16();

            const nameRecordTbl = [];
            const count = nameTbl.count;
            let i;
            let nameRecord;

            for (i = 0; i < count; ++i) {
                nameRecord = {};
                nameRecord.platform = reader.readUint16();
                nameRecord.encoding = reader.readUint16();
                nameRecord.language = reader.readUint16();
                nameRecord.nameId = reader.readUint16();
                nameRecord.length = reader.readUint16();
                nameRecord.offset = reader.readUint16();
                nameRecordTbl.push(nameRecord);
            }

            offset += nameTbl.stringOffset;

            // 读取字符名字
            for (i = 0; i < count; ++i) {
                nameRecord = nameRecordTbl[i];
                nameRecord.name = reader.readBytes(offset + nameRecord.offset, nameRecord.length);
            }

            const names = {};

            // mac 下的english name
            let platform = _enum_platform__WEBPACK_IMPORTED_MODULE_3__.default.Macintosh;
            let encoding = _enum_encoding__WEBPACK_IMPORTED_MODULE_4__.mac.Default;
            let language = 0;

            // 如果有windows 下的 english，则用windows下的 name
            if (nameRecordTbl.some((record) => record.platform === _enum_platform__WEBPACK_IMPORTED_MODULE_3__.default.Microsoft
                    && record.encoding === _enum_encoding__WEBPACK_IMPORTED_MODULE_4__.win.UCS2
                    && record.language === 1033)) {
                platform = _enum_platform__WEBPACK_IMPORTED_MODULE_3__.default.Microsoft;
                encoding = _enum_encoding__WEBPACK_IMPORTED_MODULE_4__.win.UCS2;
                language = 1033;
            }

            for (i = 0; i < count; ++i) {
                nameRecord = nameRecordTbl[i];
                if (nameRecord.platform === platform
                    && nameRecord.encoding === encoding
                    && nameRecord.language === language
                    && _enum_nameId__WEBPACK_IMPORTED_MODULE_1__.default[nameRecord.nameId]) {
                    names[_enum_nameId__WEBPACK_IMPORTED_MODULE_1__.default[nameRecord.nameId]] = language === 0
                        ? _util_string__WEBPACK_IMPORTED_MODULE_2__.default.getUTF8String(nameRecord.name)
                        : _util_string__WEBPACK_IMPORTED_MODULE_2__.default.getUCS2String(nameRecord.name);
                }
            }

            return names;
        },

        write(writer, ttf) {
            const nameRecordTbl = ttf.support.name;

            writer.writeUint16(0); // format
            writer.writeUint16(nameRecordTbl.length); // count
            writer.writeUint16(6 + nameRecordTbl.length * 12); // string offset

            // write name tbl header
            let offset = 0;
            nameRecordTbl.forEach((nameRecord) => {
                writer.writeUint16(nameRecord.platform);
                writer.writeUint16(nameRecord.encoding);
                writer.writeUint16(nameRecord.language);
                writer.writeUint16(nameRecord.nameId);
                writer.writeUint16(nameRecord.name.length);
                writer.writeUint16(offset); // offset
                offset += nameRecord.name.length;
            });

            // write name tbl strings
            nameRecordTbl.forEach((nameRecord) => {
                writer.writeBytes(nameRecord.name);
            });

            return writer;
        },

        size(ttf) {
            const names = ttf.name;
            let nameRecordTbl = [];

            // 写入name信息
            // 这里为了简化书写，仅支持英文编码字符，
            // 中文编码字符将被转化成url encode
            let size = 6;
            Object.keys(names).forEach((name) => {
                const id = _enum_nameId__WEBPACK_IMPORTED_MODULE_1__.default.names[name];

                const utf8Bytes = _util_string__WEBPACK_IMPORTED_MODULE_2__.default.toUTF8Bytes(names[name]);
                const usc2Bytes = _util_string__WEBPACK_IMPORTED_MODULE_2__.default.toUCS2Bytes(names[name]);

                if (undefined !== id) {
                    // mac
                    nameRecordTbl.push({
                        nameId: id,
                        platform: 1,
                        encoding: 0,
                        language: 0,
                        name: utf8Bytes
                    });

                    // windows
                    nameRecordTbl.push({
                        nameId: id,
                        platform: 3,
                        encoding: 1,
                        language: 1033,
                        name: usc2Bytes
                    });

                    // 子表大小
                    size += 12 * 2 + utf8Bytes.length + usc2Bytes.length;
                }
            });

            const namingOrder = ['platform', 'encoding', 'language', 'nameId'];
            nameRecordTbl = nameRecordTbl.sort((a, b) => {
                let l = 0;
                namingOrder.some(name => {
                    const o = a[name] - b[name];
                    if (o) {
                        l = o;
                        return true;
                    }
                    return false;
                });
                return l;
            });

            // 保存预处理信息
            ttf.support.name = nameRecordTbl;

            return size;
        }
    }
));


/***/ }),
/* 48 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file ttf `name`编码表
 * @author mengke01(kekee000@gmail.com)
 */

const nameId = {
    0: 'copyright',
    1: 'fontFamily',
    2: 'fontSubFamily',
    3: 'uniqueSubFamily',
    4: 'fullName',
    5: 'version',
    6: 'postScriptName',
    7: 'tradeMark',
    8: 'manufacturer',
    9: 'designer',
    10: 'description',
    11: 'urlOfFontVendor',
    12: 'urlOfFontDesigner',
    13: 'licence',
    14: 'urlOfLicence',
    16: 'preferredFamily',
    17: 'preferredSubFamily',
    18: 'compatibleFull',
    19: 'sampleText'
};

// 反转names
const nameIdHash = {};
Object.keys(nameId).forEach(id => {
    nameIdHash[nameId[id]] = +id;
});

nameId.names = nameIdHash;

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (nameId);


/***/ }),
/* 49 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file 字体所属平台
 * @author mengke01(kekee000@gmail.com)
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    Unicode: 0,
    Macintosh: 1, // mac
    reserved: 2,
    Microsoft: 3 // win
});


/***/ }),
/* 50 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mac": () => (/* binding */ mac),
/* harmony export */   "win": () => (/* binding */ win)
/* harmony export */ });
/**
 * @file Unicode Platform-specific Encoding Identifiers
 * @author mengke01(kekee000@gmail.com)
 */
// mac encoding id
const mac = {
    'Default': 0, // default use
    'Version1.1': 1,
    'ISO10646': 2,
    'UnicodeBMP': 3,
    'UnicodenonBMP': 4,
    'UnicodeVariationSequences': 5,
    'FullUnicodecoverage': 6
};

// windows encoding id
const win = {
    Symbol: 0,
    UCS2: 1, // default use
    ShiftJIS: 2,
    PRC: 3,
    BigFive: 4,
    Johab: 5,
    UCS4: 6
};



/***/ }),
/* 51 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _struct__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38);
/**
 * @file hhea 表
 * @author mengke01(kekee000@gmail.com)
 *
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6hhea.html
 */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'hhea',
    [
        ['version', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Fixed],
        ['ascent', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['descent', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['lineGap', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['advanceWidthMax', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['minLeftSideBearing', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['minRightSideBearing', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['xMaxExtent', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['caretSlopeRise', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['caretSlopeRun', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['caretOffset', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['reserved0', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['reserved1', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['reserved2', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['reserved3', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['metricDataFormat', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['numOfLongHorMetrics', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16]
    ]
));


/***/ }),
/* 52 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/**
 * @file hmtx 表
 * @author mengke01(kekee000@gmail.com)
 *
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6hmtx.html
 */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'hmtx',
    [],
    {

        read(reader, ttf) {
            const offset = this.offset;
            reader.seek(offset);

            const numOfLongHorMetrics = ttf.hhea.numOfLongHorMetrics;
            const hMetrics = [];
            let i;
            let hMetric;
            for (i = 0; i < numOfLongHorMetrics; ++i) {
                hMetric = {};
                hMetric.advanceWidth = reader.readUint16();
                hMetric.leftSideBearing = reader.readInt16();
                hMetrics.push(hMetric);
            }

            // 最后一个宽度
            const advanceWidth = hMetrics[numOfLongHorMetrics - 1].advanceWidth;
            const numOfLast = ttf.maxp.numGlyphs - numOfLongHorMetrics;

            // 获取后续的hmetrics
            for (i = 0; i < numOfLast; ++i) {
                hMetric = {};
                hMetric.advanceWidth = advanceWidth;
                hMetric.leftSideBearing = reader.readInt16();
                hMetrics.push(hMetric);
            }

            return hMetrics;

        },

        write(writer, ttf) {
            let i;
            const numOfLongHorMetrics = ttf.hhea.numOfLongHorMetrics;
            for (i = 0; i < numOfLongHorMetrics; ++i) {
                writer.writeUint16(ttf.glyf[i].advanceWidth);
                writer.writeInt16(ttf.glyf[i].leftSideBearing);
            }

            // 最后一个宽度
            const numOfLast = ttf.glyf.length - numOfLongHorMetrics;

            for (i = 0; i < numOfLast; ++i) {
                writer.writeInt16(ttf.glyf[numOfLongHorMetrics + i].leftSideBearing);
            }

            return writer;
        },

        size(ttf) {

            // 计算同最后一个advanceWidth相等的元素个数
            let numOfLast = 0;
            // 最后一个advanceWidth
            const advanceWidth = ttf.glyf[ttf.glyf.length - 1].advanceWidth;

            for (let i = ttf.glyf.length - 2; i >= 0; i--) {
                if (advanceWidth === ttf.glyf[i].advanceWidth) {
                    numOfLast++;
                }
                else {
                    break;
                }
            }

            ttf.hhea.numOfLongHorMetrics = ttf.glyf.length - numOfLast;

            return 4 * ttf.hhea.numOfLongHorMetrics + 2 * numOfLast;
        }
    }
));


/***/ }),
/* 53 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _struct__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38);
/* harmony import */ var _util_string__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12);
/* harmony import */ var _enum_unicodeName__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13);
/**
 * @file post 表
 * @author mengke01(kekee000@gmail.com)
 *
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6post.html
 */






const Posthead = _table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'posthead',
    [
        ['format', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Fixed],
        ['italicAngle', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Fixed],
        ['underlinePosition', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['underlineThickness', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['isFixedPitch', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['minMemType42', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['maxMemType42', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['minMemType1', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['maxMemType1', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32]
    ]
);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'post',
    [],
    {

        read(reader, ttf) {
            const format = reader.readFixed(this.offset);
            // 读取表头
            const tbl = new Posthead(this.offset).read(reader, ttf);

            // format2
            if (format === 2) {
                const numberOfGlyphs = reader.readUint16();
                const glyphNameIndex = [];

                for (let i = 0; i < numberOfGlyphs; ++i) {
                    glyphNameIndex.push(reader.readUint16());
                }

                const pascalStringOffset = reader.offset;
                const pascalStringLength = ttf.tables.post.length - (pascalStringOffset - this.offset);
                const pascalStringBytes = reader.readBytes(reader.offset, pascalStringLength);

                tbl.nameIndex = glyphNameIndex; // 设置glyf名字索引
                tbl.names = _util_string__WEBPACK_IMPORTED_MODULE_2__.default.getPascalString(pascalStringBytes); // glyf名字数组
            }
            // deprecated
            else if (format === 2.5) {
                tbl.format = 3;
            }

            return tbl;
        },

        write(writer, ttf) {


            const post = ttf.post || {
                format: 3
            };

            // write header
            writer.writeFixed(post.format); // format
            writer.writeFixed(post.italicAngle || 0); // italicAngle
            writer.writeInt16(post.underlinePosition || 0); // underlinePosition
            writer.writeInt16(post.underlineThickness || 0); // underlineThickness
            writer.writeUint32(post.isFixedPitch || 0); // isFixedPitch
            writer.writeUint32(post.minMemType42 || 0); // minMemType42
            writer.writeUint32(post.maxMemType42 || 0); // maxMemType42
            writer.writeUint32(post.minMemType1 || 0); // minMemType1
            writer.writeUint32(post.maxMemType1 || 0); // maxMemType1

            // version 3 不设置post信息
            if (post.format === 2) {
                const numberOfGlyphs = ttf.glyf.length;
                writer.writeUint16(numberOfGlyphs); // numberOfGlyphs
                // write glyphNameIndex
                const nameIndex = ttf.support.post.nameIndex;
                for (let i = 0, l = nameIndex.length; i < l; i++) {
                    writer.writeUint16(nameIndex[i]);
                }

                // write names
                ttf.support.post.names.forEach((name) => {
                    writer.writeBytes(name);
                });
            }
        },

        size(ttf) {

            const numberOfGlyphs = ttf.glyf.length;
            ttf.post = ttf.post || {};
            ttf.post.format = ttf.post.format || 3;
            ttf.post.maxMemType1 = numberOfGlyphs;

            // version 3 不设置post信息
            if (ttf.post.format === 3 || ttf.post.format === 1) {
                return 32;
            }

            // version 2
            let size = 34 + numberOfGlyphs * 2; // header + numberOfGlyphs + numberOfGlyphs * 2
            const glyphNames = [];
            const nameIndexArr = [];
            let nameIndex = 0;

            // 获取 name的大小
            for (let i = 0; i < numberOfGlyphs; i++) {
                // .notdef
                if (i === 0) {
                    nameIndexArr.push(0);
                }
                else {
                    const glyf = ttf.glyf[i];
                    const unicode = glyf.unicode ? glyf.unicode[0] : 0;
                    const unicodeNameIndex = _enum_unicodeName__WEBPACK_IMPORTED_MODULE_3__.default[unicode];
                    if (undefined !== unicodeNameIndex) {
                        nameIndexArr.push(unicodeNameIndex);
                    }
                    else {
                        // 这里需要注意，"" 有可能是"\3" length不为0，但是是空字符串
                        const name = glyf.name;
                        if (!name || name.charCodeAt(0) < 32) {
                            nameIndexArr.push(258 + nameIndex++);
                            glyphNames.push([0]);
                            size++;
                        }
                        else {
                            nameIndexArr.push(258 + nameIndex++);
                            const bytes = _util_string__WEBPACK_IMPORTED_MODULE_2__.default.toPascalStringBytes(name); // pascal string bytes
                            glyphNames.push(bytes);
                            size += bytes.length;
                        }
                    }
                }
            }

            ttf.support.post = {
                nameIndex: nameIndexArr,
                names: glyphNames
            };

            return size;
        }
    }
));


/***/ }),
/* 54 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _struct__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38);
/**
 * @file OS/2表
 * @author mengke01(kekee000@gmail.com)
 *
 * http://www.microsoft.com/typography/otspec/os2.htm
 */




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'OS/2',
    [
        ['version', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],

        ['xAvgCharWidth', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['usWeightClass', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['usWidthClass', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],

        ['fsType', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],

        ['ySubscriptXSize', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['ySubscriptYSize', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['ySubscriptXOffset', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['ySubscriptYOffset', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],

        ['ySuperscriptXSize', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['ySuperscriptYSize', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['ySuperscriptXOffset', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['ySuperscriptYOffset', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],

        ['yStrikeoutSize', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['yStrikeoutPosition', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],

        ['sFamilyClass', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],

        // Panose
        ['bFamilyType', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],
        ['bSerifStyle', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],
        ['bWeight', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],
        ['bProportion', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],
        ['bContrast', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],
        ['bStrokeVariation', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],
        ['bArmStyle', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],
        ['bLetterform', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],
        ['bMidline', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],
        ['bXHeight', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint8],

        // unicode range
        ['ulUnicodeRange1', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['ulUnicodeRange2', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['ulUnicodeRange3', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['ulUnicodeRange4', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],

        // char 4
        ['achVendID', _struct__WEBPACK_IMPORTED_MODULE_1__.default.String, 4],

        ['fsSelection', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['usFirstCharIndex', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['usLastCharIndex', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],

        ['sTypoAscender', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['sTypoDescender', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['sTypoLineGap', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],

        ['usWinAscent', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['usWinDescent', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        // version 0 above 39

        ['ulCodePageRange1', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        ['ulCodePageRange2', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32],
        // version 1 above 41

        ['sxHeight', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],
        ['sCapHeight', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Int16],

        ['usDefaultChar', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['usBreakChar', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16],
        ['usMaxContext', _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16]
        // version 2,3,4 above 46
    ],
    {

        read(reader, ttf) {
            const format = reader.readUint16(this.offset);
            let struct = this.struct;

            // format2
            if (format === 0) {
                struct = struct.slice(0, 39);
            }
            else if (format === 1) {
                struct = struct.slice(0, 41);
            }

            const OS2Head = _table__WEBPACK_IMPORTED_MODULE_0__.default.create('os2head', struct);
            const tbl = new OS2Head(this.offset).read(reader, ttf);

            // 补齐其他version的字段
            const os2Fields = {
                ulCodePageRange1: 1,
                ulCodePageRange2: 0,
                sxHeight: 0,
                sCapHeight: 0,
                usDefaultChar: 0,
                usBreakChar: 32,
                usMaxContext: 0
            };

            return Object.assign(os2Fields, tbl);
        },

        size(ttf) {

            // 更新其他表的统计信息
            // header
            let xMin = 16384;
            let yMin = 16384;
            let xMax = -16384;
            let yMax = -16384;

            // hhea
            let advanceWidthMax = -1;
            let minLeftSideBearing = 16384;
            let minRightSideBearing = 16384;
            let xMaxExtent = -16384;

            // os2 count
            let xAvgCharWidth = 0;
            let usFirstCharIndex = 0x10FFFF;
            let usLastCharIndex = -1;

            // maxp
            let maxPoints = 0;
            let maxContours = 0;
            let maxCompositePoints = 0;
            let maxCompositeContours = 0;
            let maxSizeOfInstructions = 0;
            let maxComponentElements = 0;

            let glyfNotEmpty = 0; // 非空glyf
            const hinting = ttf.writeOptions ? ttf.writeOptions.hinting : false;

            // 计算instructions和functiondefs
            if (hinting) {

                if (ttf.cvt) {
                    maxSizeOfInstructions = Math.max(maxSizeOfInstructions, ttf.cvt.length);
                }

                if (ttf.prep) {
                    maxSizeOfInstructions = Math.max(maxSizeOfInstructions, ttf.prep.length);
                }

                if (ttf.fpgm) {
                    maxSizeOfInstructions = Math.max(maxSizeOfInstructions, ttf.fpgm.length);
                }

            }


            ttf.glyf.forEach((glyf) => {

                // 统计control point信息
                if (glyf.compound) {
                    let compositeContours = 0;
                    let compositePoints = 0;
                    glyf.glyfs.forEach((g) => {
                        const cglyf = ttf.glyf[g.glyphIndex];
                        if (!cglyf) {
                            return;
                        }
                        compositeContours += cglyf.contours ? cglyf.contours.length : 0;
                        if (cglyf.contours && cglyf.contours.length) {
                            cglyf.contours.forEach((contour) => {
                                compositePoints += contour.length;
                            });
                        }
                    });

                    maxComponentElements++;
                    maxCompositePoints = Math.max(maxCompositePoints, compositePoints);
                    maxCompositeContours = Math.max(maxCompositeContours, compositeContours);
                }
                // 简单图元
                else if (glyf.contours && glyf.contours.length) {
                    maxContours = Math.max(maxContours, glyf.contours.length);

                    let points = 0;
                    glyf.contours.forEach((contour) => {
                        points += contour.length;
                    });
                    maxPoints = Math.max(maxPoints, points);
                }

                if (hinting && glyf.instructions) {
                    maxSizeOfInstructions = Math.max(maxSizeOfInstructions, glyf.instructions.length);
                }

                // 统计边界信息
                if (glyf.xMin < xMin) {
                    xMin = glyf.xMin;
                }

                if (glyf.yMin < yMin) {
                    yMin = glyf.yMin;
                }

                if (glyf.xMax > xMax) {
                    xMax = glyf.xMax;
                }

                if (glyf.yMax > yMax) {
                    yMax = glyf.yMax;
                }

                advanceWidthMax = Math.max(advanceWidthMax, glyf.advanceWidth);
                minLeftSideBearing = Math.min(minLeftSideBearing, glyf.leftSideBearing);
                minRightSideBearing = Math.min(minRightSideBearing, glyf.advanceWidth - glyf.xMax);
                xMaxExtent = Math.max(xMaxExtent, glyf.xMax);

                xAvgCharWidth += glyf.advanceWidth;

                glyfNotEmpty++;

                let unicodes = glyf.unicode;

                if (typeof glyf.unicode === 'number') {
                    unicodes = [glyf.unicode];
                }

                if (Array.isArray(unicodes)) {
                    unicodes.forEach((unicode) => {
                        if (unicode !== 0xFFFF) {
                            usFirstCharIndex = Math.min(usFirstCharIndex, unicode);
                            usLastCharIndex = Math.max(usLastCharIndex, unicode);
                        }
                    });
                }
            });

            // 重新设置version 4
            ttf['OS/2'].version = 0x4;
            ttf['OS/2'].achVendID = (ttf['OS/2'].achVendID + '    ').slice(0, 4);
            ttf['OS/2'].xAvgCharWidth = xAvgCharWidth / (glyfNotEmpty || 1);
            ttf['OS/2'].ulUnicodeRange2 = 268435456;
            ttf['OS/2'].usFirstCharIndex = usFirstCharIndex;
            ttf['OS/2'].usLastCharIndex = usLastCharIndex;

            // rewrite hhea
            ttf.hhea.version = ttf.hhea.version || 0x1;
            ttf.hhea.advanceWidthMax = advanceWidthMax;
            ttf.hhea.minLeftSideBearing = minLeftSideBearing;
            ttf.hhea.minRightSideBearing = minRightSideBearing;
            ttf.hhea.xMaxExtent = xMaxExtent;

            // rewrite head
            ttf.head.version = ttf.head.version || 0x1;
            ttf.head.lowestRecPPEM = ttf.head.lowestRecPPEM || 0x8;
            ttf.head.xMin = xMin;
            ttf.head.yMin = yMin;
            ttf.head.xMax = xMax;
            ttf.head.yMax = yMax;

            // head rewrite
            if (ttf.support.head) {
                const {xMin, yMin, xMax, yMax} = ttf.support.head;
                if (xMin != null) {
                    ttf.head.xMin = xMin;
                }
                if (yMin != null) {
                    ttf.head.yMin = yMin;
                }
                if (xMax != null) {
                    ttf.head.xMax = xMax;
                }
                if (yMax != null) {
                    ttf.head.yMax = yMax;
                }

            }
            // hhea rewrite
            if (ttf.support.hhea) {
                const {advanceWidthMax, xMaxExtent, minLeftSideBearing, minRightSideBearing} = ttf.support.hhea;
                if (advanceWidthMax != null) {
                    ttf.hhea.advanceWidthMax = advanceWidthMax;
                }
                if (xMaxExtent != null) {
                    ttf.hhea.xMaxExtent = xMaxExtent;
                }
                if (minLeftSideBearing != null) {
                    ttf.hhea.minLeftSideBearing = minLeftSideBearing;
                }
                if (minRightSideBearing != null) {
                    ttf.hhea.minRightSideBearing = minRightSideBearing;
                }
            }
            // 这里根据存储的maxp来设置新的maxp，避免重复计算maxp
            ttf.maxp = ttf.maxp || {};
            ttf.support.maxp = {
                version: 1.0,
                numGlyphs: ttf.glyf.length,
                maxPoints,
                maxContours,
                maxCompositePoints,
                maxCompositeContours,
                maxZones: ttf.maxp.maxZones || 0,
                maxTwilightPoints: ttf.maxp.maxTwilightPoints || 0,
                maxStorage: ttf.maxp.maxStorage || 0,
                maxFunctionDefs: ttf.maxp.maxFunctionDefs || 0,
                maxStackElements: ttf.maxp.maxStackElements || 0,
                maxSizeOfInstructions,
                maxComponentElements,
                maxComponentDepth: maxComponentElements ? 1 : 0
            };

            return _table__WEBPACK_IMPORTED_MODULE_0__.default.size.call(this, ttf);
        }
    }
));


/***/ }),
/* 55 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _util_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12);
/* harmony import */ var _cff_encoding__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(56);
/* harmony import */ var _cff_cffStandardStrings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57);
/* harmony import */ var _cff_parseCFFDict__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58);
/* harmony import */ var _cff_parseCFFGlyph__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(60);
/* harmony import */ var _cff_parseCFFCharset__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(61);
/* harmony import */ var _cff_parseCFFEncoding__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(62);
/* harmony import */ var _reader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(28);
/**
 * @file cff表
 * @author mengke01(kekee000@gmail.com)
 *
 * reference:
 * http://wwwimages.adobe.com/content/dam/Adobe/en/devnet/font/pdfs/5176.CFF.pdf
 *
 * modify from:
 * https://github.com/nodebox/opentype.js/blob/master/src/tables/cff.js
 */











/**
 * 获取cff偏移
 *
 * @param  {Reader} reader  读取器
 * @param  {number} offSize 偏移大小
 * @param  {number} offset  起始偏移
 * @return {number}         偏移
 */
function getOffset(reader, offSize) {
    let v = 0;
    for (let i = 0; i < offSize; i++) {
        v <<= 8;
        v += reader.readUint8();
    }
    return v;
}

/**
 * 解析cff表头部
 *
 * @param  {Reader} reader 读取器
 * @return {Object}        头部字段
 */
function parseCFFHead(reader) {
    const head = {};
    head.startOffset = reader.offset;
    head.endOffset = head.startOffset + 4;
    head.formatMajor = reader.readUint8();
    head.formatMinor = reader.readUint8();
    head.size = reader.readUint8();
    head.offsetSize = reader.readUint8();
    return head;
}

/**
 * 解析`CFF`表索引
 *
 * @param  {Reader} reader       读取器
 * @param  {number} offset       偏移
 * @param  {Funciton} conversionFn 转换函数
 * @return {Object}              表对象
 */
function parseCFFIndex(reader, offset, conversionFn) {
    if (offset) {
        reader.seek(offset);
    }
    const start = reader.offset;
    const offsets = [];
    const objects = [];
    const count = reader.readUint16();
    let i;
    let l;
    if (count !== 0) {
        const offsetSize = reader.readUint8();
        for (i = 0, l = count + 1; i < l; i++) {
            offsets.push(getOffset(reader, offsetSize));
        }

        for (i = 0, l = count; i < l; i++) {
            let value = reader.readBytes(offsets[i + 1] - offsets[i]);
            if (conversionFn) {
                value = conversionFn(value);
            }
            objects.push(value);
        }
    }

    return {
        objects,
        startOffset: start,
        endOffset: reader.offset
    };
}

// Subroutines are encoded using the negative half of the number space.
// See type 2 chapter 4.7 "Subroutine operators".
function calcCFFSubroutineBias(subrs) {
    let bias;
    if (subrs.length < 1240) {
        bias = 107;
    }
    else if (subrs.length < 33900) {
        bias = 1131;
    }
    else {
        bias = 32768;
    }

    return bias;
}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'cff',
    [],
    {
        read(reader, font) {

            const offset = this.offset;
            reader.seek(offset);

            const head = parseCFFHead(reader);
            const nameIndex = parseCFFIndex(reader, head.endOffset, _util_string__WEBPACK_IMPORTED_MODULE_1__.default.getString);
            const topDictIndex = parseCFFIndex(reader, nameIndex.endOffset);
            const stringIndex = parseCFFIndex(reader, topDictIndex.endOffset, _util_string__WEBPACK_IMPORTED_MODULE_1__.default.getString);
            const globalSubrIndex = parseCFFIndex(reader, stringIndex.endOffset);

            const cff = {
                head
            };

            // 全局子glyf数据
            cff.gsubrs = globalSubrIndex.objects;
            cff.gsubrsBias = calcCFFSubroutineBias(globalSubrIndex.objects);

            // 顶级字典数据
            const dictReader = new _reader__WEBPACK_IMPORTED_MODULE_8__.default(new Uint8Array(topDictIndex.objects[0]).buffer);
            const topDict = _cff_parseCFFDict__WEBPACK_IMPORTED_MODULE_4__.default.parseTopDict(
                dictReader,
                0,
                dictReader.length,
                stringIndex.objects
            );
            cff.topDict = topDict;

            // 私有字典数据
            const privateDictLength = topDict.private[0];
            let privateDict = {};
            let privateDictOffset;
            if (privateDictLength) {
                privateDictOffset = offset + topDict.private[1];
                privateDict = _cff_parseCFFDict__WEBPACK_IMPORTED_MODULE_4__.default.parsePrivateDict(
                    reader,
                    privateDictOffset,
                    privateDictLength,
                    stringIndex.objects
                );
                cff.defaultWidthX = privateDict.defaultWidthX;
                cff.nominalWidthX = privateDict.nominalWidthX;
            }
            else {
                cff.defaultWidthX = 0;
                cff.nominalWidthX = 0;
            }

            // 私有子glyf数据
            if (privateDict.subrs) {
                const subrOffset = privateDictOffset + privateDict.subrs;
                const subrIndex = parseCFFIndex(reader, subrOffset);
                cff.subrs = subrIndex.objects;
                cff.subrsBias = calcCFFSubroutineBias(cff.subrs);
            }
            else {
                cff.subrs = [];
                cff.subrsBias = 0;
            }
            cff.privateDict = privateDict;

            // 解析glyf数据和名字
            const charStringsIndex = parseCFFIndex(reader, offset + topDict.charStrings);
            const nGlyphs = charStringsIndex.objects.length;

            if (topDict.charset < 3) {
                // @author: fr33z00
                // See end of chapter 13 (p22) of #5176.CFF.pdf :
                // Still more optimization is possible by
                // observing that many fonts adopt one of 3 common charsets. In
                // these cases the operand to the charset operator in the Top DICT
                // specifies a predefined charset id, in place of an offset, as shown in table 22
                cff.charset = _cff_cffStandardStrings__WEBPACK_IMPORTED_MODULE_3__.default;
            }
            else {
                cff.charset = (0,_cff_parseCFFCharset__WEBPACK_IMPORTED_MODULE_6__.default)(reader, offset + topDict.charset, nGlyphs, stringIndex.objects);
            }

            // Standard encoding
            if (topDict.encoding === 0) {
                cff.encoding = _cff_encoding__WEBPACK_IMPORTED_MODULE_2__.default.standardEncoding;
            }
            // Expert encoding
            else if (topDict.encoding === 1) {
                cff.encoding = _cff_encoding__WEBPACK_IMPORTED_MODULE_2__.default.expertEncoding;
            }
            else {
                cff.encoding = (0,_cff_parseCFFEncoding__WEBPACK_IMPORTED_MODULE_7__.default)(reader, offset + topDict.encoding);
            }

            cff.glyf = [];

            // only parse subset glyphs
            const subset = font.readOptions.subset;
            if (subset && subset.length > 0) {

                // subset map
                const subsetMap = {
                    0: true // 设置.notdef
                };
                const codes = font.cmap;

                // unicode to index
                Object.keys(codes).forEach((c) => {
                    if (subset.indexOf(+c) > -1) {
                        const i = codes[c];
                        subsetMap[i] = true;
                    }
                });
                font.subsetMap = subsetMap;

                Object.keys(subsetMap).forEach((i) => {
                    i = +i;
                    const glyf = (0,_cff_parseCFFGlyph__WEBPACK_IMPORTED_MODULE_5__.default)(charStringsIndex.objects[i], cff, i);
                    glyf.name = cff.charset[i];
                    cff.glyf[i] = glyf;
                });
            }
            // parse all
            else {
                for (let i = 0, l = nGlyphs; i < l; i++) {
                    const glyf = (0,_cff_parseCFFGlyph__WEBPACK_IMPORTED_MODULE_5__.default)(charStringsIndex.objects[i], cff, i);
                    glyf.name = cff.charset[i];
                    cff.glyf.push(glyf);
                }
            }

            return cff;
        },

        // eslint-disable-next-line no-unused-vars
        write(writer, font) {
            throw new Error('not support write cff table');
        },

        // eslint-disable-next-line no-unused-vars
        size(font) {
            throw new Error('not support get cff table size');
        }
    }
));


/***/ }),
/* 56 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file cff名字设置
 * @author mengke01(kekee000@gmail.com)
 */


const cffStandardEncoding = [
    '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    'space', 'exclam', 'quotedbl', 'numbersign', 'dollar', 'percent', 'ampersand', 'quoteright',
    'parenleft', 'parenright', 'asterisk', 'plus', 'comma', 'hyphen',
    'period', 'slash', 'zero', 'one', 'two',
    'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'colon', 'semicolon', 'less', 'equal', 'greater',
    'question', 'at', 'A', 'B', 'C', 'D', 'E', 'F',
    'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
    'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'bracketleft',
    'backslash', 'bracketright', 'asciicircum', 'underscore',
    'quoteleft', 'a', 'b', 'c', 'd', 'e', 'f', 'g',
    'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z', 'braceleft', 'bar',
    'braceright', 'asciitilde', '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    'exclamdown', 'cent', 'sterling', 'fraction', 'yen', 'florin', 'section', 'currency', 'quotesingle',
    'quotedblleft', 'guillemotleft', 'guilsinglleft', 'guilsinglright', 'fi', 'fl', '', 'endash', 'dagger',
    'daggerdbl', 'periodcentered', '', 'paragraph', 'bullet', 'quotesinglbase', 'quotedblbase', 'quotedblright',
    'guillemotright', 'ellipsis', 'perthousand', '',
    'questiondown', '', 'grave', 'acute', 'circumflex', 'tilde',
    'macron', 'breve', 'dotaccent', 'dieresis', '',
    'ring', 'cedilla', '', 'hungarumlaut', 'ogonek', 'caron',
    'emdash', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    'AE', '', 'ordfeminine', '', '', '',
    '', 'Lslash', 'Oslash', 'OE', 'ordmasculine', '', '', '', '', '', 'ae', '', '', '', 'dotlessi', '', '',
    'lslash', 'oslash', 'oe', 'germandbls'
];

const cffExpertEncoding = [
    '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    '', '', '', '', 'space', 'exclamsmall', 'Hungarumlautsmall', '', 'dollaroldstyle', 'dollarsuperior',
    'ampersandsmall', 'Acutesmall', 'parenleftsuperior',
    'parenrightsuperior', 'twodotenleader', 'onedotenleader',
    'comma', 'hyphen', 'period', 'fraction', 'zerooldstyle', 'oneoldstyle', 'twooldstyle', 'threeoldstyle',
    'fouroldstyle', 'fiveoldstyle', 'sixoldstyle', 'sevenoldstyle', 'eightoldstyle', 'nineoldstyle', 'colon',
    'semicolon', 'commasuperior', 'threequartersemdash', 'periodsuperior', 'questionsmall', '', 'asuperior',
    'bsuperior', 'centsuperior', 'dsuperior', 'esuperior',
    '', '', 'isuperior', '', '', 'lsuperior', 'msuperior',
    'nsuperior', 'osuperior', '', '', 'rsuperior', 'ssuperior', 'tsuperior', '', 'ff', 'fi', 'fl', 'ffi', 'ffl',
    'parenleftinferior', '', 'parenrightinferior', 'Circumflexsmall', 'hyphensuperior', 'Gravesmall', 'Asmall',
    'Bsmall', 'Csmall', 'Dsmall', 'Esmall', 'Fsmall', 'Gsmall',
    'Hsmall', 'Ismall', 'Jsmall', 'Ksmall', 'Lsmall',
    'Msmall', 'Nsmall', 'Osmall', 'Psmall', 'Qsmall', 'Rsmall',
    'Ssmall', 'Tsmall', 'Usmall', 'Vsmall', 'Wsmall',
    'Xsmall', 'Ysmall', 'Zsmall', 'colonmonetary', 'onefitted', 'rupiah', 'Tildesmall',
    '', '', '', '', '', '', '',
    '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
    'exclamdownsmall', 'centoldstyle', 'Lslashsmall', '', '', 'Scaronsmall', 'Zcaronsmall', 'Dieresissmall',
    'Brevesmall', 'Caronsmall', '', 'Dotaccentsmall', '', '',
    'Macronsmall', '', '', 'figuredash', 'hypheninferior',
    '', '', 'Ogoneksmall', 'Ringsmall', 'Cedillasmall', '', '', '', 'onequarter', 'onehalf', 'threequarters',
    'questiondownsmall', 'oneeighth', 'threeeighths',
    'fiveeighths', 'seveneighths', 'onethird', 'twothirds', '',
    '', 'zerosuperior', 'onesuperior', 'twosuperior', 'threesuperior', 'foursuperior', 'fivesuperior',
    'sixsuperior', 'sevensuperior', 'eightsuperior',
    'ninesuperior', 'zeroinferior', 'oneinferior', 'twoinferior',
    'threeinferior', 'fourinferior', 'fiveinferior', 'sixinferior', 'seveninferior', 'eightinferior',
    'nineinferior', 'centinferior', 'dollarinferior', 'periodinferior', 'commainferior', 'Agravesmall',
    'Aacutesmall', 'Acircumflexsmall', 'Atildesmall',
    'Adieresissmall', 'Aringsmall', 'AEsmall', 'Ccedillasmall',
    'Egravesmall', 'Eacutesmall', 'Ecircumflexsmall', 'Edieresissmall', 'Igravesmall', 'Iacutesmall',
    'Icircumflexsmall', 'Idieresissmall', 'Ethsmall', 'Ntildesmall', 'Ogravesmall', 'Oacutesmall',
    'Ocircumflexsmall', 'Otildesmall', 'Odieresissmall',
    'OEsmall', 'Oslashsmall', 'Ugravesmall', 'Uacutesmall',
    'Ucircumflexsmall', 'Udieresissmall', 'Yacutesmall', 'Thornsmall', 'Ydieresissmall'
];



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    standardEncoding: cffStandardEncoding,
    expertEncoding: cffExpertEncoding
});


/***/ }),
/* 57 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file cffStandardStrings.js
 * @author mengke01(kekee000@gmail.com)
 */
const cffStandardStrings = [
    '.notdef', 'space', 'exclam', 'quotedbl', 'numbersign', 'dollar', 'percent', 'ampersand', 'quoteright',
    'parenleft', 'parenright', 'asterisk', 'plus', 'comma', 'hyphen', 'period', 'slash', 'zero', 'one', 'two',
    'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'colon', 'semicolon', 'less', 'equal', 'greater',
    'question', 'at', 'A', 'B', 'C', 'D', 'E',
    'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
    'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'bracketleft', 'backslash', 'bracketright', 'asciicircum', 'underscore',
    'quoteleft', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
    'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z', 'braceleft', 'bar', 'braceright',
    'asciitilde', 'exclamdown', 'cent', 'sterling',
    'fraction', 'yen', 'florin', 'section', 'currency', 'quotesingle', 'quotedblleft', 'guillemotleft',
    'guilsinglleft', 'guilsinglright', 'fi', 'fl', 'endash', 'dagger',
    'daggerdbl', 'periodcentered', 'paragraph',
    'bullet', 'quotesinglbase', 'quotedblbase', 'quotedblright', 'guillemotright', 'ellipsis', 'perthousand',
    'questiondown', 'grave', 'acute', 'circumflex', 'tilde', 'macron', 'breve', 'dotaccent', 'dieresis', 'ring',
    'cedilla', 'hungarumlaut', 'ogonek', 'caron', 'emdash', 'AE', 'ordfeminine', 'Lslash', 'Oslash', 'OE',
    'ordmasculine', 'ae', 'dotlessi', 'lslash', 'oslash', 'oe', 'germandbls', 'onesuperior', 'logicalnot', 'mu',
    'trademark', 'Eth', 'onehalf', 'plusminus', 'Thorn', 'onequarter', 'divide', 'brokenbar', 'degree', 'thorn',
    'threequarters', 'twosuperior', 'registered', 'minus', 'eth', 'multiply', 'threesuperior', 'copyright',
    'Aacute', 'Acircumflex', 'Adieresis', 'Agrave', 'Aring', 'Atilde', 'Ccedilla', 'Eacute', 'Ecircumflex',
    'Edieresis', 'Egrave', 'Iacute', 'Icircumflex', 'Idieresis', 'Igrave', 'Ntilde', 'Oacute', 'Ocircumflex',
    'Odieresis', 'Ograve', 'Otilde', 'Scaron', 'Uacute', 'Ucircumflex', 'Udieresis', 'Ugrave', 'Yacute',
    'Ydieresis', 'Zcaron', 'aacute', 'acircumflex', 'adieresis',
    'agrave', 'aring', 'atilde', 'ccedilla', 'eacute',
    'ecircumflex', 'edieresis', 'egrave', 'iacute', 'icircumflex', 'idieresis', 'igrave', 'ntilde', 'oacute',
    'ocircumflex', 'odieresis', 'ograve', 'otilde', 'scaron', 'uacute', 'ucircumflex', 'udieresis', 'ugrave',
    'yacute', 'ydieresis', 'zcaron', 'exclamsmall', 'Hungarumlautsmall', 'dollaroldstyle', 'dollarsuperior',
    'ampersandsmall', 'Acutesmall', 'parenleftsuperior', 'parenrightsuperior', '266 ff', 'onedotenleader',
    'zerooldstyle', 'oneoldstyle', 'twooldstyle', 'threeoldstyle',
    'fouroldstyle', 'fiveoldstyle', 'sixoldstyle',
    'sevenoldstyle', 'eightoldstyle', 'nineoldstyle', 'commasuperior', 'threequartersemdash', 'periodsuperior',
    'questionsmall', 'asuperior', 'bsuperior', 'centsuperior',
    'dsuperior', 'esuperior', 'isuperior', 'lsuperior',
    'msuperior', 'nsuperior', 'osuperior', 'rsuperior', 'ssuperior', 'tsuperior', 'ff', 'ffi', 'ffl',
    'parenleftinferior', 'parenrightinferior', 'Circumflexsmall', 'hyphensuperior', 'Gravesmall', 'Asmall',
    'Bsmall', 'Csmall', 'Dsmall', 'Esmall', 'Fsmall', 'Gsmall',
    'Hsmall', 'Ismall', 'Jsmall', 'Ksmall', 'Lsmall',
    'Msmall', 'Nsmall', 'Osmall', 'Psmall', 'Qsmall', 'Rsmall',
    'Ssmall', 'Tsmall', 'Usmall', 'Vsmall', 'Wsmall',
    'Xsmall', 'Ysmall', 'Zsmall', 'colonmonetary', 'onefitted', 'rupiah', 'Tildesmall', 'exclamdownsmall',
    'centoldstyle', 'Lslashsmall', 'Scaronsmall', 'Zcaronsmall', 'Dieresissmall', 'Brevesmall', 'Caronsmall',
    'Dotaccentsmall', 'Macronsmall', 'figuredash', 'hypheninferior', 'Ogoneksmall', 'Ringsmall', 'Cedillasmall',
    'questiondownsmall', 'oneeighth', 'threeeighths', 'fiveeighths', 'seveneighths', 'onethird', 'twothirds',
    'zerosuperior', 'foursuperior', 'fivesuperior', 'sixsuperior',
    'sevensuperior', 'eightsuperior', 'ninesuperior',
    'zeroinferior', 'oneinferior', 'twoinferior', 'threeinferior',
    'fourinferior', 'fiveinferior', 'sixinferior',
    'seveninferior', 'eightinferior', 'nineinferior', 'centinferior', 'dollarinferior', 'periodinferior',
    'commainferior', 'Agravesmall', 'Aacutesmall', 'Acircumflexsmall', 'Atildesmall', 'Adieresissmall',
    'Aringsmall', 'AEsmall', 'Ccedillasmall', 'Egravesmall',
    'Eacutesmall', 'Ecircumflexsmall', 'Edieresissmall',
    'Igravesmall', 'Iacutesmall', 'Icircumflexsmall',
    'Idieresissmall', 'Ethsmall', 'Ntildesmall', 'Ogravesmall',
    'Oacutesmall', 'Ocircumflexsmall', 'Otildesmall',
    'Odieresissmall', 'OEsmall', 'Oslashsmall', 'Ugravesmall',
    'Uacutesmall', 'Ucircumflexsmall', 'Udieresissmall',
    'Yacutesmall', 'Thornsmall', 'Ydieresissmall', '001.000',
    '001.001', '001.002', '001.003', 'Black', 'Bold',
    'Book', 'Light', 'Medium', 'Regular', 'Roman', 'Semibold'
];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cffStandardStrings);


/***/ }),
/* 58 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _getCFFString__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59);
/**
 * @file 解析cffdict数据
 * @author mengke01(kekee000@gmail.com)
 */



const TOP_DICT_META = [
    {
        name: 'version',
        op: 0,
        type: 'SID'
    },
    {
        name: 'notice',
        op: 1,
        type: 'SID'
    },
    {
        name: 'copyright',
        op: 1200,
        type: 'SID'
    },
    {
        name: 'fullName',
        op: 2,
        type: 'SID'
    },
    {
        name: 'familyName',
        op: 3,
        type: 'SID'
    },
    {
        name: 'weight',
        op: 4,
        type: 'SID'
    },
    {
        name: 'isFixedPitch',
        op: 1201,
        type: 'number',
        value: 0
    },
    {
        name: 'italicAngle',
        op: 1202,
        type: 'number',
        value: 0
    },
    {
        name: 'underlinePosition',
        op: 1203,
        type: 'number',
        value: -100
    },
    {
        name: 'underlineThickness',
        op: 1204,
        type: 'number',
        value: 50
    },
    {
        name: 'paintType',
        op: 1205,
        type: 'number',
        value: 0
    },
    {
        name: 'charstringType',
        op: 1206,
        type: 'number',
        value: 2
    },
    {
        name: 'fontMatrix',
        op: 1207,
        type: ['real', 'real', 'real', 'real', 'real', 'real'],
        value: [0.001, 0, 0, 0.001, 0, 0]
    },
    {
        name: 'uniqueId',
        op: 13,
        type: 'number'
    },
    {
        name: 'fontBBox',
        op: 5,
        type: ['number', 'number', 'number', 'number'],
        value: [0, 0, 0, 0]
    },
    {
        name: 'strokeWidth',
        op: 1208,
        type: 'number',
        value: 0
    },
    {
        name: 'xuid',
        op: 14,
        type: [],
        value: null
    },
    {
        name: 'charset',
        op: 15,
        type: 'offset',
        value: 0
    },
    {
        name: 'encoding',
        op: 16,
        type: 'offset',
        value: 0
    },
    {
        name: 'charStrings',
        op: 17,
        type: 'offset',
        value: 0
    },
    {
        name: 'private',
        op: 18,
        type: ['number', 'offset'],
        value: [0, 0]
    }
];

const PRIVATE_DICT_META = [
    {
        name: 'subrs',
        op: 19,
        type: 'offset',
        value: 0
    },
    {
        name: 'defaultWidthX',
        op: 20,
        type: 'number',
        value: 0
    },
    {
        name: 'nominalWidthX',
        op: 21,
        type: 'number',
        value: 0
    }
];

function entriesToObject(entries) {
    const hash = {};

    for (let i = 0, l = entries.length; i < l; i++) {
        const key = entries[i][0];
        if (undefined !== hash[key]) {
            console.warn('dict already has key:' + key);
            continue;
        }

        const values = entries[i][1];
        hash[key] = values.length === 1 ? values[0] : values;
    }

    return hash;
}


/* eslint-disable no-constant-condition */
function parseFloatOperand(reader) {
    let s = '';
    const eof = 15;
    const lookup = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.', 'E', 'E-', null, '-'];

    while (true) {
        const b = reader.readUint8();
        const n1 = b >> 4;
        const n2 = b & 15;

        if (n1 === eof) {
            break;
        }

        s += lookup[n1];

        if (n2 === eof) {
            break;
        }

        s += lookup[n2];
    }

    return parseFloat(s);
}
/* eslint-enable no-constant-condition */

/**
 * 解析cff字典数据
 *
 * @param  {Reader} reader 读取器
 * @param  {number} b0     操作码
 * @return {number}        数据
 */
function parseOperand(reader, b0) {
    let b1;
    let b2;
    let b3;
    let b4;
    if (b0 === 28) {
        b1 = reader.readUint8();
        b2 = reader.readUint8();
        return b1 << 8 | b2;
    }

    if (b0 === 29) {
        b1 = reader.readUint8();
        b2 = reader.readUint8();
        b3 = reader.readUint8();
        b4 = reader.readUint8();
        return b1 << 24 | b2 << 16 | b3 << 8 | b4;
    }

    if (b0 === 30) {
        return parseFloatOperand(reader);
    }

    if (b0 >= 32 && b0 <= 246) {
        return b0 - 139;
    }

    if (b0 >= 247 && b0 <= 250) {
        b1 = reader.readUint8();
        return (b0 - 247) * 256 + b1 + 108;
    }

    if (b0 >= 251 && b0 <= 254) {
        b1 = reader.readUint8();
        return -(b0 - 251) * 256 - b1 - 108;
    }

    throw new Error('invalid b0 ' + b0 + ',at:' + reader.offset);
}



/**
 * 解析字典值
 *
 * @param  {Object} dict    字典数据
 * @param  {Array} meta    元数据
 * @param  {Object} strings cff字符串字典
 * @return {Object}         解析后数据
 */
function interpretDict(dict, meta, strings) {
    const newDict = {};

    // Because we also want to include missing values, we start out from the meta list
    // and lookup values in the dict.
    for (let i = 0, l = meta.length; i < l; i++) {
        const m = meta[i];
        let value = dict[m.op];
        if (value === undefined) {
            value = m.value !== undefined ? m.value : null;
        }

        if (m.type === 'SID') {
            value = (0,_getCFFString__WEBPACK_IMPORTED_MODULE_0__.default)(strings, value);
        }

        newDict[m.name] = value;
    }

    return newDict;
}


/**
 * 解析cff dict字典
 *
 * @param  {Reader} reader 读取器
 * @param  {number} offset  起始偏移
 * @param  {number} length   大小
 * @return {Object}        配置
 */
function parseCFFDict(reader, offset, length) {
    if (null != offset) {
        reader.seek(offset);
    }

    const entries = [];
    let operands = [];
    const lastOffset = reader.offset + (null != length ? length : reader.length);

    while (reader.offset < lastOffset) {
        let op = reader.readUint8();

        // The first byte for each dict item distinguishes between operator (key) and operand (value).
        // Values <= 21 are operators.
        if (op <= 21) {
            // Two-byte operators have an initial escape byte of 12.
            if (op === 12) {
                op = 1200 + reader.readUint8();
            }

            entries.push([op, operands]);
            operands = [];
        }
        else {
            // Since the operands (values) come before the operators (keys), we store all operands in a list
            // until we encounter an operator.
            operands.push(parseOperand(reader, op));
        }
    }

    return entriesToObject(entries);
}

/**
 * 解析cff top字典
 *
 * @param  {Reader} reader  读取器
 * @param  {number} start 开始offset
 * @param  {number} length 大小
 * @param  {Object} strings 字符串集合
 * @return {Object}         字典数据
 */
function parseTopDict(reader, start, length, strings) {
    const dict = parseCFFDict(reader, start || 0, length || reader.length);
    return interpretDict(dict, TOP_DICT_META, strings);
}

/**
 * 解析cff私有字典
 *
 * @param  {Reader} reader  读取器
 * @param  {number} start 开始offset
 * @param  {number} length 大小
 * @param  {Object} strings 字符串集合
 * @return {Object}         字典数据
 */
function parsePrivateDict(reader, start, length, strings) {
    const dict = parseCFFDict(reader, start || 0, length || reader.length);
    return interpretDict(dict, PRIVATE_DICT_META, strings);
}


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    parseTopDict,
    parsePrivateDict
});


/***/ }),
/* 59 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getCFFString)
/* harmony export */ });
/* harmony import */ var _cffStandardStrings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(57);
/**
 * @file 获取cff字符串
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * 根据索引获取cff字符串
 *
 * @param  {Object} strings 标准cff字符串索引
 * @param  {number} index   索引号
 * @return {number}         字符串索引
 */
function getCFFString(strings, index) {
    if (index <= 390) {
        index = _cffStandardStrings__WEBPACK_IMPORTED_MODULE_0__.default[index];
    }
    // Strings below index 392 are standard CFF strings and are not encoded in the font.
    else {
        index = strings[index - 391];
    }

    return index;
}


/***/ }),
/* 60 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ parseCFFCharstring)
/* harmony export */ });
/**
 * @file 解析cff字形
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 解析cff字形，返回直线和三次bezier曲线点数组
 *
 * @param  {Array} code  操作码
 * @param  {Object} font  相关联的font对象
 * @param  {number} index glyf索引
 * @return {Object}       glyf对象
 */
function parseCFFCharstring(code, font, index) {
    let c1x;
    let c1y;
    let c2x;
    let c2y;
    const contours = [];
    let contour = [];
    const stack = [];
    const glyfs = [];
    let nStems = 0;
    let haveWidth = false;
    let width = font.defaultWidthX;
    let open = false;
    let x = 0;
    let y = 0;

    function lineTo(x, y) {
        contour.push({
            onCurve: true,
            x,
            y
        });
    }

    function curveTo(c1x, c1y, c2x, c2y, x, y) {
        contour.push({
            x: c1x,
            y: c1y
        });
        contour.push({
            x: c2x,
            y: c2y
        });
        contour.push({
            onCurve: true,
            x,
            y
        });
    }

    function newContour(x, y) {
        if (open) {
            contours.push(contour);
        }

        contour = [];
        lineTo(x, y);
        open = true;
    }

    function parseStems() {
        // The number of stem operators on the stack is always even.
        // If the value is uneven, that means a width is specified.
        const hasWidthArg = stack.length % 2 !== 0;
        if (hasWidthArg && !haveWidth) {
            width = stack.shift() + font.nominalWidthX;
        }

        nStems += stack.length >> 1;
        stack.length = 0;
        haveWidth = true;
    }

    function parse(code) {
        let b1;
        let b2;
        let b3;
        let b4;
        let codeIndex;
        let subrCode;
        let jpx;
        let jpy;
        let c3x;
        let c3y;
        let c4x;
        let c4y;

        let i = 0;
        while (i < code.length) {
            let v = code[i];
            i += 1;
            switch (v) {
            case 1: // hstem
                parseStems();
                break;
            case 3: // vstem
                parseStems();
                break;
            case 4: // vmoveto
                if (stack.length > 1 && !haveWidth) {
                    width = stack.shift() + font.nominalWidthX;
                    haveWidth = true;
                }

                y += stack.pop();
                newContour(x, y);
                break;
            case 5: // rlineto
                while (stack.length > 0) {
                    x += stack.shift();
                    y += stack.shift();
                    lineTo(x, y);
                }

                break;
            case 6: // hlineto
                while (stack.length > 0) {
                    x += stack.shift();
                    lineTo(x, y);
                    if (stack.length === 0) {
                        break;
                    }

                    y += stack.shift();
                    lineTo(x, y);
                }

                break;
            case 7: // vlineto
                while (stack.length > 0) {
                    y += stack.shift();
                    lineTo(x, y);
                    if (stack.length === 0) {
                        break;
                    }

                    x += stack.shift();
                    lineTo(x, y);
                }

                break;
            case 8: // rrcurveto
                while (stack.length > 0) {
                    c1x = x + stack.shift();
                    c1y = y + stack.shift();
                    c2x = c1x + stack.shift();
                    c2y = c1y + stack.shift();
                    x = c2x + stack.shift();
                    y = c2y + stack.shift();
                    curveTo(c1x, c1y, c2x, c2y, x, y);
                }

                break;
            case 10: // callsubr
                codeIndex = stack.pop() + font.subrsBias;
                subrCode = font.subrs[codeIndex];
                if (subrCode) {
                    parse(subrCode);
                }

                break;
            case 11: // return
                return;
            case 12: // flex operators
                v = code[i];
                i += 1;
                switch (v) {
                case 35: // flex
                    // |- dx1 dy1 dx2 dy2 dx3 dy3 dx4 dy4 dx5 dy5 dx6 dy6 fd flex (12 35) |-
                    c1x = x   + stack.shift(); // dx1
                    c1y = y   + stack.shift(); // dy1
                    c2x = c1x + stack.shift(); // dx2
                    c2y = c1y + stack.shift(); // dy2
                    jpx = c2x + stack.shift(); // dx3
                    jpy = c2y + stack.shift(); // dy3
                    c3x = jpx + stack.shift(); // dx4
                    c3y = jpy + stack.shift(); // dy4
                    c4x = c3x + stack.shift(); // dx5
                    c4y = c3y + stack.shift(); // dy5
                    x = c4x + stack.shift(); // dx6
                    y = c4y + stack.shift(); // dy6
                    stack.shift(); // flex depth
                    curveTo(c1x, c1y, c2x, c2y, jpx, jpy);
                    curveTo(c3x, c3y, c4x, c4y, x, y);
                    break;
                case 34: // hflex
                    // |- dx1 dx2 dy2 dx3 dx4 dx5 dx6 hflex (12 34) |-
                    c1x = x   + stack.shift(); // dx1
                    c1y = y; // dy1
                    c2x = c1x + stack.shift(); // dx2
                    c2y = c1y + stack.shift(); // dy2
                    jpx = c2x + stack.shift(); // dx3
                    jpy = c2y; // dy3
                    c3x = jpx + stack.shift(); // dx4
                    c3y = c2y; // dy4
                    c4x = c3x + stack.shift(); // dx5
                    c4y = y; // dy5
                    x = c4x + stack.shift(); // dx6
                    curveTo(c1x, c1y, c2x, c2y, jpx, jpy);
                    curveTo(c3x, c3y, c4x, c4y, x, y);
                    break;
                case 36: // hflex1
                    // |- dx1 dy1 dx2 dy2 dx3 dx4 dx5 dy5 dx6 hflex1 (12 36) |-
                    c1x = x   + stack.shift(); // dx1
                    c1y = y   + stack.shift(); // dy1
                    c2x = c1x + stack.shift(); // dx2
                    c2y = c1y + stack.shift(); // dy2
                    jpx = c2x + stack.shift(); // dx3
                    jpy = c2y; // dy3
                    c3x = jpx + stack.shift(); // dx4
                    c3y = c2y; // dy4
                    c4x = c3x + stack.shift(); // dx5
                    c4y = c3y + stack.shift(); // dy5
                    x = c4x + stack.shift(); // dx6
                    curveTo(c1x, c1y, c2x, c2y, jpx, jpy);
                    curveTo(c3x, c3y, c4x, c4y, x, y);
                    break;
                case 37: // flex1
                    // |- dx1 dy1 dx2 dy2 dx3 dy3 dx4 dy4 dx5 dy5 d6 flex1 (12 37) |-
                    c1x = x   + stack.shift(); // dx1
                    c1y = y   + stack.shift(); // dy1
                    c2x = c1x + stack.shift(); // dx2
                    c2y = c1y + stack.shift(); // dy2
                    jpx = c2x + stack.shift(); // dx3
                    jpy = c2y + stack.shift(); // dy3
                    c3x = jpx + stack.shift(); // dx4
                    c3y = jpy + stack.shift(); // dy4
                    c4x = c3x + stack.shift(); // dx5
                    c4y = c3y + stack.shift(); // dy5
                    if (Math.abs(c4x - x) > Math.abs(c4y - y)) {
                        x = c4x + stack.shift();
                    }
                    else {
                        y = c4y + stack.shift();
                    }

                    curveTo(c1x, c1y, c2x, c2y, jpx, jpy);
                    curveTo(c3x, c3y, c4x, c4y, x, y);
                    break;
                default:
                    console.warn('Glyph ' + index + ': unknown operator ' + (1200 + v));
                    stack.length = 0;
                }
                break;
            case 14: // endchar
                if (stack.length === 1 && !haveWidth) {
                    width = stack.shift() + font.nominalWidthX;
                    haveWidth = true;
                }
                else if (stack.length === 4) {
                    glyfs[1] = {
                        glyphIndex: font.charset.indexOf(font.encoding[stack.pop()]),
                        transform: {a: 1, b: 0, c: 0, d: 1, e: 0, f: 0}
                    };
                    glyfs[0] = {
                        glyphIndex: font.charset.indexOf(font.encoding[stack.pop()]),
                        transform: {a: 1, b: 0, c: 0, d: 1, e: 0, f: 0}
                    };
                    glyfs[1].transform.f = stack.pop();
                    glyfs[1].transform.e = stack.pop();
                }
                else if (stack.length === 5) {
                    if (!haveWidth) {
                        width = stack.shift() + font.nominalWidthX;
                    }
                    haveWidth = true;
                    glyfs[1] = {
                        glyphIndex: font.charset.indexOf(font.encoding[stack.pop()]),
                        transform: {a: 1, b: 0, c: 0, d: 1, e: 0, f: 0}
                    };
                    glyfs[0] = {
                        glyphIndex: font.charset.indexOf(font.encoding[stack.pop()]),
                        transform: {a: 1, b: 0, c: 0, d: 1, e: 0, f: 0}
                    };
                    glyfs[1].transform.f = stack.pop();
                    glyfs[1].transform.e = stack.pop();
                }

                if (open) {
                    contours.push(contour);
                    open = false;
                }

                break;
            case 18: // hstemhm
                parseStems();
                break;
            case 19: // hintmask
            case 20: // cntrmask
                parseStems();
                i += (nStems + 7) >> 3;
                break;
            case 21: // rmoveto
                if (stack.length > 2 && !haveWidth) {
                    width = stack.shift() + font.nominalWidthX;
                    haveWidth = true;
                }

                y += stack.pop();
                x += stack.pop();
                newContour(x, y);
                break;
            case 22: // hmoveto
                if (stack.length > 1 && !haveWidth) {
                    width = stack.shift() + font.nominalWidthX;
                    haveWidth = true;
                }

                x += stack.pop();
                newContour(x, y);
                break;
            case 23: // vstemhm
                parseStems();
                break;
            case 24: // rcurveline
                while (stack.length > 2) {
                    c1x = x + stack.shift();
                    c1y = y + stack.shift();
                    c2x = c1x + stack.shift();
                    c2y = c1y + stack.shift();
                    x = c2x + stack.shift();
                    y = c2y + stack.shift();
                    curveTo(c1x, c1y, c2x, c2y, x, y);
                }

                x += stack.shift();
                y += stack.shift();
                lineTo(x, y);
                break;
            case 25: // rlinecurve
                while (stack.length > 6) {
                    x += stack.shift();
                    y += stack.shift();
                    lineTo(x, y);
                }

                c1x = x + stack.shift();
                c1y = y + stack.shift();
                c2x = c1x + stack.shift();
                c2y = c1y + stack.shift();
                x = c2x + stack.shift();
                y = c2y + stack.shift();
                curveTo(c1x, c1y, c2x, c2y, x, y);
                break;
            case 26: // vvcurveto
                if (stack.length % 2) {
                    x += stack.shift();
                }

                while (stack.length > 0) {
                    c1x = x;
                    c1y = y + stack.shift();
                    c2x = c1x + stack.shift();
                    c2y = c1y + stack.shift();
                    x = c2x;
                    y = c2y + stack.shift();
                    curveTo(c1x, c1y, c2x, c2y, x, y);
                }

                break;
            case 27: // hhcurveto
                if (stack.length % 2) {
                    y += stack.shift();
                }

                while (stack.length > 0) {
                    c1x = x + stack.shift();
                    c1y = y;
                    c2x = c1x + stack.shift();
                    c2y = c1y + stack.shift();
                    x = c2x + stack.shift();
                    y = c2y;
                    curveTo(c1x, c1y, c2x, c2y, x, y);
                }

                break;
            case 28: // shortint
                b1 = code[i];
                b2 = code[i + 1];
                stack.push(((b1 << 24) | (b2 << 16)) >> 16);
                i += 2;
                break;
            case 29: // callgsubr
                codeIndex = stack.pop() + font.gsubrsBias;
                subrCode = font.gsubrs[codeIndex];
                if (subrCode) {
                    parse(subrCode);
                }

                break;
            case 30: // vhcurveto
                while (stack.length > 0) {
                    c1x = x;
                    c1y = y + stack.shift();
                    c2x = c1x + stack.shift();
                    c2y = c1y + stack.shift();
                    x = c2x + stack.shift();
                    y = c2y + (stack.length === 1 ? stack.shift() : 0);
                    curveTo(c1x, c1y, c2x, c2y, x, y);
                    if (stack.length === 0) {
                        break;
                    }

                    c1x = x + stack.shift();
                    c1y = y;
                    c2x = c1x + stack.shift();
                    c2y = c1y + stack.shift();
                    y = c2y + stack.shift();
                    x = c2x + (stack.length === 1 ? stack.shift() : 0);
                    curveTo(c1x, c1y, c2x, c2y, x, y);
                }

                break;
            case 31: // hvcurveto
                while (stack.length > 0) {
                    c1x = x + stack.shift();
                    c1y = y;
                    c2x = c1x + stack.shift();
                    c2y = c1y + stack.shift();
                    y = c2y + stack.shift();
                    x = c2x + (stack.length === 1 ? stack.shift() : 0);
                    curveTo(c1x, c1y, c2x, c2y, x, y);
                    if (stack.length === 0) {
                        break;
                    }

                    c1x = x;
                    c1y = y + stack.shift();
                    c2x = c1x + stack.shift();
                    c2y = c1y + stack.shift();
                    x = c2x + stack.shift();
                    y = c2y + (stack.length === 1 ? stack.shift() : 0);
                    curveTo(c1x, c1y, c2x, c2y, x, y);
                }

                break;
            default:
                if (v < 32) {
                    console.warn('Glyph ' + index + ': unknown operator ' + v);
                }
                else if (v < 247) {
                    stack.push(v - 139);
                }
                else if (v < 251) {
                    b1 = code[i];
                    i += 1;
                    stack.push((v - 247) * 256 + b1 + 108);
                }
                else if (v < 255) {
                    b1 = code[i];
                    i += 1;
                    stack.push(-(v - 251) * 256 - b1 - 108);
                }
                else {
                    b1 = code[i];
                    b2 = code[i + 1];
                    b3 = code[i + 2];
                    b4 = code[i + 3];
                    i += 4;
                    stack.push(((b1 << 24) | (b2 << 16) | (b3 << 8) | b4) / 65536);
                }
            }
        }
    }

    parse(code);

    const glyf = {

        // 移除重复的起点和终点
        contours: contours.map(contour => {
            const last = contour.length - 1;
            if (contour[0].x === contour[last].x && contour[0].y === contour[last].y) {
                contour.splice(last, 1);
            }
            return contour;
        }),

        advanceWidth: width
    };
    if (glyfs.length) {
        glyf.compound = true;
        glyf.glyfs = glyfs;
    }
    return glyf;
}


/***/ }),
/* 61 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ parseCFFCharset)
/* harmony export */ });
/* harmony import */ var _getCFFString__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59);
/**
 * @file 解析cff字符集
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * 解析cff字形名称
 * See Adobe TN #5176 chapter 13, "Charsets".
 *
 * @param  {Reader} reader  读取器
 * @param  {number} start   起始偏移
 * @param  {number} nGlyphs 字形个数
 * @param  {Object} strings cff字符串字典
 * @return {Array}         字符集
 */
function parseCFFCharset(reader, start, nGlyphs, strings) {
    if (start) {
        reader.seek(start);
    }

    let i;
    let sid;
    let count;
    // The .notdef glyph is not included, so subtract 1.
    nGlyphs -= 1;
    const charset = ['.notdef'];

    const format = reader.readUint8();
    if (format === 0) {
        for (i = 0; i < nGlyphs; i += 1) {
            sid = reader.readUint16();
            charset.push((0,_getCFFString__WEBPACK_IMPORTED_MODULE_0__.default)(strings, sid));
        }
    }
    else if (format === 1) {
        while (charset.length <= nGlyphs) {
            sid = reader.readUint16();
            count = reader.readUint8();
            for (i = 0; i <= count; i += 1) {
                charset.push((0,_getCFFString__WEBPACK_IMPORTED_MODULE_0__.default)(strings, sid));
                sid += 1;
            }
        }
    }
    else if (format === 2) {
        while (charset.length <= nGlyphs) {
            sid = reader.readUint16();
            count = reader.readUint16();
            for (i = 0; i <= count; i += 1) {
                charset.push((0,_getCFFString__WEBPACK_IMPORTED_MODULE_0__.default)(strings, sid));
                sid += 1;
            }
        }
    }
    else {
        throw new Error('Unknown charset format ' + format);
    }

    return charset;
}


/***/ }),
/* 62 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ parseCFFEncoding)
/* harmony export */ });
/**
 * @file 解析cff编码
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 解析cff encoding数据
 * See Adobe TN #5176 chapter 12, "Encodings".
 *
 * @param  {Reader} reader 读取器
 * @param  {number=} start  偏移
 * @return {Object}        编码表
 */
function parseCFFEncoding(reader, start) {
    if (null != start) {
        reader.seek(start);
    }

    let i;
    let code;
    const encoding = {};
    const format = reader.readUint8();

    if (format === 0) {
        const nCodes = reader.readUint8();
        for (i = 0; i < nCodes; i += 1) {
            code = reader.readUint8();
            encoding[code] = i;
        }
    }
    else if (format === 1) {
        const nRanges = reader.readUint8();
        code = 1;
        for (i = 0; i < nRanges; i += 1) {
            const first = reader.readUint8();
            const nLeft = reader.readUint8();
            for (let j = first; j <= first + nLeft; j += 1) {
                encoding[j] = code;
                code += 1;
            }
        }
    }
    else {
        console.warn('unknown encoding format:' + format);
    }

    return encoding;
}


/***/ }),
/* 63 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/**
 * @file GPOS
 * @author fr33z00(https://github.com/fr33z00)
 *
 * @reference: https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6cvt.html
 */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'GPOS',
    [],
    {

        read(reader, ttf) {
            const length = ttf.tables.GPOS.length;
            return reader.readBytes(this.offset, length);
        },

        write(writer, ttf) {
            if (ttf.GPOS) {
                writer.writeBytes(ttf.GPOS, ttf.GPOS.length);
            }
        },

        size(ttf) {
            return ttf.GPOS ? ttf.GPOS.length : 0;
        }
    }
));


/***/ }),
/* 64 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/**
 * @file kern
 * @author fr33z00(https://github.com/fr33z00)
 *
 * @reference: https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6cvt.html
 */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'kern',
    [],
    {

        read(reader, ttf) {
            const length = ttf.tables.kern.length;
            return reader.readBytes(this.offset, length);
        },

        write(writer, ttf) {
            if (ttf.kern) {
                writer.writeBytes(ttf.kern, ttf.kern.length);
            }
        },

        size(ttf) {
            return ttf.kern ? ttf.kern.length : 0;
        }
    }
));


/***/ }),
/* 65 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ otfContours2ttfContours)
/* harmony export */ });
/* harmony import */ var _math_bezierCubic2Q2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66);
/* harmony import */ var _graphics_pathCeil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16);
/**
 * @file otf轮廓转ttf轮廓
 * @author mengke01(kekee000@gmail.com)
 */




/**
 * 转换轮廓
 *
 * @param  {Array} otfContour otf轮廓
 * @return {Array}            ttf轮廓
 */
function transformContour(otfContour) {
    const contour = [];
    let prevPoint;
    let curPoint;
    let nextPoint;
    let nextNextPoint;

    contour.push(prevPoint = otfContour[0]);
    for (let i = 1, l = otfContour.length; i < l; i++) {
        curPoint = otfContour[i];

        if (curPoint.onCurve) {
            contour.push(curPoint);
            prevPoint = curPoint;
        }
        // 三次bezier曲线
        else {
            nextPoint = otfContour[i + 1];
            nextNextPoint = i === l - 2 ? otfContour[0] : otfContour[i + 2];
            const bezierArray = (0,_math_bezierCubic2Q2__WEBPACK_IMPORTED_MODULE_0__.default)(prevPoint, curPoint, nextPoint, nextNextPoint);
            bezierArray[0][2].onCurve = true;
            contour.push(bezierArray[0][1]);
            contour.push(bezierArray[0][2]);

            // 第二个曲线
            if (bezierArray[1]) {
                bezierArray[1][2].onCurve = true;
                contour.push(bezierArray[1][1]);
                contour.push(bezierArray[1][2]);
            }

            prevPoint = nextNextPoint;
            i += 2;
        }
    }

    return (0,_graphics_pathCeil__WEBPACK_IMPORTED_MODULE_1__.default)(contour);
}


/**
 * otf轮廓转ttf轮廓
 *
 * @param  {Array} otfContours otf轮廓数组
 * @return {Array} ttf轮廓
 */
function otfContours2ttfContours(otfContours) {
    if (!otfContours || !otfContours.length) {
        return otfContours;
    }
    const contours = [];
    for (let i = 0, l = otfContours.length; i < l; i++) {

        // 这里可能由于转换错误导致空轮廓，需要去除
        if (otfContours[i][0]) {
            contours.push(transformContour(otfContours[i]));
        }
    }

    return contours;
}


/***/ }),
/* 66 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ bezierCubic2Q2)
/* harmony export */ });
/**
 * @file 三次贝塞尔转二次贝塞尔
 * @author mengke01(kekee000@gmail.com)
 *
 * references:
 * https://github.com/search?utf8=%E2%9C%93&q=svg2ttf
 * http://www.caffeineowl.com/graphics/2d/vectorial/cubic2quad01.html
 *
 */

function toQuad(p1, c1, c2, p2) {
    // Quad control point is (3*c2 - p2 + 3*c1 - p1)/4
    const x = (3 * c2.x - p2.x + 3 * c1.x - p1.x) / 4;
    const y = (3 * c2.y - p2.y + 3 * c1.y - p1.y) / 4;
    return [
        p1,
        {x, y},
        p2
    ];
}


/**
 * 三次贝塞尔转二次贝塞尔
 *
 * @param {Object} p1 开始点
 * @param {Object} c1 控制点1
 * @param {Object} c2 控制点2
 * @param {Object} p2 结束点
 * @return {Array} 二次贝塞尔控制点
 */
function bezierCubic2Q2(p1, c1, c2, p2) {

    // 判断极端情况，控制点和起止点一样
    if (p1.x === c1.x && p1.y === c1.y && c2.x === p2.x && c2.y === p2.y) {
        return [
            [
                p1,
                {
                    x: (p1.x + p2.x) / 2,
                    y: (p1.y + p2.y) / 2
                },
                p2
            ]
        ];
    }

    const mx = p2.x - 3 * c2.x + 3 * c1.x - p1.x;
    const my = p2.y - 3 * c2.y + 3 * c1.y - p1.y;

    // control points near
    if (mx * mx + my * my <= 4) {
        return [
            toQuad(p1, c1, c2, p2)
        ];
    }

    // Split to 2 qubic beziers by midpoints
    // (p2 + 3*c2 + 3*c1 + p1)/8
    const mp = {
        x: (p2.x + 3 * c2.x + 3 * c1.x + p1.x) / 8,
        y: (p2.y + 3 * c2.y + 3 * c1.y + p1.y) / 8
    };

    return [
        toQuad(
            p1,
            {
                x: (p1.x + c1.x) / 2,
                y: (p1.y + c1.y) / 2

            },
            {
                x: (p1.x + 2 * c1.x + c2.x) / 4,
                y: (p1.y + 2 * c1.y + c2.y) / 4
            },
            mp
        ),
        toQuad(
            mp,
            {
                x: (p2.x + c1.x + 2 * c2.x) / 4,
                y: (p2.y + c1.y + 2 * c2.y) / 4

            },
            {
                x: (p2.x + c2.x) / 2,
                y: (p2.y + c2.y) / 2
            },
            p2
        )
    ];
}


/***/ }),
/* 67 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ eot2ttf)
/* harmony export */ });
/* harmony import */ var _reader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(28);
/* harmony import */ var _writer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(33);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(29);
/**
 * @file eot转ttf
 * @author mengke01(kekee000@gmail.com)
 */





/**
 * eot格式转换成ttf字体格式
 *
 * @param {ArrayBuffer} eotBuffer eot缓冲数组
 * @param {Object} options 选项
 *
 * @return {ArrayBuffer} ttf格式byte流
 */
// eslint-disable-next-line no-unused-vars
function eot2ttf(eotBuffer, options = {}) {
    // 这里用小尾方式读取
    const eotReader = new _reader__WEBPACK_IMPORTED_MODULE_0__.default(eotBuffer, 0, eotBuffer.byteLength, true);

    // check magic number
    const magicNumber = eotReader.readUint16(34);
    if (magicNumber !== 0x504C) {
        _error__WEBPACK_IMPORTED_MODULE_2__.default.raise(10110);
    }

    // check version
    const version = eotReader.readUint32(8);
    if (version !== 0x20001 && version !== 0x10000 && version !== 0x20002) {
        _error__WEBPACK_IMPORTED_MODULE_2__.default.raise(10110);
    }

    const eotSize = eotBuffer.byteLength || eotBuffer.length;
    const fontSize = eotReader.readUint32(4);

    let fontOffset = 82;
    const familyNameSize = eotReader.readUint16(fontOffset);
    fontOffset += 4 + familyNameSize;

    const styleNameSize = eotReader.readUint16(fontOffset);
    fontOffset += 4 + styleNameSize;

    const versionNameSize = eotReader.readUint16(fontOffset);
    fontOffset += 4 + versionNameSize;

    const fullNameSize = eotReader.readUint16(fontOffset);
    fontOffset += 2 + fullNameSize;

    // version 0x20001
    if (version === 0x20001 || version === 0x20002) {
        const rootStringSize = eotReader.readUint16(fontOffset + 2);
        fontOffset += 4 + rootStringSize;
    }

    // version 0x20002
    if (version === 0x20002) {
        fontOffset += 10;
        const signatureSize = eotReader.readUint16(fontOffset);
        fontOffset += 2 + signatureSize;
        fontOffset += 4;
        const eudcFontSize = eotReader.readUint32(fontOffset);
        fontOffset += 4 + eudcFontSize;
    }

    if (fontOffset + fontSize > eotSize) {
        _error__WEBPACK_IMPORTED_MODULE_2__.default.raise(10001);
    }

    // support slice
    if (eotBuffer.slice) {
        return eotBuffer.slice(fontOffset, fontOffset + fontSize);
    }

    // not support ArrayBuffer.slice eg. IE10
    const bytes = eotReader.readBytes(fontOffset, fontSize);
    return new _writer__WEBPACK_IMPORTED_MODULE_1__.default(new ArrayBuffer(fontSize)).writeBytes(bytes).getBuffer();
}


/***/ }),
/* 68 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ svg2ttfObject)
/* harmony export */ });
/* harmony import */ var _common_string__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30);
/* harmony import */ var _common_DOMParser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(69);
/* harmony import */ var _svg_path2contours__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74);
/* harmony import */ var _svg_svgnode2contours__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77);
/* harmony import */ var _graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17);
/* harmony import */ var _graphics_pathsUtil__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(85);
/* harmony import */ var _util_glyfAdjust__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(29);
/* harmony import */ var _getEmptyttfObject__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7);
/* harmony import */ var _util_reduceGlyf__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(25);
/**
 * @file svg格式转ttfObject格式
 * @author mengke01(kekee000@gmail.com)
 */












/**
 * 加载xml字符串
 *
 * @param {string} xml xml字符串
 * @return {XMLDocument}
 */
function loadXML(xml) {
    if (_common_DOMParser__WEBPACK_IMPORTED_MODULE_1__.default) {
        try {
            const domParser = new _common_DOMParser__WEBPACK_IMPORTED_MODULE_1__.default();
            const xmlDoc = domParser.parseFromString(xml, 'text/xml');
            return xmlDoc;
        }
        catch (exp) {
            _error__WEBPACK_IMPORTED_MODULE_7__.default.raise(10103);
        }
    }
    _error__WEBPACK_IMPORTED_MODULE_7__.default.raise(10004);
}

/**
 * 对xml文本进行处理
 *
 * @param  {string} svg svg文本
 * @return {string} 处理后文本
 */
function resolveSVG(svg) {
    // 去除xmlns，防止xmlns导致svg解析错误
    svg = svg.replace(/\s+xmlns(?::[\w-]+)?=("|')[^"']*\1/g, ' ')
        .replace(/<defs[>\s][\s\S]+?\/defs>/g, (text) => {
            if (text.indexOf('</font>') >= 0) {
                return text;
            }
            return '';
        })
        .replace(/<use[>\s][\s\S]+?\/use>/g, '');
    return svg;
}

/**
 * 获取空的ttf格式对象
 *
 * @return {Object} ttfObject对象
 */
function getEmptyTTF() {
    const ttf = (0,_getEmptyttfObject__WEBPACK_IMPORTED_MODULE_8__.default)();
    ttf.head.unitsPerEm = 0; // 去除unitsPerEm以便于重新计算
    ttf.from = 'svgfont';
    return ttf;
}

/**
 * 获取空的对象，用来作为ttf的容器
 *
 * @return {Object} ttfObject对象
 */
function getEmptyObject() {
    return {
        'from': 'svg',
        'OS/2': {},
        'name': {},
        'hhea': {},
        'head': {},
        'post': {},
        'glyf': []
    };
}

/**
 * 根据边界获取unitsPerEm
 *
 * @param {number} xMin x最小值
 * @param {number} xMax x最大值
 * @param {number} yMin y最小值
 * @param {number} yMax y最大值
 * @return {number}
 */
function getUnitsPerEm(xMin, xMax, yMin, yMax) {
    const seed = Math.ceil(Math.min(yMax - yMin, xMax - xMin));

    if (!seed) {
        return 1024;
    }

    if (seed <= 128) {
        return seed;
    }

    // 获取合适的unitsPerEm
    let unitsPerEm = 128;
    while (unitsPerEm < 16384) {

        if (seed <= 1.2 * unitsPerEm) {
            return unitsPerEm;
        }

        unitsPerEm <<= 1;
    }

    return 1024;
}

/**
 * 对ttfObject进行处理，去除小数
 *
 * @param {Object} ttf ttfObject
 * @return {Object} ttfObject
 */
function resolve(ttf) {


    // 如果是svg格式字体，则去小数
    // 由于svg格式导入时候会出现字形重复问题，这里进行优化
    if (ttf.from === 'svgfont' && ttf.head.unitsPerEm > 128) {
        ttf.glyf.forEach((g) => {
            if (g.contours) {
                (0,_util_glyfAdjust__WEBPACK_IMPORTED_MODULE_6__.default)(g);
                (0,_util_reduceGlyf__WEBPACK_IMPORTED_MODULE_9__.default)(g);
            }
        });
    }
    // 否则重新计算字形大小，缩放到1024的em
    else {
        let xMin = 16384;
        let xMax = -16384;
        let yMin = 16384;
        let yMax = -16384;

        ttf.glyf.forEach((g) => {
            if (g.contours) {
                const bound = (0,_graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_4__.computePathBox)(...g.contours);
                if (bound) {
                    xMin = Math.min(xMin, bound.x);
                    xMax = Math.max(xMax, bound.x + bound.width);
                    yMin = Math.min(yMin, bound.y);
                    yMax = Math.max(yMax, bound.y + bound.height);
                }
            }
        });

        const unitsPerEm = getUnitsPerEm(xMin, xMax, yMin, yMax);
        const scale = 1024 / unitsPerEm;

        ttf.glyf.forEach((g) => {
            (0,_util_glyfAdjust__WEBPACK_IMPORTED_MODULE_6__.default)(g, scale, scale);
            (0,_util_reduceGlyf__WEBPACK_IMPORTED_MODULE_9__.default)(g);
        });
        ttf.head.unitsPerEm = 1024;
    }

    return ttf;
}

/**
 * 解析字体信息相关节点
 *
 * @param {XMLDocument} xmlDoc XML文档对象
 * @param {Object} ttf ttf对象
 * @return {Object} ttf对象
 */
function parseFont(xmlDoc, ttf) {

    const metaNode = xmlDoc.getElementsByTagName('metadata')[0];
    const fontNode = xmlDoc.getElementsByTagName('font')[0];
    const fontFaceNode = xmlDoc.getElementsByTagName('font-face')[0];

    if (metaNode && metaNode.textContent) {
        ttf.metadata = _common_string__WEBPACK_IMPORTED_MODULE_0__.default.decodeHTML(metaNode.textContent.trim());
    }

    // 解析font，如果有font节点说明是svg格式字体文件
    if (fontNode) {
        ttf.id = fontNode.getAttribute('id') || '';
        ttf.hhea.advanceWidthMax = +(fontNode.getAttribute('horiz-adv-x') || 0);
        ttf.from = 'svgfont';
    }

    if (fontFaceNode) {
        const OS2 = ttf['OS/2'];
        ttf.name.fontFamily = fontFaceNode.getAttribute('font-family') || '';
        OS2.usWeightClass = +(fontFaceNode.getAttribute('font-weight') || 0);
        ttf.head.unitsPerEm = +(fontFaceNode.getAttribute('units-per-em') || 0);

        // 解析panose, eg: 2 0 6 3 0 0 0 0 0 0
        const panose = (fontFaceNode.getAttribute('panose-1') || '').split(' ');
        [
            'bFamilyType', 'bSerifStyle', 'bWeight', 'bProportion', 'bContrast',
            'bStrokeVariation', 'bArmStyle', 'bLetterform', 'bMidline', 'bXHeight'
        ].forEach((name, i) => {
            OS2[name] = +(panose[i] || 0);
        });

        ttf.hhea.ascent = +(fontFaceNode.getAttribute('ascent') || 0);
        ttf.hhea.descent = +(fontFaceNode.getAttribute('descent') || 0);
        OS2.bXHeight = +(fontFaceNode.getAttribute('x-height') || 0);

        // 解析bounding
        const box = (fontFaceNode.getAttribute('bbox') || '').split(' ');
        ['xMin', 'yMin', 'xMax', 'yMax'].forEach((name, i) => {
            ttf.head[name] = +(box[i] || '');
        });

        ttf.post.underlineThickness = +(fontFaceNode.getAttribute('underline-thickness') || 0);
        ttf.post.underlinePosition = +(fontFaceNode.getAttribute('underline-position') || 0);

        // unicode range
        const unicodeRange = fontFaceNode.getAttribute('unicode-range');
        if (unicodeRange) {
            unicodeRange.replace(/u\+([0-9A-Z]+)(-[0-9A-Z]+)?/i, ($0, a, b) => {
                OS2.usFirstCharIndex = Number('0x' + a);
                OS2.usLastCharIndex = b ? Number('0x' + b.slice(1)) : 0xFFFFFFFF;
            });
        }
    }

    return ttf;
}

/**
 * 解析字体信息相关节点
 *
 * @param {XMLDocument} xmlDoc XML文档对象
 * @param {Object} ttf ttf对象
 * @return {Object} ttf对象
 */
function parseGlyf(xmlDoc, ttf) {

    const missingNode = xmlDoc.getElementsByTagName('missing-glyph')[0];

    // 解析glyf
    let d;
    let unicode;
    if (missingNode) {

        const missing = {
            name: '.notdef'
        };

        if (missingNode.getAttribute('horiz-adv-x')) {
            missing.advanceWidth = +missingNode.getAttribute('horiz-adv-x');
        }

        if ((d = missingNode.getAttribute('d'))) {
            missing.contours = (0,_svg_path2contours__WEBPACK_IMPORTED_MODULE_2__.default)(d);
        }

        // 去除默认的空字形
        if (ttf.glyf[0] && ttf.glyf[0].name === '.notdef') {
            ttf.glyf.splice(0, 1);
        }

        ttf.glyf.unshift(missing);
    }

    const glyfNodes = xmlDoc.getElementsByTagName('glyph');

    if (glyfNodes.length) {


        for (let i = 0, l = glyfNodes.length; i < l; i++) {

            const node = glyfNodes[i];
            const glyf = {
                name: node.getAttribute('glyph-name') || node.getAttribute('name') || ''
            };

            if (node.getAttribute('horiz-adv-x')) {
                glyf.advanceWidth = +node.getAttribute('horiz-adv-x');
            }

            if ((unicode = node.getAttribute('unicode'))) {
                const nextUnicode = [];
                let totalCodePoints = 0;
                for (let ui = 0; ui < unicode.length; ui++) {
                    const ucp = unicode.codePointAt(ui);
                    nextUnicode.push(ucp);
                    ui = ucp > 0xffff ? ui + 1 : ui;
                    totalCodePoints += 1;
                }
                if (totalCodePoints === 1) {
                    // TTF can't handle ligatures
                    glyf.unicode = nextUnicode;

                    if ((d = node.getAttribute('d'))) {
                        glyf.contours = (0,_svg_path2contours__WEBPACK_IMPORTED_MODULE_2__.default)(d);
                    }
                    ttf.glyf.push(glyf);

                }
            }

        }
    }

    return ttf;
}


/**
 * 解析字体信息相关节点
 *
 * @param {XMLDocument} xmlDoc XML文档对象
 * @param {Object} ttf ttf对象
 */
function parsePath(xmlDoc, ttf) {

    // 单个path组成一个glfy字形
    let contours;
    let glyf;
    let node;
    const pathNodes = xmlDoc.getElementsByTagName('path');

    if (pathNodes.length) {
        for (let i = 0, l = pathNodes.length; i < l; i++) {
            node = pathNodes[i];
            glyf = {
                name: node.getAttribute('name') || ''
            };
            contours = (0,_svg_svgnode2contours__WEBPACK_IMPORTED_MODULE_3__.default)([node]);
            glyf.contours = contours;
            ttf.glyf.push(glyf);
        }
    }

    // 其他svg指令组成一个glyf字形
    contours = (0,_svg_svgnode2contours__WEBPACK_IMPORTED_MODULE_3__.default)(
        Array.prototype.slice.call(xmlDoc.getElementsByTagName('*')).filter((node) => node.tagName !== 'path')
    );
    if (contours) {
        glyf = {
            name: ''
        };

        glyf.contours = contours;
        ttf.glyf.push(glyf);
    }
}

/**
 * 解析xml文档
 *
 * @param {XMLDocument} xmlDoc XML文档对象
 * @param {Object} options 导入选项
 *
 * @return {Object} 解析后对象
 */
function parseXML(xmlDoc, options) {

    if (!xmlDoc.getElementsByTagName('svg').length) {
        _error__WEBPACK_IMPORTED_MODULE_7__.default.raise(10106);
    }

    let ttf;

    // 如果是svg字体格式，则解析glyf，否则解析path
    if (xmlDoc.getElementsByTagName('font')[0]) {
        ttf = getEmptyTTF();
        parseFont(xmlDoc, ttf);
        parseGlyf(xmlDoc, ttf);
    }
    else {
        ttf = getEmptyObject();
        parsePath(xmlDoc, ttf);
    }

    if (!ttf.glyf.length) {
        _error__WEBPACK_IMPORTED_MODULE_7__.default.raise(10201);
    }

    if (ttf.from === 'svg') {
        const glyf = ttf.glyf;
        let i;
        let l;
        // 合并导入的字形为单个字形
        if (options.combinePath) {
            const combined = [];
            for (i = 0, l = glyf.length; i < l; i++) {
                const contours = glyf[i].contours;
                for (let index = 0, length = contours.length; index < length; index++) {
                    combined.push(contours[index]);
                }
            }

            glyf[0].contours = combined;
            glyf.splice(1);
        }

        // 对字形进行反转
        for (i = 0, l = glyf.length; i < l; i++) {
            // 这里为了使ai等工具里面的字形方便导入，对svg做了反向处理
            glyf[i].contours = _graphics_pathsUtil__WEBPACK_IMPORTED_MODULE_5__.default.flip(glyf[i].contours);
        }
    }

    return ttf;
}

/**
 * svg格式转ttfObject格式
 *
 * @param {string} svg svg格式
 * @param {Object=} options 导入选项
 * @param {boolean} options.combinePath 是否合并成单个字形，仅限于普通svg导入
 * @return {Object} ttfObject
 */
function svg2ttfObject(svg, options = {combinePath: false}) {
    let xmlDoc = svg;
    if (typeof svg === 'string') {
        svg = resolveSVG(svg);
        xmlDoc = loadXML(svg);
    }

    const ttf = parseXML(xmlDoc, options);
    return resolve(ttf);
}


/***/ }),
/* 69 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file DOM解析器，兼容node端和浏览器端
 * @author mengke01(kekee000@gmail.com)
 */

/* eslint-disable no-undef */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (typeof window !== 'undefined' && window.DOMParser
    ? window.DOMParser
    : __webpack_require__(70).DOMParser);


/***/ }),
/* 70 */
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

function DOMParser(options){
	this.options = options ||{locator:{}};
}

DOMParser.prototype.parseFromString = function(source,mimeType){
	var options = this.options;
	var sax =  new XMLReader();
	var domBuilder = options.domBuilder || new DOMHandler();//contentHandler and LexicalHandler
	var errorHandler = options.errorHandler;
	var locator = options.locator;
	var defaultNSMap = options.xmlns||{};
	var isHTML = /\/x?html?$/.test(mimeType);//mimeType.toLowerCase().indexOf('html') > -1;
  	var entityMap = isHTML?htmlEntity.entityMap:{'lt':'<','gt':'>','amp':'&','quot':'"','apos':"'"};
	if(locator){
		domBuilder.setDocumentLocator(locator)
	}

	sax.errorHandler = buildErrorHandler(errorHandler,domBuilder,locator);
	sax.domBuilder = options.domBuilder || domBuilder;
	if(isHTML){
		defaultNSMap['']= 'http://www.w3.org/1999/xhtml';
	}
	defaultNSMap.xml = defaultNSMap.xml || 'http://www.w3.org/XML/1998/namespace';
	if(source && typeof source === 'string'){
		sax.parse(source,defaultNSMap,entityMap);
	}else{
		sax.errorHandler.error("invalid doc source");
	}
	return domBuilder.doc;
}
function buildErrorHandler(errorImpl,domBuilder,locator){
	if(!errorImpl){
		if(domBuilder instanceof DOMHandler){
			return domBuilder;
		}
		errorImpl = domBuilder ;
	}
	var errorHandler = {}
	var isCallback = errorImpl instanceof Function;
	locator = locator||{}
	function build(key){
		var fn = errorImpl[key];
		if(!fn && isCallback){
			fn = errorImpl.length == 2?function(msg){errorImpl(key,msg)}:errorImpl;
		}
		errorHandler[key] = fn && function(msg){
			fn('[xmldom '+key+']\t'+msg+_locator(locator));
		}||function(){};
	}
	build('warning');
	build('error');
	build('fatalError');
	return errorHandler;
}

//console.log('#\n\n\n\n\n\n\n####')
/**
 * +ContentHandler+ErrorHandler
 * +LexicalHandler+EntityResolver2
 * -DeclHandler-DTDHandler
 *
 * DefaultHandler:EntityResolver, DTDHandler, ContentHandler, ErrorHandler
 * DefaultHandler2:DefaultHandler,LexicalHandler, DeclHandler, EntityResolver2
 * @link http://www.saxproject.org/apidoc/org/xml/sax/helpers/DefaultHandler.html
 */
function DOMHandler() {
    this.cdata = false;
}
function position(locator,node){
	node.lineNumber = locator.lineNumber;
	node.columnNumber = locator.columnNumber;
}
/**
 * @see org.xml.sax.ContentHandler#startDocument
 * @link http://www.saxproject.org/apidoc/org/xml/sax/ContentHandler.html
 */
DOMHandler.prototype = {
	startDocument : function() {
    	this.doc = new DOMImplementation().createDocument(null, null, null);
    	if (this.locator) {
        	this.doc.documentURI = this.locator.systemId;
    	}
	},
	startElement:function(namespaceURI, localName, qName, attrs) {
		var doc = this.doc;
	    var el = doc.createElementNS(namespaceURI, qName||localName);
	    var len = attrs.length;
	    appendElement(this, el);
	    this.currentElement = el;

		this.locator && position(this.locator,el)
	    for (var i = 0 ; i < len; i++) {
	        var namespaceURI = attrs.getURI(i);
	        var value = attrs.getValue(i);
	        var qName = attrs.getQName(i);
			var attr = doc.createAttributeNS(namespaceURI, qName);
			this.locator &&position(attrs.getLocator(i),attr);
			attr.value = attr.nodeValue = value;
			el.setAttributeNode(attr)
	    }
	},
	endElement:function(namespaceURI, localName, qName) {
		var current = this.currentElement
		var tagName = current.tagName;
		this.currentElement = current.parentNode;
	},
	startPrefixMapping:function(prefix, uri) {
	},
	endPrefixMapping:function(prefix) {
	},
	processingInstruction:function(target, data) {
	    var ins = this.doc.createProcessingInstruction(target, data);
	    this.locator && position(this.locator,ins)
	    appendElement(this, ins);
	},
	ignorableWhitespace:function(ch, start, length) {
	},
	characters:function(chars, start, length) {
		chars = _toString.apply(this,arguments)
		//console.log(chars)
		if(chars){
			if (this.cdata) {
				var charNode = this.doc.createCDATASection(chars);
			} else {
				var charNode = this.doc.createTextNode(chars);
			}
			if(this.currentElement){
				this.currentElement.appendChild(charNode);
			}else if(/^\s*$/.test(chars)){
				this.doc.appendChild(charNode);
				//process xml
			}
			this.locator && position(this.locator,charNode)
		}
	},
	skippedEntity:function(name) {
	},
	endDocument:function() {
		this.doc.normalize();
	},
	setDocumentLocator:function (locator) {
	    if(this.locator = locator){// && !('lineNumber' in locator)){
	    	locator.lineNumber = 0;
	    }
	},
	//LexicalHandler
	comment:function(chars, start, length) {
		chars = _toString.apply(this,arguments)
	    var comm = this.doc.createComment(chars);
	    this.locator && position(this.locator,comm)
	    appendElement(this, comm);
	},

	startCDATA:function() {
	    //used in characters() methods
	    this.cdata = true;
	},
	endCDATA:function() {
	    this.cdata = false;
	},

	startDTD:function(name, publicId, systemId) {
		var impl = this.doc.implementation;
	    if (impl && impl.createDocumentType) {
	        var dt = impl.createDocumentType(name, publicId, systemId);
	        this.locator && position(this.locator,dt)
	        appendElement(this, dt);
	    }
	},
	/**
	 * @see org.xml.sax.ErrorHandler
	 * @link http://www.saxproject.org/apidoc/org/xml/sax/ErrorHandler.html
	 */
	warning:function(error) {
		console.warn('[xmldom warning]\t'+error,_locator(this.locator));
	},
	error:function(error) {
		console.error('[xmldom error]\t'+error,_locator(this.locator));
	},
	fatalError:function(error) {
		throw new ParseError(error, this.locator);
	}
}
function _locator(l){
	if(l){
		return '\n@'+(l.systemId ||'')+'#[line:'+l.lineNumber+',col:'+l.columnNumber+']'
	}
}
function _toString(chars,start,length){
	if(typeof chars == 'string'){
		return chars.substr(start,length)
	}else{//java sax connect width xmldom on rhino(what about: "? && !(chars instanceof String)")
		if(chars.length >= start+length || start){
			return new java.lang.String(chars,start,length)+'';
		}
		return chars;
	}
}

/*
 * @link http://www.saxproject.org/apidoc/org/xml/sax/ext/LexicalHandler.html
 * used method of org.xml.sax.ext.LexicalHandler:
 *  #comment(chars, start, length)
 *  #startCDATA()
 *  #endCDATA()
 *  #startDTD(name, publicId, systemId)
 *
 *
 * IGNORED method of org.xml.sax.ext.LexicalHandler:
 *  #endDTD()
 *  #startEntity(name)
 *  #endEntity(name)
 *
 *
 * @link http://www.saxproject.org/apidoc/org/xml/sax/ext/DeclHandler.html
 * IGNORED method of org.xml.sax.ext.DeclHandler
 * 	#attributeDecl(eName, aName, type, mode, value)
 *  #elementDecl(name, model)
 *  #externalEntityDecl(name, publicId, systemId)
 *  #internalEntityDecl(name, value)
 * @link http://www.saxproject.org/apidoc/org/xml/sax/ext/EntityResolver2.html
 * IGNORED method of org.xml.sax.EntityResolver2
 *  #resolveEntity(String name,String publicId,String baseURI,String systemId)
 *  #resolveEntity(publicId, systemId)
 *  #getExternalSubset(name, baseURI)
 * @link http://www.saxproject.org/apidoc/org/xml/sax/DTDHandler.html
 * IGNORED method of org.xml.sax.DTDHandler
 *  #notationDecl(name, publicId, systemId) {};
 *  #unparsedEntityDecl(name, publicId, systemId, notationName) {};
 */
"endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(/\w+/g,function(key){
	DOMHandler.prototype[key] = function(){return null}
})

/* Private static helpers treated below as private instance methods, so don't need to add these to the public API; we might use a Relator to also get rid of non-standard public properties */
function appendElement (hander,node) {
    if (!hander.currentElement) {
        hander.doc.appendChild(node);
    } else {
        hander.currentElement.appendChild(node);
    }
}//appendChild and setAttributeNS are preformance key

//if(typeof require == 'function'){
var htmlEntity = __webpack_require__(71);
var sax = __webpack_require__(72);
var XMLReader = sax.XMLReader;
var ParseError = sax.ParseError;
var DOMImplementation = exports.DOMImplementation = __webpack_require__(73).DOMImplementation;
exports.XMLSerializer = __webpack_require__(73).XMLSerializer ;
exports.DOMParser = DOMParser;
exports.__DOMHandler = DOMHandler;
//}


/***/ }),
/* 71 */
/***/ ((__unused_webpack_module, exports) => {

exports.entityMap = {
       lt: '<',
       gt: '>',
       amp: '&',
       quot: '"',
       apos: "'",
       Agrave: "À",
       Aacute: "Á",
       Acirc: "Â",
       Atilde: "Ã",
       Auml: "Ä",
       Aring: "Å",
       AElig: "Æ",
       Ccedil: "Ç",
       Egrave: "È",
       Eacute: "É",
       Ecirc: "Ê",
       Euml: "Ë",
       Igrave: "Ì",
       Iacute: "Í",
       Icirc: "Î",
       Iuml: "Ï",
       ETH: "Ð",
       Ntilde: "Ñ",
       Ograve: "Ò",
       Oacute: "Ó",
       Ocirc: "Ô",
       Otilde: "Õ",
       Ouml: "Ö",
       Oslash: "Ø",
       Ugrave: "Ù",
       Uacute: "Ú",
       Ucirc: "Û",
       Uuml: "Ü",
       Yacute: "Ý",
       THORN: "Þ",
       szlig: "ß",
       agrave: "à",
       aacute: "á",
       acirc: "â",
       atilde: "ã",
       auml: "ä",
       aring: "å",
       aelig: "æ",
       ccedil: "ç",
       egrave: "è",
       eacute: "é",
       ecirc: "ê",
       euml: "ë",
       igrave: "ì",
       iacute: "í",
       icirc: "î",
       iuml: "ï",
       eth: "ð",
       ntilde: "ñ",
       ograve: "ò",
       oacute: "ó",
       ocirc: "ô",
       otilde: "õ",
       ouml: "ö",
       oslash: "ø",
       ugrave: "ù",
       uacute: "ú",
       ucirc: "û",
       uuml: "ü",
       yacute: "ý",
       thorn: "þ",
       yuml: "ÿ",
       nbsp: "\u00a0",
       iexcl: "¡",
       cent: "¢",
       pound: "£",
       curren: "¤",
       yen: "¥",
       brvbar: "¦",
       sect: "§",
       uml: "¨",
       copy: "©",
       ordf: "ª",
       laquo: "«",
       not: "¬",
       shy: "­­",
       reg: "®",
       macr: "¯",
       deg: "°",
       plusmn: "±",
       sup2: "²",
       sup3: "³",
       acute: "´",
       micro: "µ",
       para: "¶",
       middot: "·",
       cedil: "¸",
       sup1: "¹",
       ordm: "º",
       raquo: "»",
       frac14: "¼",
       frac12: "½",
       frac34: "¾",
       iquest: "¿",
       times: "×",
       divide: "÷",
       forall: "∀",
       part: "∂",
       exist: "∃",
       empty: "∅",
       nabla: "∇",
       isin: "∈",
       notin: "∉",
       ni: "∋",
       prod: "∏",
       sum: "∑",
       minus: "−",
       lowast: "∗",
       radic: "√",
       prop: "∝",
       infin: "∞",
       ang: "∠",
       and: "∧",
       or: "∨",
       cap: "∩",
       cup: "∪",
       'int': "∫",
       there4: "∴",
       sim: "∼",
       cong: "≅",
       asymp: "≈",
       ne: "≠",
       equiv: "≡",
       le: "≤",
       ge: "≥",
       sub: "⊂",
       sup: "⊃",
       nsub: "⊄",
       sube: "⊆",
       supe: "⊇",
       oplus: "⊕",
       otimes: "⊗",
       perp: "⊥",
       sdot: "⋅",
       Alpha: "Α",
       Beta: "Β",
       Gamma: "Γ",
       Delta: "Δ",
       Epsilon: "Ε",
       Zeta: "Ζ",
       Eta: "Η",
       Theta: "Θ",
       Iota: "Ι",
       Kappa: "Κ",
       Lambda: "Λ",
       Mu: "Μ",
       Nu: "Ν",
       Xi: "Ξ",
       Omicron: "Ο",
       Pi: "Π",
       Rho: "Ρ",
       Sigma: "Σ",
       Tau: "Τ",
       Upsilon: "Υ",
       Phi: "Φ",
       Chi: "Χ",
       Psi: "Ψ",
       Omega: "Ω",
       alpha: "α",
       beta: "β",
       gamma: "γ",
       delta: "δ",
       epsilon: "ε",
       zeta: "ζ",
       eta: "η",
       theta: "θ",
       iota: "ι",
       kappa: "κ",
       lambda: "λ",
       mu: "μ",
       nu: "ν",
       xi: "ξ",
       omicron: "ο",
       pi: "π",
       rho: "ρ",
       sigmaf: "ς",
       sigma: "σ",
       tau: "τ",
       upsilon: "υ",
       phi: "φ",
       chi: "χ",
       psi: "ψ",
       omega: "ω",
       thetasym: "ϑ",
       upsih: "ϒ",
       piv: "ϖ",
       OElig: "Œ",
       oelig: "œ",
       Scaron: "Š",
       scaron: "š",
       Yuml: "Ÿ",
       fnof: "ƒ",
       circ: "ˆ",
       tilde: "˜",
       ensp: " ",
       emsp: " ",
       thinsp: " ",
       zwnj: "‌",
       zwj: "‍",
       lrm: "‎",
       rlm: "‏",
       ndash: "–",
       mdash: "—",
       lsquo: "‘",
       rsquo: "’",
       sbquo: "‚",
       ldquo: "“",
       rdquo: "”",
       bdquo: "„",
       dagger: "†",
       Dagger: "‡",
       bull: "•",
       hellip: "…",
       permil: "‰",
       prime: "′",
       Prime: "″",
       lsaquo: "‹",
       rsaquo: "›",
       oline: "‾",
       euro: "€",
       trade: "™",
       larr: "←",
       uarr: "↑",
       rarr: "→",
       darr: "↓",
       harr: "↔",
       crarr: "↵",
       lceil: "⌈",
       rceil: "⌉",
       lfloor: "⌊",
       rfloor: "⌋",
       loz: "◊",
       spades: "♠",
       clubs: "♣",
       hearts: "♥",
       diams: "♦"
};


/***/ }),
/* 72 */
/***/ ((__unused_webpack_module, exports) => {

//[4]   	NameStartChar	   ::=   	":" | [A-Z] | "_" | [a-z] | [#xC0-#xD6] | [#xD8-#xF6] | [#xF8-#x2FF] | [#x370-#x37D] | [#x37F-#x1FFF] | [#x200C-#x200D] | [#x2070-#x218F] | [#x2C00-#x2FEF] | [#x3001-#xD7FF] | [#xF900-#xFDCF] | [#xFDF0-#xFFFD] | [#x10000-#xEFFFF]
//[4a]   	NameChar	   ::=   	NameStartChar | "-" | "." | [0-9] | #xB7 | [#x0300-#x036F] | [#x203F-#x2040]
//[5]   	Name	   ::=   	NameStartChar (NameChar)*
var nameStartChar = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]///\u10000-\uEFFFF
var nameChar = new RegExp("[\\-\\.0-9"+nameStartChar.source.slice(1,-1)+"\\u00B7\\u0300-\\u036F\\u203F-\\u2040]");
var tagNamePattern = new RegExp('^'+nameStartChar.source+nameChar.source+'*(?:\:'+nameStartChar.source+nameChar.source+'*)?$');
//var tagNamePattern = /^[a-zA-Z_][\w\-\.]*(?:\:[a-zA-Z_][\w\-\.]*)?$/
//var handlers = 'resolveEntity,getExternalSubset,characters,endDocument,endElement,endPrefixMapping,ignorableWhitespace,processingInstruction,setDocumentLocator,skippedEntity,startDocument,startElement,startPrefixMapping,notationDecl,unparsedEntityDecl,error,fatalError,warning,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,comment,endCDATA,endDTD,endEntity,startCDATA,startDTD,startEntity'.split(',')

//S_TAG,	S_ATTR,	S_EQ,	S_ATTR_NOQUOT_VALUE
//S_ATTR_SPACE,	S_ATTR_END,	S_TAG_SPACE, S_TAG_CLOSE
var S_TAG = 0;//tag name offerring
var S_ATTR = 1;//attr name offerring 
var S_ATTR_SPACE=2;//attr name end and space offer
var S_EQ = 3;//=space?
var S_ATTR_NOQUOT_VALUE = 4;//attr value(no quot value only)
var S_ATTR_END = 5;//attr value end and no space(quot end)
var S_TAG_SPACE = 6;//(attr value end || tag end ) && (space offer)
var S_TAG_CLOSE = 7;//closed el<el />

/**
 * Creates an error that will not be caught by XMLReader aka the SAX parser.
 *
 * @param {string} message
 * @param {any?} locator Optional, can provide details about the location in the source
 * @constructor
 */
function ParseError(message, locator) {
	this.message = message
	this.locator = locator
	if(Error.captureStackTrace) Error.captureStackTrace(this, ParseError);
}
ParseError.prototype = new Error();
ParseError.prototype.name = ParseError.name

function XMLReader(){
	
}

XMLReader.prototype = {
	parse:function(source,defaultNSMap,entityMap){
		var domBuilder = this.domBuilder;
		domBuilder.startDocument();
		_copy(defaultNSMap ,defaultNSMap = {})
		parse(source,defaultNSMap,entityMap,
				domBuilder,this.errorHandler);
		domBuilder.endDocument();
	}
}
function parse(source,defaultNSMapCopy,entityMap,domBuilder,errorHandler){
	function fixedFromCharCode(code) {
		// String.prototype.fromCharCode does not supports
		// > 2 bytes unicode chars directly
		if (code > 0xffff) {
			code -= 0x10000;
			var surrogate1 = 0xd800 + (code >> 10)
				, surrogate2 = 0xdc00 + (code & 0x3ff);

			return String.fromCharCode(surrogate1, surrogate2);
		} else {
			return String.fromCharCode(code);
		}
	}
	function entityReplacer(a){
		var k = a.slice(1,-1);
		if(k in entityMap){
			return entityMap[k]; 
		}else if(k.charAt(0) === '#'){
			return fixedFromCharCode(parseInt(k.substr(1).replace('x','0x')))
		}else{
			errorHandler.error('entity not found:'+a);
			return a;
		}
	}
	function appendText(end){//has some bugs
		if(end>start){
			var xt = source.substring(start,end).replace(/&#?\w+;/g,entityReplacer);
			locator&&position(start);
			domBuilder.characters(xt,0,end-start);
			start = end
		}
	}
	function position(p,m){
		while(p>=lineEnd && (m = linePattern.exec(source))){
			lineStart = m.index;
			lineEnd = lineStart + m[0].length;
			locator.lineNumber++;
			//console.log('line++:',locator,startPos,endPos)
		}
		locator.columnNumber = p-lineStart+1;
	}
	var lineStart = 0;
	var lineEnd = 0;
	var linePattern = /.*(?:\r\n?|\n)|.*$/g
	var locator = domBuilder.locator;
	
	var parseStack = [{currentNSMap:defaultNSMapCopy}]
	var closeMap = {};
	var start = 0;
	while(true){
		try{
			var tagStart = source.indexOf('<',start);
			if(tagStart<0){
				if(!source.substr(start).match(/^\s*$/)){
					var doc = domBuilder.doc;
	    			var text = doc.createTextNode(source.substr(start));
	    			doc.appendChild(text);
	    			domBuilder.currentElement = text;
				}
				return;
			}
			if(tagStart>start){
				appendText(tagStart);
			}
			switch(source.charAt(tagStart+1)){
			case '/':
				var end = source.indexOf('>',tagStart+3);
				var tagName = source.substring(tagStart+2,end);
				var config = parseStack.pop();
				if(end<0){
					
	        		tagName = source.substring(tagStart+2).replace(/[\s<].*/,'');
	        		//console.error('#@@@@@@'+tagName)
	        		errorHandler.error("end tag name: "+tagName+' is not complete:'+config.tagName);
	        		end = tagStart+1+tagName.length;
	        	}else if(tagName.match(/\s</)){
	        		tagName = tagName.replace(/[\s<].*/,'');
	        		errorHandler.error("end tag name: "+tagName+' maybe not complete');
	        		end = tagStart+1+tagName.length;
				}
				//console.error(parseStack.length,parseStack)
				//console.error(config);
				var localNSMap = config.localNSMap;
				var endMatch = config.tagName == tagName;
				var endIgnoreCaseMach = endMatch || config.tagName&&config.tagName.toLowerCase() == tagName.toLowerCase()
		        if(endIgnoreCaseMach){
		        	domBuilder.endElement(config.uri,config.localName,tagName);
					if(localNSMap){
						for(var prefix in localNSMap){
							domBuilder.endPrefixMapping(prefix) ;
						}
					}
					if(!endMatch){
		            	errorHandler.fatalError("end tag name: "+tagName+' is not match the current start tagName:'+config.tagName ); // No known test case
					}
		        }else{
		        	parseStack.push(config)
		        }
				
				end++;
				break;
				// end elment
			case '?':// <?...?>
				locator&&position(tagStart);
				end = parseInstruction(source,tagStart,domBuilder);
				break;
			case '!':// <!doctype,<![CDATA,<!--
				locator&&position(tagStart);
				end = parseDCC(source,tagStart,domBuilder,errorHandler);
				break;
			default:
				locator&&position(tagStart);
				var el = new ElementAttributes();
				var currentNSMap = parseStack[parseStack.length-1].currentNSMap;
				//elStartEnd
				var end = parseElementStartPart(source,tagStart,el,currentNSMap,entityReplacer,errorHandler);
				var len = el.length;
				
				
				if(!el.closed && fixSelfClosed(source,end,el.tagName,closeMap)){
					el.closed = true;
					if(!entityMap.nbsp){
						errorHandler.warning('unclosed xml attribute');
					}
				}
				if(locator && len){
					var locator2 = copyLocator(locator,{});
					//try{//attribute position fixed
					for(var i = 0;i<len;i++){
						var a = el[i];
						position(a.offset);
						a.locator = copyLocator(locator,{});
					}
					//}catch(e){console.error('@@@@@'+e)}
					domBuilder.locator = locator2
					if(appendElement(el,domBuilder,currentNSMap)){
						parseStack.push(el)
					}
					domBuilder.locator = locator;
				}else{
					if(appendElement(el,domBuilder,currentNSMap)){
						parseStack.push(el)
					}
				}
				
				
				
				if(el.uri === 'http://www.w3.org/1999/xhtml' && !el.closed){
					end = parseHtmlSpecialContent(source,end,el.tagName,entityReplacer,domBuilder)
				}else{
					end++;
				}
			}
		}catch(e){
			if (e instanceof ParseError) {
				throw e;
			}
			errorHandler.error('element parse error: '+e)
			end = -1;
		}
		if(end>start){
			start = end;
		}else{
			//TODO: 这里有可能sax回退，有位置错误风险
			appendText(Math.max(tagStart,start)+1);
		}
	}
}
function copyLocator(f,t){
	t.lineNumber = f.lineNumber;
	t.columnNumber = f.columnNumber;
	return t;
}

/**
 * @see #appendElement(source,elStartEnd,el,selfClosed,entityReplacer,domBuilder,parseStack);
 * @return end of the elementStartPart(end of elementEndPart for selfClosed el)
 */
function parseElementStartPart(source,start,el,currentNSMap,entityReplacer,errorHandler){

	/**
	 * @param {string} qname
	 * @param {string} value
	 * @param {number} startIndex
	 */
	function addAttribute(qname, value, startIndex) {
		if (qname in el.attributeNames) errorHandler.fatalError('Attribute ' + qname + ' redefined')
		el.addValue(qname, value, startIndex)
	}
	var attrName;
	var value;
	var p = ++start;
	var s = S_TAG;//status
	while(true){
		var c = source.charAt(p);
		switch(c){
		case '=':
			if(s === S_ATTR){//attrName
				attrName = source.slice(start,p);
				s = S_EQ;
			}else if(s === S_ATTR_SPACE){
				s = S_EQ;
			}else{
				//fatalError: equal must after attrName or space after attrName
				throw new Error('attribute equal must after attrName'); // No known test case
			}
			break;
		case '\'':
		case '"':
			if(s === S_EQ || s === S_ATTR //|| s == S_ATTR_SPACE
				){//equal
				if(s === S_ATTR){
					errorHandler.warning('attribute value must after "="')
					attrName = source.slice(start,p)
				}
				start = p+1;
				p = source.indexOf(c,start)
				if(p>0){
					value = source.slice(start,p).replace(/&#?\w+;/g,entityReplacer);
					addAttribute(attrName, value, start-1);
					s = S_ATTR_END;
				}else{
					//fatalError: no end quot match
					throw new Error('attribute value no end \''+c+'\' match');
				}
			}else if(s == S_ATTR_NOQUOT_VALUE){
				value = source.slice(start,p).replace(/&#?\w+;/g,entityReplacer);
				//console.log(attrName,value,start,p)
				addAttribute(attrName, value, start);
				//console.dir(el)
				errorHandler.warning('attribute "'+attrName+'" missed start quot('+c+')!!');
				start = p+1;
				s = S_ATTR_END
			}else{
				//fatalError: no equal before
				throw new Error('attribute value must after "="'); // No known test case
			}
			break;
		case '/':
			switch(s){
			case S_TAG:
				el.setTagName(source.slice(start,p));
			case S_ATTR_END:
			case S_TAG_SPACE:
			case S_TAG_CLOSE:
				s =S_TAG_CLOSE;
				el.closed = true;
			case S_ATTR_NOQUOT_VALUE:
			case S_ATTR:
			case S_ATTR_SPACE:
				break;
			//case S_EQ:
			default:
				throw new Error("attribute invalid close char('/')") // No known test case
			}
			break;
		case ''://end document
			errorHandler.error('unexpected end of input');
			if(s == S_TAG){
				el.setTagName(source.slice(start,p));
			}
			return p;
		case '>':
			switch(s){
			case S_TAG:
				el.setTagName(source.slice(start,p));
			case S_ATTR_END:
			case S_TAG_SPACE:
			case S_TAG_CLOSE:
				break;//normal
			case S_ATTR_NOQUOT_VALUE://Compatible state
			case S_ATTR:
				value = source.slice(start,p);
				if(value.slice(-1) === '/'){
					el.closed  = true;
					value = value.slice(0,-1)
				}
			case S_ATTR_SPACE:
				if(s === S_ATTR_SPACE){
					value = attrName;
				}
				if(s == S_ATTR_NOQUOT_VALUE){
					errorHandler.warning('attribute "'+value+'" missed quot(")!');
					addAttribute(attrName, value.replace(/&#?\w+;/g,entityReplacer), start)
				}else{
					if(currentNSMap[''] !== 'http://www.w3.org/1999/xhtml' || !value.match(/^(?:disabled|checked|selected)$/i)){
						errorHandler.warning('attribute "'+value+'" missed value!! "'+value+'" instead!!')
					}
					addAttribute(value, value, start)
				}
				break;
			case S_EQ:
				throw new Error('attribute value missed!!');
			}
//			console.log(tagName,tagNamePattern,tagNamePattern.test(tagName))
			return p;
		/*xml space '\x20' | #x9 | #xD | #xA; */
		case '\u0080':
			c = ' ';
		default:
			if(c<= ' '){//space
				switch(s){
				case S_TAG:
					el.setTagName(source.slice(start,p));//tagName
					s = S_TAG_SPACE;
					break;
				case S_ATTR:
					attrName = source.slice(start,p)
					s = S_ATTR_SPACE;
					break;
				case S_ATTR_NOQUOT_VALUE:
					var value = source.slice(start,p).replace(/&#?\w+;/g,entityReplacer);
					errorHandler.warning('attribute "'+value+'" missed quot(")!!');
					addAttribute(attrName, value, start)
				case S_ATTR_END:
					s = S_TAG_SPACE;
					break;
				//case S_TAG_SPACE:
				//case S_EQ:
				//case S_ATTR_SPACE:
				//	void();break;
				//case S_TAG_CLOSE:
					//ignore warning
				}
			}else{//not space
//S_TAG,	S_ATTR,	S_EQ,	S_ATTR_NOQUOT_VALUE
//S_ATTR_SPACE,	S_ATTR_END,	S_TAG_SPACE, S_TAG_CLOSE
				switch(s){
				//case S_TAG:void();break;
				//case S_ATTR:void();break;
				//case S_ATTR_NOQUOT_VALUE:void();break;
				case S_ATTR_SPACE:
					var tagName =  el.tagName;
					if(currentNSMap[''] !== 'http://www.w3.org/1999/xhtml' || !attrName.match(/^(?:disabled|checked|selected)$/i)){
						errorHandler.warning('attribute "'+attrName+'" missed value!! "'+attrName+'" instead2!!')
					}
					addAttribute(attrName, attrName, start);
					start = p;
					s = S_ATTR;
					break;
				case S_ATTR_END:
					errorHandler.warning('attribute space is required"'+attrName+'"!!')
				case S_TAG_SPACE:
					s = S_ATTR;
					start = p;
					break;
				case S_EQ:
					s = S_ATTR_NOQUOT_VALUE;
					start = p;
					break;
				case S_TAG_CLOSE:
					throw new Error("elements closed character '/' and '>' must be connected to");
				}
			}
		}//end outer switch
		//console.log('p++',p)
		p++;
	}
}
/**
 * @return true if has new namespace define
 */
function appendElement(el,domBuilder,currentNSMap){
	var tagName = el.tagName;
	var localNSMap = null;
	//var currentNSMap = parseStack[parseStack.length-1].currentNSMap;
	var i = el.length;
	while(i--){
		var a = el[i];
		var qName = a.qName;
		var value = a.value;
		var nsp = qName.indexOf(':');
		if(nsp>0){
			var prefix = a.prefix = qName.slice(0,nsp);
			var localName = qName.slice(nsp+1);
			var nsPrefix = prefix === 'xmlns' && localName
		}else{
			localName = qName;
			prefix = null
			nsPrefix = qName === 'xmlns' && ''
		}
		//can not set prefix,because prefix !== ''
		a.localName = localName ;
		//prefix == null for no ns prefix attribute 
		if(nsPrefix !== false){//hack!!
			if(localNSMap == null){
				localNSMap = {}
				//console.log(currentNSMap,0)
				_copy(currentNSMap,currentNSMap={})
				//console.log(currentNSMap,1)
			}
			currentNSMap[nsPrefix] = localNSMap[nsPrefix] = value;
			a.uri = 'http://www.w3.org/2000/xmlns/'
			domBuilder.startPrefixMapping(nsPrefix, value) 
		}
	}
	var i = el.length;
	while(i--){
		a = el[i];
		var prefix = a.prefix;
		if(prefix){//no prefix attribute has no namespace
			if(prefix === 'xml'){
				a.uri = 'http://www.w3.org/XML/1998/namespace';
			}if(prefix !== 'xmlns'){
				a.uri = currentNSMap[prefix || '']
				
				//{console.log('###'+a.qName,domBuilder.locator.systemId+'',currentNSMap,a.uri)}
			}
		}
	}
	var nsp = tagName.indexOf(':');
	if(nsp>0){
		prefix = el.prefix = tagName.slice(0,nsp);
		localName = el.localName = tagName.slice(nsp+1);
	}else{
		prefix = null;//important!!
		localName = el.localName = tagName;
	}
	//no prefix element has default namespace
	var ns = el.uri = currentNSMap[prefix || ''];
	domBuilder.startElement(ns,localName,tagName,el);
	//endPrefixMapping and startPrefixMapping have not any help for dom builder
	//localNSMap = null
	if(el.closed){
		domBuilder.endElement(ns,localName,tagName);
		if(localNSMap){
			for(prefix in localNSMap){
				domBuilder.endPrefixMapping(prefix) 
			}
		}
	}else{
		el.currentNSMap = currentNSMap;
		el.localNSMap = localNSMap;
		//parseStack.push(el);
		return true;
	}
}
function parseHtmlSpecialContent(source,elStartEnd,tagName,entityReplacer,domBuilder){
	if(/^(?:script|textarea)$/i.test(tagName)){
		var elEndStart =  source.indexOf('</'+tagName+'>',elStartEnd);
		var text = source.substring(elStartEnd+1,elEndStart);
		if(/[&<]/.test(text)){
			if(/^script$/i.test(tagName)){
				//if(!/\]\]>/.test(text)){
					//lexHandler.startCDATA();
					domBuilder.characters(text,0,text.length);
					//lexHandler.endCDATA();
					return elEndStart;
				//}
			}//}else{//text area
				text = text.replace(/&#?\w+;/g,entityReplacer);
				domBuilder.characters(text,0,text.length);
				return elEndStart;
			//}
			
		}
	}
	return elStartEnd+1;
}
function fixSelfClosed(source,elStartEnd,tagName,closeMap){
	//if(tagName in closeMap){
	var pos = closeMap[tagName];
	if(pos == null){
		//console.log(tagName)
		pos =  source.lastIndexOf('</'+tagName+'>')
		if(pos<elStartEnd){//忘记闭合
			pos = source.lastIndexOf('</'+tagName)
		}
		closeMap[tagName] =pos
	}
	return pos<elStartEnd;
	//} 
}
function _copy(source,target){
	for(var n in source){target[n] = source[n]}
}
function parseDCC(source,start,domBuilder,errorHandler){//sure start with '<!'
	var next= source.charAt(start+2)
	switch(next){
	case '-':
		if(source.charAt(start + 3) === '-'){
			var end = source.indexOf('-->',start+4);
			//append comment source.substring(4,end)//<!--
			if(end>start){
				domBuilder.comment(source,start+4,end-start-4);
				return end+3;
			}else{
				errorHandler.error("Unclosed comment");
				return -1;
			}
		}else{
			//error
			return -1;
		}
	default:
		if(source.substr(start+3,6) == 'CDATA['){
			var end = source.indexOf(']]>',start+9);
			domBuilder.startCDATA();
			domBuilder.characters(source,start+9,end-start-9);
			domBuilder.endCDATA() 
			return end+3;
		}
		//<!DOCTYPE
		//startDTD(java.lang.String name, java.lang.String publicId, java.lang.String systemId) 
		var matchs = split(source,start);
		var len = matchs.length;
		if(len>1 && /!doctype/i.test(matchs[0][0])){
			var name = matchs[1][0];
			var pubid = false;
			var sysid = false;
			if(len>3){
				if(/^public$/i.test(matchs[2][0])){
					pubid = matchs[3][0];
					sysid = len>4 && matchs[4][0];
				}else if(/^system$/i.test(matchs[2][0])){
					sysid = matchs[3][0];
				}
			}
			var lastMatch = matchs[len-1]
			domBuilder.startDTD(name, pubid, sysid);
			domBuilder.endDTD();
			
			return lastMatch.index+lastMatch[0].length
		}
	}
	return -1;
}



function parseInstruction(source,start,domBuilder){
	var end = source.indexOf('?>',start);
	if(end){
		var match = source.substring(start,end).match(/^<\?(\S*)\s*([\s\S]*?)\s*$/);
		if(match){
			var len = match[0].length;
			domBuilder.processingInstruction(match[1], match[2]) ;
			return end+2;
		}else{//error
			return -1;
		}
	}
	return -1;
}

function ElementAttributes(){
	this.attributeNames = {}
}
ElementAttributes.prototype = {
	setTagName:function(tagName){
		if(!tagNamePattern.test(tagName)){
			throw new Error('invalid tagName:'+tagName)
		}
		this.tagName = tagName
	},
	addValue:function(qName, value, offset) {
		if(!tagNamePattern.test(qName)){
			throw new Error('invalid attribute:'+qName)
		}
		this.attributeNames[qName] = this.length;
		this[this.length++] = {qName:qName,value:value,offset:offset}
	},
	length:0,
	getLocalName:function(i){return this[i].localName},
	getLocator:function(i){return this[i].locator},
	getQName:function(i){return this[i].qName},
	getURI:function(i){return this[i].uri},
	getValue:function(i){return this[i].value}
//	,getIndex:function(uri, localName)){
//		if(localName){
//			
//		}else{
//			var qName = uri
//		}
//	},
//	getValue:function(){return this.getValue(this.getIndex.apply(this,arguments))},
//	getType:function(uri,localName){}
//	getType:function(i){},
}



function split(source,start){
	var match;
	var buf = [];
	var reg = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;
	reg.lastIndex = start;
	reg.exec(source);//skip <
	while(match = reg.exec(source)){
		buf.push(match);
		if(match[1])return buf;
	}
}

exports.XMLReader = XMLReader;
exports.ParseError = ParseError;


/***/ }),
/* 73 */
/***/ ((__unused_webpack_module, exports) => {

function copy(src,dest){
	for(var p in src){
		dest[p] = src[p];
	}
}
/**
^\w+\.prototype\.([_\w]+)\s*=\s*((?:.*\{\s*?[\r\n][\s\S]*?^})|\S.*?(?=[;\r\n]));?
^\w+\.prototype\.([_\w]+)\s*=\s*(\S.*?(?=[;\r\n]));?
 */
function _extends(Class,Super){
	var pt = Class.prototype;
	if(!(pt instanceof Super)){
		function t(){};
		t.prototype = Super.prototype;
		t = new t();
		copy(pt,t);
		Class.prototype = pt = t;
	}
	if(pt.constructor != Class){
		if(typeof Class != 'function'){
			console.error("unknow Class:"+Class)
		}
		pt.constructor = Class
	}
}
var htmlns = 'http://www.w3.org/1999/xhtml' ;
// Node Types
var NodeType = {}
var ELEMENT_NODE                = NodeType.ELEMENT_NODE                = 1;
var ATTRIBUTE_NODE              = NodeType.ATTRIBUTE_NODE              = 2;
var TEXT_NODE                   = NodeType.TEXT_NODE                   = 3;
var CDATA_SECTION_NODE          = NodeType.CDATA_SECTION_NODE          = 4;
var ENTITY_REFERENCE_NODE       = NodeType.ENTITY_REFERENCE_NODE       = 5;
var ENTITY_NODE                 = NodeType.ENTITY_NODE                 = 6;
var PROCESSING_INSTRUCTION_NODE = NodeType.PROCESSING_INSTRUCTION_NODE = 7;
var COMMENT_NODE                = NodeType.COMMENT_NODE                = 8;
var DOCUMENT_NODE               = NodeType.DOCUMENT_NODE               = 9;
var DOCUMENT_TYPE_NODE          = NodeType.DOCUMENT_TYPE_NODE          = 10;
var DOCUMENT_FRAGMENT_NODE      = NodeType.DOCUMENT_FRAGMENT_NODE      = 11;
var NOTATION_NODE               = NodeType.NOTATION_NODE               = 12;

// ExceptionCode
var ExceptionCode = {}
var ExceptionMessage = {};
var INDEX_SIZE_ERR              = ExceptionCode.INDEX_SIZE_ERR              = ((ExceptionMessage[1]="Index size error"),1);
var DOMSTRING_SIZE_ERR          = ExceptionCode.DOMSTRING_SIZE_ERR          = ((ExceptionMessage[2]="DOMString size error"),2);
var HIERARCHY_REQUEST_ERR       = ExceptionCode.HIERARCHY_REQUEST_ERR       = ((ExceptionMessage[3]="Hierarchy request error"),3);
var WRONG_DOCUMENT_ERR          = ExceptionCode.WRONG_DOCUMENT_ERR          = ((ExceptionMessage[4]="Wrong document"),4);
var INVALID_CHARACTER_ERR       = ExceptionCode.INVALID_CHARACTER_ERR       = ((ExceptionMessage[5]="Invalid character"),5);
var NO_DATA_ALLOWED_ERR         = ExceptionCode.NO_DATA_ALLOWED_ERR         = ((ExceptionMessage[6]="No data allowed"),6);
var NO_MODIFICATION_ALLOWED_ERR = ExceptionCode.NO_MODIFICATION_ALLOWED_ERR = ((ExceptionMessage[7]="No modification allowed"),7);
var NOT_FOUND_ERR               = ExceptionCode.NOT_FOUND_ERR               = ((ExceptionMessage[8]="Not found"),8);
var NOT_SUPPORTED_ERR           = ExceptionCode.NOT_SUPPORTED_ERR           = ((ExceptionMessage[9]="Not supported"),9);
var INUSE_ATTRIBUTE_ERR         = ExceptionCode.INUSE_ATTRIBUTE_ERR         = ((ExceptionMessage[10]="Attribute in use"),10);
//level2
var INVALID_STATE_ERR        	= ExceptionCode.INVALID_STATE_ERR        	= ((ExceptionMessage[11]="Invalid state"),11);
var SYNTAX_ERR               	= ExceptionCode.SYNTAX_ERR               	= ((ExceptionMessage[12]="Syntax error"),12);
var INVALID_MODIFICATION_ERR 	= ExceptionCode.INVALID_MODIFICATION_ERR 	= ((ExceptionMessage[13]="Invalid modification"),13);
var NAMESPACE_ERR            	= ExceptionCode.NAMESPACE_ERR           	= ((ExceptionMessage[14]="Invalid namespace"),14);
var INVALID_ACCESS_ERR       	= ExceptionCode.INVALID_ACCESS_ERR      	= ((ExceptionMessage[15]="Invalid access"),15);

/**
 * DOM Level 2
 * Object DOMException
 * @see http://www.w3.org/TR/2000/REC-DOM-Level-2-Core-20001113/ecma-script-binding.html
 * @see http://www.w3.org/TR/REC-DOM-Level-1/ecma-script-language-binding.html
 */
function DOMException(code, message) {
	if(message instanceof Error){
		var error = message;
	}else{
		error = this;
		Error.call(this, ExceptionMessage[code]);
		this.message = ExceptionMessage[code];
		if(Error.captureStackTrace) Error.captureStackTrace(this, DOMException);
	}
	error.code = code;
	if(message) this.message = this.message + ": " + message;
	return error;
};
DOMException.prototype = Error.prototype;
copy(ExceptionCode,DOMException)
/**
 * @see http://www.w3.org/TR/2000/REC-DOM-Level-2-Core-20001113/core.html#ID-536297177
 * The NodeList interface provides the abstraction of an ordered collection of nodes, without defining or constraining how this collection is implemented. NodeList objects in the DOM are live.
 * The items in the NodeList are accessible via an integral index, starting from 0.
 */
function NodeList() {
};
NodeList.prototype = {
	/**
	 * The number of nodes in the list. The range of valid child node indices is 0 to length-1 inclusive.
	 * @standard level1
	 */
	length:0, 
	/**
	 * Returns the indexth item in the collection. If index is greater than or equal to the number of nodes in the list, this returns null.
	 * @standard level1
	 * @param index  unsigned long 
	 *   Index into the collection.
	 * @return Node
	 * 	The node at the indexth position in the NodeList, or null if that is not a valid index. 
	 */
	item: function(index) {
		return this[index] || null;
	},
	toString:function(isHTML,nodeFilter){
		for(var buf = [], i = 0;i<this.length;i++){
			serializeToString(this[i],buf,isHTML,nodeFilter);
		}
		return buf.join('');
	}
};
function LiveNodeList(node,refresh){
	this._node = node;
	this._refresh = refresh
	_updateLiveList(this);
}
function _updateLiveList(list){
	var inc = list._node._inc || list._node.ownerDocument._inc;
	if(list._inc != inc){
		var ls = list._refresh(list._node);
		//console.log(ls.length)
		__set__(list,'length',ls.length);
		copy(ls,list);
		list._inc = inc;
	}
}
LiveNodeList.prototype.item = function(i){
	_updateLiveList(this);
	return this[i];
}

_extends(LiveNodeList,NodeList);
/**
 * 
 * Objects implementing the NamedNodeMap interface are used to represent collections of nodes that can be accessed by name. Note that NamedNodeMap does not inherit from NodeList; NamedNodeMaps are not maintained in any particular order. Objects contained in an object implementing NamedNodeMap may also be accessed by an ordinal index, but this is simply to allow convenient enumeration of the contents of a NamedNodeMap, and does not imply that the DOM specifies an order to these Nodes.
 * NamedNodeMap objects in the DOM are live.
 * used for attributes or DocumentType entities 
 */
function NamedNodeMap() {
};

function _findNodeIndex(list,node){
	var i = list.length;
	while(i--){
		if(list[i] === node){return i}
	}
}

function _addNamedNode(el,list,newAttr,oldAttr){
	if(oldAttr){
		list[_findNodeIndex(list,oldAttr)] = newAttr;
	}else{
		list[list.length++] = newAttr;
	}
	if(el){
		newAttr.ownerElement = el;
		var doc = el.ownerDocument;
		if(doc){
			oldAttr && _onRemoveAttribute(doc,el,oldAttr);
			_onAddAttribute(doc,el,newAttr);
		}
	}
}
function _removeNamedNode(el,list,attr){
	//console.log('remove attr:'+attr)
	var i = _findNodeIndex(list,attr);
	if(i>=0){
		var lastIndex = list.length-1
		while(i<lastIndex){
			list[i] = list[++i]
		}
		list.length = lastIndex;
		if(el){
			var doc = el.ownerDocument;
			if(doc){
				_onRemoveAttribute(doc,el,attr);
				attr.ownerElement = null;
			}
		}
	}else{
		throw DOMException(NOT_FOUND_ERR,new Error(el.tagName+'@'+attr))
	}
}
NamedNodeMap.prototype = {
	length:0,
	item:NodeList.prototype.item,
	getNamedItem: function(key) {
//		if(key.indexOf(':')>0 || key == 'xmlns'){
//			return null;
//		}
		//console.log()
		var i = this.length;
		while(i--){
			var attr = this[i];
			//console.log(attr.nodeName,key)
			if(attr.nodeName == key){
				return attr;
			}
		}
	},
	setNamedItem: function(attr) {
		var el = attr.ownerElement;
		if(el && el!=this._ownerElement){
			throw new DOMException(INUSE_ATTRIBUTE_ERR);
		}
		var oldAttr = this.getNamedItem(attr.nodeName);
		_addNamedNode(this._ownerElement,this,attr,oldAttr);
		return oldAttr;
	},
	/* returns Node */
	setNamedItemNS: function(attr) {// raises: WRONG_DOCUMENT_ERR,NO_MODIFICATION_ALLOWED_ERR,INUSE_ATTRIBUTE_ERR
		var el = attr.ownerElement, oldAttr;
		if(el && el!=this._ownerElement){
			throw new DOMException(INUSE_ATTRIBUTE_ERR);
		}
		oldAttr = this.getNamedItemNS(attr.namespaceURI,attr.localName);
		_addNamedNode(this._ownerElement,this,attr,oldAttr);
		return oldAttr;
	},

	/* returns Node */
	removeNamedItem: function(key) {
		var attr = this.getNamedItem(key);
		_removeNamedNode(this._ownerElement,this,attr);
		return attr;
		
		
	},// raises: NOT_FOUND_ERR,NO_MODIFICATION_ALLOWED_ERR
	
	//for level2
	removeNamedItemNS:function(namespaceURI,localName){
		var attr = this.getNamedItemNS(namespaceURI,localName);
		_removeNamedNode(this._ownerElement,this,attr);
		return attr;
	},
	getNamedItemNS: function(namespaceURI, localName) {
		var i = this.length;
		while(i--){
			var node = this[i];
			if(node.localName == localName && node.namespaceURI == namespaceURI){
				return node;
			}
		}
		return null;
	}
};
/**
 * @see http://www.w3.org/TR/REC-DOM-Level-1/level-one-core.html#ID-102161490
 */
function DOMImplementation(/* Object */ features) {
	this._features = {};
	if (features) {
		for (var feature in features) {
			 this._features = features[feature];
		}
	}
};

DOMImplementation.prototype = {
	hasFeature: function(/* string */ feature, /* string */ version) {
		var versions = this._features[feature.toLowerCase()];
		if (versions && (!version || version in versions)) {
			return true;
		} else {
			return false;
		}
	},
	// Introduced in DOM Level 2:
	createDocument:function(namespaceURI,  qualifiedName, doctype){// raises:INVALID_CHARACTER_ERR,NAMESPACE_ERR,WRONG_DOCUMENT_ERR
		var doc = new Document();
		doc.implementation = this;
		doc.childNodes = new NodeList();
		doc.doctype = doctype;
		if(doctype){
			doc.appendChild(doctype);
		}
		if(qualifiedName){
			var root = doc.createElementNS(namespaceURI,qualifiedName);
			doc.appendChild(root);
		}
		return doc;
	},
	// Introduced in DOM Level 2:
	createDocumentType:function(qualifiedName, publicId, systemId){// raises:INVALID_CHARACTER_ERR,NAMESPACE_ERR
		var node = new DocumentType();
		node.name = qualifiedName;
		node.nodeName = qualifiedName;
		node.publicId = publicId;
		node.systemId = systemId;
		// Introduced in DOM Level 2:
		//readonly attribute DOMString        internalSubset;
		
		//TODO:..
		//  readonly attribute NamedNodeMap     entities;
		//  readonly attribute NamedNodeMap     notations;
		return node;
	}
};


/**
 * @see http://www.w3.org/TR/2000/REC-DOM-Level-2-Core-20001113/core.html#ID-1950641247
 */

function Node() {
};

Node.prototype = {
	firstChild : null,
	lastChild : null,
	previousSibling : null,
	nextSibling : null,
	attributes : null,
	parentNode : null,
	childNodes : null,
	ownerDocument : null,
	nodeValue : null,
	namespaceURI : null,
	prefix : null,
	localName : null,
	// Modified in DOM Level 2:
	insertBefore:function(newChild, refChild){//raises 
		return _insertBefore(this,newChild,refChild);
	},
	replaceChild:function(newChild, oldChild){//raises 
		this.insertBefore(newChild,oldChild);
		if(oldChild){
			this.removeChild(oldChild);
		}
	},
	removeChild:function(oldChild){
		return _removeChild(this,oldChild);
	},
	appendChild:function(newChild){
		return this.insertBefore(newChild,null);
	},
	hasChildNodes:function(){
		return this.firstChild != null;
	},
	cloneNode:function(deep){
		return cloneNode(this.ownerDocument||this,this,deep);
	},
	// Modified in DOM Level 2:
	normalize:function(){
		var child = this.firstChild;
		while(child){
			var next = child.nextSibling;
			if(next && next.nodeType == TEXT_NODE && child.nodeType == TEXT_NODE){
				this.removeChild(next);
				child.appendData(next.data);
			}else{
				child.normalize();
				child = next;
			}
		}
	},
  	// Introduced in DOM Level 2:
	isSupported:function(feature, version){
		return this.ownerDocument.implementation.hasFeature(feature,version);
	},
    // Introduced in DOM Level 2:
    hasAttributes:function(){
    	return this.attributes.length>0;
    },
    lookupPrefix:function(namespaceURI){
    	var el = this;
    	while(el){
    		var map = el._nsMap;
    		//console.dir(map)
    		if(map){
    			for(var n in map){
    				if(map[n] == namespaceURI){
    					return n;
    				}
    			}
    		}
    		el = el.nodeType == ATTRIBUTE_NODE?el.ownerDocument : el.parentNode;
    	}
    	return null;
    },
    // Introduced in DOM Level 3:
    lookupNamespaceURI:function(prefix){
    	var el = this;
    	while(el){
    		var map = el._nsMap;
    		//console.dir(map)
    		if(map){
    			if(prefix in map){
    				return map[prefix] ;
    			}
    		}
    		el = el.nodeType == ATTRIBUTE_NODE?el.ownerDocument : el.parentNode;
    	}
    	return null;
    },
    // Introduced in DOM Level 3:
    isDefaultNamespace:function(namespaceURI){
    	var prefix = this.lookupPrefix(namespaceURI);
    	return prefix == null;
    }
};


function _xmlEncoder(c){
	return c == '<' && '&lt;' ||
         c == '>' && '&gt;' ||
         c == '&' && '&amp;' ||
         c == '"' && '&quot;' ||
         '&#'+c.charCodeAt()+';'
}


copy(NodeType,Node);
copy(NodeType,Node.prototype);

/**
 * @param callback return true for continue,false for break
 * @return boolean true: break visit;
 */
function _visitNode(node,callback){
	if(callback(node)){
		return true;
	}
	if(node = node.firstChild){
		do{
			if(_visitNode(node,callback)){return true}
        }while(node=node.nextSibling)
    }
}



function Document(){
}
function _onAddAttribute(doc,el,newAttr){
	doc && doc._inc++;
	var ns = newAttr.namespaceURI ;
	if(ns == 'http://www.w3.org/2000/xmlns/'){
		//update namespace
		el._nsMap[newAttr.prefix?newAttr.localName:''] = newAttr.value
	}
}
function _onRemoveAttribute(doc,el,newAttr,remove){
	doc && doc._inc++;
	var ns = newAttr.namespaceURI ;
	if(ns == 'http://www.w3.org/2000/xmlns/'){
		//update namespace
		delete el._nsMap[newAttr.prefix?newAttr.localName:'']
	}
}
function _onUpdateChild(doc,el,newChild){
	if(doc && doc._inc){
		doc._inc++;
		//update childNodes
		var cs = el.childNodes;
		if(newChild){
			cs[cs.length++] = newChild;
		}else{
			//console.log(1)
			var child = el.firstChild;
			var i = 0;
			while(child){
				cs[i++] = child;
				child =child.nextSibling;
			}
			cs.length = i;
		}
	}
}

/**
 * attributes;
 * children;
 * 
 * writeable properties:
 * nodeValue,Attr:value,CharacterData:data
 * prefix
 */
function _removeChild(parentNode,child){
	var previous = child.previousSibling;
	var next = child.nextSibling;
	if(previous){
		previous.nextSibling = next;
	}else{
		parentNode.firstChild = next
	}
	if(next){
		next.previousSibling = previous;
	}else{
		parentNode.lastChild = previous;
	}
	_onUpdateChild(parentNode.ownerDocument,parentNode);
	return child;
}
/**
 * preformance key(refChild == null)
 */
function _insertBefore(parentNode,newChild,nextChild){
	var cp = newChild.parentNode;
	if(cp){
		cp.removeChild(newChild);//remove and update
	}
	if(newChild.nodeType === DOCUMENT_FRAGMENT_NODE){
		var newFirst = newChild.firstChild;
		if (newFirst == null) {
			return newChild;
		}
		var newLast = newChild.lastChild;
	}else{
		newFirst = newLast = newChild;
	}
	var pre = nextChild ? nextChild.previousSibling : parentNode.lastChild;

	newFirst.previousSibling = pre;
	newLast.nextSibling = nextChild;
	
	
	if(pre){
		pre.nextSibling = newFirst;
	}else{
		parentNode.firstChild = newFirst;
	}
	if(nextChild == null){
		parentNode.lastChild = newLast;
	}else{
		nextChild.previousSibling = newLast;
	}
	do{
		newFirst.parentNode = parentNode;
	}while(newFirst !== newLast && (newFirst= newFirst.nextSibling))
	_onUpdateChild(parentNode.ownerDocument||parentNode,parentNode);
	//console.log(parentNode.lastChild.nextSibling == null)
	if (newChild.nodeType == DOCUMENT_FRAGMENT_NODE) {
		newChild.firstChild = newChild.lastChild = null;
	}
	return newChild;
}
function _appendSingleChild(parentNode,newChild){
	var cp = newChild.parentNode;
	if(cp){
		var pre = parentNode.lastChild;
		cp.removeChild(newChild);//remove and update
		var pre = parentNode.lastChild;
	}
	var pre = parentNode.lastChild;
	newChild.parentNode = parentNode;
	newChild.previousSibling = pre;
	newChild.nextSibling = null;
	if(pre){
		pre.nextSibling = newChild;
	}else{
		parentNode.firstChild = newChild;
	}
	parentNode.lastChild = newChild;
	_onUpdateChild(parentNode.ownerDocument,parentNode,newChild);
	return newChild;
	//console.log("__aa",parentNode.lastChild.nextSibling == null)
}
Document.prototype = {
	//implementation : null,
	nodeName :  '#document',
	nodeType :  DOCUMENT_NODE,
	doctype :  null,
	documentElement :  null,
	_inc : 1,
	
	insertBefore :  function(newChild, refChild){//raises 
		if(newChild.nodeType == DOCUMENT_FRAGMENT_NODE){
			var child = newChild.firstChild;
			while(child){
				var next = child.nextSibling;
				this.insertBefore(child,refChild);
				child = next;
			}
			return newChild;
		}
		if(this.documentElement == null && newChild.nodeType == ELEMENT_NODE){
			this.documentElement = newChild;
		}
		
		return _insertBefore(this,newChild,refChild),(newChild.ownerDocument = this),newChild;
	},
	removeChild :  function(oldChild){
		if(this.documentElement == oldChild){
			this.documentElement = null;
		}
		return _removeChild(this,oldChild);
	},
	// Introduced in DOM Level 2:
	importNode : function(importedNode,deep){
		return importNode(this,importedNode,deep);
	},
	// Introduced in DOM Level 2:
	getElementById :	function(id){
		var rtv = null;
		_visitNode(this.documentElement,function(node){
			if(node.nodeType == ELEMENT_NODE){
				if(node.getAttribute('id') == id){
					rtv = node;
					return true;
				}
			}
		})
		return rtv;
	},
	
	getElementsByClassName: function(className) {
		var pattern = new RegExp("(^|\\s)" + className + "(\\s|$)");
		return new LiveNodeList(this, function(base) {
			var ls = [];
			_visitNode(base.documentElement, function(node) {
				if(node !== base && node.nodeType == ELEMENT_NODE) {
					if(pattern.test(node.getAttribute('class'))) {
						ls.push(node);
					}
				}
			});
			return ls;
		});
	},
	
	//document factory method:
	createElement :	function(tagName){
		var node = new Element();
		node.ownerDocument = this;
		node.nodeName = tagName;
		node.tagName = tagName;
		node.childNodes = new NodeList();
		var attrs	= node.attributes = new NamedNodeMap();
		attrs._ownerElement = node;
		return node;
	},
	createDocumentFragment :	function(){
		var node = new DocumentFragment();
		node.ownerDocument = this;
		node.childNodes = new NodeList();
		return node;
	},
	createTextNode :	function(data){
		var node = new Text();
		node.ownerDocument = this;
		node.appendData(data)
		return node;
	},
	createComment :	function(data){
		var node = new Comment();
		node.ownerDocument = this;
		node.appendData(data)
		return node;
	},
	createCDATASection :	function(data){
		var node = new CDATASection();
		node.ownerDocument = this;
		node.appendData(data)
		return node;
	},
	createProcessingInstruction :	function(target,data){
		var node = new ProcessingInstruction();
		node.ownerDocument = this;
		node.tagName = node.target = target;
		node.nodeValue= node.data = data;
		return node;
	},
	createAttribute :	function(name){
		var node = new Attr();
		node.ownerDocument	= this;
		node.name = name;
		node.nodeName	= name;
		node.localName = name;
		node.specified = true;
		return node;
	},
	createEntityReference :	function(name){
		var node = new EntityReference();
		node.ownerDocument	= this;
		node.nodeName	= name;
		return node;
	},
	// Introduced in DOM Level 2:
	createElementNS :	function(namespaceURI,qualifiedName){
		var node = new Element();
		var pl = qualifiedName.split(':');
		var attrs	= node.attributes = new NamedNodeMap();
		node.childNodes = new NodeList();
		node.ownerDocument = this;
		node.nodeName = qualifiedName;
		node.tagName = qualifiedName;
		node.namespaceURI = namespaceURI;
		if(pl.length == 2){
			node.prefix = pl[0];
			node.localName = pl[1];
		}else{
			//el.prefix = null;
			node.localName = qualifiedName;
		}
		attrs._ownerElement = node;
		return node;
	},
	// Introduced in DOM Level 2:
	createAttributeNS :	function(namespaceURI,qualifiedName){
		var node = new Attr();
		var pl = qualifiedName.split(':');
		node.ownerDocument = this;
		node.nodeName = qualifiedName;
		node.name = qualifiedName;
		node.namespaceURI = namespaceURI;
		node.specified = true;
		if(pl.length == 2){
			node.prefix = pl[0];
			node.localName = pl[1];
		}else{
			//el.prefix = null;
			node.localName = qualifiedName;
		}
		return node;
	}
};
_extends(Document,Node);


function Element() {
	this._nsMap = {};
};
Element.prototype = {
	nodeType : ELEMENT_NODE,
	hasAttribute : function(name){
		return this.getAttributeNode(name)!=null;
	},
	getAttribute : function(name){
		var attr = this.getAttributeNode(name);
		return attr && attr.value || '';
	},
	getAttributeNode : function(name){
		return this.attributes.getNamedItem(name);
	},
	setAttribute : function(name, value){
		var attr = this.ownerDocument.createAttribute(name);
		attr.value = attr.nodeValue = "" + value;
		this.setAttributeNode(attr)
	},
	removeAttribute : function(name){
		var attr = this.getAttributeNode(name)
		attr && this.removeAttributeNode(attr);
	},
	
	//four real opeartion method
	appendChild:function(newChild){
		if(newChild.nodeType === DOCUMENT_FRAGMENT_NODE){
			return this.insertBefore(newChild,null);
		}else{
			return _appendSingleChild(this,newChild);
		}
	},
	setAttributeNode : function(newAttr){
		return this.attributes.setNamedItem(newAttr);
	},
	setAttributeNodeNS : function(newAttr){
		return this.attributes.setNamedItemNS(newAttr);
	},
	removeAttributeNode : function(oldAttr){
		//console.log(this == oldAttr.ownerElement)
		return this.attributes.removeNamedItem(oldAttr.nodeName);
	},
	//get real attribute name,and remove it by removeAttributeNode
	removeAttributeNS : function(namespaceURI, localName){
		var old = this.getAttributeNodeNS(namespaceURI, localName);
		old && this.removeAttributeNode(old);
	},
	
	hasAttributeNS : function(namespaceURI, localName){
		return this.getAttributeNodeNS(namespaceURI, localName)!=null;
	},
	getAttributeNS : function(namespaceURI, localName){
		var attr = this.getAttributeNodeNS(namespaceURI, localName);
		return attr && attr.value || '';
	},
	setAttributeNS : function(namespaceURI, qualifiedName, value){
		var attr = this.ownerDocument.createAttributeNS(namespaceURI, qualifiedName);
		attr.value = attr.nodeValue = "" + value;
		this.setAttributeNode(attr)
	},
	getAttributeNodeNS : function(namespaceURI, localName){
		return this.attributes.getNamedItemNS(namespaceURI, localName);
	},
	
	getElementsByTagName : function(tagName){
		return new LiveNodeList(this,function(base){
			var ls = [];
			_visitNode(base,function(node){
				if(node !== base && node.nodeType == ELEMENT_NODE && (tagName === '*' || node.tagName == tagName)){
					ls.push(node);
				}
			});
			return ls;
		});
	},
	getElementsByTagNameNS : function(namespaceURI, localName){
		return new LiveNodeList(this,function(base){
			var ls = [];
			_visitNode(base,function(node){
				if(node !== base && node.nodeType === ELEMENT_NODE && (namespaceURI === '*' || node.namespaceURI === namespaceURI) && (localName === '*' || node.localName == localName)){
					ls.push(node);
				}
			});
			return ls;
			
		});
	}
};
Document.prototype.getElementsByTagName = Element.prototype.getElementsByTagName;
Document.prototype.getElementsByTagNameNS = Element.prototype.getElementsByTagNameNS;


_extends(Element,Node);
function Attr() {
};
Attr.prototype.nodeType = ATTRIBUTE_NODE;
_extends(Attr,Node);


function CharacterData() {
};
CharacterData.prototype = {
	data : '',
	substringData : function(offset, count) {
		return this.data.substring(offset, offset+count);
	},
	appendData: function(text) {
		text = this.data+text;
		this.nodeValue = this.data = text;
		this.length = text.length;
	},
	insertData: function(offset,text) {
		this.replaceData(offset,0,text);
	
	},
	appendChild:function(newChild){
		throw new Error(ExceptionMessage[HIERARCHY_REQUEST_ERR])
	},
	deleteData: function(offset, count) {
		this.replaceData(offset,count,"");
	},
	replaceData: function(offset, count, text) {
		var start = this.data.substring(0,offset);
		var end = this.data.substring(offset+count);
		text = start + text + end;
		this.nodeValue = this.data = text;
		this.length = text.length;
	}
}
_extends(CharacterData,Node);
function Text() {
};
Text.prototype = {
	nodeName : "#text",
	nodeType : TEXT_NODE,
	splitText : function(offset) {
		var text = this.data;
		var newText = text.substring(offset);
		text = text.substring(0, offset);
		this.data = this.nodeValue = text;
		this.length = text.length;
		var newNode = this.ownerDocument.createTextNode(newText);
		if(this.parentNode){
			this.parentNode.insertBefore(newNode, this.nextSibling);
		}
		return newNode;
	}
}
_extends(Text,CharacterData);
function Comment() {
};
Comment.prototype = {
	nodeName : "#comment",
	nodeType : COMMENT_NODE
}
_extends(Comment,CharacterData);

function CDATASection() {
};
CDATASection.prototype = {
	nodeName : "#cdata-section",
	nodeType : CDATA_SECTION_NODE
}
_extends(CDATASection,CharacterData);


function DocumentType() {
};
DocumentType.prototype.nodeType = DOCUMENT_TYPE_NODE;
_extends(DocumentType,Node);

function Notation() {
};
Notation.prototype.nodeType = NOTATION_NODE;
_extends(Notation,Node);

function Entity() {
};
Entity.prototype.nodeType = ENTITY_NODE;
_extends(Entity,Node);

function EntityReference() {
};
EntityReference.prototype.nodeType = ENTITY_REFERENCE_NODE;
_extends(EntityReference,Node);

function DocumentFragment() {
};
DocumentFragment.prototype.nodeName =	"#document-fragment";
DocumentFragment.prototype.nodeType =	DOCUMENT_FRAGMENT_NODE;
_extends(DocumentFragment,Node);


function ProcessingInstruction() {
}
ProcessingInstruction.prototype.nodeType = PROCESSING_INSTRUCTION_NODE;
_extends(ProcessingInstruction,Node);
function XMLSerializer(){}
XMLSerializer.prototype.serializeToString = function(node,isHtml,nodeFilter){
	return nodeSerializeToString.call(node,isHtml,nodeFilter);
}
Node.prototype.toString = nodeSerializeToString;
function nodeSerializeToString(isHtml,nodeFilter){
	var buf = [];
	var refNode = this.nodeType == 9 && this.documentElement || this;
	var prefix = refNode.prefix;
	var uri = refNode.namespaceURI;
	
	if(uri && prefix == null){
		//console.log(prefix)
		var prefix = refNode.lookupPrefix(uri);
		if(prefix == null){
			//isHTML = true;
			var visibleNamespaces=[
			{namespace:uri,prefix:null}
			//{namespace:uri,prefix:''}
			]
		}
	}
	serializeToString(this,buf,isHtml,nodeFilter,visibleNamespaces);
	//console.log('###',this.nodeType,uri,prefix,buf.join(''))
	return buf.join('');
}
function needNamespaceDefine(node,isHTML, visibleNamespaces) {
	var prefix = node.prefix||'';
	var uri = node.namespaceURI;
	if (!prefix && !uri){
		return false;
	}
	if (prefix === "xml" && uri === "http://www.w3.org/XML/1998/namespace" 
		|| uri == 'http://www.w3.org/2000/xmlns/'){
		return false;
	}
	
	var i = visibleNamespaces.length 
	//console.log('@@@@',node.tagName,prefix,uri,visibleNamespaces)
	while (i--) {
		var ns = visibleNamespaces[i];
		// get namespace prefix
		//console.log(node.nodeType,node.tagName,ns.prefix,prefix)
		if (ns.prefix == prefix){
			return ns.namespace != uri;
		}
	}
	//console.log(isHTML,uri,prefix=='')
	//if(isHTML && prefix ==null && uri == 'http://www.w3.org/1999/xhtml'){
	//	return false;
	//}
	//node.flag = '11111'
	//console.error(3,true,node.flag,node.prefix,node.namespaceURI)
	return true;
}
function serializeToString(node,buf,isHTML,nodeFilter,visibleNamespaces){
	if(nodeFilter){
		node = nodeFilter(node);
		if(node){
			if(typeof node == 'string'){
				buf.push(node);
				return;
			}
		}else{
			return;
		}
		//buf.sort.apply(attrs, attributeSorter);
	}
	switch(node.nodeType){
	case ELEMENT_NODE:
		if (!visibleNamespaces) visibleNamespaces = [];
		var startVisibleNamespaces = visibleNamespaces.length;
		var attrs = node.attributes;
		var len = attrs.length;
		var child = node.firstChild;
		var nodeName = node.tagName;
		
		isHTML =  (htmlns === node.namespaceURI) ||isHTML 
		buf.push('<',nodeName);
		
		
		
		for(var i=0;i<len;i++){
			// add namespaces for attributes
			var attr = attrs.item(i);
			if (attr.prefix == 'xmlns') {
				visibleNamespaces.push({ prefix: attr.localName, namespace: attr.value });
			}else if(attr.nodeName == 'xmlns'){
				visibleNamespaces.push({ prefix: '', namespace: attr.value });
			}
		}
		for(var i=0;i<len;i++){
			var attr = attrs.item(i);
			if (needNamespaceDefine(attr,isHTML, visibleNamespaces)) {
				var prefix = attr.prefix||'';
				var uri = attr.namespaceURI;
				var ns = prefix ? ' xmlns:' + prefix : " xmlns";
				buf.push(ns, '="' , uri , '"');
				visibleNamespaces.push({ prefix: prefix, namespace:uri });
			}
			serializeToString(attr,buf,isHTML,nodeFilter,visibleNamespaces);
		}
		// add namespace for current node		
		if (needNamespaceDefine(node,isHTML, visibleNamespaces)) {
			var prefix = node.prefix||'';
			var uri = node.namespaceURI;
			var ns = prefix ? ' xmlns:' + prefix : " xmlns";
			buf.push(ns, '="' , uri , '"');
			visibleNamespaces.push({ prefix: prefix, namespace:uri });
		}
		
		if(child || isHTML && !/^(?:meta|link|img|br|hr|input)$/i.test(nodeName)){
			buf.push('>');
			//if is cdata child node
			if(isHTML && /^script$/i.test(nodeName)){
				while(child){
					if(child.data){
						buf.push(child.data);
					}else{
						serializeToString(child,buf,isHTML,nodeFilter,visibleNamespaces);
					}
					child = child.nextSibling;
				}
			}else
			{
				while(child){
					serializeToString(child,buf,isHTML,nodeFilter,visibleNamespaces);
					child = child.nextSibling;
				}
			}
			buf.push('</',nodeName,'>');
		}else{
			buf.push('/>');
		}
		// remove added visible namespaces
		//visibleNamespaces.length = startVisibleNamespaces;
		return;
	case DOCUMENT_NODE:
	case DOCUMENT_FRAGMENT_NODE:
		var child = node.firstChild;
		while(child){
			serializeToString(child,buf,isHTML,nodeFilter,visibleNamespaces);
			child = child.nextSibling;
		}
		return;
	case ATTRIBUTE_NODE:
		return buf.push(' ',node.name,'="',node.value.replace(/[&"]/g,_xmlEncoder),'"');
	case TEXT_NODE:
		/**
		 * The ampersand character (&) and the left angle bracket (<) must not appear in their literal form,
		 * except when used as markup delimiters, or within a comment, a processing instruction, or a CDATA section.
		 * If they are needed elsewhere, they must be escaped using either numeric character references or the strings
		 * `&amp;` and `&lt;` respectively.
		 * The right angle bracket (>) may be represented using the string " &gt; ", and must, for compatibility,
		 * be escaped using either `&gt;` or a character reference when it appears in the string `]]>` in content,
		 * when that string is not marking the end of a CDATA section.
		 *
		 * In the content of elements, character data is any string of characters
		 * which does not contain the start-delimiter of any markup
		 * and does not include the CDATA-section-close delimiter, `]]>`.
		 *
		 * @see https://www.w3.org/TR/xml/#NT-CharData
		 */
		return buf.push(node.data
			.replace(/[<&]/g,_xmlEncoder)
			.replace(/]]>/g, ']]&gt;')
		);
	case CDATA_SECTION_NODE:
		return buf.push( '<![CDATA[',node.data,']]>');
	case COMMENT_NODE:
		return buf.push( "<!--",node.data,"-->");
	case DOCUMENT_TYPE_NODE:
		var pubid = node.publicId;
		var sysid = node.systemId;
		buf.push('<!DOCTYPE ',node.name);
		if(pubid){
			buf.push(' PUBLIC ', pubid);
			if (sysid && sysid!='.') {
				buf.push(' ', sysid);
			}
			buf.push('>');
		}else if(sysid && sysid!='.'){
			buf.push(' SYSTEM ', sysid, '>');
		}else{
			var sub = node.internalSubset;
			if(sub){
				buf.push(" [",sub,"]");
			}
			buf.push(">");
		}
		return;
	case PROCESSING_INSTRUCTION_NODE:
		return buf.push( "<?",node.target," ",node.data,"?>");
	case ENTITY_REFERENCE_NODE:
		return buf.push( '&',node.nodeName,';');
	//case ENTITY_NODE:
	//case NOTATION_NODE:
	default:
		buf.push('??',node.nodeName);
	}
}
function importNode(doc,node,deep){
	var node2;
	switch (node.nodeType) {
	case ELEMENT_NODE:
		node2 = node.cloneNode(false);
		node2.ownerDocument = doc;
		//var attrs = node2.attributes;
		//var len = attrs.length;
		//for(var i=0;i<len;i++){
			//node2.setAttributeNodeNS(importNode(doc,attrs.item(i),deep));
		//}
	case DOCUMENT_FRAGMENT_NODE:
		break;
	case ATTRIBUTE_NODE:
		deep = true;
		break;
	//case ENTITY_REFERENCE_NODE:
	//case PROCESSING_INSTRUCTION_NODE:
	////case TEXT_NODE:
	//case CDATA_SECTION_NODE:
	//case COMMENT_NODE:
	//	deep = false;
	//	break;
	//case DOCUMENT_NODE:
	//case DOCUMENT_TYPE_NODE:
	//cannot be imported.
	//case ENTITY_NODE:
	//case NOTATION_NODE：
	//can not hit in level3
	//default:throw e;
	}
	if(!node2){
		node2 = node.cloneNode(false);//false
	}
	node2.ownerDocument = doc;
	node2.parentNode = null;
	if(deep){
		var child = node.firstChild;
		while(child){
			node2.appendChild(importNode(doc,child,deep));
			child = child.nextSibling;
		}
	}
	return node2;
}
//
//var _relationMap = {firstChild:1,lastChild:1,previousSibling:1,nextSibling:1,
//					attributes:1,childNodes:1,parentNode:1,documentElement:1,doctype,};
function cloneNode(doc,node,deep){
	var node2 = new node.constructor();
	for(var n in node){
		var v = node[n];
		if(typeof v != 'object' ){
			if(v != node2[n]){
				node2[n] = v;
			}
		}
	}
	if(node.childNodes){
		node2.childNodes = new NodeList();
	}
	node2.ownerDocument = doc;
	switch (node2.nodeType) {
	case ELEMENT_NODE:
		var attrs	= node.attributes;
		var attrs2	= node2.attributes = new NamedNodeMap();
		var len = attrs.length
		attrs2._ownerElement = node2;
		for(var i=0;i<len;i++){
			node2.setAttributeNode(cloneNode(doc,attrs.item(i),true));
		}
		break;;
	case ATTRIBUTE_NODE:
		deep = true;
	}
	if(deep){
		var child = node.firstChild;
		while(child){
			node2.appendChild(cloneNode(doc,child,deep));
			child = child.nextSibling;
		}
	}
	return node2;
}

function __set__(object,key,value){
	object[key] = value
}
//do dynamic
try{
	if(Object.defineProperty){
		Object.defineProperty(LiveNodeList.prototype,'length',{
			get:function(){
				_updateLiveList(this);
				return this.$$length;
			}
		});
		Object.defineProperty(Node.prototype,'textContent',{
			get:function(){
				return getTextContent(this);
			},
			set:function(data){
				switch(this.nodeType){
				case ELEMENT_NODE:
				case DOCUMENT_FRAGMENT_NODE:
					while(this.firstChild){
						this.removeChild(this.firstChild);
					}
					if(data || String(data)){
						this.appendChild(this.ownerDocument.createTextNode(data));
					}
					break;
				default:
					//TODO:
					this.data = data;
					this.value = data;
					this.nodeValue = data;
				}
			}
		})
		
		function getTextContent(node){
			switch(node.nodeType){
			case ELEMENT_NODE:
			case DOCUMENT_FRAGMENT_NODE:
				var buf = [];
				node = node.firstChild;
				while(node){
					if(node.nodeType!==7 && node.nodeType !==8){
						buf.push(getTextContent(node));
					}
					node = node.nextSibling;
				}
				return buf.join('');
			default:
				return node.nodeValue;
			}
		}
		__set__ = function(object,key,value){
			//console.log(value)
			object['$$'+key] = value
		}
	}
}catch(e){//ie8
}

//if(typeof require == 'function'){
	exports.Node = Node;
	exports.DOMException = DOMException;
	exports.DOMImplementation = DOMImplementation;
	exports.XMLSerializer = XMLSerializer;
//}


/***/ }),
/* 74 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ path2contours)
/* harmony export */ });
/* harmony import */ var _math_bezierCubic2Q2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66);
/* harmony import */ var _graphics_getArc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(75);
/* harmony import */ var _parseParams__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76);
/**
 * @file svg path转换为轮廓
 * @author mengke01(kekee000@gmail.com)
 */





/**
 * 三次贝塞尔曲线，转二次贝塞尔曲线
 *
 * @param {Array} cubicList 三次曲线数组
 * @param {Array} contour 当前解析后的轮廓数组
 * @return {Array} 当前解析后的轮廓数组
 */
function cubic2Points(cubicList, contour) {

    let i;
    let l;
    const q2List = [];

    cubicList.forEach(c => {
        const list = (0,_math_bezierCubic2Q2__WEBPACK_IMPORTED_MODULE_0__.default)(c[0], c[1], c[2], c[3]);
        for (i = 0, l = list.length; i < l; i++) {
            q2List.push(list[i]);
        }
    });

    let q2;
    let prevq2;
    for (i = 0, l = q2List.length; i < l; i++) {
        q2 = q2List[i];
        if (i === 0) {
            contour.push({
                x: q2[1].x,
                y: q2[1].y
            });
            contour.push({
                x: q2[2].x,
                y: q2[2].y,
                onCurve: true
            });
        }
        else {
            prevq2 = q2List[i - 1];
            // 检查是否存在切线点
            if (
                prevq2[1].x + q2[1].x === 2 * q2[0].x
                && prevq2[1].y + q2[1].y === 2 * q2[0].y
            ) {
                contour.pop();
            }
            contour.push({
                x: q2[1].x,
                y: q2[1].y
            });
            contour.push({
                x: q2[2].x,
                y: q2[2].y,
                onCurve: true
            });
        }
    }

    contour.push({
        x: q2[2].x,
        y: q2[2].y,
        onCurve: true
    });

    return contour;
}


/**
 * svg 命令数组转轮廓
 *
 * @param {Array} segments svg 命令数组
 * @return {Array} 轮廓数组
 */
function segments2Contours(segments) {

    // 解析segments
    const contours = [];
    let contour = [];
    let prevX = 0;
    let prevY = 0;
    let segment;
    let args;
    let cmd;
    let relative;
    let q;
    let ql;
    let px;
    let py;
    let cubicList;
    let p1;
    let p2;
    let c1;
    let c2;
    let prevCubicC1; // 三次贝塞尔曲线前一个控制点，用于绘制`s`命令

    for (let i = 0, l = segments.length; i < l; i++) {
        segment = segments[i];
        cmd = segment.cmd;
        relative = segment.relative;
        args = segment.args;

        if (args && !args.length && cmd !== 'Z') {
            console.warn('`' + cmd + '` command args empty!');
            continue;
        }

        if (cmd === 'Z') {
            contours.push(contour);
            contour = [];
        }
        else if (cmd === 'M' || cmd === 'L') {
            if (args.length % 2) {
                throw new Error('`M` command error:' + args.join(','));
            }

            // 这里可能会连续绘制，最后一个是终点
            if (relative) {
                px = prevX;
                py = prevY;
            }
            else {
                px = 0;
                py = 0;
            }

            for (q = 0, ql = args.length; q < ql; q += 2) {

                if (relative) {
                    px += args[q];
                    py += args[q + 1];
                }
                else {
                    px = args[q];
                    py = args[q + 1];
                }

                contour.push({
                    x: px,
                    y: py,
                    onCurve: true
                });
            }

            prevX = px;
            prevY = py;
        }
        else if (cmd === 'H') {
            if (relative) {
                prevX += args[0];
            }
            else {
                prevX = args[0];
            }

            contour.push({
                x: prevX,
                y: prevY,
                onCurve: true
            });
        }
        else if (cmd === 'V') {
            if (relative) {
                prevY += args[0];
            }
            else {
                prevY = args[0];
            }

            contour.push({
                x: prevX,
                y: prevY,
                onCurve: true
            });
        }
        // 二次贝塞尔
        else if (cmd === 'Q') {
            // 这里可能会连续绘制，最后一个是终点
            if (relative) {
                px = prevX;
                py = prevY;
            }
            else {
                px = 0;
                py = 0;
            }

            for (q = 0, ql = args.length; q < ql; q += 4) {

                contour.push({
                    x: px + args[q],
                    y: py + args[q + 1]
                });
                contour.push({
                    x: px + args[q + 2],
                    y: py + args[q + 3],
                    onCurve: true
                });

                if (relative) {
                    px += args[q + 2];
                    py += args[q + 3];
                }
                else {
                    px = 0;
                    py = 0;
                }
            }

            if (relative) {
                prevX = px;
                prevY = py;
            }
            else {
                prevX = args[ql - 2];
                prevY = args[ql - 1];
            }
        }
        // 二次贝塞尔平滑
        else if (cmd === 'T') {
            // 这里需要移除上一个曲线的终点
            let last = contour.pop();
            let pc = contour[contour.length - 1];
            if (!pc) {
                pc = last;
            }

            contour.push(pc = {
                x: 2 * last.x - pc.x,
                y: 2 * last.y - pc.y
            });

            px = prevX;
            py = prevY;

            for (q = 0, ql = args.length - 2; q < ql; q += 2) {

                if (relative) {
                    px += args[q];
                    py += args[q + 1];
                }
                else {
                    px = args[q];
                    py = args[q + 1];
                }

                last = {
                    x: px,
                    y: py
                };

                contour.push(pc = {
                    x: 2 * last.x - pc.x,
                    y: 2 * last.y - pc.y
                });
            }

            if (relative) {
                prevX = px + args[ql];
                prevY = py + args[ql + 1];
            }
            else {
                prevX = args[ql];
                prevY = args[ql + 1];
            }

            contour.push({
                x: prevX,
                y: prevY,
                onCurve: true
            });

        }
        // 三次贝塞尔
        else if (cmd === 'C') {
            if (args.length % 6) {
                throw new Error('`C` command params error:' + args.join(','));
            }

            // 这里可能会连续绘制，最后一个是终点
            cubicList = [];

            if (relative) {
                px = prevX;
                py = prevY;
            }
            else {
                px = 0;
                py = 0;
            }

            p1 = {
                x: prevX,
                y: prevY
            };

            for (q = 0, ql = args.length; q < ql; q += 6) {

                c1 = {
                    x: px + args[q],
                    y: py + args[q + 1]
                };

                c2 = {
                    x: px + args[q + 2],
                    y: py + args[q + 3]
                };

                p2 = {
                    x: px + args[q + 4],
                    y: py + args[q + 5]
                };

                cubicList.push([p1, c1, c2, p2]);

                p1 = p2;

                if (relative) {
                    px += args[q + 4];
                    py += args[q + 5];
                }
                else {
                    px = 0;
                    py = 0;
                }
            }

            if (relative) {
                prevX = px;
                prevY = py;
            }
            else {
                prevX = args[ql - 2];
                prevY = args[ql - 1];
            }

            cubic2Points(cubicList, contour);
            prevCubicC1 = cubicList[cubicList.length - 1][2];
        }
        // 三次贝塞尔平滑
        else if (cmd === 'S') {
            if (args.length % 4) {
                throw new Error('`S` command params error:' + args.join(','));
            }

            // 这里可能会连续绘制，最后一个是终点
            cubicList = [];

            if (relative) {
                px = prevX;
                py = prevY;
            }
            else {
                px = 0;
                py = 0;
            }

            // 这里需要移除上一个曲线的终点
            p1 = contour.pop();
            if (!prevCubicC1) {
                prevCubicC1 = p1;
            }

            c1 = {
                x: 2 * p1.x - prevCubicC1.x,
                y: 2 * p1.y - prevCubicC1.y
            };

            for (q = 0, ql = args.length; q < ql; q += 4) {

                c2 = {
                    x: px + args[q],
                    y: py + args[q + 1]
                };

                p2 = {
                    x: px + args[q + 2],
                    y: py + args[q + 3]
                };

                cubicList.push([p1, c1, c2, p2]);

                p1 = p2;

                c1 = {
                    x: 2 * p1.x - c2.x,
                    y: 2 * p1.y - c2.y
                };

                if (relative) {
                    px += args[q + 2];
                    py += args[q + 3];
                }
                else {
                    px = 0;
                    py = 0;
                }
            }

            if (relative) {
                prevX = px;
                prevY = py;
            }
            else {
                prevX = args[ql - 2];
                prevY = args[ql - 1];
            }

            cubic2Points(cubicList, contour);
            prevCubicC1 = cubicList[cubicList.length - 1][2];
        }
        // 求弧度, rx, ry, angle, largeArc, sweep, ex, ey
        else if (cmd === 'A') {
            if (args.length % 7) {
                throw new Error('arc command params error:' + args.join(','));
            }

            for (q = 0, ql = args.length; q < ql; q += 7) {
                let ex = args[q + 5];
                let ey = args[q + 6];

                if (relative) {
                    ex = prevX + ex;
                    ey = prevY + ey;
                }

                const path = (0,_graphics_getArc__WEBPACK_IMPORTED_MODULE_1__.default)(
                    args[q], args[q + 1],
                    args[q + 2], args[q + 3], args[q + 4],
                    {x: prevX, y: prevY},
                    {x: ex, y: ey}
                );

                if (path && path.length > 1) {
                    for (let r = 1, rl = path.length; r < rl; r++) {
                        contour.push(path[r]);
                    }
                }
                prevX = ex;
                prevY = ey;
            }
        }
    }

    return contours;
}

/**
 * svg path转轮廓
 *
 * @param {string} path svg的path字符串
 * @return {Array} 转换后的轮廓
 */
function path2contours(path) {

    if (!path || !path.length) {
        return null;
    }

    path = path.trim();

    // 修正头部不为`m`的情况
    if (path[0] !== 'M' && path[0] !== 'm') {
        path = 'M 0 0' + path;
    }

    // 修复中间没有结束符`z`的情况
    path = path.replace(/(\d+)\s*(m|$)/gi, '$1z$2');

    // 获取segments
    const segments = [];
    let cmd;
    let relative = false;
    let lastIndex;
    let args;

    for (let i = 0, l = path.length; i < l; i++) {
        const c = path[i].toUpperCase();
        const r = c !== path[i];

        switch (c) {
        case 'M':
            /* jshint -W086 */
            if (i === 0) {
                cmd = c;
                lastIndex = 1;
                break;
            }
        // eslint-disable-next-line no-fallthrough
        case 'Q':
        case 'T':
        case 'C':
        case 'S':
        case 'H':
        case 'V':
        case 'L':
        case 'A':
        case 'Z':
            if (cmd === 'Z') {
                segments.push({cmd: 'Z'});
            }
            else {
                args = path.slice(lastIndex, i);
                segments.push({
                    cmd,
                    relative,
                    args: (0,_parseParams__WEBPACK_IMPORTED_MODULE_2__.default)(args)
                });
            }

            cmd = c;
            relative = r;
            lastIndex = i + 1;
            break;

        }
    }

    segments.push({cmd: 'Z'});

    return segments2Contours(segments);
}


/***/ }),
/* 75 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getArc)
/* harmony export */ });
/* harmony import */ var _math_bezierCubic2Q2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(66);
/**
 * @file 使用插值法获取椭圆弧度，以支持svg arc命令
 * @author mengke01(kekee000@gmail.com)
 *
 * modify from:
 * https://github.com/fontello/svgpath/blob/master/lib/a2c.js
 * references:
 * http://www.w3.org/TR/SVG/implnote.html#ArcImplementationNotes
 */




const TAU = Math.PI * 2;

function vectorAngle(ux, uy, vx, vy) {
    // Calculate an angle between two vectors
    const sign = (ux * vy - uy * vx < 0) ? -1 : 1;
    const umag = Math.sqrt(ux * ux + uy * uy);
    const vmag = Math.sqrt(ux * ux + uy * uy);
    const dot = ux * vx + uy * vy;
    let div = dot / (umag * vmag);

    if (div > 1 || div < -1) {
        // rounding errors, e.g. -1.0000000000000002 can screw up this
        div = Math.max(div, -1);
        div = Math.min(div, 1);
    }

    return sign * Math.acos(div);
}

function correctRadii(midx, midy, rx, ry) {
    // Correction of out-of-range radii
    rx = Math.abs(rx);
    ry = Math.abs(ry);

    const Λ = (midx * midx) / (rx * rx) + (midy * midy) / (ry * ry);
    if (Λ > 1) {
        rx *= Math.sqrt(Λ);
        ry *= Math.sqrt(Λ);
    }

    return [rx, ry];
}


function getArcCenter(x1, y1, x2, y2, fa, fs, rx, ry, sin_φ, cos_φ) {
    // Convert from endpoint to center parameterization,
    // see http://www.w3.org/TR/SVG11/implnote.html#ArcImplementationNotes

    // Step 1.
    //
    // Moving an ellipse so origin will be the middlepoint between our two
    // points. After that, rotate it to line up ellipse axes with coordinate
    // axes.
    //
    const x1p = cos_φ * (x1 - x2) / 2 + sin_φ * (y1 - y2) / 2;
    const y1p = -sin_φ * (x1 - x2) / 2 + cos_φ * (y1 - y2) / 2;

    const rx_sq = rx * rx;
    const ry_sq = ry * ry;
    const x1p_sq = x1p * x1p;
    const y1p_sq = y1p * y1p;

    // Step 2.
    //
    // Compute coordinates of the centre of this ellipse (cx', cy')
    // in the new coordinate system.
    //
    let radicant = (rx_sq * ry_sq) - (rx_sq * y1p_sq) - (ry_sq * x1p_sq);

    if (radicant < 0) {
        // due to rounding errors it might be e.g. -1.3877787807814457e-17
        radicant = 0;
    }

    radicant /= (rx_sq * y1p_sq) + (ry_sq * x1p_sq);
    radicant = Math.sqrt(radicant) * (fa === fs ? -1 : 1);

    const cxp = radicant * rx / ry * y1p;
    const cyp = radicant * -ry / rx * x1p;

    // Step 3.
    //
    // Transform back to get centre coordinates (cx, cy) in the original
    // coordinate system.
    //
    const cx = cos_φ * cxp - sin_φ * cyp + (x1 + x2) / 2;
    const cy = sin_φ * cxp + cos_φ * cyp + (y1 + y2) / 2;

    // Step 4.
    //
    // Compute angles (θ1, Δθ).
    //
    const v1x = (x1p - cxp) / rx;
    const v1y = (y1p - cyp) / ry;
    const v2x = (-x1p - cxp) / rx;
    const v2y = (-y1p - cyp) / ry;

    const θ1 = vectorAngle(1, 0, v1x, v1y);
    let Δθ = vectorAngle(v1x, v1y, v2x, v2y);

    if (fs === 0 && Δθ > 0) {
        Δθ -= TAU;
    }
    if (fs === 1 && Δθ < 0) {
        Δθ += TAU;
    }

    return [cx, cy, θ1, Δθ];
}

function approximateUnitArc(θ1, Δθ) {
    // Approximate one unit arc segment with bézier curves,
    // see http://math.stackexchange.com/questions/873224/
    //      calculate-control-points-of-cubic-bezier-curve-approximating-a-part-of-a-circle
    const α = 4 / 3 * Math.tan(Δθ / 4);

    const x1 = Math.cos(θ1);
    const y1 = Math.sin(θ1);
    const x2 = Math.cos(θ1 + Δθ);
    const y2 = Math.sin(θ1 + Δθ);

    return [x1, y1, x1 - y1 * α, y1 + x1 * α, x2 + y2 * α, y2 - x2 * α, x2, y2];
}


function a2c(x1, y1, x2, y2, fa, fs, rx, ry, φ) {
    const sin_φ = Math.sin(φ * TAU / 360);
    const cos_φ = Math.cos(φ * TAU / 360);

    // Make sure radii are valid
    //
    const x1p = cos_φ * (x1 - x2) / 2 + sin_φ * (y1 - y2) / 2;
    const y1p = -sin_φ * (x1 - x2) / 2 + cos_φ * (y1 - y2) / 2;

    if (x1p === 0 && y1p === 0) {
        // we're asked to draw line to itself
        return [];
    }

    if (rx === 0 || ry === 0) {
        // one of the radii is zero
        return [];
    }

    const radii = correctRadii(x1p, y1p, rx, ry);
    rx = radii[0];
    ry = radii[1];

    // Get center parameters (cx, cy, θ1, Δθ)
    //
    const cc = getArcCenter(x1, y1, x2, y2, fa, fs, rx, ry, sin_φ, cos_φ);

    const result = [];
    let θ1 = cc[2];
    let Δθ = cc[3];

    // Split an arc to multiple segments, so each segment
    // will be less than τ/4 (= 90°)
    //
    const segments = Math.max(Math.ceil(Math.abs(Δθ) / (TAU / 4)), 1);
    Δθ /= segments;

    for (let i = 0; i < segments; i++) {
        result.push(approximateUnitArc(θ1, Δθ));
        θ1 += Δθ;
    }

    // We have a bezier approximation of a unit circle,
    // now need to transform back to the original ellipse
    //
    return result.map(curve => {
        for (let i = 0; i < curve.length; i += 2) {
            let x = curve[i + 0];
            let y = curve[i + 1];

            // scale
            x *= rx;
            y *= ry;

            // rotate
            const xp = cos_φ * x - sin_φ * y;
            const yp = sin_φ * x + cos_φ * y;

            // translate
            curve[i + 0] = xp + cc[0];
            curve[i + 1] = yp + cc[1];
        }

        return curve;
    });
}

/**
 * 获取椭圆弧度
 *
 * @param {number} rx 椭圆长半轴
 * @param {number} ry 椭圆短半轴
 * @param {number} angle 旋转角度
 * @param {number} largeArc 是否大圆弧
 * @param {number} sweep 是否延伸圆弧
 * @param {Object} p0 分割点1
 * @param {Object} p1 分割点2
 * @return {Array} 分割后的路径
 */
function getArc(rx, ry, angle, largeArc, sweep, p0, p1) {
    const result = a2c(p0.x, p0.y, p1.x, p1.y, largeArc, sweep, rx, ry, angle);
    const path = [];

    if (result.length) {
        path.push({
            x: result[0][0],
            y: result[0][1],
            onCurve: true
        });

        // 将三次曲线转换成二次曲线
        result.forEach(c => {
            const q2Array = (0,_math_bezierCubic2Q2__WEBPACK_IMPORTED_MODULE_0__.default)({
                x: c[0],
                y: c[1]
            }, {
                x: c[2],
                y: c[3]
            }, {
                x: c[4],
                y: c[5]
            }, {
                x: c[6],
                y: c[7]
            });

            q2Array[0][2].onCurve = true;
            path.push(q2Array[0][1]);
            path.push(q2Array[0][2]);
            if (q2Array[1]) {
                q2Array[1][2].onCurve = true;
                path.push(q2Array[1][1]);
                path.push(q2Array[1][2]);
            }
        });
    }

    return path;
}


/***/ }),
/* 76 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file 解析参数数组
 * @author mengke01(kekee000@gmail.com)
 */

const SEGMENT_REGEX = /-?\d+(?:\.\d+)?(?:e[-+]?\d+)?\b/g;

/**
 * 获取参数值
 *
 * @param  {string} d 参数
 * @return {number}   参数值
 */
function getSegment(d) {
    return +d.trim();
}

/**
 * 解析参数数组
 *
 * @param  {string} str 参数字符串
 * @return {Array}   参数数组
 */
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(str) {
    if (!str) {
        return [];
    }
    const matchs = str.match(SEGMENT_REGEX);
    return matchs ? matchs.map(getSegment) : [];
}


/***/ }),
/* 77 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ svgnode2contours)
/* harmony export */ });
/* harmony import */ var _path2contours__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74);
/* harmony import */ var _oval2contour__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(78);
/* harmony import */ var _polygon2contour__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(80);
/* harmony import */ var _rect2contour__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(81);
/* harmony import */ var _parseTransform__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(82);
/* harmony import */ var _contoursTransform__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(83);
/**
 * @file svg节点转字形轮廓
 * @author mengke01(kekee000@gmail.com)
 */








// 支持的解析器集合
const support = {

    path: {
        parse: _path2contours__WEBPACK_IMPORTED_MODULE_0__.default, // 解析器
        params: ['d'], // 参数列表
        contours: true // 是否是多个轮廓
    },

    circle: {
        parse: _oval2contour__WEBPACK_IMPORTED_MODULE_1__.default,
        params: ['cx', 'cy', 'r']
    },

    ellipse: {
        parse: _oval2contour__WEBPACK_IMPORTED_MODULE_1__.default,
        params: ['cx', 'cy', 'rx', 'ry']
    },

    rect: {
        parse: _rect2contour__WEBPACK_IMPORTED_MODULE_3__.default,
        params: ['x', 'y', 'width', 'height']
    },

    polygon: {
        parse: _polygon2contour__WEBPACK_IMPORTED_MODULE_2__.default,
        params: ['points']
    },

    polyline: {
        parse: _polygon2contour__WEBPACK_IMPORTED_MODULE_2__.default,
        params: ['points']
    }
};

/**
 * svg节点转字形轮廓
 *
 * @param {Array} xmlNodes xml节点集合
 * @return {Array|false} 轮廓数组
 */
function svgnode2contours(xmlNodes) {
    let i;
    let length;
    let j;
    let jlength;
    let segment; // 当前指令
    const parsedSegments = []; // 解析后的指令

    if (xmlNodes.length) {
        for (i = 0, length = xmlNodes.length; i < length; i++) {
            const node = xmlNodes[i];
            const name = node.tagName;
            if (support[name]) {
                const supportParams = support[name].params;
                const params = [];
                for (j = 0, jlength = supportParams.length; j < jlength; j++) {
                    params.push(node.getAttribute(supportParams[j]));
                }

                segment = {
                    name,
                    params,
                    transform: (0,_parseTransform__WEBPACK_IMPORTED_MODULE_4__.default)(node.getAttribute('transform'))
                };

                if (node.parentNode) {
                    let curNode = node.parentNode;
                    const transforms = segment.transform || [];
                    let transAttr;
                    const iterator = function (t) {
                        transforms.unshift(t);
                    };
                    while (curNode !== null && curNode.tagName !== 'svg') {
                        transAttr = curNode.getAttribute('transform');
                        if (transAttr) {
                            (0,_parseTransform__WEBPACK_IMPORTED_MODULE_4__.default)(transAttr).reverse().forEach(iterator);
                        }
                        curNode = curNode.parentNode;
                    }

                    segment.transform = transforms.length ? transforms : null;
                }
                parsedSegments.push(segment);
            }
        }
    }

    if (parsedSegments.length) {
        const result = [];
        for (i = 0, length = parsedSegments.length; i < length; i++) {
            segment = parsedSegments[i];
            const parser = support[segment.name];
            const contour = parser.parse.apply(null, segment.params);
            if (contour && contour.length) {
                let contours = parser.contours ? contour : [contour];

                // 如果有变换则应用变换规则
                if (segment.transform) {
                    contours = (0,_contoursTransform__WEBPACK_IMPORTED_MODULE_5__.default)(contours, segment.transform);
                }

                for (j = 0, jlength = contours.length; j < jlength; j++) {
                    result.push(contours[j]);
                }
            }
        }
        return result;
    }

    return false;
}


/***/ }),
/* 78 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ oval2contour)
/* harmony export */ });
/* harmony import */ var _graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17);
/* harmony import */ var _graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(15);
/* harmony import */ var _graphics_path_circle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(79);
/* harmony import */ var _common_lang__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8);
/**
 * @file 椭圆转换成轮廓
 * @author mengke01(kekee000@gmail.com)
 */






/**
 * 椭圆转换成轮廓
 *
 * @param {number} cx 椭圆中心点x
 * @param {number} cy 椭圆中心点y
 * @param {number} rx 椭圆x轴半径
 * @param {number} ry 椭圆y周半径
 * @return {Array} 轮廓数组
 */
function oval2contour(cx, cy, rx, ry) {

    if (undefined === ry) {
        ry = rx;
    }

    const bound = (0,_graphics_computeBoundingBox__WEBPACK_IMPORTED_MODULE_0__.computePath)(_graphics_path_circle__WEBPACK_IMPORTED_MODULE_2__.default);
    const scaleX = (+rx) * 2 / bound.width;
    const scaleY = (+ry) * 2 / bound.height;
    const centerX = bound.width * scaleX / 2;
    const centerY = bound.height * scaleY / 2;
    const contour = (0,_common_lang__WEBPACK_IMPORTED_MODULE_3__.clone)(_graphics_path_circle__WEBPACK_IMPORTED_MODULE_2__.default);
    (0,_graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_1__.default)(contour, scaleX, scaleY);
    (0,_graphics_pathAdjust__WEBPACK_IMPORTED_MODULE_1__.default)(contour, 1, 1, +cx - centerX, +cy - centerY);

    return contour;
}


/***/ }),
/* 79 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file 圆路径集合，逆时针
 * @author mengke01(kekee000@gmail.com)
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([
    {
        x: 582,
        y: 0
    },
    {
        x: 758,
        y: 75
    },
    {
        x: 890,
        y: 208
    },
    {
        x: 965,
        y: 384
    },
    {
        x: 965,
        y: 583
    },
    {
        x: 890,
        y: 760
    },
    {
        x: 758,
        y: 891
    },
    {
        x: 582,
        y: 966
    },
    {
        x: 383,
        y: 966
    },
    {
        x: 207,
        y: 891
    },
    {
        x: 75,
        y: 760
    },
    {
        x: 0,
        y: 583
    },
    {
        x: 0,
        y: 384
    },
    {
        x: 75,
        y: 208
    },
    {
        x: 207,
        y: 75
    },
    {
        x: 383,
        y: 0
    }
]);


/***/ }),
/* 80 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ polygon2contour)
/* harmony export */ });
/* harmony import */ var _parseParams__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76);
/**
 * @file 多边形转换成轮廓
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * 多边形转换成轮廓
 *
 * @param {Array} points 多边形点集合
 * @return {Array} contours
 */
function polygon2contour(points) {

    if (!points || !points.length) {
        return null;
    }

    const contours = [];
    const segments = (0,_parseParams__WEBPACK_IMPORTED_MODULE_0__.default)(points);
    for (let i = 0, l = segments.length; i < l; i += 2) {
        contours.push({
            x: segments[i],
            y: segments[i + 1],
            onCurve: true
        });
    }

    return contours;
}


/***/ }),
/* 81 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ rect2contour)
/* harmony export */ });
/**
 * @file 矩形转换成轮廓
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 矩形转换成轮廓
 *
 * @param {number} x 左上角x
 * @param {number} y 左上角y
 * @param {number} width 宽度
 * @param {number} height 高度
 * @return {Array} 轮廓数组
 */
function rect2contour(x, y, width, height) {
    x = +x;
    y = +y;
    width = +width;
    height = +height;

    return [
        {
            x,
            y,
            onCurve: true
        },
        {
            x: x + width,
            y,
            onCurve: true
        },
        {
            x: x + width,
            y: y + height,
            onCurve: true
        },
        {
            x,
            y: y + height,
            onCurve: true
        }
    ];
}


/***/ }),
/* 82 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ parseTransform)
/* harmony export */ });
/* harmony import */ var _parseParams__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76);
/**
 * @file 解析transform参数
 * @author mengke01(kekee000@gmail.com)
 */


const TRANSFORM_REGEX = /(\w+)\s*\(([\d-.,\s]*)\)/g;

/**
 * 解析transform参数
 *
 * @param {string} str 参数字符串
 * @return {Array} transform数组, 格式如下：
 *     [
 *         {
 *             name: 'scale',
 *             params: []
 *         }
 *     ]
 */
function parseTransform(str) {

    if (!str) {
        return false;
    }

    TRANSFORM_REGEX.lastIndex = 0;
    const transforms = [];
    let match;

    while ((match = TRANSFORM_REGEX.exec(str))) {
        transforms.push({
            name: match[1],
            params: (0,_parseParams__WEBPACK_IMPORTED_MODULE_0__.default)(match[2])
        });
    }

    return transforms;
}


/***/ }),
/* 83 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ contoursTransform)
/* harmony export */ });
/* harmony import */ var _graphics_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(84);
/* harmony import */ var _graphics_pathTransform__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21);
/**
 * @file 根据transform参数变换轮廓
 * @author mengke01(kekee000@gmail.com)
 */




/**
 * 根据transform参数变换轮廓
 *
 * @param {Array} contours 轮廓集合
 * @param {Array} transforms 变换指令集合
 *     transforms = [{
 *         name: 'scale'
 *         params: [3,4]
 *     }]
 *
 * @return {Array} 变换后的轮廓数组
 */
function contoursTransform(contours, transforms) {
    if (!contours || !contours.length || !transforms || !transforms.length) {
        return contours;
    }

    let matrix = [1, 0, 0, 1, 0, 0];
    for (let i = 0, l = transforms.length; i < l; i++) {
        const transform = transforms[i];
        const params = transform.params;
        let radian = null;
        switch (transform.name) {
        case 'translate':
            matrix = (0,_graphics_matrix__WEBPACK_IMPORTED_MODULE_0__.mul)(matrix, [1, 0, 0, 1, params[0], params[1]]);
            break;
        case 'scale':
            matrix = (0,_graphics_matrix__WEBPACK_IMPORTED_MODULE_0__.mul)(matrix, [params[0], 0, 0, params[1], 0, 0]);
            break;
        case 'matrix':
            matrix = (0,_graphics_matrix__WEBPACK_IMPORTED_MODULE_0__.mul)(matrix,
                [params[0], params[1], params[2], params[3], params[4], params[5]]);
            break;
        case 'rotate':
            radian = params[0] * Math.PI / 180;
            if (params.length > 1) {

                matrix = (0,_graphics_matrix__WEBPACK_IMPORTED_MODULE_0__.multiply)(
                    matrix,
                    [1, 0, 0, 1, -params[1], -params[2]],
                    [Math.cos(radian), Math.sin(radian), -Math.sin(radian), Math.cos(radian), 0, 0],
                    [1, 0, 0, 1, params[1], params[2]]
                );
            }
            else {
                matrix = (0,_graphics_matrix__WEBPACK_IMPORTED_MODULE_0__.mul)(
                    matrix, [Math.cos(radian), Math.sin(radian), -Math.sin(radian), Math.cos(radian), 0, 0]);
            }
            break;
        case 'skewX':
            matrix = (0,_graphics_matrix__WEBPACK_IMPORTED_MODULE_0__.mul)(matrix,
                [1, 0, Math.tan(params[0] * Math.PI / 180), 1, 0, 0]);
            break;
        case 'skewY':
            matrix = (0,_graphics_matrix__WEBPACK_IMPORTED_MODULE_0__.mul)(matrix,
                [1, Math.tan(params[0] * Math.PI / 180), 0, 1, 0, 0]);
            break;
        }
    }

    contours.forEach(p => {
        (0,_graphics_pathTransform__WEBPACK_IMPORTED_MODULE_1__.default)(p, matrix[0], matrix[1], matrix[2], matrix[3], matrix[4], matrix[5]);
    });

    return contours;
}


/***/ }),
/* 84 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mul": () => (/* binding */ mul),
/* harmony export */   "multiply": () => (/* binding */ multiply)
/* harmony export */ });
/**
 * @file matrix变换操作
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 仿射矩阵相乘
 *
 * @param  {Array=} matrix1 矩阵1
 * @param  {Array=} matrix2 矩阵2
 * @return {Array}         新矩阵
 */
function mul(matrix1 = [1, 0, 0, 1], matrix2 = [1, 0, 0, 1]) {
    // 旋转变换 4 个参数
    if (matrix1.length === 4) {
        return [
            matrix1[0] * matrix2[0] + matrix1[2] * matrix2[1],
            matrix1[1] * matrix2[0] + matrix1[3] * matrix2[1],
            matrix1[0] * matrix2[2] + matrix1[2] * matrix2[3],
            matrix1[1] * matrix2[2] + matrix1[3] * matrix2[3]
        ];
    }
    // 旋转位移变换, 6 个参数

    return [
        matrix1[0] * matrix2[0] + matrix1[2] * matrix2[1],
        matrix1[1] * matrix2[0] + matrix1[3] * matrix2[1],
        matrix1[0] * matrix2[2] + matrix1[2] * matrix2[3],
        matrix1[1] * matrix2[2] + matrix1[3] * matrix2[3],

        matrix1[0] * matrix2[4] + matrix1[2] * matrix2[5] + matrix1[4],
        matrix1[1] * matrix2[4] + matrix1[3] * matrix2[5] + matrix1[5]
    ];
}

/**
 * 多个仿射矩阵相乘
 *
 * @param {...Array} matrixs matrix array
 * @return {Array}         新矩阵
 */
function multiply(...matrixs) {
    let result = matrixs[0];
    for (let i = 1, matrix; (matrix = matrixs[i]); i++) {
        result = mul(result, matrix);
    }

    return result;
}


/***/ }),
/* 85 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _computeBoundingBox__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17);
/* harmony import */ var _pathAdjust__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(15);
/* harmony import */ var _pathRotate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(86);
/**
 * @file 路径组变化函数
 * @author mengke01(kekee000@gmail.com)
 */





/**
 * 翻转路径
 *
 * @param {Array} paths 路径数组
 * @param {number} xScale x翻转
 * @param {number} yScale y翻转
 * @return {Array} 变换后的路径
 */
function mirrorPaths(paths, xScale, yScale) {
    const {x, y, width, height} = (0,_computeBoundingBox__WEBPACK_IMPORTED_MODULE_0__.computePath)(...paths);

    if (xScale === -1) {
        paths.forEach(p => {
            (0,_pathAdjust__WEBPACK_IMPORTED_MODULE_1__.default)(p, -1, 1, -x, 0);
            (0,_pathAdjust__WEBPACK_IMPORTED_MODULE_1__.default)(p, 1, 1, x + width, 0);
            p.reverse();
        });

    }

    if (yScale === -1) {
        paths.forEach(p => {
            (0,_pathAdjust__WEBPACK_IMPORTED_MODULE_1__.default)(p, 1, -1, 0, -y);
            (0,_pathAdjust__WEBPACK_IMPORTED_MODULE_1__.default)(p, 1, 1, 0, y + height);
            p.reverse();
        });
    }

    return paths;
}



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({

    /**
     * 旋转路径
     *
     * @param {Array} paths 路径数组
     * @param {number} angle 弧度
     * @return {Array} 变换后的路径
     */
    rotate(paths, angle) {
        if (!angle) {
            return paths;
        }

        const bound = (0,_computeBoundingBox__WEBPACK_IMPORTED_MODULE_0__.computePath)(...paths);

        const cx = bound.x + (bound.width) / 2;
        const cy = bound.y + (bound.height) / 2;

        paths.forEach(p => {
            (0,_pathRotate__WEBPACK_IMPORTED_MODULE_2__.default)(p, angle, cx, cy);
        });

        return paths;
    },

    /**
     * 路径组变换
     *
     * @param {Array} paths 路径数组
     * @param {number} x x 方向缩放
     * @param {number} y y 方向缩放
     * @return {Array} 变换后的路径
     */
    move(paths, x, y) {
        const bound = (0,_computeBoundingBox__WEBPACK_IMPORTED_MODULE_0__.computePath)(...paths);
        paths.forEach(path => {
            (0,_pathAdjust__WEBPACK_IMPORTED_MODULE_1__.default)(path, 1, 1, x - bound.x, y - bound.y);
        });

        return paths;
    },

    mirror(paths) {
        return mirrorPaths(paths, -1, 1);
    },

    flip(paths) {
        return mirrorPaths(paths, 1, -1);
    }
});


/***/ }),
/* 86 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ pathRotate)
/* harmony export */ });
/**
 * @file 路径旋转
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 对path坐标进行调整
 *
 * @param {Object} contour 坐标点
 * @param {number} angle 角度
 * @param {number} centerX x偏移
 * @param {number} centerY y偏移
 *
 * @return {Object} contour 坐标点
 */
function pathRotate(contour, angle, centerX, centerY) {
    angle = angle === undefined ? 0 : angle;
    const x = centerX || 0;
    const y = centerY || 0;
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    let px;
    let py;
    let p;

    // x1=cos(angle)*x-sin(angle)*y;
    // y1=cos(angle)*y+sin(angle)*x;
    for (let i = 0, l = contour.length; i < l; i++) {
        p = contour[i];
        px = cos * (p.x - x) - sin * (p.y - y);
        py = cos * (p.y - y) + sin * (p.x - x);
        p.x = px + x;
        p.y = py + y;
    }

    return contour;
}


/***/ }),
/* 87 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ TTFReader)
/* harmony export */ });
/* harmony import */ var _table_directory__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36);
/* harmony import */ var _table_support__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(88);
/* harmony import */ var _reader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(28);
/* harmony import */ var _enum_postName__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(14);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29);
/* harmony import */ var _util_compound2simpleglyf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19);
/**
 * @file ttf读取器
 * @author mengke01(kekee000@gmail.com)
 *
 * thanks to：
 * ynakajima/ttf.js
 * https://github.com/ynakajima/ttf.js
 */








class TTFReader {

    /**
     * ttf读取器的构造函数
     *
     * @param {Object} options 写入参数
     * @param {boolean} options.hinting 保留hinting信息
     * @param {boolean} options.compound2simple 复合字形转简单字形
     * @constructor
     */
    constructor(options = {}) {
        options.subset = options.subset || []; // 子集
        options.hinting = options.hinting || false; // 不保留hints信息
        options.compound2simple = options.compound2simple || false; // 复合字形转简单字形
        this.options = options;
    }

    /**
     * 初始化读取
     *
     * @param {ArrayBuffer} buffer buffer对象
     * @return {Object} ttf对象
     */
    readBuffer(buffer) {

        const reader = new _reader__WEBPACK_IMPORTED_MODULE_2__.default(buffer, 0, buffer.byteLength, false);

        const ttf = {};

        // version
        ttf.version = reader.readFixed(0);

        if (ttf.version !== 0x1) {
            _error__WEBPACK_IMPORTED_MODULE_4__.default.raise(10101);
        }

        // num tables
        ttf.numTables = reader.readUint16();

        if (ttf.numTables <= 0 || ttf.numTables > 100) {
            _error__WEBPACK_IMPORTED_MODULE_4__.default.raise(10101);
        }

        // searchRange
        ttf.searchRange = reader.readUint16();

        // entrySelector
        ttf.entrySelector = reader.readUint16();

        // rangeShift
        ttf.rangeShift = reader.readUint16();

        ttf.tables = new _table_directory__WEBPACK_IMPORTED_MODULE_0__.default(reader.offset).read(reader, ttf);

        if (!ttf.tables.glyf || !ttf.tables.head || !ttf.tables.cmap || !ttf.tables.hmtx) {
            _error__WEBPACK_IMPORTED_MODULE_4__.default.raise(10204);
        }

        ttf.readOptions = this.options;

        // 读取支持的表数据
        Object.keys(_table_support__WEBPACK_IMPORTED_MODULE_1__.default).forEach((tableName) => {

            if (ttf.tables[tableName]) {
                const offset = ttf.tables[tableName].offset;
                ttf[tableName] = new _table_support__WEBPACK_IMPORTED_MODULE_1__.default[tableName](offset).read(reader, ttf);
            }
        });

        if (!ttf.glyf) {
            _error__WEBPACK_IMPORTED_MODULE_4__.default.raise(10201);
        }

        reader.dispose();

        return ttf;
    }

    /**
     * 关联glyf相关的信息
     *
     * @param {Object} ttf ttf对象
     */
    resolveGlyf(ttf) {
        const codes = ttf.cmap;
        const glyf = ttf.glyf;
        const subsetMap = ttf.readOptions.subset ? ttf.subsetMap : null; // 当前ttf的子集列表

        // unicode
        Object.keys(codes).forEach((c) => {
            const i = codes[c];
            if (subsetMap && !subsetMap[i]) {
                return;
            }
            if (!glyf[i].unicode) {
                glyf[i].unicode = [];
            }
            glyf[i].unicode.push(+c);
        });

        // advanceWidth
        ttf.hmtx.forEach((item, i) => {
            if (subsetMap && !subsetMap[i]) {
                return;
            }
            glyf[i].advanceWidth = item.advanceWidth;
            glyf[i].leftSideBearing = item.leftSideBearing;
        });

        // format = 2 的post表会携带glyf name信息
        if (ttf.post && 2 === ttf.post.format) {
            const nameIndex = ttf.post.nameIndex;
            const names = ttf.post.names;
            nameIndex.forEach((nameIndex, i) => {
                if (subsetMap && !subsetMap[i]) {
                    return;
                }
                if (nameIndex <= 257) {
                    glyf[i].name = _enum_postName__WEBPACK_IMPORTED_MODULE_3__.default[nameIndex];
                }
                else {
                    glyf[i].name = names[nameIndex - 258] || '';
                }
            });
        }

        // 设置了subsetMap之后需要选取subset中的字形
        // 并且对复合字形转换成简单字形
        if (subsetMap) {
            const subGlyf = [];
            Object.keys(subsetMap).forEach((i) => {
                i = +i;
                if (glyf[i].compound) {
                    (0,_util_compound2simpleglyf__WEBPACK_IMPORTED_MODULE_5__.default)(i, ttf, true);
                }
                subGlyf.push(glyf[i]);
            });
            ttf.glyf = subGlyf;
            // 转换之后不存在复合字形了
            ttf.maxp.maxComponentElements = 0;
            ttf.maxp.maxComponentDepth = 0;
        }
    }

    /**
     * 清除非必须的表
     *
     * @param {Object} ttf ttf对象
     */
    cleanTables(ttf) {
        delete ttf.readOptions;
        delete ttf.tables;
        delete ttf.hmtx;
        delete ttf.loca;
        if (ttf.post) {
            delete ttf.post.nameIndex;
            delete ttf.post.names;
        }

        delete ttf.subsetMap;

        // 不携带hinting信息则删除hint相关表
        if (!this.options.hinting) {
            delete ttf.fpgm;
            delete ttf.cvt;
            delete ttf.prep;
            delete ttf.GPOS;
            delete ttf.kern;
            ttf.glyf.forEach((glyf) => {
                delete glyf.instructions;
            });
        }

        // 复合字形转简单字形
        if (this.options.compound2simple && ttf.maxp.maxComponentElements) {
            ttf.glyf.forEach((glyf, index) => {
                if (glyf.compound) {
                    (0,_util_compound2simpleglyf__WEBPACK_IMPORTED_MODULE_5__.default)(index, ttf, true);
                }
            });
            ttf.maxp.maxComponentElements = 0;
            ttf.maxp.maxComponentDepth = 0;
        }
    }

    /**
     * 获取解析后的ttf文档
     *
     * @param {ArrayBuffer} buffer buffer对象
     * @return {Object} ttf文档
     */
    read(buffer) {
        this.ttf = this.readBuffer(buffer);
        this.resolveGlyf(this.ttf);
        this.cleanTables(this.ttf);
        return this.ttf;
    }

    /**
     * 注销
     */
    dispose() {
        delete this.ttf;
        delete this.options;
    }

}


/***/ }),
/* 88 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(40);
/* harmony import */ var _maxp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41);
/* harmony import */ var _loca__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(89);
/* harmony import */ var _cmap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42);
/* harmony import */ var _glyf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90);
/* harmony import */ var _name__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(47);
/* harmony import */ var _hhea__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(51);
/* harmony import */ var _hmtx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(52);
/* harmony import */ var _post__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(53);
/* harmony import */ var _OS2__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(54);
/* harmony import */ var _fpgm__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(96);
/* harmony import */ var _cvt__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(97);
/* harmony import */ var _prep__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(98);
/* harmony import */ var _gasp__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(99);
/* harmony import */ var _GPOS__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(63);
/* harmony import */ var _kern__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(64);
/**
 * @file ttf读取和写入支持的表
 * @author mengke01(kekee000@gmail.com)
 */



















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    head: _head__WEBPACK_IMPORTED_MODULE_0__.default,
    maxp: _maxp__WEBPACK_IMPORTED_MODULE_1__.default,
    loca: _loca__WEBPACK_IMPORTED_MODULE_2__.default,
    cmap: _cmap__WEBPACK_IMPORTED_MODULE_3__.default,
    glyf: _glyf__WEBPACK_IMPORTED_MODULE_4__.default,
    name: _name__WEBPACK_IMPORTED_MODULE_5__.default,
    hhea: _hhea__WEBPACK_IMPORTED_MODULE_6__.default,
    hmtx: _hmtx__WEBPACK_IMPORTED_MODULE_7__.default,
    post: _post__WEBPACK_IMPORTED_MODULE_8__.default,
    'OS/2': _OS2__WEBPACK_IMPORTED_MODULE_9__.default,
    fpgm: _fpgm__WEBPACK_IMPORTED_MODULE_10__.default,
    cvt: _cvt__WEBPACK_IMPORTED_MODULE_11__.default,
    prep: _prep__WEBPACK_IMPORTED_MODULE_12__.default,
    gasp: _gasp__WEBPACK_IMPORTED_MODULE_13__.default,
    GPOS: _GPOS__WEBPACK_IMPORTED_MODULE_14__.default,
    kern: _kern__WEBPACK_IMPORTED_MODULE_15__.default
});


/***/ }),
/* 89 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _struct__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38);
/**
 * @file loca表
 * @author mengke01(kekee000@gmail.com)
 */




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'loca',
    [],
    {

        read(reader, ttf) {
            let offset = this.offset;
            const indexToLocFormat = ttf.head.indexToLocFormat;
            // indexToLocFormat有2字节和4字节的区别
            const type = _struct__WEBPACK_IMPORTED_MODULE_1__.default.names[(indexToLocFormat === 0) ? _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint16 : _struct__WEBPACK_IMPORTED_MODULE_1__.default.Uint32];
            const size = (indexToLocFormat === 0) ? 2 : 4; // 字节大小
            const sizeRatio = (indexToLocFormat === 0) ? 2 : 1; // 真实地址偏移
            const wordOffset = [];

            reader.seek(offset);

            const numGlyphs = ttf.maxp.numGlyphs;
            for (let i = 0; i < numGlyphs; ++i) {
                wordOffset.push(reader.read(type, offset, false) * sizeRatio);
                offset += size;
            }

            return wordOffset;
        },

        write(writer, ttf) {
            const glyfSupport = ttf.support.glyf;
            let offset = ttf.support.glyf.offset || 0;
            const indexToLocFormat = ttf.head.indexToLocFormat;
            const sizeRatio = (indexToLocFormat === 0) ? 0.5 : 1;
            const numGlyphs = ttf.glyf.length;

            for (let i = 0; i < numGlyphs; ++i) {
                if (indexToLocFormat) {
                    writer.writeUint32(offset);
                }
                else {
                    writer.writeUint16(offset);
                }
                offset += glyfSupport[i].size * sizeRatio;
            }

            // write extra
            if (indexToLocFormat) {
                writer.writeUint32(offset);
            }
            else {
                writer.writeUint16(offset);
            }

            return writer;
        },

        size(ttf) {
            const locaCount = ttf.glyf.length + 1;
            return ttf.head.indexToLocFormat ? locaCount * 4 : locaCount * 2;
        }
    }
));


/***/ }),
/* 90 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/* harmony import */ var _glyf_parse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(91);
/* harmony import */ var _glyf_write__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(94);
/* harmony import */ var _glyf_sizeof__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(95);
/* harmony import */ var _common_lang__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8);
/**
 * @file glyf表
 * @author mengke01(kekee000@gmail.com)
 *
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6glyf.html
 */







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'glyf',
    [],
    {

        read(reader, ttf) {
            const startOffset = this.offset;
            const loca = ttf.loca;
            const numGlyphs = ttf.maxp.numGlyphs;
            const glyphs = [];

            reader.seek(startOffset);

            // subset
            const subset = ttf.readOptions.subset;

            if (subset && subset.length > 0) {
                const subsetMap = {
                    0: true // 设置.notdef
                };
                subsetMap[0] = true;
                // subset map
                const cmap = ttf.cmap;

                // unicode to index
                Object.keys(cmap).forEach((c) => {
                    if (subset.indexOf(+c) > -1) {
                        const i = cmap[c];
                        subsetMap[i] = true;
                    }
                });
                ttf.subsetMap = subsetMap;
                const parsedGlyfMap = {};
                // 循环解析subset相关的glyf，包括复合字形相关的字形
                const travelsParse = function travels(subsetMap) {
                    const newSubsetMap = {};
                    Object.keys(subsetMap).forEach((i) => {
                        const index = +i;
                        parsedGlyfMap[index] = true;
                        // 当前的和下一个一样，或者最后一个无轮廓
                        if (loca[index] === loca[index + 1]) {
                            glyphs[index] = {
                                contours: []
                            };
                        }
                        else {
                            glyphs[index] = (0,_glyf_parse__WEBPACK_IMPORTED_MODULE_1__.default)(reader, ttf, startOffset + loca[index]);
                        }

                        if (glyphs[index].compound) {
                            glyphs[index].glyfs.forEach((g) => {
                                if (!parsedGlyfMap[g.glyphIndex]) {
                                    newSubsetMap[g.glyphIndex] = true;
                                }
                            });
                        }
                    });

                    if (!(0,_common_lang__WEBPACK_IMPORTED_MODULE_4__.isEmptyObject)(newSubsetMap)) {
                        travels(newSubsetMap);
                    }
                };

                travelsParse(subsetMap);
                return glyphs;
            }

            // 解析字体轮廓, 前n-1个
            let i;
            let l;
            for (i = 0, l = numGlyphs - 1; i < l; i++) {
                // 当前的和下一个一样，或者最后一个无轮廓
                if (loca[i] === loca[i + 1]) {
                    glyphs[i] = {
                        contours: []
                    };
                }
                else {
                    glyphs[i] = (0,_glyf_parse__WEBPACK_IMPORTED_MODULE_1__.default)(reader, ttf, startOffset + loca[i]);
                }
            }

            // 最后一个轮廓
            if ((ttf.tables.glyf.length - loca[i]) < 5) {
                glyphs[i] = {
                    contours: []
                };
            }
            else {
                glyphs[i] = (0,_glyf_parse__WEBPACK_IMPORTED_MODULE_1__.default)(reader, ttf, startOffset + loca[i]);
            }

            return glyphs;
        },

        write: _glyf_write__WEBPACK_IMPORTED_MODULE_2__.default,
        size: _glyf_sizeof__WEBPACK_IMPORTED_MODULE_3__.default
    }
));


/***/ }),
/* 91 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ parseGlyf)
/* harmony export */ });
/* harmony import */ var _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92);
/* harmony import */ var _enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(93);
/**
 * @file 解析glyf轮廓
 * @author mengke01(kekee000@gmail.com)
 */




const MAX_INSTRUCTION_LENGTH = 5000; // 设置instructions阈值防止读取错误
const MAX_NUMBER_OF_COORDINATES = 20000; // 设置坐标最大个数阈值，防止glyf读取错误

/**
 * 读取简单字形
 *
 * @param {Reader} reader Reader对象
 * @param {Object} glyf 空glyf
 * @return {Object} 解析后的glyf
 */
function parseSimpleGlyf(reader, glyf) {
    const offset = reader.offset;

    // 轮廓点个数
    const numberOfCoordinates = glyf.endPtsOfContours[
        glyf.endPtsOfContours.length - 1
    ] + 1;

    // 判断坐标是否超过最大个数
    if (numberOfCoordinates > MAX_NUMBER_OF_COORDINATES) {
        console.warn('error read glyf coordinates:' + offset);
        return glyf;
    }

    // 获取flag标志
    let i;
    let length;
    const flags = [];
    let flag;

    i = 0;
    while (i < numberOfCoordinates) {
        flag = reader.readUint8();
        flags.push(flag);
        i++;

        // 标志位3重复flag
        if ((flag & _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.REPEAT) && i < numberOfCoordinates) {
            // 重复个数
            const repeat = reader.readUint8();
            for (let j = 0; j < repeat; j++) {
                flags.push(flag);
                i++;
            }
        }
    }

    // 坐标集合
    const coordinates = [];
    const xCoordinates = [];
    let prevX = 0;
    let x;

    for (i = 0, length = flags.length; i < length; ++i) {
        x = 0;
        flag = flags[i];

        // 标志位1
        // If set, the corresponding y-coordinate is 1 byte long, not 2
        if (flag & _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.XSHORT) {
            x = reader.readUint8();

            // 标志位5
            x = (flag & _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.XSAME) ? x : -1 * x;
        }
        // 与上一值一致
        else if (flag & _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.XSAME) {
            x = 0;
        }
        // 新值
        else {
            x = reader.readInt16();
        }

        prevX += x;
        xCoordinates[i] = prevX;
        coordinates[i] = {
            x: prevX,
            y: 0
        };
        if (flag & _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.ONCURVE) {
            coordinates[i].onCurve = true;
        }
    }

    const yCoordinates = [];
    let prevY = 0;
    let y;

    for (i = 0, length = flags.length; i < length; i++) {
        y = 0;
        flag = flags[i];

        if (flag & _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.YSHORT) {
            y = reader.readUint8();
            y = (flag & _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.YSAME) ? y : -1 * y;
        }
        else if (flag & _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.YSAME) {
            y = 0;
        }
        else {
            y = reader.readInt16();
        }

        prevY += y;
        yCoordinates[i] = prevY;
        if (coordinates[i]) {
            coordinates[i].y = prevY;
        }
    }

    // 计算轮廓集合
    if (coordinates.length) {
        const endPtsOfContours = glyf.endPtsOfContours;
        const contours = [];
        contours.push(coordinates.slice(0, endPtsOfContours[0] + 1));

        for (i = 1, length = endPtsOfContours.length; i < length; i++) {
            contours.push(coordinates.slice(endPtsOfContours[i - 1] + 1, endPtsOfContours[i] + 1));
        }

        glyf.contours = contours;
    }

    return glyf;
}

/**
 * 读取复合字形
 *
 * @param {Reader} reader Reader对象
 * @param {Object} glyf glyf对象
 * @return {Object} glyf对象
 */
function parseCompoundGlyf(reader, glyf) {
    glyf.compound = true;
    glyf.glyfs = [];

    let flags;
    let g;

    // 读取复杂字形
    do {
        flags = reader.readUint16();
        g = {};
        g.flags = flags;
        g.glyphIndex = reader.readUint16();

        let arg1 = 0;
        let arg2 = 0;
        let scaleX = 16384;
        let scaleY = 16384;
        let scale01 = 0;
        let scale10 = 0;

        if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.ARG_1_AND_2_ARE_WORDS & flags) {
            arg1 = reader.readInt16();
            arg2 = reader.readInt16();

        }
        else {
            arg1 = reader.readInt8();
            arg2 = reader.readInt8();
        }

        if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.ROUND_XY_TO_GRID & flags) {
            arg1 = Math.round(arg1);
            arg2 = Math.round(arg2);
        }

        if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.WE_HAVE_A_SCALE & flags) {
            scaleX = reader.readInt16();
            scaleY = scaleX;
        }
        else if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.WE_HAVE_AN_X_AND_Y_SCALE & flags) {
            scaleX = reader.readInt16();
            scaleY = reader.readInt16();
        }
        else if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.WE_HAVE_A_TWO_BY_TWO & flags) {
            scaleX = reader.readInt16();
            scale01 = reader.readInt16();
            scale10 = reader.readInt16();
            scaleY = reader.readInt16();
        }

        if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.ARGS_ARE_XY_VALUES & flags) {
            g.useMyMetrics = !!flags & _enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.USE_MY_METRICS;
            g.overlapCompound = !!flags & _enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.OVERLAP_COMPOUND;

            g.transform = {
                a: Math.round(10000 * scaleX / 16384) / 10000,
                b: Math.round(10000 * scale01 / 16384) / 10000,
                c: Math.round(10000 * scale10 / 16384) / 10000,
                d: Math.round(10000 * scaleY / 16384) / 10000,
                e: arg1,
                f: arg2
            };
        }
        else {
            g.points = [arg1, arg2];
            g.transform = {
                a: Math.round(10000 * scaleX / 16384) / 10000,
                b: Math.round(10000 * scale01 / 16384) / 10000,
                c: Math.round(10000 * scale10 / 16384) / 10000,
                d: Math.round(10000 * scaleY / 16384) / 10000,
                e: 0,
                f: 0
            };
        }

        glyf.glyfs.push(g);

    } while (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.MORE_COMPONENTS & flags);

    if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_1__.default.WE_HAVE_INSTRUCTIONS & flags) {
        const length = reader.readUint16();
        if (length < MAX_INSTRUCTION_LENGTH) {
            const instructions = [];
            for (let i = 0; i < length; ++i) {
                instructions.push(reader.readUint8());
            }
            glyf.instructions = instructions;
        }
        else {
            console.warn(length);
        }
    }

    return glyf;
}



/**
 * 解析glyf轮廓
 *
 * @param  {Reader} reader 读取器
 * @param  {Object} ttf    ttf对象
 * @param  {number=} offset 偏移
 * @return {Object}        glyf对象
 */
function parseGlyf(reader, ttf, offset) {

    if (null != offset) {
        reader.seek(offset);
    }

    const glyf = {};
    let i;
    let length;
    let instructions;

    // 边界值
    const numberOfContours = reader.readInt16();
    glyf.xMin = reader.readInt16();
    glyf.yMin = reader.readInt16();
    glyf.xMax = reader.readInt16();
    glyf.yMax = reader.readInt16();

    // 读取简单字形
    if (numberOfContours >= 0) {
        // endPtsOfConturs
        const endPtsOfContours = [];
        if (numberOfContours >= 0) {
            for (i = 0; i < numberOfContours; i++) {
                endPtsOfContours.push(reader.readUint16());
            }
            glyf.endPtsOfContours = endPtsOfContours;
        }

        // instructions
        length = reader.readUint16();
        if (length) {
            // range错误
            if (length < MAX_INSTRUCTION_LENGTH) {
                instructions = [];
                for (i = 0; i < length; ++i) {
                    instructions.push(reader.readUint8());
                }
                glyf.instructions = instructions;
            }
            else {
                console.warn(length);
            }
        }

        parseSimpleGlyf(reader, glyf);
        delete glyf.endPtsOfContours;
    }
    else {
        parseCompoundGlyf(reader, glyf);
    }

    return glyf;
}


/***/ }),
/* 92 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file 轮廓标记位
 * @author mengke01(kekee000@gmail.com)
 *
 * see:
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6glyf.html
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    ONCURVE: 0x01, // on curve ,off curve
    XSHORT: 0x02, // x-Short Vector
    YSHORT: 0x04, // y-Short Vector
    REPEAT: 0x08, // next byte is flag repeat count
    XSAME: 0x10, // This x is same (Positive x-Short vector)
    YSAME: 0x20, // This y is same (Positive y-Short vector)
    Reserved1: 0x40,
    Reserved2: 0x80
});


/***/ }),
/* 93 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @file 复合图元标记位
 * @author mengke01(kekee000@gmail.com)
 *
 * 复合图元标记位
 * https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6glyf.html
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    ARG_1_AND_2_ARE_WORDS: 0x01,
    ARGS_ARE_XY_VALUES: 0x02,
    ROUND_XY_TO_GRID: 0x04,
    WE_HAVE_A_SCALE: 0x08,
    RESERVED: 0x10,
    MORE_COMPONENTS: 0x20,
    WE_HAVE_AN_X_AND_Y_SCALE: 0x40,
    WE_HAVE_A_TWO_BY_TWO: 0x80,
    WE_HAVE_INSTRUCTIONS: 0x100,
    USE_MY_METRICS: 0x200,
    OVERLAP_COMPOUND: 0x400,
    SCALED_COMPONENT_OFFSET: 0x800,
    UNSCALED_COMPONENT_OFFSET: 0x1000
});


/***/ }),
/* 94 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ write)
/* harmony export */ });
/* harmony import */ var _enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93);
/**
 * @file 写glyf数据
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * 写glyf
 *
 * @param  {Object} writer 写入器
 * @param  {Object} ttf    ttf对象
 * @return {Object}        写入器
 */
function write(writer, ttf) {

    const hinting = ttf.writeOptions ? ttf.writeOptions.hinting : false;
    ttf.glyf.forEach((glyf, index) => {

        // header
        writer.writeInt16(glyf.compound ? -1 : (glyf.contours || []).length);
        writer.writeInt16(glyf.xMin);
        writer.writeInt16(glyf.yMin);
        writer.writeInt16(glyf.xMax);
        writer.writeInt16(glyf.yMax);

        let i;
        let l;
        let flags;

        // 复合图元
        if (glyf.compound) {

            for (i = 0, l = glyf.glyfs.length; i < l; i++) {
                const g = glyf.glyfs[i];

                flags = g.points
                    ? 0 : (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.ARGS_ARE_XY_VALUES + _enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.ROUND_XY_TO_GRID); // xy values

                // more components
                if (i < l - 1) {
                    flags += _enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.MORE_COMPONENTS;
                }


                // use my metrics
                flags += g.useMyMetrics ? _enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.USE_MY_METRICS : 0;
                // overlap compound
                flags += g.overlapCompound ? _enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.OVERLAP_COMPOUND : 0;

                const transform = g.transform;
                const a = transform.a;
                const b = transform.b;
                const c = transform.c;
                const d = transform.d;
                const e = g.points ? g.points[0] : transform.e;
                const f = g.points ? g.points[1] : transform.f;

                // xy values or points
                // int 8 放不下，则用int16放
                if (e < 0 || e > 0x7F || f < 0 || f > 0x7F) {
                    flags += _enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.ARG_1_AND_2_ARE_WORDS;
                }

                if (b || c) {
                    flags += _enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.WE_HAVE_A_TWO_BY_TWO;
                }
                else if ((a !== 1 || d !== 1) && a === d) {
                    flags += _enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.WE_HAVE_A_SCALE;
                }
                else if (a !== 1 || d !== 1) {
                    flags += _enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.WE_HAVE_AN_X_AND_Y_SCALE;
                }

                writer.writeUint16(flags);
                writer.writeUint16(g.glyphIndex);

                if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.ARG_1_AND_2_ARE_WORDS & flags) {
                    writer.writeInt16(e);
                    writer.writeInt16(f);

                }
                else {
                    writer.writeUint8(e);
                    writer.writeUint8(f);
                }

                if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.WE_HAVE_A_SCALE & flags) {
                    writer.writeInt16(Math.round(a * 16384));
                }
                else if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.WE_HAVE_AN_X_AND_Y_SCALE & flags) {
                    writer.writeInt16(Math.round(a * 16384));
                    writer.writeInt16(Math.round(d * 16384));
                }
                else if (_enum_componentFlag__WEBPACK_IMPORTED_MODULE_0__.default.WE_HAVE_A_TWO_BY_TWO & flags) {
                    writer.writeInt16(Math.round(a * 16384));
                    writer.writeInt16(Math.round(b * 16384));
                    writer.writeInt16(Math.round(c * 16384));
                    writer.writeInt16(Math.round(d * 16384));
                }
            }

        }
        else {

            let endPtsOfContours = -1;
            (glyf.contours || []).forEach((contour) => {
                endPtsOfContours += contour.length;
                writer.writeUint16(endPtsOfContours);
            });

            // instruction
            if (hinting && glyf.instructions) {
                const instructions = glyf.instructions;
                writer.writeUint16(instructions.length);
                for (i = 0, l = instructions.length; i < l; i++) {
                    writer.writeUint8(instructions[i]);
                }
            }
            else {
                writer.writeUint16(0);
            }


            // 获取暂存中的flags
            flags = ttf.support.glyf[index].flags || [];
            for (i = 0, l = flags.length; i < l; i++) {
                writer.writeUint8(flags[i]);
            }

            const xCoord = ttf.support.glyf[index].xCoord || [];
            for (i = 0, l = xCoord.length; i < l; i++) {
                if (0 <= xCoord[i] && xCoord[i] <= 0xFF) {
                    writer.writeUint8(xCoord[i]);
                }
                else {
                    writer.writeInt16(xCoord[i]);
                }
            }

            const yCoord = ttf.support.glyf[index].yCoord || [];
            for (i = 0, l = yCoord.length; i < l; i++) {
                if (0 <= yCoord[i] && yCoord[i] <= 0xFF) {
                    writer.writeUint8(yCoord[i]);
                }
                else {
                    writer.writeInt16(yCoord[i]);
                }
            }
        }

        // 4字节对齐
        const glyfSize = ttf.support.glyf[index].glyfSize;

        if (glyfSize % 4) {
            writer.writeEmpty(4 - glyfSize % 4);
        }
    });

    return writer;
}


/***/ }),
/* 95 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ sizeof)
/* harmony export */ });
/* harmony import */ var _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92);
/**
 * @file 获取glyf的大小，同时对glyf写入进行预处理
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * 获取glyf的大小
 *
 * @param {Object} glyf glyf对象
 * @param {Object} glyfSupport glyf相关统计
 * @param {boolean} hinting 是否保留hints
 * @return {number} size大小
 */
function sizeofSimple(glyf, glyfSupport, hinting) {

    // fixed header + endPtsOfContours
    let result = 12
        + (glyf.contours || []).length * 2
        + (glyfSupport.flags || []).length;

    (glyfSupport.xCoord || []).forEach((x) => {
        result += 0 <= x && x <= 0xFF ? 1 : 2;
    });

    (glyfSupport.yCoord || []).forEach((y) => {
        result += 0 <= y && y <= 0xFF ? 1 : 2;
    });

    return result + (hinting && glyf.instructions ? glyf.instructions.length : 0);
}

/**
 * 复合图元size
 *
 * @param {Object} glyf glyf对象
 * @param {boolean} hinting 是否保留hints, compound 图元暂时不做hinting
 * @return {number} size大小
 */
// eslint-disable-next-line no-unused-vars
function sizeofCompound(glyf, hinting) {
    let size = 10;
    let transform;
    glyf.glyfs.forEach((g) => {
        transform = g.transform;
        // flags + glyfIndex
        size += 4;

        // a, b, c, d, e
        // xy values or points
        if (transform.e < 0 || transform.e > 0x7F || transform.f < 0 || transform.f > 0x7F) {
            size += 4;
        }
        else {
            size += 2;
        }

        // 01 , 10
        if (transform.b || transform.c) {
            size += 8;
        }
        // scale
        else  if (transform.a !== 1 || transform.d !== 1) {
            size += transform.a === transform.d ? 2 : 4;
        }

    });

    return size;
}

/**
 * 获取flags
 *
 * @param {Object} glyf glyf对象
 * @param {Object} glyfSupport glyf相关统计
 * @return {Array}
 */
function getFlags(glyf, glyfSupport) {

    if (!glyf.contours || 0 === glyf.contours.length) {
        return glyfSupport;
    }

    const flags = [];
    const xCoord = [];
    const yCoord = [];

    const contours = glyf.contours;
    let contour;
    let prev;
    let first = true;

    for (let j = 0, cl = contours.length; j < cl; j++) {
        contour = contours[j];

        for (let i = 0, l = contour.length; i < l; i++) {

            const point = contour[i];
            if (first) {
                xCoord.push(point.x);
                yCoord.push(point.y);
                first = false;
            }
            else {
                xCoord.push(point.x - prev.x);
                yCoord.push(point.y - prev.y);
            }
            flags.push(point.onCurve ? _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.ONCURVE : 0);
            prev = point;
        }
    }

    // compress
    const flagsC = [];
    const xCoordC = [];
    const yCoordC = [];
    let x;
    let y;
    let prevFlag;
    let repeatPoint = -1;

    flags.forEach((flag, index) => {

        x = xCoord[index];
        y = yCoord[index];

        // 第一个
        if (index === 0) {

            if (-0xFF <= x && x <= 0xFF) {
                flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.XSHORT;
                if (x >= 0) {
                    flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.XSAME;
                }

                x = Math.abs(x);
            }

            if (-0xFF <= y && y <= 0xFF) {
                flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.YSHORT;
                if (y >= 0) {
                    flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.YSAME;
                }

                y = Math.abs(y);
            }

            flagsC.push(prevFlag = flag);
            xCoordC.push(x);
            yCoordC.push(y);
        }
        // 后续
        else {

            if (x === 0) {
                flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.XSAME;
            }
            else {
                if (-0xFF <= x && x <= 0xFF) {
                    flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.XSHORT;
                    if (x > 0) {
                        flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.XSAME;
                    }

                    x = Math.abs(x);
                }

                xCoordC.push(x);
            }

            if (y === 0) {
                flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.YSAME;
            }
            else {
                if (-0xFF <= y && y <= 0xFF) {
                    flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.YSHORT;
                    if (y > 0) {
                        flag += _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.YSAME;
                    }
                    y = Math.abs(y);
                }
                yCoordC.push(y);
            }

            // repeat
            if (flag === prevFlag) {
                // 记录重复个数
                if (-1 === repeatPoint) {
                    repeatPoint = flagsC.length - 1;
                    flagsC[repeatPoint] |= _enum_glyFlag__WEBPACK_IMPORTED_MODULE_0__.default.REPEAT;
                    flagsC.push(1);
                }
                else {
                    ++flagsC[repeatPoint + 1];
                }
            }
            else {
                repeatPoint = -1;
                flagsC.push(prevFlag = flag);
            }
        }

    });

    glyfSupport.flags = flagsC;
    glyfSupport.xCoord = xCoordC;
    glyfSupport.yCoord = yCoordC;

    return glyfSupport;
}

/**
 * 对glyf数据进行预处理，获取大小
 *
 * @param  {Object} ttf ttf对象
 * @return {number} 大小
 */
function sizeof(ttf) {
    ttf.support.glyf = [];
    let tableSize = 0;
    const hinting = ttf.writeOptions ? ttf.writeOptions.hinting : false;
    ttf.glyf.forEach((glyf) => {
        let glyfSupport = {};
        glyfSupport = glyf.compound ? glyfSupport : getFlags(glyf, glyfSupport);

        const glyfSize = glyf.compound
            ? sizeofCompound(glyf, hinting)
            : sizeofSimple(glyf, glyfSupport, hinting);
        let size = glyfSize;

        // 4字节对齐
        if (size % 4) {
            size += 4 - size % 4;
        }

        glyfSupport.glyfSize = glyfSize;
        glyfSupport.size = size;

        ttf.support.glyf.push(glyfSupport);

        tableSize += size;
    });

    ttf.support.glyf.tableSize = tableSize;

    // 写header的indexToLocFormat
    ttf.head.indexToLocFormat = tableSize > 65536 ? 1 : 0;

    return ttf.support.glyf.tableSize;
}


/***/ }),
/* 96 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/**
 * @file fpgm 表
 * @author mengke01(kekee000@gmail.com)
 *
 * reference: https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6fpgm.html
 */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'fpgm',
    [],
    {

        read(reader, ttf) {
            const length = ttf.tables.fpgm.length;
            return reader.readBytes(this.offset, length);
        },

        write(writer, ttf) {
            if (ttf.fpgm) {
                writer.writeBytes(ttf.fpgm, ttf.fpgm.length);
            }
        },

        size(ttf) {
            return ttf.fpgm ? ttf.fpgm.length : 0;
        }
    }
));



/***/ }),
/* 97 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/**
 * @file cvt表
 * @author mengke01(kekee000@gmail.com)
 *
 * @reference: https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6cvt.html
 */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'cvt',
    [],
    {

        read(reader, ttf) {
            const length = ttf.tables.cvt.length;
            return reader.readBytes(this.offset, length);
        },

        write(writer, ttf) {
            if (ttf.cvt) {
                writer.writeBytes(ttf.cvt, ttf.cvt.length);
            }
        },

        size(ttf) {
            return ttf.cvt ? ttf.cvt.length : 0;
        }
    }
));


/***/ }),
/* 98 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/**
 * @file prep表
 * @author mengke01(kekee000@gmail.com)
 *
 * @reference: http://www.microsoft.com/typography/otspec140/prep.htm
 */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'prep',
    [],
    {

        read(reader, ttf) {
            const length = ttf.tables.prep.length;
            return reader.readBytes(this.offset, length);
        },

        write(writer, ttf) {
            if (ttf.prep) {
                writer.writeBytes(ttf.prep, ttf.prep.length);
            }
        },

        size(ttf) {
            return ttf.prep ? ttf.prep.length : 0;
        }
    }
));


/***/ }),
/* 99 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(37);
/**
 * @file gasp 表
 * 对于需要hinting的字号需要这个表，否则会导致错误
 * @author mengke01(kekee000@gmail.com)
 * reference: https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6gasp.html
 */



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_table__WEBPACK_IMPORTED_MODULE_0__.default.create(
    'gasp',
    [],
    {

        read(reader, ttf) {
            const length = ttf.tables.gasp.length;
            return reader.readBytes(this.offset, length);
        },

        write(writer, ttf) {
            if (ttf.gasp) {
                writer.writeBytes(ttf.gasp, ttf.gasp.length);
            }
        },

        size(ttf) {
            return ttf.gasp ? ttf.gasp.length : 0;
        }
    }
));



/***/ }),
/* 100 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ TTFWriter)
/* harmony export */ });
/* harmony import */ var _writer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(33);
/* harmony import */ var _table_directory__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36);
/* harmony import */ var _table_support__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(88);
/* harmony import */ var _util_checkSum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(101);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29);
/**
 * @file ttf写入器
 * @author mengke01(kekee000@gmail.com)
 */







// 支持写的表, 注意表顺序
const SUPPORT_TABLES = [
    'OS/2',
    'cmap',
    'glyf',
    'head',
    'hhea',
    'hmtx',
    'loca',
    'maxp',
    'name',
    'post'
];

class TTFWriter {
    constructor(options = {}) {
        this.options = {
            hinting: options.hinting || false, // 不保留hints信息
            support: options.support // 自定义的导出表结构，可以自己修改某些表项目
        };
    }

    /**
     * 处理ttf结构，以便于写
     *
     * @param {ttfObject} ttf ttf数据结构
     */
    resolveTTF(ttf) {

        // 头部信息
        ttf.version = ttf.version || 0x1;
        ttf.numTables = ttf.writeOptions.tables.length;
        ttf.entrySelector = Math.floor(Math.log(ttf.numTables) / Math.LN2);
        ttf.searchRange = Math.pow(2, ttf.entrySelector) * 16;
        ttf.rangeShift = ttf.numTables * 16 - ttf.searchRange;

        // 重置校验码
        ttf.head.checkSumAdjustment = 0;
        ttf.head.magickNumber = 0x5F0F3CF5;

        if (typeof ttf.head.created === 'string') {
            ttf.head.created = /^\d+$/.test(ttf.head.created)
                ? +ttf.head.created : Date.parse(ttf.head.created);
        }
        if (typeof ttf.head.modified === 'string') {
            ttf.head.modified = /^\d+$/.test(ttf.head.modified)
                ? +ttf.head.modified : Date.parse(ttf.head.modified);
        }
        // 重置日期
        if (!ttf.head.created) {
            ttf.head.created = Date.now();
        }
        if (!ttf.head.modified) {
            ttf.head.modified = ttf.head.created;
        }

        const checkUnicodeRepeat = {}; // 检查是否有重复代码点

        // 将glyf的代码点按小到大排序
        ttf.glyf.forEach((glyf, index) => {
            if (glyf.unicode) {
                glyf.unicode = glyf.unicode.sort();

                glyf.unicode.forEach((u) => {
                    if (checkUnicodeRepeat[u]) {
                        _error__WEBPACK_IMPORTED_MODULE_4__.default.raise({
                            number: 10200,
                            data: index
                        }, index);
                    }
                    else {
                        checkUnicodeRepeat[u] = true;
                    }
                });

            }
        });
    }

    /**
     * 写ttf文件
     *
     * @param {ttfObject} ttf ttf数据结构
     * @return {ArrayBuffer} 字节流
     */
    dump(ttf) {

        // 用来做写入缓存的对象，用完后删掉
        ttf.support = Object.assign({}, this.options.support);

        // head + directory
        let ttfSize = 12 + ttf.numTables * 16;
        let ttfHeadOffset = 0; // 记录head的偏移

        // 构造tables
        ttf.support.tables = [];
        ttf.writeOptions.tables.forEach((tableName) => {
            const offset = ttfSize;
            const TableClass = _table_support__WEBPACK_IMPORTED_MODULE_2__.default[tableName];
            const tableSize = new TableClass().size(ttf); // 原始的表大小
            let size = tableSize; // 对齐后的表大小

            if (tableName === 'head') {
                ttfHeadOffset = offset;
            }

            // 4字节对齐
            if (size % 4) {
                size += 4 - size % 4;
            }

            ttf.support.tables.push({
                name: tableName,
                checkSum: 0,
                offset,
                length: tableSize,
                size
            });

            ttfSize += size;
        });

        const writer = new _writer__WEBPACK_IMPORTED_MODULE_0__.default(new ArrayBuffer(ttfSize));

        // 写头部
        writer.writeFixed(ttf.version);
        writer.writeUint16(ttf.numTables);
        writer.writeUint16(ttf.searchRange);
        writer.writeUint16(ttf.entrySelector);
        writer.writeUint16(ttf.rangeShift);

        // 写表偏移
        new _table_directory__WEBPACK_IMPORTED_MODULE_1__.default().write(writer, ttf);

        // 写支持的表数据
        ttf.support.tables.forEach((table) => {

            const tableStart = writer.offset;
            const TableClass = _table_support__WEBPACK_IMPORTED_MODULE_2__.default[table.name];
            new TableClass().write(writer, ttf);

            if (table.length % 4) {
                // 对齐字节
                writer.writeEmpty(4 - table.length % 4);
            }

            // 计算校验和
            table.checkSum = (0,_util_checkSum__WEBPACK_IMPORTED_MODULE_3__.default)(writer.getBuffer(), tableStart, table.size);

        });

        // 重新写入每个表校验和
        ttf.support.tables.forEach((table, index) => {
            const offset = 12 + index * 16 + 4;
            writer.writeUint32(table.checkSum, offset);
        });

        // 写入总校验和
        const ttfCheckSum = (0xB1B0AFBA - (0,_util_checkSum__WEBPACK_IMPORTED_MODULE_3__.default)(writer.getBuffer()) + 0x100000000) % 0x100000000;
        writer.writeUint32(ttfCheckSum, ttfHeadOffset + 8);

        delete ttf.writeOptions;
        delete ttf.support;

        const buffer = writer.getBuffer();
        writer.dispose();

        return buffer;
    }

    /**
     * 对ttf的表进行评估，标记需要处理的表
     *
     * @param  {Object} ttf ttf对象
     */
    prepareDump(ttf) {

        if (!ttf.glyf || ttf.glyf.length === 0) {
            _error__WEBPACK_IMPORTED_MODULE_4__.default.raise(10201);
        }

        if (!ttf['OS/2'] || !ttf.head || !ttf.name) {
            _error__WEBPACK_IMPORTED_MODULE_4__.default.raise(10204);
        }


        const tables = SUPPORT_TABLES.slice(0);
        ttf.writeOptions = {};
        // hinting tables direct copy
        if (this.options.hinting) {
            ['cvt', 'fpgm', 'prep', 'gasp', 'GPOS', 'kern'].forEach((table) => {
                if (ttf[table]) {
                    tables.push(table);
                }
            });
        }

        ttf.writeOptions.hinting = !!this.options.hinting;
        ttf.writeOptions.tables = tables.sort();
    }

    /**
     * 写一个ttf字体结构
     *
     * @param {Object} ttf ttf数据结构
     * @return {ArrayBuffer} 缓冲数组
     */
    write(ttf) {
        this.prepareDump(ttf);
        this.resolveTTF(ttf);
        const buffer = this.dump(ttf);
        return buffer;
    }

    /**
     * 注销
     */
    dispose() {
        delete this.options;
    }
}


/***/ }),
/* 101 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ checkSum)
/* harmony export */ });
/**
 * @file ttf table校验函数
 * @author mengke01(kekee000@gmail.com)
 */

function checkSumArrayBuffer(buffer, offset = 0, length) {
    length = length == null ? buffer.byteLength : length;

    if (offset + length > buffer.byteLength) {
        throw new Error('check sum out of bound');
    }

    const nLongs = Math.floor(length / 4);
    const view = new DataView(buffer, offset, length);
    let sum = 0;
    let i = 0;

    while (i < nLongs) {
        sum += view.getUint32(4 * i++, false);
    }

    let leftBytes = length - nLongs * 4;
    if (leftBytes) {
        offset = nLongs * 4;
        while (leftBytes > 0) {
            sum += view.getUint8(offset, false) << (leftBytes * 8);
            offset++;
            leftBytes--;
        }
    }
    return sum % 0x100000000;
}

function checkSumArray(buffer, offset = 0, length) {
    length = length || buffer.length;

    if (offset + length > buffer.length) {
        throw new Error('check sum out of bound');
    }

    const nLongs = Math.floor(length / 4);
    let sum = 0;
    let i = 0;

    while (i < nLongs) {
        sum += (buffer[i++] << 24)
            + (buffer[i++] << 16)
            + (buffer[i++] << 8)
            + buffer[i++];
    }

    let leftBytes = length - nLongs * 4;
    if (leftBytes) {
        offset = nLongs * 4;
        while (leftBytes > 0) {
            sum += buffer[offset] << (leftBytes * 8);
            offset++;
            leftBytes--;
        }
    }
    return sum % 0x100000000;
}


/**
 * table校验
 *
 * @param {ArrayBuffer|Array} buffer 表数据
 * @param {number=} offset 偏移量
 * @param {number=} length 长度
 *
 * @return {number} 校验和
 */
function checkSum(buffer, offset, length) {
    if (buffer instanceof ArrayBuffer) {
        return checkSumArrayBuffer(buffer, offset, length);
    }
    else if (buffer instanceof Array) {
        return checkSumArray(buffer, offset, length);
    }

    throw new Error('not support checksum buffer type');
}


/***/ }),
/* 102 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ttf2eot)
/* harmony export */ });
/* harmony import */ var _reader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(28);
/* harmony import */ var _writer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(33);
/* harmony import */ var _util_string__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(29);
/* harmony import */ var _table_table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(37);
/* harmony import */ var _table_struct__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38);
/* harmony import */ var _table_name__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(47);
/**
 * @file ttf转eot
 * @author mengke01(kekee000@gmail.com)
 *
 * reference:
 * http://www.w3.org/Submission/EOT/
 * https://github.com/fontello/ttf2eot/blob/master/index.js
 */









const EotHead = _table_table__WEBPACK_IMPORTED_MODULE_4__.default.create(
    'head',
    [
        ['EOTSize', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint32],
        ['FontDataSize', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint32],
        ['Version', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint32],
        ['Flags', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint32],
        ['PANOSE', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Bytes, 10],
        ['Charset', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint8],
        ['Italic', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint8],
        ['Weight', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint32],
        ['fsType', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint16],
        ['MagicNumber', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint16],
        ['UnicodeRange', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Bytes, 16],
        ['CodePageRange', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Bytes, 8],
        ['CheckSumAdjustment', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint32],
        ['Reserved', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Bytes, 16],
        ['Padding1', _table_struct__WEBPACK_IMPORTED_MODULE_5__.default.Uint16]
    ]
);

/**
 * ttf格式转换成eot字体格式
 *
 * @param {ArrayBuffer} ttfBuffer ttf缓冲数组
 * @param {Object} options 选项
 * @return {ArrayBuffer} eot格式byte流
 */
// eslint-disable-next-line no-unused-vars
function ttf2eot(ttfBuffer, options = {}) {
    // 构造eot头部
    const eotHead = new EotHead();
    const eotHeaderSize = eotHead.size();
    const eot = {};
    eot.head = eotHead.read(new _reader__WEBPACK_IMPORTED_MODULE_0__.default(new ArrayBuffer(eotHeaderSize)));

    // set fields
    eot.head.FontDataSize = ttfBuffer.byteLength || ttfBuffer.length;
    eot.head.Version = 0x20001;
    eot.head.Flags = 0;
    eot.head.Charset = 0x1;
    eot.head.MagicNumber = 0x504C;
    eot.head.Padding1 = 0;

    const ttfReader = new _reader__WEBPACK_IMPORTED_MODULE_0__.default(ttfBuffer);
    // 读取ttf表个数
    const numTables = ttfReader.readUint16(4);

    if (numTables <= 0 || numTables > 100) {
        _error__WEBPACK_IMPORTED_MODULE_3__.default.raise(10101);
    }

    // 读取ttf表索引信息
    ttfReader.seek(12);
    // 需要读取3个表内容，设置3个byte
    let tblReaded = 0;
    for (let i = 0; i < numTables && tblReaded !== 0x7; ++i) {

        const tableEntry = {
            tag: ttfReader.readString(ttfReader.offset, 4),
            checkSum: ttfReader.readUint32(),
            offset: ttfReader.readUint32(),
            length: ttfReader.readUint32()
        };

        const entryOffset = ttfReader.offset;

        if (tableEntry.tag === 'head') {
            eot.head.CheckSumAdjustment = ttfReader.readUint32(tableEntry.offset + 8);
            tblReaded += 0x1;
        }
        else if (tableEntry.tag === 'OS/2') {
            eot.head.PANOSE = ttfReader.readBytes(tableEntry.offset + 32, 10);
            eot.head.Italic = ttfReader.readUint16(tableEntry.offset + 62);
            eot.head.Weight = ttfReader.readUint16(tableEntry.offset + 4);
            eot.head.fsType = ttfReader.readUint16(tableEntry.offset + 8);
            eot.head.UnicodeRange = ttfReader.readBytes(tableEntry.offset + 42, 16);
            eot.head.CodePageRange = ttfReader.readBytes(tableEntry.offset + 78, 8);
            tblReaded += 0x2;
        }

        // 设置名字信息
        else if (tableEntry.tag === 'name') {
            const names = new _table_name__WEBPACK_IMPORTED_MODULE_6__.default(tableEntry.offset).read(ttfReader);

            eot.FamilyName = _util_string__WEBPACK_IMPORTED_MODULE_2__.default.toUCS2Bytes(names.fontFamily || '');
            eot.FamilyNameSize = eot.FamilyName.length;

            eot.StyleName = _util_string__WEBPACK_IMPORTED_MODULE_2__.default.toUCS2Bytes(names.fontStyle || '');
            eot.StyleNameSize = eot.StyleName.length;

            eot.VersionName = _util_string__WEBPACK_IMPORTED_MODULE_2__.default.toUCS2Bytes(names.version || '');
            eot.VersionNameSize = eot.VersionName.length;

            eot.FullName = _util_string__WEBPACK_IMPORTED_MODULE_2__.default.toUCS2Bytes(names.fullName || '');
            eot.FullNameSize = eot.FullName.length;

            tblReaded += 0x3;
        }

        ttfReader.seek(entryOffset);
    }

    // 计算size
    eot.head.EOTSize = eotHeaderSize
        + 4 + eot.FamilyNameSize
        + 4 + eot.StyleNameSize
        + 4 + eot.VersionNameSize
        + 4 + eot.FullNameSize
        + 2
        + eot.head.FontDataSize;

    // 这里用小尾方式写入
    const eotWriter = new _writer__WEBPACK_IMPORTED_MODULE_1__.default(new ArrayBuffer(eot.head.EOTSize), 0, eot.head.EOTSize, true);

    // write head
    eotHead.write(eotWriter, eot);

    // write names
    eotWriter.writeUint16(eot.FamilyNameSize);
    eotWriter.writeBytes(eot.FamilyName, eot.FamilyNameSize);
    eotWriter.writeUint16(0);

    eotWriter.writeUint16(eot.StyleNameSize);
    eotWriter.writeBytes(eot.StyleName, eot.StyleNameSize);
    eotWriter.writeUint16(0);

    eotWriter.writeUint16(eot.VersionNameSize);
    eotWriter.writeBytes(eot.VersionName, eot.VersionNameSize);
    eotWriter.writeUint16(0);

    eotWriter.writeUint16(eot.FullNameSize);
    eotWriter.writeBytes(eot.FullName, eot.FullNameSize);
    eotWriter.writeUint16(0);

    // write rootstring
    eotWriter.writeUint16(0);

    eotWriter.writeBytes(ttfBuffer, eot.head.FontDataSize);

    return eotWriter.getBuffer();
}


/***/ }),
/* 103 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ttf2woff)
/* harmony export */ });
/* harmony import */ var _reader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(28);
/* harmony import */ var _writer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(33);
/* harmony import */ var _common_string__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(30);
/* harmony import */ var _util_string__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29);
/* harmony import */ var _data_default__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(10);
/**
 * @file ttf转换为woff
 * @author mengke01(kekee000@gmail.com)
 *
 * woff format:
 * http://www.w3.org/TR/2012/REC-WOFF-20121213/
 *
 * references:
 * https://github.com/fontello/ttf2woff
 * https://github.com/nodeca/pako
 */








/**
 * metadata 转换成XML
 *
 * @param {Object} metadata metadata
 *
 * @example
 * metadata json:
 *
 *    {
 *        "uniqueid": "",
 *        "vendor": {
 *            "name": "",
 *            "url": ""
 *        },
 *        "credit": [
 *            {
 *                "name": "",
 *                "url": "",
 *                "role": ""
 *            }
 *        ],
 *        "description": "",
 *        "license": {
 *            "id": "",
 *            "url": "",
 *            "text": ""
 *        },
 *        "copyright": "",
 *        "trademark": "",
 *        "licensee": ""
 *    }
 *
 * @return {string} xml字符串
 */
function metadata2xml(metadata) {
    let xml = ''
        + '<?xml version="1.0" encoding="UTF-8"?>'
        +   '<metadata version="1.0">';

    metadata.uniqueid = metadata.uniqueid || (_data_default__WEBPACK_IMPORTED_MODULE_5__.default.fontId + '.' + Date.now());
    xml += '<uniqueid id="' + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.uniqueid) + '" />';

    if (metadata.vendor) {
        xml += '<vendor name="' + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.vendor.name) + '"'
            +     ' url="' + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.vendor.url) + '" />';
    }

    if (metadata.credit) {
        xml += '<credits>';
        const credits = metadata.credit instanceof Array ? metadata.credit : [metadata.credit];

        credits.forEach((credit) => {
            xml += '<credit name="' + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(credit.name) + '"'
                +     ' url="' + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(credit.url) + '"'
                +     ' role="' + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(credit.role || 'Contributor') + '" />';
        });

        xml += '</credits>';
    }

    if (metadata.description) {
        xml += '<description><text xml:lang="en">'
            +     _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.description)
            +  '</text></description>';
    }

    if (metadata.license) {
        xml += '<license url="' + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.license.url) + '"'
            +      ' id="' + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.license.id) + '"><text xml:lang="en">';
        xml += _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.license.text);
        xml += '</text></license>';
    }

    if (metadata.copyright) {
        xml += '<copyright><text xml:lang="en">';
        xml += _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.copyright);
        xml += '</text></copyright>';
    }

    if (metadata.trademark) {
        xml += '<trademark><text xml:lang="en">'
            + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.trademark)
            +  '</text></trademark>';
    }

    if (metadata.licensee) {
        xml += '<licensee name="' + _common_string__WEBPACK_IMPORTED_MODULE_2__.default.encodeHTML(metadata.licensee) + '"/>';
    }

    xml += '</metadata>';

    return xml;
}


/**
 * ttf格式转换成woff字体格式
 *
 * @param {ArrayBuffer} ttfBuffer ttf缓冲数组
 * @param {Object} options 选项
 * @param {Object} options.metadata 字体相关的信息
 * @param {Object} options.deflate 压缩相关函数
 *
 * @return {ArrayBuffer} woff格式byte流
 */
function ttf2woff(ttfBuffer, options = {}) {

    // woff 头部结构
    const woffHeader = {
        signature: 0x774F4646, // for woff
        flavor: 0x10000, // for ttf
        length: 0,
        numTables: 0,
        reserved: 0,
        totalSfntSize: 0,
        majorVersion: 0,
        minorVersion: 0,
        metaOffset: 0,
        metaLength: 0,
        metaOrigLength: 0,
        privOffset: 0,
        privLength: 0
    };

    const ttfReader = new _reader__WEBPACK_IMPORTED_MODULE_0__.default(ttfBuffer);
    let tableEntries = [];
    const numTables = ttfReader.readUint16(4); // 读取ttf表个数
    let tableEntry;
    let deflatedData;
    let i;
    let l;

    if (numTables <= 0 || numTables > 100) {
        _error__WEBPACK_IMPORTED_MODULE_4__.default.raise(10101);
    }

    // 读取ttf表索引信息
    ttfReader.seek(12);

    for (i = 0; i < numTables; ++i) {

        tableEntry = {
            tag: ttfReader.readString(ttfReader.offset, 4),
            checkSum: ttfReader.readUint32(),
            offset: ttfReader.readUint32(),
            length: ttfReader.readUint32()
        };

        const entryOffset = ttfReader.offset;

        if (tableEntry.tag === 'head') {
            // 读取font revision
            woffHeader.majorVersion = ttfReader.readUint16(tableEntry.offset + 4);
            woffHeader.minorVersion = ttfReader.readUint16(tableEntry.offset + 6);
        }

        // ttf 表数据
        const sfntData = ttfReader.readBytes(tableEntry.offset, tableEntry.length);

        // 对数据进行压缩
        if (options.deflate) {
            deflatedData = options.deflate(sfntData);

            // 这里需要判断是否压缩后数据小于原始数据
            if (deflatedData.length < sfntData.length) {
                tableEntry.data = deflatedData;
                tableEntry.deflated = true;
            }
            else {
                tableEntry.data = sfntData;
            }
        }
        else {
            tableEntry.data = sfntData;
        }

        tableEntry.compLength = tableEntry.data.length;
        tableEntries.push(tableEntry);
        ttfReader.seek(entryOffset);
    }

    if (!tableEntries.length) {
        _error__WEBPACK_IMPORTED_MODULE_4__.default.raise(10204);
    }

    // 对table进行排序
    tableEntries = tableEntries.sort((a, b) => a.tag === b.tag ? 0 : a.tag < b.tag ? -1 : 1);

    // 计算offset和 woff size
    let woffSize = 44 + 20 * numTables; // header size + table entries
    let ttfSize = 12 + 16 * numTables;

    for (i = 0, l = tableEntries.length; i < l; ++i) {
        tableEntry = tableEntries[i];
        tableEntry.offset = woffSize;
        // 4字节对齐
        woffSize += tableEntry.compLength + (tableEntry.compLength % 4 ? 4 - tableEntry.compLength % 4 : 0);
        ttfSize += tableEntry.length + (tableEntry.length % 4 ? 4 - tableEntry.length % 4 : 0);
    }

    // 计算metaData
    let metadata = null;
    if (options.metadata) {
        const xml = _util_string__WEBPACK_IMPORTED_MODULE_3__.default.toUTF8Bytes(metadata2xml(options.metadata));

        if (options.deflate) {
            deflatedData = options.deflate(xml);
            if (deflatedData.length < xml.length) {
                metadata = deflatedData;
            }
            else {
                metadata = xml;
            }
        }
        else {
            metadata = xml;
        }

        woffHeader.metaLength = metadata.length;
        woffHeader.metaOrigLength = xml.length;
        woffHeader.metaOffset = woffSize;
        // metadata header + length
        woffSize += woffHeader.metaLength + (woffHeader.metaLength % 4 ? 4 - woffHeader.metaLength % 4 : 0);
    }

    woffHeader.numTables = tableEntries.length;
    woffHeader.length = woffSize;
    woffHeader.totalSfntSize = ttfSize;

    // 写woff数据
    const woffWriter = new _writer__WEBPACK_IMPORTED_MODULE_1__.default(new ArrayBuffer(woffSize));

    // 写woff头部
    woffWriter.writeUint32(woffHeader.signature);
    woffWriter.writeUint32(woffHeader.flavor);
    woffWriter.writeUint32(woffHeader.length);
    woffWriter.writeUint16(woffHeader.numTables);
    woffWriter.writeUint16(woffHeader.reserved);
    woffWriter.writeUint32(woffHeader.totalSfntSize);
    woffWriter.writeUint16(woffHeader.majorVersion);
    woffWriter.writeUint16(woffHeader.minorVersion);
    woffWriter.writeUint32(woffHeader.metaOffset);
    woffWriter.writeUint32(woffHeader.metaLength);
    woffWriter.writeUint32(woffHeader.metaOrigLength);
    woffWriter.writeUint32(woffHeader.privOffset);
    woffWriter.writeUint32(woffHeader.privLength);


    // 写woff表索引
    for (i = 0, l = tableEntries.length; i < l; ++i) {
        tableEntry = tableEntries[i];
        woffWriter.writeString(tableEntry.tag);
        woffWriter.writeUint32(tableEntry.offset);
        woffWriter.writeUint32(tableEntry.compLength);
        woffWriter.writeUint32(tableEntry.length);
        woffWriter.writeUint32(tableEntry.checkSum);
    }

    // 写表数据
    for (i = 0, l = tableEntries.length; i < l; ++i) {
        tableEntry = tableEntries[i];
        woffWriter.writeBytes(tableEntry.data);

        if (tableEntry.compLength % 4) {
            woffWriter.writeEmpty(4 - tableEntry.compLength % 4);
        }
    }

    // 写metadata
    if (metadata) {
        woffWriter.writeBytes(metadata);
        if (woffHeader.metaLength % 4) {
            woffWriter.writeEmpty(4 - woffHeader.metaLength % 4);
        }
    }

    return woffWriter.getBuffer();
}


/***/ }),
/* 104 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ttf2svg)
/* harmony export */ });
/* harmony import */ var _common_string__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30);
/* harmony import */ var _util_string__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12);
/* harmony import */ var _ttfreader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87);
/* harmony import */ var _util_contours2svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(105);
/* harmony import */ var _util_unicode2xml__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(107);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(29);
/* harmony import */ var _data_default__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(10);
/**
 * @file ttf转svg
 * @author mengke01(kekee000@gmail.com)
 *
 * references:
 * http://www.w3.org/TR/SVG11/fonts.html
 */









// svg font id
const SVG_FONT_ID = _data_default__WEBPACK_IMPORTED_MODULE_6__.default.fontId;

// xml 模板
const XML_TPL = ''
    + '<?xml version="1.0" standalone="no"?>'
    +   '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd" >'
    +   '<svg xmlns="http://www.w3.org/2000/svg">'
    +   '<metadata>${metadata}</metadata>'
    +   '<defs><font id="${id}" horiz-adv-x="${advanceWidth}">'
    +       '<font-face font-family="${fontFamily}" font-weight="${fontWeight}" font-stretch="normal"'
    +           ' units-per-em="${unitsPerEm}" panose-1="${panose}" ascent="${ascent}" descent="${descent}"'
    +           ' x-height="${xHeight}" bbox="${bbox}" underline-thickness="${underlineThickness}"'
    +           ' underline-position="${underlinePosition}" unicode-range="${unicodeRange}" />'
    +       '<missing-glyph horiz-adv-x="${missing.advanceWidth}" ${missing.d} />'
    +       '${glyphList}'
    +   '</font></defs>'
    + '</svg>';

// glyph 模板
const GLYPH_TPL = '<glyph glyph-name="${name}" unicode="${unicode}" d="${d}" />';

/**
 * ttf数据结构转svg
 *
 * @param {ttfObject} ttf ttfObject对象
 * @param {Object} options 选项
 * @param {string} options.metadata 字体相关的信息
 * @return {string} svg字符串
 */
function ttfobject2svg(ttf, options) {

    const OS2 = ttf['OS/2'];

    // 用来填充xml的数据
    const xmlObject = {
        id: ttf.name.uniqueSubFamily || SVG_FONT_ID,
        metadata: _common_string__WEBPACK_IMPORTED_MODULE_0__.default.encodeHTML(options.metadata || ''),
        advanceWidth: ttf.hhea.advanceWidthMax,
        fontFamily: ttf.name.fontFamily,
        fontWeight: OS2.usWeightClass,
        unitsPerEm: ttf.head.unitsPerEm,
        panose: [
            OS2.bFamilyType, OS2.bSerifStyle, OS2.bWeight, OS2.bProportion, OS2.bContrast,
            OS2.bStrokeVariation, OS2.bArmStyle, OS2.bLetterform, OS2.bMidline, OS2.bXHeight
        ].join(' '),
        ascent: ttf.hhea.ascent,
        descent: ttf.hhea.descent,
        xHeight: OS2.bXHeight,
        bbox: [ttf.head.xMin, ttf.head.yMin, ttf.head.xMax, ttf.head.yMax].join(' '),
        underlineThickness: ttf.post.underlineThickness,
        underlinePosition: ttf.post.underlinePosition,
        unicodeRange: 'U+' + _common_string__WEBPACK_IMPORTED_MODULE_0__.default.pad(OS2.usFirstCharIndex.toString(16), 4)
            + '-' + _common_string__WEBPACK_IMPORTED_MODULE_0__.default.pad(OS2.usLastCharIndex.toString(16), 4)
    };

    // glyf 第一个为missing glyph
    xmlObject.missing = {};
    xmlObject.missing.advanceWidth = ttf.glyf[0].advanceWidth || 0;
    xmlObject.missing.d = ttf.glyf[0].contours && ttf.glyf[0].contours.length
        ? 'd="' + (0,_util_contours2svg__WEBPACK_IMPORTED_MODULE_3__.default)(ttf.glyf[0].contours) + '"'
        : '';

    // glyf 信息
    let glyphList = '';
    for (let i = 1, l = ttf.glyf.length; i < l; i++) {
        const glyf = ttf.glyf[i];

        // 筛选简单字形，并且有轮廓，有编码
        if (!glyf.compound && glyf.contours && glyf.unicode && glyf.unicode.length) {
            const glyfObject = {
                name: _util_string__WEBPACK_IMPORTED_MODULE_1__.default.escape(glyf.name),
                unicode: (0,_util_unicode2xml__WEBPACK_IMPORTED_MODULE_4__.default)(glyf.unicode),
                d: (0,_util_contours2svg__WEBPACK_IMPORTED_MODULE_3__.default)(glyf.contours)
            };
            glyphList += _common_string__WEBPACK_IMPORTED_MODULE_0__.default.format(GLYPH_TPL, glyfObject);
        }
    }
    xmlObject.glyphList = glyphList;

    return _common_string__WEBPACK_IMPORTED_MODULE_0__.default.format(XML_TPL, xmlObject);
}


/**
 * ttf格式转换成svg字体格式
 *
 * @param {ArrayBuffer|ttfObject} ttfBuffer ttf缓冲数组或者ttfObject对象
 * @param {Object} options 选项
 * @param {Object} options.metadata 字体相关的信息
 *
 * @return {string} svg字符串
 */
function ttf2svg(ttfBuffer, options = {}) {

    // 读取ttf二进制流
    if (ttfBuffer instanceof ArrayBuffer) {
        const reader = new _ttfreader__WEBPACK_IMPORTED_MODULE_2__.default();
        const ttfObject = reader.read(ttfBuffer);
        reader.dispose();

        return ttfobject2svg(ttfObject, options);
    }
    // 读取ttfObject
    else if (ttfBuffer.version && ttfBuffer.glyf) {

        return ttfobject2svg(ttfBuffer, options);
    }

    _error__WEBPACK_IMPORTED_MODULE_5__.default.raise(10109);
}


/***/ }),
/* 105 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ contours2svg)
/* harmony export */ });
/* harmony import */ var _contour2svg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(106);
/**
 * @file 将ttf字形转换为svg路径`d`
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * contours轮廓转svgpath
 *
 * @param {Array} contours 轮廓list
 * @param {number} precision 精确度
 * @return {string} path字符串
 */
function contours2svg(contours, precision) {

    if (!contours.length) {
        return '';
    }

    return contours.map((contour) => (0,_contour2svg__WEBPACK_IMPORTED_MODULE_0__.default)(contour, precision)).join('');
}


/***/ }),
/* 106 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ contour2svg)
/* harmony export */ });
/**
 * @file 将ttf路径转换为svg路径`d`
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 将路径转换为svg路径
 *
 * @param {Array} contour 轮廓序列
 * @param {number} precision 精确度
 * @return {string} 路径
 */
function contour2svg(contour, precision = 2) {
    if (!contour.length) {
        return '';
    }

    const ceil = function (number) {
        return +(number).toFixed(precision);
    };
    const pathArr = [];
    let curPoint;
    let prevPoint;
    let nextPoint;
    let x; // x相对坐标
    let y; // y相对坐标
    for (let i = 0, l = contour.length; i < l; i++) {
        curPoint = contour[i];
        prevPoint = i === 0 ? contour[l - 1] : contour[i - 1];
        nextPoint = i === l - 1 ? contour[0] : contour[i + 1];

        // 起始坐标
        if (i === 0) {
            if (curPoint.onCurve) {
                x = curPoint.x;
                y = curPoint.y;
                pathArr.push('M' + ceil(x) + ' ' + ceil(y));
            }
            else if (prevPoint.onCurve) {
                x = prevPoint.x;
                y = prevPoint.y;
                pathArr.push('M' + ceil(x) + ' ' + ceil(y));
            }
            else {
                x = (prevPoint.x + curPoint.x) / 2;
                y = (prevPoint.y + curPoint.y) / 2;
                pathArr.push('M' + ceil(x)  + ' ' + ceil(y));
            }
        }

        // 直线
        if (curPoint.onCurve && nextPoint.onCurve) {
            pathArr.push('l' + ceil(nextPoint.x - x)
                + ' ' + ceil(nextPoint.y - y));
            x = nextPoint.x;
            y = nextPoint.y;
        }
        else if (!curPoint.onCurve) {
            if (nextPoint.onCurve) {
                pathArr.push('q' + ceil(curPoint.x - x)
                    + ' ' + ceil(curPoint.y - y)
                    + ' ' + ceil(nextPoint.x - x)
                    + ' ' + ceil(nextPoint.y - y));
                x = nextPoint.x;
                y = nextPoint.y;
            }
            else {
                const x1 = (curPoint.x + nextPoint.x) / 2;
                const y1 = (curPoint.y + nextPoint.y) / 2;
                pathArr.push('q' + ceil(curPoint.x - x)
                        + ' ' + ceil(curPoint.y - y)
                        + ' ' + ceil(x1 - x)
                        + ' ' + ceil(y1 - y));
                x = x1;
                y = y1;
            }
        }
    }
    pathArr.push('Z');
    return pathArr.join(' ');
}


/***/ }),
/* 107 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ unicode2xml)
/* harmony export */ });
/* harmony import */ var _common_string__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30);
/**
 * @file unicode字符转xml字符编码
 * @author mengke01(kekee000@gmail.com)
 */


/**
 * unicode 转xml编码格式
 *
 * @param {Array.<number>} unicodeList unicode字符列表
 * @return {string} xml编码格式
 */
function unicode2xml(unicodeList) {
    if (typeof unicodeList === 'number') {
        unicodeList = [unicodeList];
    }
    return unicodeList.map(u => {
        if (u < 0x20) {
            return '';
        }
        return u >= 0x20 && u <= 255
            ? _common_string__WEBPACK_IMPORTED_MODULE_0__.default.encodeHTML(String.fromCharCode(u))
            : '&#x' + u.toString(16) + ';';
    }).join('');
}


/***/ }),
/* 108 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getSymbolId": () => (/* binding */ getSymbolId),
/* harmony export */   "default": () => (/* binding */ ttf2symbol)
/* harmony export */ });
/* harmony import */ var _common_string__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30);
/* harmony import */ var _ttfreader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87);
/* harmony import */ var _util_contours2svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(105);
/* harmony import */ var _graphics_pathsUtil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(85);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29);
/**
 * @file ttf 转 svg symbol
 * @author mengke01(kekee000@gmail.com)
 */







// xml 模板
const XML_TPL = ''
    + '<svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1"'
    +   ' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">'
    +   '<defs>${symbolList}</defs>'
    + '</svg>';

// symbol 模板
const SYMBOL_TPL = ''
    + '<symbol id="${id}" viewBox="0 ${descent} ${unitsPerEm} ${unitsPerEm}">'
    +   '<path d="${d}"></path>'
    + '</symbol>';


/**
 * 根据 glyf 获取 symbo 名称
 * 1. 有 `name` 属性则使用 name 属性
 * 2. 有 `unicode` 属性则取 unicode 第一个: 'uni' + unicode
 * 3. 使用索引号作为 id: 'symbol' + index
 *
 * @param  {Object} glyf  glyf 对象
 * @param  {number} index glyf 索引
 * @return {string}
 */
function getSymbolId(glyf, index) {
    if (glyf.name) {
        return glyf.name;
    }

    if (glyf.unicode && glyf.unicode.length) {
        return 'uni-' + glyf.unicode[0];
    }
    return 'symbol-' + index;
}

/**
 * ttf数据结构转svg
 *
 * @param {ttfObject} ttf ttfObject对象
 * @param {Object} options 选项
 * @param {Object} options.metadata 字体相关的信息
 * @return {string} svg字符串
 */
// eslint-disable-next-line no-unused-vars
function ttfobject2symbol(ttf, options = {}) {
    const xmlObject = {};
    const unitsPerEm = ttf.head.unitsPerEm;
    const descent = ttf.hhea.descent;
    // glyf 信息
    let symbolList = '';
    for (let i = 1, l = ttf.glyf.length; i < l; i++) {
        const glyf = ttf.glyf[i];
        // 筛选简单字形，并且有轮廓，有编码
        if (!glyf.compound && glyf.contours) {
            const contours = _graphics_pathsUtil__WEBPACK_IMPORTED_MODULE_3__.default.flip(glyf.contours);
            const glyfObject = {
                descent,
                unitsPerEm,
                id: getSymbolId(glyf, i),
                d: (0,_util_contours2svg__WEBPACK_IMPORTED_MODULE_2__.default)(contours)
            };
            symbolList += _common_string__WEBPACK_IMPORTED_MODULE_0__.default.format(SYMBOL_TPL, glyfObject);
        }
    }
    xmlObject.symbolList = symbolList;
    return _common_string__WEBPACK_IMPORTED_MODULE_0__.default.format(XML_TPL, xmlObject);
}


/**
 * ttf格式转换成svg字体格式
 *
 * @param {ArrayBuffer|ttfObject} ttfBuffer ttf缓冲数组或者ttfObject对象
 * @param {Object} options 选项
 * @param {Object} options.metadata 字体相关的信息
 *
 * @return {string} svg字符串
 */
function ttf2symbol(ttfBuffer, options = {}) {

    // 读取ttf二进制流
    if (ttfBuffer instanceof ArrayBuffer) {
        const reader = new _ttfreader__WEBPACK_IMPORTED_MODULE_1__.default();
        const ttfObject = reader.read(ttfBuffer);
        reader.dispose();

        return ttfobject2symbol(ttfObject, options);
    }
    // 读取ttfObject
    else if (ttfBuffer.version && ttfBuffer.glyf) {

        return ttfobject2symbol(ttfBuffer, options);
    }

    _error__WEBPACK_IMPORTED_MODULE_4__.default.raise(10112);
}


/***/ }),
/* 109 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ttftowoff2),
/* harmony export */   "ttftowoff2async": () => (/* binding */ ttftowoff2async)
/* harmony export */ });
/* harmony import */ var _woff2_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(110);
/* harmony import */ var _woff2_index__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_woff2_index__WEBPACK_IMPORTED_MODULE_0__);
/**
 * @file ttf to woff2
 * @author mengke01(kekee000@gmail.com)
 */


/**
 * ttf格式转换成woff2字体格式
 *
 * @param {ArrayBuffer} ttfBuffer ttf缓冲数组
 * @param {Object} options 选项
 *
 * @return {Promise.<ArrayBuffer>} woff格式byte流
 */
// eslint-disable-next-line no-unused-vars
function ttftowoff2(ttfBuffer, options = {}) {
    if (!_woff2_index__WEBPACK_IMPORTED_MODULE_0___default().isInited()) {
        throw new Error('use woff2.init() to init woff2 module!');
    }

    const result = _woff2_index__WEBPACK_IMPORTED_MODULE_0___default().encode(ttfBuffer);
    return result.buffer;
}


/**
 * ttf格式转换成woff2字体格式
 *
 * @param {ArrayBuffer} ttfBuffer ttf缓冲数组
 * @param {Object} options 选项
 *
 * @return {Promise.<ArrayBuffer>} woff格式byte流
 */
function ttftowoff2async(ttfBuffer, options = {}) {
    return _woff2_index__WEBPACK_IMPORTED_MODULE_0___default().init(options.wasmUrl).then(() => {
        const result = _woff2_index__WEBPACK_IMPORTED_MODULE_0___default().encode(ttfBuffer);
        return result.buffer;
    });
}


/***/ }),
/* 110 */
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var __dirname = "/";
/**
 * @file woff2 wasm build of google woff2
 * thanks to woff2-asm
 * https://github.com/alimilhim/woff2-wasm
 * @author mengke01(kekee000@gmail.com)
 */

function convertFromVecToUint8Array(vector) {
    const arr = [];
    for (let i = 0, l = vector.size(); i < l; i++) {
        arr.push(vector.get(i));
    }
    return new Uint8Array(arr);
}


// eslint-disable-next-line import/no-commonjs
module.exports = {

    woff2Module: null,

    /**
     * 是否已经加载完毕
     *
     * @return {boolean}
     */
    isInited() {
        return this.woff2Module
            && this.woff2Module.woff2Enc
            && this.woff2Module.woff2Dec;
    },

    /**
     * 初始化 woff 模块
     *
     * @param {string|ArrayBuffer} wasmUrl woff2.wasm file url
     * @return {Promise}
     */
    init(wasmUrl) {
        return new Promise(resolve => {
            if (this.woff2Module) {
                resolve(this);
                return;
            }

            // for browser
            const moduleLoader = __webpack_require__(111);
            let moduleLoaderConfig = null;
            if (typeof window !== 'undefined') {
                moduleLoaderConfig = {
                    locateFile(path) {
                        if (path.endsWith('.wasm')) {
                            return wasmUrl;
                        }
                        return path;
                    }
                };
            }
            // for nodejs
            else {
                moduleLoaderConfig = {
                    wasmBinaryFile: __dirname + '/woff2.wasm'
                };
            }
            const woff2Module = moduleLoader(moduleLoaderConfig);
            woff2Module.onRuntimeInitialized = () => {
                this.woff2Module = woff2Module;
                resolve(this);
            };
        });
    },

    /**
     * 将ttf buffer 转换成 woff2 buffer
     *
     * @param {ArrayBuffer|Buffer|Array} ttfBuffer ttf buffer
     * @return {Uint8Array} uint8 array
     */
    encode(ttfBuffer) {
        const buffer = new Uint8Array(ttfBuffer);
        const woffbuff = this.woff2Module.woff2Enc(buffer, buffer.byteLength);
        return convertFromVecToUint8Array(woffbuff);
    },

    /**
     * 将woff2 buffer 转换成 ttf buffer
     *
     * @param {ArrayBuffer|Buffer|Array} woff2Buffer woff2 buffer
     * @return {Uint8Array} uint8 array
     */
    decode(woff2Buffer) {
        const buffer = new Uint8Array(woff2Buffer);
        const ttfbuff = this.woff2Module.woff2Dec(buffer, buffer.byteLength);
        return convertFromVecToUint8Array(ttfbuff);
    }
};


/***/ }),
/* 111 */
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var __dirname = "/";
/* provided dependency */ var process = __webpack_require__(112);

var Module = (function() {
  var _scriptDir = typeof document !== 'undefined' && document.currentScript ? document.currentScript.src : undefined;
  return (
function(Module) {
  Module = Module || {};

"use strict";var Module=typeof Module!=="undefined"?Module:{};var moduleOverrides={};var key;for(key in Module){if(Module.hasOwnProperty(key)){moduleOverrides[key]=Module[key]}}var arguments_=[];var thisProgram="./this.program";var quit_=function(status,toThrow){throw toThrow};var ENVIRONMENT_IS_WEB=false;var ENVIRONMENT_IS_WORKER=false;var ENVIRONMENT_IS_NODE=false;var ENVIRONMENT_HAS_NODE=false;var ENVIRONMENT_IS_SHELL=false;ENVIRONMENT_IS_WEB=typeof window==="object";ENVIRONMENT_IS_WORKER=typeof importScripts==="function";ENVIRONMENT_HAS_NODE=typeof process==="object"&&typeof process.versions==="object"&&typeof process.versions.node==="string";ENVIRONMENT_IS_NODE=ENVIRONMENT_HAS_NODE&&!ENVIRONMENT_IS_WEB&&!ENVIRONMENT_IS_WORKER;ENVIRONMENT_IS_SHELL=!ENVIRONMENT_IS_WEB&&!ENVIRONMENT_IS_NODE&&!ENVIRONMENT_IS_WORKER;if(Module["ENVIRONMENT"]){throw new Error("Module.ENVIRONMENT has been deprecated. To force the environment, use the ENVIRONMENT compile-time option (for example, -s ENVIRONMENT=web or -s ENVIRONMENT=node)")}var scriptDirectory="";function locateFile(path){if(Module["locateFile"]){return Module["locateFile"](path,scriptDirectory)}return scriptDirectory+path}var read_,readAsync,readBinary,setWindowTitle;if(ENVIRONMENT_IS_NODE){scriptDirectory=__dirname+"/";var nodeFS;var nodePath;read_=function shell_read(filename,binary){var ret;if(!nodeFS)nodeFS=__webpack_require__(113)(["fs"].join());if(!nodePath)nodePath=__webpack_require__(113)(["path"].join());filename=nodePath["normalize"](filename);ret=nodeFS["readFileSync"](filename);return binary?ret:ret.toString()};readBinary=function readBinary(filename){var ret=read_(filename,true);if(!ret.buffer){ret=new Uint8Array(ret)}assert(ret.buffer);return ret};if(process["argv"].length>1){thisProgram=process["argv"][1].replace(/\\/g,"/")}arguments_=process["argv"].slice(2);process["on"]("uncaughtException",function(ex){if(!(ex instanceof ExitStatus)){throw ex}});process["on"]("unhandledRejection",abort);quit_=function(status){process["exit"](status)};Module["inspect"]=function(){return"[Emscripten Module object]"}}else if(ENVIRONMENT_IS_SHELL){if(typeof read!="undefined"){read_=function shell_read(f){return read(f)}}readBinary=function readBinary(f){var data;if(typeof readbuffer==="function"){return new Uint8Array(readbuffer(f))}data=read(f,"binary");assert(typeof data==="object");return data};if(typeof scriptArgs!="undefined"){arguments_=scriptArgs}else if(typeof arguments!="undefined"){arguments_=arguments}if(typeof quit==="function"){quit_=function(status){quit(status)}}if(typeof print!=="undefined"){if(typeof console==="undefined")console={};console.log=print;console.warn=console.error=typeof printErr!=="undefined"?printErr:print}}else if(ENVIRONMENT_IS_WEB||ENVIRONMENT_IS_WORKER){if(ENVIRONMENT_IS_WORKER){scriptDirectory=self.location.href}else if(document.currentScript){scriptDirectory=document.currentScript.src}if(_scriptDir){scriptDirectory=_scriptDir}if(scriptDirectory.indexOf("blob:")!==0){scriptDirectory=scriptDirectory.substr(0,scriptDirectory.lastIndexOf("/")+1)}else{scriptDirectory=""}read_=function shell_read(url){var xhr=new XMLHttpRequest;xhr.open("GET",url,false);xhr.send(null);return xhr.responseText};if(ENVIRONMENT_IS_WORKER){readBinary=function readBinary(url){var xhr=new XMLHttpRequest;xhr.open("GET",url,false);xhr.responseType="arraybuffer";xhr.send(null);return new Uint8Array(xhr.response)}}readAsync=function readAsync(url,onload,onerror){var xhr=new XMLHttpRequest;xhr.open("GET",url,true);xhr.responseType="arraybuffer";xhr.onload=function xhr_onload(){if(xhr.status==200||xhr.status==0&&xhr.response){onload(xhr.response);return}onerror()};xhr.onerror=onerror;xhr.send(null)};setWindowTitle=function(title){document.title=title}}else{throw new Error("environment detection error")}var out=Module["print"]||function(){};var err=Module["printErr"]||function(){};for(key in moduleOverrides){if(moduleOverrides.hasOwnProperty(key)){Module[key]=moduleOverrides[key]}}moduleOverrides=null;if(Module["arguments"])arguments_=Module["arguments"];if(!Object.getOwnPropertyDescriptor(Module,"arguments"))Object.defineProperty(Module,"arguments",{configurable:true,get:function(){abort("Module.arguments has been replaced with plain arguments_")}});if(Module["thisProgram"])thisProgram=Module["thisProgram"];if(!Object.getOwnPropertyDescriptor(Module,"thisProgram"))Object.defineProperty(Module,"thisProgram",{configurable:true,get:function(){abort("Module.thisProgram has been replaced with plain thisProgram")}});if(Module["quit"])quit_=Module["quit"];if(!Object.getOwnPropertyDescriptor(Module,"quit"))Object.defineProperty(Module,"quit",{configurable:true,get:function(){abort("Module.quit has been replaced with plain quit_")}});assert(typeof Module["memoryInitializerPrefixURL"]==="undefined","Module.memoryInitializerPrefixURL option was removed, use Module.locateFile instead");assert(typeof Module["pthreadMainPrefixURL"]==="undefined","Module.pthreadMainPrefixURL option was removed, use Module.locateFile instead");assert(typeof Module["cdInitializerPrefixURL"]==="undefined","Module.cdInitializerPrefixURL option was removed, use Module.locateFile instead");assert(typeof Module["filePackagePrefixURL"]==="undefined","Module.filePackagePrefixURL option was removed, use Module.locateFile instead");assert(typeof Module["read"]==="undefined","Module.read option was removed (modify read_ in JS)");assert(typeof Module["readAsync"]==="undefined","Module.readAsync option was removed (modify readAsync in JS)");assert(typeof Module["readBinary"]==="undefined","Module.readBinary option was removed (modify readBinary in JS)");assert(typeof Module["setWindowTitle"]==="undefined","Module.setWindowTitle option was removed (modify setWindowTitle in JS)");if(!Object.getOwnPropertyDescriptor(Module,"read"))Object.defineProperty(Module,"read",{configurable:true,get:function(){abort("Module.read has been replaced with plain read_")}});if(!Object.getOwnPropertyDescriptor(Module,"readAsync"))Object.defineProperty(Module,"readAsync",{configurable:true,get:function(){abort("Module.readAsync has been replaced with plain readAsync")}});if(!Object.getOwnPropertyDescriptor(Module,"readBinary"))Object.defineProperty(Module,"readBinary",{configurable:true,get:function(){abort("Module.readBinary has been replaced with plain readBinary")}});stackSave=stackRestore=stackAlloc=function(){abort("cannot use the stack before compiled code is ready to run, and has provided stack access")};function warnOnce(text){if(!warnOnce.shown)warnOnce.shown={};if(!warnOnce.shown[text]){warnOnce.shown[text]=1;err(text)}}var asm2wasmImports={"f64-rem":function(x,y){return x%y},"debugger":function(){debugger}};var functionPointers=new Array(0);var tempRet0=0;var setTempRet0=function(value){tempRet0=value};var wasmBinary;if(Module["wasmBinary"])wasmBinary=Module["wasmBinary"];if(!Object.getOwnPropertyDescriptor(Module,"wasmBinary"))Object.defineProperty(Module,"wasmBinary",{configurable:true,get:function(){abort("Module.wasmBinary has been replaced with plain wasmBinary")}});var noExitRuntime;if(Module["noExitRuntime"])noExitRuntime=Module["noExitRuntime"];if(!Object.getOwnPropertyDescriptor(Module,"noExitRuntime"))Object.defineProperty(Module,"noExitRuntime",{configurable:true,get:function(){abort("Module.noExitRuntime has been replaced with plain noExitRuntime")}});if(typeof WebAssembly!=="object"){abort("No WebAssembly support found. Build with -s WASM=0 to target JavaScript instead.")}var wasmMemory;var wasmTable=new WebAssembly.Table({"initial":352,"maximum":352,"element":"anyfunc"});var ABORT=false;var EXITSTATUS=0;function assert(condition,text){if(!condition){abort("Assertion failed: "+text)}}function getCFunc(ident){var func=Module["_"+ident];assert(func,"Cannot call unknown function "+ident+", make sure it is exported");return func}function ccall(ident,returnType,argTypes,args,opts){var toC={"string":function(str){var ret=0;if(str!==null&&str!==undefined&&str!==0){var len=(str.length<<2)+1;ret=stackAlloc(len);stringToUTF8(str,ret,len)}return ret},"array":function(arr){var ret=stackAlloc(arr.length);writeArrayToMemory(arr,ret);return ret}};function convertReturnValue(ret){if(returnType==="string")return UTF8ToString(ret);if(returnType==="boolean")return Boolean(ret);return ret}var func=getCFunc(ident);var cArgs=[];var stack=0;assert(returnType!=="array",'Return type should not be "array".');if(args){for(var i=0;i<args.length;i++){var converter=toC[argTypes[i]];if(converter){if(stack===0)stack=stackSave();cArgs[i]=converter(args[i])}else{cArgs[i]=args[i]}}}var ret=func.apply(null,cArgs);ret=convertReturnValue(ret);if(stack!==0)stackRestore(stack);return ret}function cwrap(ident,returnType,argTypes,opts){return function(){return ccall(ident,returnType,argTypes,arguments,opts)}}var UTF8Decoder=typeof TextDecoder!=="undefined"?new TextDecoder("utf8"):undefined;function UTF8ArrayToString(u8Array,idx,maxBytesToRead){var endIdx=idx+maxBytesToRead;var endPtr=idx;while(u8Array[endPtr]&&!(endPtr>=endIdx))++endPtr;if(endPtr-idx>16&&u8Array.subarray&&UTF8Decoder){return UTF8Decoder.decode(u8Array.subarray(idx,endPtr))}else{var str="";while(idx<endPtr){var u0=u8Array[idx++];if(!(u0&128)){str+=String.fromCharCode(u0);continue}var u1=u8Array[idx++]&63;if((u0&224)==192){str+=String.fromCharCode((u0&31)<<6|u1);continue}var u2=u8Array[idx++]&63;if((u0&240)==224){u0=(u0&15)<<12|u1<<6|u2}else{if((u0&248)!=240)warnOnce("Invalid UTF-8 leading byte 0x"+u0.toString(16)+" encountered when deserializing a UTF-8 string on the asm.js/wasm heap to a JS string!");u0=(u0&7)<<18|u1<<12|u2<<6|u8Array[idx++]&63}if(u0<65536){str+=String.fromCharCode(u0)}else{var ch=u0-65536;str+=String.fromCharCode(55296|ch>>10,56320|ch&1023)}}}return str}function UTF8ToString(ptr,maxBytesToRead){return ptr?UTF8ArrayToString(HEAPU8,ptr,maxBytesToRead):""}function stringToUTF8Array(str,outU8Array,outIdx,maxBytesToWrite){if(!(maxBytesToWrite>0))return 0;var startIdx=outIdx;var endIdx=outIdx+maxBytesToWrite-1;for(var i=0;i<str.length;++i){var u=str.charCodeAt(i);if(u>=55296&&u<=57343){var u1=str.charCodeAt(++i);u=65536+((u&1023)<<10)|u1&1023}if(u<=127){if(outIdx>=endIdx)break;outU8Array[outIdx++]=u}else if(u<=2047){if(outIdx+1>=endIdx)break;outU8Array[outIdx++]=192|u>>6;outU8Array[outIdx++]=128|u&63}else if(u<=65535){if(outIdx+2>=endIdx)break;outU8Array[outIdx++]=224|u>>12;outU8Array[outIdx++]=128|u>>6&63;outU8Array[outIdx++]=128|u&63}else{if(outIdx+3>=endIdx)break;if(u>=2097152)warnOnce("Invalid Unicode code point 0x"+u.toString(16)+" encountered when serializing a JS string to an UTF-8 string on the asm.js/wasm heap! (Valid unicode code points should be in range 0-0x1FFFFF).");outU8Array[outIdx++]=240|u>>18;outU8Array[outIdx++]=128|u>>12&63;outU8Array[outIdx++]=128|u>>6&63;outU8Array[outIdx++]=128|u&63}}outU8Array[outIdx]=0;return outIdx-startIdx}function stringToUTF8(str,outPtr,maxBytesToWrite){assert(typeof maxBytesToWrite=="number","stringToUTF8(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");return stringToUTF8Array(str,HEAPU8,outPtr,maxBytesToWrite)}function lengthBytesUTF8(str){var len=0;for(var i=0;i<str.length;++i){var u=str.charCodeAt(i);if(u>=55296&&u<=57343)u=65536+((u&1023)<<10)|str.charCodeAt(++i)&1023;if(u<=127)++len;else if(u<=2047)len+=2;else if(u<=65535)len+=3;else len+=4}return len}var UTF16Decoder=typeof TextDecoder!=="undefined"?new TextDecoder("utf-16le"):undefined;function writeArrayToMemory(array,buffer){assert(array.length>=0,"writeArrayToMemory array must have a length (should be an array or typed array)");HEAP8.set(array,buffer)}var WASM_PAGE_SIZE=65536;function alignUp(x,multiple){if(x%multiple>0){x+=multiple-x%multiple}return x}var buffer,HEAP8,HEAPU8,HEAP16,HEAPU16,HEAP32,HEAPU32,HEAPF32,HEAPF64;function updateGlobalBufferAndViews(buf){buffer=buf;Module["HEAP8"]=HEAP8=new Int8Array(buf);Module["HEAP16"]=HEAP16=new Int16Array(buf);Module["HEAP32"]=HEAP32=new Int32Array(buf);Module["HEAPU8"]=HEAPU8=new Uint8Array(buf);Module["HEAPU16"]=HEAPU16=new Uint16Array(buf);Module["HEAPU32"]=HEAPU32=new Uint32Array(buf);Module["HEAPF32"]=HEAPF32=new Float32Array(buf);Module["HEAPF64"]=HEAPF64=new Float64Array(buf)}var STACK_BASE=434112,STACK_MAX=5676992,DYNAMIC_BASE=5676992,DYNAMICTOP_PTR=433920;assert(STACK_BASE%16===0,"stack must start aligned");assert(DYNAMIC_BASE%16===0,"heap must start aligned");var TOTAL_STACK=5242880;if(Module["TOTAL_STACK"])assert(TOTAL_STACK===Module["TOTAL_STACK"],"the stack size can no longer be determined at runtime");var INITIAL_TOTAL_MEMORY=Module["TOTAL_MEMORY"]||16777216;if(!Object.getOwnPropertyDescriptor(Module,"TOTAL_MEMORY"))Object.defineProperty(Module,"TOTAL_MEMORY",{configurable:true,get:function(){abort("Module.TOTAL_MEMORY has been replaced with plain INITIAL_TOTAL_MEMORY")}});assert(INITIAL_TOTAL_MEMORY>=TOTAL_STACK,"TOTAL_MEMORY should be larger than TOTAL_STACK, was "+INITIAL_TOTAL_MEMORY+"! (TOTAL_STACK="+TOTAL_STACK+")");assert(typeof Int32Array!=="undefined"&&typeof Float64Array!=="undefined"&&Int32Array.prototype.subarray!==undefined&&Int32Array.prototype.set!==undefined,"JS engine does not provide full typed array support");if(Module["wasmMemory"]){wasmMemory=Module["wasmMemory"]}else{wasmMemory=new WebAssembly.Memory({"initial":INITIAL_TOTAL_MEMORY/WASM_PAGE_SIZE})}if(wasmMemory){buffer=wasmMemory.buffer}INITIAL_TOTAL_MEMORY=buffer.byteLength;assert(INITIAL_TOTAL_MEMORY%WASM_PAGE_SIZE===0);updateGlobalBufferAndViews(buffer);HEAP32[DYNAMICTOP_PTR>>2]=DYNAMIC_BASE;function writeStackCookie(){assert((STACK_MAX&3)==0);HEAPU32[(STACK_MAX>>2)-1]=34821223;HEAPU32[(STACK_MAX>>2)-2]=2310721022;HEAP32[0]=1668509029}function checkStackCookie(){var cookie1=HEAPU32[(STACK_MAX>>2)-1];var cookie2=HEAPU32[(STACK_MAX>>2)-2];if(cookie1!=34821223||cookie2!=2310721022){abort("Stack overflow! Stack cookie has been overwritten, expected hex dwords 0x89BACDFE and 0x02135467, but received 0x"+cookie2.toString(16)+" "+cookie1.toString(16))}if(HEAP32[0]!==1668509029)abort("Runtime error: The application has corrupted its heap memory area (address zero)!")}function abortStackOverflow(allocSize){abort("Stack overflow! Attempted to allocate "+allocSize+" bytes on the stack, but stack has only "+(STACK_MAX-stackSave()+allocSize)+" bytes available!")}(function(){var h16=new Int16Array(1);var h8=new Int8Array(h16.buffer);h16[0]=25459;if(h8[0]!==115||h8[1]!==99)throw"Runtime error: expected the system to be little-endian!"})();function abortFnPtrError(ptr,sig){abort("Invalid function pointer "+ptr+" called with signature '"+sig+"'. Perhaps this is an invalid value (e.g. caused by calling a virtual method on a NULL pointer)? Or calling a function with an incorrect type, which will fail? (it is worth building your source files with -Werror (warnings are errors), as warnings can indicate undefined behavior which can cause this). Build with ASSERTIONS=2 for more info.")}function callRuntimeCallbacks(callbacks){while(callbacks.length>0){var callback=callbacks.shift();if(typeof callback=="function"){callback();continue}var func=callback.func;if(typeof func==="number"){if(callback.arg===undefined){Module["dynCall_v"](func)}else{Module["dynCall_vi"](func,callback.arg)}}else{func(callback.arg===undefined?null:callback.arg)}}}var __ATPRERUN__=[];var __ATINIT__=[];var __ATMAIN__=[];var __ATPOSTRUN__=[];var runtimeInitialized=false;var runtimeExited=false;function preRun(){if(Module["preRun"]){if(typeof Module["preRun"]=="function")Module["preRun"]=[Module["preRun"]];while(Module["preRun"].length){addOnPreRun(Module["preRun"].shift())}}callRuntimeCallbacks(__ATPRERUN__)}function initRuntime(){checkStackCookie();assert(!runtimeInitialized);runtimeInitialized=true;callRuntimeCallbacks(__ATINIT__)}function preMain(){checkStackCookie();callRuntimeCallbacks(__ATMAIN__)}function exitRuntime(){checkStackCookie();runtimeExited=true}function postRun(){checkStackCookie();if(Module["postRun"]){if(typeof Module["postRun"]=="function")Module["postRun"]=[Module["postRun"]];while(Module["postRun"].length){addOnPostRun(Module["postRun"].shift())}}callRuntimeCallbacks(__ATPOSTRUN__)}function addOnPreRun(cb){__ATPRERUN__.unshift(cb)}function addOnPostRun(cb){__ATPOSTRUN__.unshift(cb)}assert(Math.imul,"This browser does not support Math.imul(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");assert(Math.fround,"This browser does not support Math.fround(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");assert(Math.clz32,"This browser does not support Math.clz32(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");assert(Math.trunc,"This browser does not support Math.trunc(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");var runDependencies=0;var runDependencyWatcher=null;var dependenciesFulfilled=null;var runDependencyTracking={};function addRunDependency(id){runDependencies++;if(Module["monitorRunDependencies"]){Module["monitorRunDependencies"](runDependencies)}if(id){assert(!runDependencyTracking[id]);runDependencyTracking[id]=1;if(runDependencyWatcher===null&&typeof setInterval!=="undefined"){runDependencyWatcher=setInterval(function(){if(ABORT){clearInterval(runDependencyWatcher);runDependencyWatcher=null;return}var shown=false;for(var dep in runDependencyTracking){if(!shown){shown=true;err("still waiting on run dependencies:")}err("dependency: "+dep)}if(shown){err("(end of list)")}},1e4)}}else{err("warning: run dependency added without ID")}}function removeRunDependency(id){runDependencies--;if(Module["monitorRunDependencies"]){Module["monitorRunDependencies"](runDependencies)}if(id){assert(runDependencyTracking[id]);delete runDependencyTracking[id]}else{err("warning: run dependency removed without ID")}if(runDependencies==0){if(runDependencyWatcher!==null){clearInterval(runDependencyWatcher);runDependencyWatcher=null}if(dependenciesFulfilled){var callback=dependenciesFulfilled;dependenciesFulfilled=null;callback()}}}Module["preloadedImages"]={};Module["preloadedAudios"]={};function abort(what){if(Module["onAbort"]){Module["onAbort"](what)}what+="";out(what);err(what);ABORT=true;EXITSTATUS=1;var extra="";var output="abort("+what+") at "+stackTrace()+extra;throw output}var FS={error:function(){abort("Filesystem support (FS) was not included. The problem is that you are using files from JS, but files were not used from C/C++, so filesystem support was not auto-included. You can force-include filesystem support with  -s FORCE_FILESYSTEM=1")},init:function(){FS.error()},createDataFile:function(){FS.error()},createPreloadedFile:function(){FS.error()},createLazyFile:function(){FS.error()},open:function(){FS.error()},mkdev:function(){FS.error()},registerDevice:function(){FS.error()},analyzePath:function(){FS.error()},loadFilesFromDB:function(){FS.error()},ErrnoError:function ErrnoError(){FS.error()}};Module["FS_createDataFile"]=FS.createDataFile;Module["FS_createPreloadedFile"]=FS.createPreloadedFile;var dataURIPrefix="data:application/octet-stream;base64,";function isDataURI(filename){return String.prototype.startsWith?filename.startsWith(dataURIPrefix):filename.indexOf(dataURIPrefix)===0}var wasmBinaryFile="woff2.wasm";if(!isDataURI(wasmBinaryFile)){wasmBinaryFile=locateFile(wasmBinaryFile)}function getBinary(){try{if(wasmBinary){return new Uint8Array(wasmBinary)}if(readBinary){return readBinary(wasmBinaryFile)}else{throw"both async and sync fetching of the wasm failed"}}catch(err){abort(err)}}function getBinaryPromise(){if(!wasmBinary&&(ENVIRONMENT_IS_WEB||ENVIRONMENT_IS_WORKER)&&typeof fetch==="function"){return fetch(wasmBinaryFile,{credentials:"same-origin"}).then(function(response){if(!response["ok"]){throw"failed to load wasm binary file at '"+wasmBinaryFile+"'"}return response["arrayBuffer"]()}).catch(function(){return getBinary()})}return new Promise(function(resolve,reject){resolve(getBinary())})}function createWasm(){var info={"env":asmLibraryArg,"wasi_unstable":asmLibraryArg,"global":{"NaN":NaN,Infinity:Infinity},"global.Math":Math,"asm2wasm":asm2wasmImports};function receiveInstance(instance,module){var exports=instance.exports;Module["asm"]=exports;removeRunDependency("wasm-instantiate")}addRunDependency("wasm-instantiate");var trueModule=Module;function receiveInstantiatedSource(output){assert(Module===trueModule,"the Module object should not be replaced during async compilation - perhaps the order of HTML elements is wrong?");trueModule=null;receiveInstance(output["instance"])}function instantiateArrayBuffer(receiver){return getBinaryPromise().then(function(binary){return WebAssembly.instantiate(binary,info)}).then(receiver,function(reason){err("failed to asynchronously prepare wasm: "+reason);abort(reason)})}function instantiateAsync(){if(!wasmBinary&&typeof WebAssembly.instantiateStreaming==="function"&&!isDataURI(wasmBinaryFile)&&typeof fetch==="function"){fetch(wasmBinaryFile,{credentials:"same-origin"}).then(function(response){var result=WebAssembly.instantiateStreaming(response,info);return result.then(receiveInstantiatedSource,function(reason){err("wasm streaming compile failed: "+reason);err("falling back to ArrayBuffer instantiation");instantiateArrayBuffer(receiveInstantiatedSource)})})}else{return instantiateArrayBuffer(receiveInstantiatedSource)}}if(Module["instantiateWasm"]){try{var exports=Module["instantiateWasm"](info,receiveInstance);return exports}catch(e){err("Module.instantiateWasm callback failed with error: "+e);return false}}instantiateAsync();return{}}Module["asm"]=createWasm;__ATINIT__.push({func:function(){globalCtors()}});var tempDoublePtr=434096;assert(tempDoublePtr%8==0);function demangle(func){var __cxa_demangle_func=Module["___cxa_demangle"]||Module["__cxa_demangle"];assert(__cxa_demangle_func);try{var s=func;if(s.startsWith("__Z"))s=s.substr(1);var len=lengthBytesUTF8(s)+1;var buf=_malloc(len);stringToUTF8(s,buf,len);var status=_malloc(4);var ret=__cxa_demangle_func(buf,0,0,status);if(HEAP32[status>>2]===0&&ret){return UTF8ToString(ret)}}catch(e){}finally{if(buf)_free(buf);if(status)_free(status);if(ret)_free(ret)}return func}function demangleAll(text){var regex=/\b__Z[\w\d_]+/g;return text.replace(regex,function(x){var y=demangle(x);return x===y?x:y+" ["+x+"]"})}function jsStackTrace(){var err=new Error;if(!err.stack){try{throw new Error(0)}catch(e){err=e}if(!err.stack){return"(no stack trace available)"}}return err.stack.toString()}function stackTrace(){var js=jsStackTrace();if(Module["extraStackTrace"])js+="\n"+Module["extraStackTrace"]();return demangleAll(js)}function ___assert_fail(condition,filename,line,func){abort("Assertion failed: "+UTF8ToString(condition)+", at: "+[filename?UTF8ToString(filename):"unknown filename",line,func?UTF8ToString(func):"unknown function"])}function ___cxa_allocate_exception(size){return _malloc(size)}var ___exception_infos={};var ___exception_last=0;function ___cxa_throw(ptr,type,destructor){___exception_infos[ptr]={ptr:ptr,adjusted:[ptr],type:type,destructor:destructor,refcount:0,caught:false,rethrown:false};___exception_last=ptr;if(!("uncaught_exception"in __ZSt18uncaught_exceptionv)){__ZSt18uncaught_exceptionv.uncaught_exceptions=1}else{__ZSt18uncaught_exceptionv.uncaught_exceptions++}throw ptr+" - Exception catching is disabled, this exception cannot be caught. Compile with -s DISABLE_EXCEPTION_CATCHING=0 or DISABLE_EXCEPTION_CATCHING=2 to catch."}function ___lock(){}function ___unlock(){}var PATH={splitPath:function(filename){var splitPathRe=/^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;return splitPathRe.exec(filename).slice(1)},normalizeArray:function(parts,allowAboveRoot){var up=0;for(var i=parts.length-1;i>=0;i--){var last=parts[i];if(last==="."){parts.splice(i,1)}else if(last===".."){parts.splice(i,1);up++}else if(up){parts.splice(i,1);up--}}if(allowAboveRoot){for(;up;up--){parts.unshift("..")}}return parts},normalize:function(path){var isAbsolute=path.charAt(0)==="/",trailingSlash=path.substr(-1)==="/";path=PATH.normalizeArray(path.split("/").filter(function(p){return!!p}),!isAbsolute).join("/");if(!path&&!isAbsolute){path="."}if(path&&trailingSlash){path+="/"}return(isAbsolute?"/":"")+path},dirname:function(path){var result=PATH.splitPath(path),root=result[0],dir=result[1];if(!root&&!dir){return"."}if(dir){dir=dir.substr(0,dir.length-1)}return root+dir},basename:function(path){if(path==="/")return"/";var lastSlash=path.lastIndexOf("/");if(lastSlash===-1)return path;return path.substr(lastSlash+1)},extname:function(path){return PATH.splitPath(path)[3]},join:function(){var paths=Array.prototype.slice.call(arguments,0);return PATH.normalize(paths.join("/"))},join2:function(l,r){return PATH.normalize(l+"/"+r)}};var SYSCALLS={buffers:[null,[],[]],printChar:function(stream,curr){var buffer=SYSCALLS.buffers[stream];assert(buffer);if(curr===0||curr===10){(stream===1?out:err)(UTF8ArrayToString(buffer,0));buffer.length=0}else{buffer.push(curr)}},varargs:0,get:function(varargs){SYSCALLS.varargs+=4;var ret=HEAP32[SYSCALLS.varargs-4>>2];return ret},getStr:function(){var ret=UTF8ToString(SYSCALLS.get());return ret},get64:function(){var low=SYSCALLS.get(),high=SYSCALLS.get();if(low>=0)assert(high===0);else assert(high===-1);return low},getZero:function(){assert(SYSCALLS.get()===0)}};function _fd_close(fd){try{abort("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");return 0}catch(e){if(typeof FS==="undefined"||!(e instanceof FS.ErrnoError))abort(e);return e.errno}}function ___wasi_fd_close(){return _fd_close.apply(null,arguments)}function _fd_seek(fd,offset_low,offset_high,whence,newOffset){try{abort("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");return 0}catch(e){if(typeof FS==="undefined"||!(e instanceof FS.ErrnoError))abort(e);return e.errno}}function ___wasi_fd_seek(){return _fd_seek.apply(null,arguments)}function flush_NO_FILESYSTEM(){var fflush=Module["_fflush"];if(fflush)fflush(0);var buffers=SYSCALLS.buffers;if(buffers[1].length)SYSCALLS.printChar(1,10);if(buffers[2].length)SYSCALLS.printChar(2,10)}function _fd_write(fd,iov,iovcnt,pnum){try{var num=0;for(var i=0;i<iovcnt;i++){var ptr=HEAP32[iov+i*8>>2];var len=HEAP32[iov+(i*8+4)>>2];for(var j=0;j<len;j++){SYSCALLS.printChar(fd,HEAPU8[ptr+j])}num+=len}HEAP32[pnum>>2]=num;return 0}catch(e){if(typeof FS==="undefined"||!(e instanceof FS.ErrnoError))abort(e);return e.errno}}function ___wasi_fd_write(){return _fd_write.apply(null,arguments)}function getShiftFromSize(size){switch(size){case 1:return 0;case 2:return 1;case 4:return 2;case 8:return 3;default:throw new TypeError("Unknown type size: "+size)}}function embind_init_charCodes(){var codes=new Array(256);for(var i=0;i<256;++i){codes[i]=String.fromCharCode(i)}embind_charCodes=codes}var embind_charCodes=undefined;function readLatin1String(ptr){var ret="";var c=ptr;while(HEAPU8[c]){ret+=embind_charCodes[HEAPU8[c++]]}return ret}var awaitingDependencies={};var registeredTypes={};var typeDependencies={};var char_0=48;var char_9=57;function makeLegalFunctionName(name){if(undefined===name){return"_unknown"}name=name.replace(/[^a-zA-Z0-9_]/g,"$");var f=name.charCodeAt(0);if(f>=char_0&&f<=char_9){return"_"+name}else{return name}}function createNamedFunction(name,body){name=makeLegalFunctionName(name);return new Function("body","return function "+name+"() {\n"+'    "use strict";'+"    return body.apply(this, arguments);\n"+"};\n")(body)}function extendError(baseErrorType,errorName){var errorClass=createNamedFunction(errorName,function(message){this.name=errorName;this.message=message;var stack=new Error(message).stack;if(stack!==undefined){this.stack=this.toString()+"\n"+stack.replace(/^Error(:[^\n]*)?\n/,"")}});errorClass.prototype=Object.create(baseErrorType.prototype);errorClass.prototype.constructor=errorClass;errorClass.prototype.toString=function(){if(this.message===undefined){return this.name}else{return this.name+": "+this.message}};return errorClass}var BindingError=undefined;function throwBindingError(message){throw new BindingError(message)}var InternalError=undefined;function throwInternalError(message){throw new InternalError(message)}function whenDependentTypesAreResolved(myTypes,dependentTypes,getTypeConverters){myTypes.forEach(function(type){typeDependencies[type]=dependentTypes});function onComplete(typeConverters){var myTypeConverters=getTypeConverters(typeConverters);if(myTypeConverters.length!==myTypes.length){throwInternalError("Mismatched type converter count")}for(var i=0;i<myTypes.length;++i){registerType(myTypes[i],myTypeConverters[i])}}var typeConverters=new Array(dependentTypes.length);var unregisteredTypes=[];var registered=0;dependentTypes.forEach(function(dt,i){if(registeredTypes.hasOwnProperty(dt)){typeConverters[i]=registeredTypes[dt]}else{unregisteredTypes.push(dt);if(!awaitingDependencies.hasOwnProperty(dt)){awaitingDependencies[dt]=[]}awaitingDependencies[dt].push(function(){typeConverters[i]=registeredTypes[dt];++registered;if(registered===unregisteredTypes.length){onComplete(typeConverters)}})}});if(0===unregisteredTypes.length){onComplete(typeConverters)}}function registerType(rawType,registeredInstance,options){options=options||{};if(!("argPackAdvance"in registeredInstance)){throw new TypeError("registerType registeredInstance requires argPackAdvance")}var name=registeredInstance.name;if(!rawType){throwBindingError('type "'+name+'" must have a positive integer typeid pointer')}if(registeredTypes.hasOwnProperty(rawType)){if(options.ignoreDuplicateRegistrations){return}else{throwBindingError("Cannot register type '"+name+"' twice")}}registeredTypes[rawType]=registeredInstance;delete typeDependencies[rawType];if(awaitingDependencies.hasOwnProperty(rawType)){var callbacks=awaitingDependencies[rawType];delete awaitingDependencies[rawType];callbacks.forEach(function(cb){cb()})}}function __embind_register_bool(rawType,name,size,trueValue,falseValue){var shift=getShiftFromSize(size);name=readLatin1String(name);registerType(rawType,{name:name,"fromWireType":function(wt){return!!wt},"toWireType":function(destructors,o){return o?trueValue:falseValue},"argPackAdvance":8,"readValueFromPointer":function(pointer){var heap;if(size===1){heap=HEAP8}else if(size===2){heap=HEAP16}else if(size===4){heap=HEAP32}else{throw new TypeError("Unknown boolean type size: "+name)}return this["fromWireType"](heap[pointer>>shift])},destructorFunction:null})}function ClassHandle_isAliasOf(other){if(!(this instanceof ClassHandle)){return false}if(!(other instanceof ClassHandle)){return false}var leftClass=this.$$.ptrType.registeredClass;var left=this.$$.ptr;var rightClass=other.$$.ptrType.registeredClass;var right=other.$$.ptr;while(leftClass.baseClass){left=leftClass.upcast(left);leftClass=leftClass.baseClass}while(rightClass.baseClass){right=rightClass.upcast(right);rightClass=rightClass.baseClass}return leftClass===rightClass&&left===right}function shallowCopyInternalPointer(o){return{count:o.count,deleteScheduled:o.deleteScheduled,preservePointerOnDelete:o.preservePointerOnDelete,ptr:o.ptr,ptrType:o.ptrType,smartPtr:o.smartPtr,smartPtrType:o.smartPtrType}}function throwInstanceAlreadyDeleted(obj){function getInstanceTypeName(handle){return handle.$$.ptrType.registeredClass.name}throwBindingError(getInstanceTypeName(obj)+" instance already deleted")}var finalizationGroup=false;function detachFinalizer(handle){}function runDestructor($$){if($$.smartPtr){$$.smartPtrType.rawDestructor($$.smartPtr)}else{$$.ptrType.registeredClass.rawDestructor($$.ptr)}}function releaseClassHandle($$){$$.count.value-=1;var toDelete=0===$$.count.value;if(toDelete){runDestructor($$)}}function attachFinalizer(handle){if("undefined"===typeof FinalizationGroup){attachFinalizer=function(handle){return handle};return handle}finalizationGroup=new FinalizationGroup(function(iter){for(var result=iter.next();!result.done;result=iter.next()){var $$=result.value;if(!$$.ptr){console.warn("object already deleted: "+$$.ptr)}else{releaseClassHandle($$)}}});attachFinalizer=function(handle){finalizationGroup.register(handle,handle.$$,handle.$$);return handle};detachFinalizer=function(handle){finalizationGroup.unregister(handle.$$)};return attachFinalizer(handle)}function ClassHandle_clone(){if(!this.$$.ptr){throwInstanceAlreadyDeleted(this)}if(this.$$.preservePointerOnDelete){this.$$.count.value+=1;return this}else{var clone=attachFinalizer(Object.create(Object.getPrototypeOf(this),{$$:{value:shallowCopyInternalPointer(this.$$)}}));clone.$$.count.value+=1;clone.$$.deleteScheduled=false;return clone}}function ClassHandle_delete(){if(!this.$$.ptr){throwInstanceAlreadyDeleted(this)}if(this.$$.deleteScheduled&&!this.$$.preservePointerOnDelete){throwBindingError("Object already scheduled for deletion")}detachFinalizer(this);releaseClassHandle(this.$$);if(!this.$$.preservePointerOnDelete){this.$$.smartPtr=undefined;this.$$.ptr=undefined}}function ClassHandle_isDeleted(){return!this.$$.ptr}var delayFunction=undefined;var deletionQueue=[];function flushPendingDeletes(){while(deletionQueue.length){var obj=deletionQueue.pop();obj.$$.deleteScheduled=false;obj["delete"]()}}function ClassHandle_deleteLater(){if(!this.$$.ptr){throwInstanceAlreadyDeleted(this)}if(this.$$.deleteScheduled&&!this.$$.preservePointerOnDelete){throwBindingError("Object already scheduled for deletion")}deletionQueue.push(this);if(deletionQueue.length===1&&delayFunction){delayFunction(flushPendingDeletes)}this.$$.deleteScheduled=true;return this}function init_ClassHandle(){ClassHandle.prototype["isAliasOf"]=ClassHandle_isAliasOf;ClassHandle.prototype["clone"]=ClassHandle_clone;ClassHandle.prototype["delete"]=ClassHandle_delete;ClassHandle.prototype["isDeleted"]=ClassHandle_isDeleted;ClassHandle.prototype["deleteLater"]=ClassHandle_deleteLater}function ClassHandle(){}var registeredPointers={};function ensureOverloadTable(proto,methodName,humanName){if(undefined===proto[methodName].overloadTable){var prevFunc=proto[methodName];proto[methodName]=function(){if(!proto[methodName].overloadTable.hasOwnProperty(arguments.length)){throwBindingError("Function '"+humanName+"' called with an invalid number of arguments ("+arguments.length+") - expects one of ("+proto[methodName].overloadTable+")!")}return proto[methodName].overloadTable[arguments.length].apply(this,arguments)};proto[methodName].overloadTable=[];proto[methodName].overloadTable[prevFunc.argCount]=prevFunc}}function exposePublicSymbol(name,value,numArguments){if(Module.hasOwnProperty(name)){if(undefined===numArguments||undefined!==Module[name].overloadTable&&undefined!==Module[name].overloadTable[numArguments]){throwBindingError("Cannot register public name '"+name+"' twice")}ensureOverloadTable(Module,name,name);if(Module.hasOwnProperty(numArguments)){throwBindingError("Cannot register multiple overloads of a function with the same number of arguments ("+numArguments+")!")}Module[name].overloadTable[numArguments]=value}else{Module[name]=value;if(undefined!==numArguments){Module[name].numArguments=numArguments}}}function RegisteredClass(name,constructor,instancePrototype,rawDestructor,baseClass,getActualType,upcast,downcast){this.name=name;this.constructor=constructor;this.instancePrototype=instancePrototype;this.rawDestructor=rawDestructor;this.baseClass=baseClass;this.getActualType=getActualType;this.upcast=upcast;this.downcast=downcast;this.pureVirtualFunctions=[]}function upcastPointer(ptr,ptrClass,desiredClass){while(ptrClass!==desiredClass){if(!ptrClass.upcast){throwBindingError("Expected null or instance of "+desiredClass.name+", got an instance of "+ptrClass.name)}ptr=ptrClass.upcast(ptr);ptrClass=ptrClass.baseClass}return ptr}function constNoSmartPtrRawPointerToWireType(destructors,handle){if(handle===null){if(this.isReference){throwBindingError("null is not a valid "+this.name)}return 0}if(!handle.$$){throwBindingError('Cannot pass "'+_embind_repr(handle)+'" as a '+this.name)}if(!handle.$$.ptr){throwBindingError("Cannot pass deleted object as a pointer of type "+this.name)}var handleClass=handle.$$.ptrType.registeredClass;var ptr=upcastPointer(handle.$$.ptr,handleClass,this.registeredClass);return ptr}function genericPointerToWireType(destructors,handle){var ptr;if(handle===null){if(this.isReference){throwBindingError("null is not a valid "+this.name)}if(this.isSmartPointer){ptr=this.rawConstructor();if(destructors!==null){destructors.push(this.rawDestructor,ptr)}return ptr}else{return 0}}if(!handle.$$){throwBindingError('Cannot pass "'+_embind_repr(handle)+'" as a '+this.name)}if(!handle.$$.ptr){throwBindingError("Cannot pass deleted object as a pointer of type "+this.name)}if(!this.isConst&&handle.$$.ptrType.isConst){throwBindingError("Cannot convert argument of type "+(handle.$$.smartPtrType?handle.$$.smartPtrType.name:handle.$$.ptrType.name)+" to parameter type "+this.name)}var handleClass=handle.$$.ptrType.registeredClass;ptr=upcastPointer(handle.$$.ptr,handleClass,this.registeredClass);if(this.isSmartPointer){if(undefined===handle.$$.smartPtr){throwBindingError("Passing raw pointer to smart pointer is illegal")}switch(this.sharingPolicy){case 0:if(handle.$$.smartPtrType===this){ptr=handle.$$.smartPtr}else{throwBindingError("Cannot convert argument of type "+(handle.$$.smartPtrType?handle.$$.smartPtrType.name:handle.$$.ptrType.name)+" to parameter type "+this.name)}break;case 1:ptr=handle.$$.smartPtr;break;case 2:if(handle.$$.smartPtrType===this){ptr=handle.$$.smartPtr}else{var clonedHandle=handle["clone"]();ptr=this.rawShare(ptr,__emval_register(function(){clonedHandle["delete"]()}));if(destructors!==null){destructors.push(this.rawDestructor,ptr)}}break;default:throwBindingError("Unsupporting sharing policy")}}return ptr}function nonConstNoSmartPtrRawPointerToWireType(destructors,handle){if(handle===null){if(this.isReference){throwBindingError("null is not a valid "+this.name)}return 0}if(!handle.$$){throwBindingError('Cannot pass "'+_embind_repr(handle)+'" as a '+this.name)}if(!handle.$$.ptr){throwBindingError("Cannot pass deleted object as a pointer of type "+this.name)}if(handle.$$.ptrType.isConst){throwBindingError("Cannot convert argument of type "+handle.$$.ptrType.name+" to parameter type "+this.name)}var handleClass=handle.$$.ptrType.registeredClass;var ptr=upcastPointer(handle.$$.ptr,handleClass,this.registeredClass);return ptr}function simpleReadValueFromPointer(pointer){return this["fromWireType"](HEAPU32[pointer>>2])}function RegisteredPointer_getPointee(ptr){if(this.rawGetPointee){ptr=this.rawGetPointee(ptr)}return ptr}function RegisteredPointer_destructor(ptr){if(this.rawDestructor){this.rawDestructor(ptr)}}function RegisteredPointer_deleteObject(handle){if(handle!==null){handle["delete"]()}}function downcastPointer(ptr,ptrClass,desiredClass){if(ptrClass===desiredClass){return ptr}if(undefined===desiredClass.baseClass){return null}var rv=downcastPointer(ptr,ptrClass,desiredClass.baseClass);if(rv===null){return null}return desiredClass.downcast(rv)}function getInheritedInstanceCount(){return Object.keys(registeredInstances).length}function getLiveInheritedInstances(){var rv=[];for(var k in registeredInstances){if(registeredInstances.hasOwnProperty(k)){rv.push(registeredInstances[k])}}return rv}function setDelayFunction(fn){delayFunction=fn;if(deletionQueue.length&&delayFunction){delayFunction(flushPendingDeletes)}}function init_embind(){Module["getInheritedInstanceCount"]=getInheritedInstanceCount;Module["getLiveInheritedInstances"]=getLiveInheritedInstances;Module["flushPendingDeletes"]=flushPendingDeletes;Module["setDelayFunction"]=setDelayFunction}var registeredInstances={};function getBasestPointer(class_,ptr){if(ptr===undefined){throwBindingError("ptr should not be undefined")}while(class_.baseClass){ptr=class_.upcast(ptr);class_=class_.baseClass}return ptr}function getInheritedInstance(class_,ptr){ptr=getBasestPointer(class_,ptr);return registeredInstances[ptr]}function makeClassHandle(prototype,record){if(!record.ptrType||!record.ptr){throwInternalError("makeClassHandle requires ptr and ptrType")}var hasSmartPtrType=!!record.smartPtrType;var hasSmartPtr=!!record.smartPtr;if(hasSmartPtrType!==hasSmartPtr){throwInternalError("Both smartPtrType and smartPtr must be specified")}record.count={value:1};return attachFinalizer(Object.create(prototype,{$$:{value:record}}))}function RegisteredPointer_fromWireType(ptr){var rawPointer=this.getPointee(ptr);if(!rawPointer){this.destructor(ptr);return null}var registeredInstance=getInheritedInstance(this.registeredClass,rawPointer);if(undefined!==registeredInstance){if(0===registeredInstance.$$.count.value){registeredInstance.$$.ptr=rawPointer;registeredInstance.$$.smartPtr=ptr;return registeredInstance["clone"]()}else{var rv=registeredInstance["clone"]();this.destructor(ptr);return rv}}function makeDefaultHandle(){if(this.isSmartPointer){return makeClassHandle(this.registeredClass.instancePrototype,{ptrType:this.pointeeType,ptr:rawPointer,smartPtrType:this,smartPtr:ptr})}else{return makeClassHandle(this.registeredClass.instancePrototype,{ptrType:this,ptr:ptr})}}var actualType=this.registeredClass.getActualType(rawPointer);var registeredPointerRecord=registeredPointers[actualType];if(!registeredPointerRecord){return makeDefaultHandle.call(this)}var toType;if(this.isConst){toType=registeredPointerRecord.constPointerType}else{toType=registeredPointerRecord.pointerType}var dp=downcastPointer(rawPointer,this.registeredClass,toType.registeredClass);if(dp===null){return makeDefaultHandle.call(this)}if(this.isSmartPointer){return makeClassHandle(toType.registeredClass.instancePrototype,{ptrType:toType,ptr:dp,smartPtrType:this,smartPtr:ptr})}else{return makeClassHandle(toType.registeredClass.instancePrototype,{ptrType:toType,ptr:dp})}}function init_RegisteredPointer(){RegisteredPointer.prototype.getPointee=RegisteredPointer_getPointee;RegisteredPointer.prototype.destructor=RegisteredPointer_destructor;RegisteredPointer.prototype["argPackAdvance"]=8;RegisteredPointer.prototype["readValueFromPointer"]=simpleReadValueFromPointer;RegisteredPointer.prototype["deleteObject"]=RegisteredPointer_deleteObject;RegisteredPointer.prototype["fromWireType"]=RegisteredPointer_fromWireType}function RegisteredPointer(name,registeredClass,isReference,isConst,isSmartPointer,pointeeType,sharingPolicy,rawGetPointee,rawConstructor,rawShare,rawDestructor){this.name=name;this.registeredClass=registeredClass;this.isReference=isReference;this.isConst=isConst;this.isSmartPointer=isSmartPointer;this.pointeeType=pointeeType;this.sharingPolicy=sharingPolicy;this.rawGetPointee=rawGetPointee;this.rawConstructor=rawConstructor;this.rawShare=rawShare;this.rawDestructor=rawDestructor;if(!isSmartPointer&&registeredClass.baseClass===undefined){if(isConst){this["toWireType"]=constNoSmartPtrRawPointerToWireType;this.destructorFunction=null}else{this["toWireType"]=nonConstNoSmartPtrRawPointerToWireType;this.destructorFunction=null}}else{this["toWireType"]=genericPointerToWireType}}function replacePublicSymbol(name,value,numArguments){if(!Module.hasOwnProperty(name)){throwInternalError("Replacing nonexistant public symbol")}if(undefined!==Module[name].overloadTable&&undefined!==numArguments){Module[name].overloadTable[numArguments]=value}else{Module[name]=value;Module[name].argCount=numArguments}}function embind__requireFunction(signature,rawFunction){signature=readLatin1String(signature);function makeDynCaller(dynCall){var args=[];for(var i=1;i<signature.length;++i){args.push("a"+i)}var name="dynCall_"+signature+"_"+rawFunction;var body="return function "+name+"("+args.join(", ")+") {\n";body+="    return dynCall(rawFunction"+(args.length?", ":"")+args.join(", ")+");\n";body+="};\n";return new Function("dynCall","rawFunction",body)(dynCall,rawFunction)}var fp;if(Module["FUNCTION_TABLE_"+signature]!==undefined){fp=Module["FUNCTION_TABLE_"+signature][rawFunction]}else if(typeof FUNCTION_TABLE!=="undefined"){fp=FUNCTION_TABLE[rawFunction]}else{var dc=Module["dynCall_"+signature];if(dc===undefined){dc=Module["dynCall_"+signature.replace(/f/g,"d")];if(dc===undefined){throwBindingError("No dynCall invoker for signature: "+signature)}}fp=makeDynCaller(dc)}if(typeof fp!=="function"){throwBindingError("unknown function pointer with signature "+signature+": "+rawFunction)}return fp}var UnboundTypeError=undefined;function getTypeName(type){var ptr=___getTypeName(type);var rv=readLatin1String(ptr);_free(ptr);return rv}function throwUnboundTypeError(message,types){var unboundTypes=[];var seen={};function visit(type){if(seen[type]){return}if(registeredTypes[type]){return}if(typeDependencies[type]){typeDependencies[type].forEach(visit);return}unboundTypes.push(type);seen[type]=true}types.forEach(visit);throw new UnboundTypeError(message+": "+unboundTypes.map(getTypeName).join([", "]))}function __embind_register_class(rawType,rawPointerType,rawConstPointerType,baseClassRawType,getActualTypeSignature,getActualType,upcastSignature,upcast,downcastSignature,downcast,name,destructorSignature,rawDestructor){name=readLatin1String(name);getActualType=embind__requireFunction(getActualTypeSignature,getActualType);if(upcast){upcast=embind__requireFunction(upcastSignature,upcast)}if(downcast){downcast=embind__requireFunction(downcastSignature,downcast)}rawDestructor=embind__requireFunction(destructorSignature,rawDestructor);var legalFunctionName=makeLegalFunctionName(name);exposePublicSymbol(legalFunctionName,function(){throwUnboundTypeError("Cannot construct "+name+" due to unbound types",[baseClassRawType])});whenDependentTypesAreResolved([rawType,rawPointerType,rawConstPointerType],baseClassRawType?[baseClassRawType]:[],function(base){base=base[0];var baseClass;var basePrototype;if(baseClassRawType){baseClass=base.registeredClass;basePrototype=baseClass.instancePrototype}else{basePrototype=ClassHandle.prototype}var constructor=createNamedFunction(legalFunctionName,function(){if(Object.getPrototypeOf(this)!==instancePrototype){throw new BindingError("Use 'new' to construct "+name)}if(undefined===registeredClass.constructor_body){throw new BindingError(name+" has no accessible constructor")}var body=registeredClass.constructor_body[arguments.length];if(undefined===body){throw new BindingError("Tried to invoke ctor of "+name+" with invalid number of parameters ("+arguments.length+") - expected ("+Object.keys(registeredClass.constructor_body).toString()+") parameters instead!")}return body.apply(this,arguments)});var instancePrototype=Object.create(basePrototype,{constructor:{value:constructor}});constructor.prototype=instancePrototype;var registeredClass=new RegisteredClass(name,constructor,instancePrototype,rawDestructor,baseClass,getActualType,upcast,downcast);var referenceConverter=new RegisteredPointer(name,registeredClass,true,false,false);var pointerConverter=new RegisteredPointer(name+"*",registeredClass,false,false,false);var constPointerConverter=new RegisteredPointer(name+" const*",registeredClass,false,true,false);registeredPointers[rawType]={pointerType:pointerConverter,constPointerType:constPointerConverter};replacePublicSymbol(legalFunctionName,constructor);return[referenceConverter,pointerConverter,constPointerConverter]})}function heap32VectorToArray(count,firstElement){var array=[];for(var i=0;i<count;i++){array.push(HEAP32[(firstElement>>2)+i])}return array}function runDestructors(destructors){while(destructors.length){var ptr=destructors.pop();var del=destructors.pop();del(ptr)}}function __embind_register_class_constructor(rawClassType,argCount,rawArgTypesAddr,invokerSignature,invoker,rawConstructor){var rawArgTypes=heap32VectorToArray(argCount,rawArgTypesAddr);invoker=embind__requireFunction(invokerSignature,invoker);whenDependentTypesAreResolved([],[rawClassType],function(classType){classType=classType[0];var humanName="constructor "+classType.name;if(undefined===classType.registeredClass.constructor_body){classType.registeredClass.constructor_body=[]}if(undefined!==classType.registeredClass.constructor_body[argCount-1]){throw new BindingError("Cannot register multiple constructors with identical number of parameters ("+(argCount-1)+") for class '"+classType.name+"'! Overload resolution is currently only performed using the parameter count, not actual type info!")}classType.registeredClass.constructor_body[argCount-1]=function unboundTypeHandler(){throwUnboundTypeError("Cannot construct "+classType.name+" due to unbound types",rawArgTypes)};whenDependentTypesAreResolved([],rawArgTypes,function(argTypes){classType.registeredClass.constructor_body[argCount-1]=function constructor_body(){if(arguments.length!==argCount-1){throwBindingError(humanName+" called with "+arguments.length+" arguments, expected "+(argCount-1))}var destructors=[];var args=new Array(argCount);args[0]=rawConstructor;for(var i=1;i<argCount;++i){args[i]=argTypes[i]["toWireType"](destructors,arguments[i-1])}var ptr=invoker.apply(null,args);runDestructors(destructors);return argTypes[0]["fromWireType"](ptr)};return[]});return[]})}function new_(constructor,argumentList){if(!(constructor instanceof Function)){throw new TypeError("new_ called with constructor type "+typeof constructor+" which is not a function")}var dummy=createNamedFunction(constructor.name||"unknownFunctionName",function(){});dummy.prototype=constructor.prototype;var obj=new dummy;var r=constructor.apply(obj,argumentList);return r instanceof Object?r:obj}function craftInvokerFunction(humanName,argTypes,classType,cppInvokerFunc,cppTargetFunc){var argCount=argTypes.length;if(argCount<2){throwBindingError("argTypes array size mismatch! Must at least get return value and 'this' types!")}var isClassMethodFunc=argTypes[1]!==null&&classType!==null;var needsDestructorStack=false;for(var i=1;i<argTypes.length;++i){if(argTypes[i]!==null&&argTypes[i].destructorFunction===undefined){needsDestructorStack=true;break}}var returns=argTypes[0].name!=="void";var argsList="";var argsListWired="";for(var i=0;i<argCount-2;++i){argsList+=(i!==0?", ":"")+"arg"+i;argsListWired+=(i!==0?", ":"")+"arg"+i+"Wired"}var invokerFnBody="return function "+makeLegalFunctionName(humanName)+"("+argsList+") {\n"+"if (arguments.length !== "+(argCount-2)+") {\n"+"throwBindingError('function "+humanName+" called with ' + arguments.length + ' arguments, expected "+(argCount-2)+" args!');\n"+"}\n";if(needsDestructorStack){invokerFnBody+="var destructors = [];\n"}var dtorStack=needsDestructorStack?"destructors":"null";var args1=["throwBindingError","invoker","fn","runDestructors","retType","classParam"];var args2=[throwBindingError,cppInvokerFunc,cppTargetFunc,runDestructors,argTypes[0],argTypes[1]];if(isClassMethodFunc){invokerFnBody+="var thisWired = classParam.toWireType("+dtorStack+", this);\n"}for(var i=0;i<argCount-2;++i){invokerFnBody+="var arg"+i+"Wired = argType"+i+".toWireType("+dtorStack+", arg"+i+"); // "+argTypes[i+2].name+"\n";args1.push("argType"+i);args2.push(argTypes[i+2])}if(isClassMethodFunc){argsListWired="thisWired"+(argsListWired.length>0?", ":"")+argsListWired}invokerFnBody+=(returns?"var rv = ":"")+"invoker(fn"+(argsListWired.length>0?", ":"")+argsListWired+");\n";if(needsDestructorStack){invokerFnBody+="runDestructors(destructors);\n"}else{for(var i=isClassMethodFunc?1:2;i<argTypes.length;++i){var paramName=i===1?"thisWired":"arg"+(i-2)+"Wired";if(argTypes[i].destructorFunction!==null){invokerFnBody+=paramName+"_dtor("+paramName+"); // "+argTypes[i].name+"\n";args1.push(paramName+"_dtor");args2.push(argTypes[i].destructorFunction)}}}if(returns){invokerFnBody+="var ret = retType.fromWireType(rv);\n"+"return ret;\n"}else{}invokerFnBody+="}\n";args1.push(invokerFnBody);var invokerFunction=new_(Function,args1).apply(null,args2);return invokerFunction}function __embind_register_class_function(rawClassType,methodName,argCount,rawArgTypesAddr,invokerSignature,rawInvoker,context,isPureVirtual){var rawArgTypes=heap32VectorToArray(argCount,rawArgTypesAddr);methodName=readLatin1String(methodName);rawInvoker=embind__requireFunction(invokerSignature,rawInvoker);whenDependentTypesAreResolved([],[rawClassType],function(classType){classType=classType[0];var humanName=classType.name+"."+methodName;if(isPureVirtual){classType.registeredClass.pureVirtualFunctions.push(methodName)}function unboundTypesHandler(){throwUnboundTypeError("Cannot call "+humanName+" due to unbound types",rawArgTypes)}var proto=classType.registeredClass.instancePrototype;var method=proto[methodName];if(undefined===method||undefined===method.overloadTable&&method.className!==classType.name&&method.argCount===argCount-2){unboundTypesHandler.argCount=argCount-2;unboundTypesHandler.className=classType.name;proto[methodName]=unboundTypesHandler}else{ensureOverloadTable(proto,methodName,humanName);proto[methodName].overloadTable[argCount-2]=unboundTypesHandler}whenDependentTypesAreResolved([],rawArgTypes,function(argTypes){var memberFunction=craftInvokerFunction(humanName,argTypes,classType,rawInvoker,context);if(undefined===proto[methodName].overloadTable){memberFunction.argCount=argCount-2;proto[methodName]=memberFunction}else{proto[methodName].overloadTable[argCount-2]=memberFunction}return[]});return[]})}var emval_free_list=[];var emval_handle_array=[{},{value:undefined},{value:null},{value:true},{value:false}];function __emval_decref(handle){if(handle>4&&0===--emval_handle_array[handle].refcount){emval_handle_array[handle]=undefined;emval_free_list.push(handle)}}function count_emval_handles(){var count=0;for(var i=5;i<emval_handle_array.length;++i){if(emval_handle_array[i]!==undefined){++count}}return count}function get_first_emval(){for(var i=5;i<emval_handle_array.length;++i){if(emval_handle_array[i]!==undefined){return emval_handle_array[i]}}return null}function init_emval(){Module["count_emval_handles"]=count_emval_handles;Module["get_first_emval"]=get_first_emval}function __emval_register(value){switch(value){case undefined:{return 1}case null:{return 2}case true:{return 3}case false:{return 4}default:{var handle=emval_free_list.length?emval_free_list.pop():emval_handle_array.length;emval_handle_array[handle]={refcount:1,value:value};return handle}}}function __embind_register_emval(rawType,name){name=readLatin1String(name);registerType(rawType,{name:name,"fromWireType":function(handle){var rv=emval_handle_array[handle].value;__emval_decref(handle);return rv},"toWireType":function(destructors,value){return __emval_register(value)},"argPackAdvance":8,"readValueFromPointer":simpleReadValueFromPointer,destructorFunction:null})}function _embind_repr(v){if(v===null){return"null"}var t=typeof v;if(t==="object"||t==="array"||t==="function"){return v.toString()}else{return""+v}}function floatReadValueFromPointer(name,shift){switch(shift){case 2:return function(pointer){return this["fromWireType"](HEAPF32[pointer>>2])};case 3:return function(pointer){return this["fromWireType"](HEAPF64[pointer>>3])};default:throw new TypeError("Unknown float type: "+name)}}function __embind_register_float(rawType,name,size){var shift=getShiftFromSize(size);name=readLatin1String(name);registerType(rawType,{name:name,"fromWireType":function(value){return value},"toWireType":function(destructors,value){if(typeof value!=="number"&&typeof value!=="boolean"){throw new TypeError('Cannot convert "'+_embind_repr(value)+'" to '+this.name)}return value},"argPackAdvance":8,"readValueFromPointer":floatReadValueFromPointer(name,shift),destructorFunction:null})}function __embind_register_function(name,argCount,rawArgTypesAddr,signature,rawInvoker,fn){var argTypes=heap32VectorToArray(argCount,rawArgTypesAddr);name=readLatin1String(name);rawInvoker=embind__requireFunction(signature,rawInvoker);exposePublicSymbol(name,function(){throwUnboundTypeError("Cannot call "+name+" due to unbound types",argTypes)},argCount-1);whenDependentTypesAreResolved([],argTypes,function(argTypes){var invokerArgsArray=[argTypes[0],null].concat(argTypes.slice(1));replacePublicSymbol(name,craftInvokerFunction(name,invokerArgsArray,null,rawInvoker,fn),argCount-1);return[]})}function integerReadValueFromPointer(name,shift,signed){switch(shift){case 0:return signed?function readS8FromPointer(pointer){return HEAP8[pointer]}:function readU8FromPointer(pointer){return HEAPU8[pointer]};case 1:return signed?function readS16FromPointer(pointer){return HEAP16[pointer>>1]}:function readU16FromPointer(pointer){return HEAPU16[pointer>>1]};case 2:return signed?function readS32FromPointer(pointer){return HEAP32[pointer>>2]}:function readU32FromPointer(pointer){return HEAPU32[pointer>>2]};default:throw new TypeError("Unknown integer type: "+name)}}function __embind_register_integer(primitiveType,name,size,minRange,maxRange){name=readLatin1String(name);if(maxRange===-1){maxRange=4294967295}var shift=getShiftFromSize(size);var fromWireType=function(value){return value};if(minRange===0){var bitshift=32-8*size;fromWireType=function(value){return value<<bitshift>>>bitshift}}var isUnsignedType=name.indexOf("unsigned")!=-1;registerType(primitiveType,{name:name,"fromWireType":fromWireType,"toWireType":function(destructors,value){if(typeof value!=="number"&&typeof value!=="boolean"){throw new TypeError('Cannot convert "'+_embind_repr(value)+'" to '+this.name)}if(value<minRange||value>maxRange){throw new TypeError('Passing a number "'+_embind_repr(value)+'" from JS side to C/C++ side to an argument of type "'+name+'", which is outside the valid range ['+minRange+", "+maxRange+"]!")}return isUnsignedType?value>>>0:value|0},"argPackAdvance":8,"readValueFromPointer":integerReadValueFromPointer(name,shift,minRange!==0),destructorFunction:null})}function __embind_register_memory_view(rawType,dataTypeIndex,name){var typeMapping=[Int8Array,Uint8Array,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array];var TA=typeMapping[dataTypeIndex];function decodeMemoryView(handle){handle=handle>>2;var heap=HEAPU32;var size=heap[handle];var data=heap[handle+1];return new TA(heap["buffer"],data,size)}name=readLatin1String(name);registerType(rawType,{name:name,"fromWireType":decodeMemoryView,"argPackAdvance":8,"readValueFromPointer":decodeMemoryView},{ignoreDuplicateRegistrations:true})}function __embind_register_std_string(rawType,name){name=readLatin1String(name);var stdStringIsUTF8=name==="std::string";registerType(rawType,{name:name,"fromWireType":function(value){var length=HEAPU32[value>>2];var str;if(stdStringIsUTF8){var endChar=HEAPU8[value+4+length];var endCharSwap=0;if(endChar!=0){endCharSwap=endChar;HEAPU8[value+4+length]=0}var decodeStartPtr=value+4;for(var i=0;i<=length;++i){var currentBytePtr=value+4+i;if(HEAPU8[currentBytePtr]==0){var stringSegment=UTF8ToString(decodeStartPtr);if(str===undefined)str=stringSegment;else{str+=String.fromCharCode(0);str+=stringSegment}decodeStartPtr=currentBytePtr+1}}if(endCharSwap!=0)HEAPU8[value+4+length]=endCharSwap}else{var a=new Array(length);for(var i=0;i<length;++i){a[i]=String.fromCharCode(HEAPU8[value+4+i])}str=a.join("")}_free(value);return str},"toWireType":function(destructors,value){if(value instanceof ArrayBuffer){value=new Uint8Array(value)}var getLength;var valueIsOfTypeString=typeof value==="string";if(!(valueIsOfTypeString||value instanceof Uint8Array||value instanceof Uint8ClampedArray||value instanceof Int8Array)){throwBindingError("Cannot pass non-string to std::string")}if(stdStringIsUTF8&&valueIsOfTypeString){getLength=function(){return lengthBytesUTF8(value)}}else{getLength=function(){return value.length}}var length=getLength();var ptr=_malloc(4+length+1);HEAPU32[ptr>>2]=length;if(stdStringIsUTF8&&valueIsOfTypeString){stringToUTF8(value,ptr+4,length+1)}else{if(valueIsOfTypeString){for(var i=0;i<length;++i){var charCode=value.charCodeAt(i);if(charCode>255){_free(ptr);throwBindingError("String has UTF-16 code units that do not fit in 8 bits")}HEAPU8[ptr+4+i]=charCode}}else{for(var i=0;i<length;++i){HEAPU8[ptr+4+i]=value[i]}}}if(destructors!==null){destructors.push(_free,ptr)}return ptr},"argPackAdvance":8,"readValueFromPointer":simpleReadValueFromPointer,destructorFunction:function(ptr){_free(ptr)}})}function __embind_register_std_wstring(rawType,charSize,name){name=readLatin1String(name);var getHeap,shift;if(charSize===2){getHeap=function(){return HEAPU16};shift=1}else if(charSize===4){getHeap=function(){return HEAPU32};shift=2}registerType(rawType,{name:name,"fromWireType":function(value){var HEAP=getHeap();var length=HEAPU32[value>>2];var a=new Array(length);var start=value+4>>shift;for(var i=0;i<length;++i){a[i]=String.fromCharCode(HEAP[start+i])}_free(value);return a.join("")},"toWireType":function(destructors,value){var length=value.length;var ptr=_malloc(4+length*charSize);var HEAP=getHeap();HEAPU32[ptr>>2]=length;var start=ptr+4>>shift;for(var i=0;i<length;++i){HEAP[start+i]=value.charCodeAt(i)}if(destructors!==null){destructors.push(_free,ptr)}return ptr},"argPackAdvance":8,"readValueFromPointer":simpleReadValueFromPointer,destructorFunction:function(ptr){_free(ptr)}})}function __embind_register_void(rawType,name){name=readLatin1String(name);registerType(rawType,{isVoid:true,name:name,"argPackAdvance":0,"fromWireType":function(){return undefined},"toWireType":function(destructors,o){return undefined}})}function __emval_incref(handle){if(handle>4){emval_handle_array[handle].refcount+=1}}function requireRegisteredType(rawType,humanName){var impl=registeredTypes[rawType];if(undefined===impl){throwBindingError(humanName+" has unknown type "+getTypeName(rawType))}return impl}function __emval_take_value(type,argv){type=requireRegisteredType(type,"_emval_take_value");var v=type["readValueFromPointer"](argv);return __emval_register(v)}function _abort(){abort()}function _emscripten_get_heap_size(){return HEAP8.length}function emscripten_realloc_buffer(size){try{wasmMemory.grow(size-buffer.byteLength+65535>>16);updateGlobalBufferAndViews(wasmMemory.buffer);return 1}catch(e){console.error("emscripten_realloc_buffer: Attempted to grow heap from "+buffer.byteLength+" bytes to "+size+" bytes, but got error: "+e)}}function _emscripten_resize_heap(requestedSize){var oldSize=_emscripten_get_heap_size();assert(requestedSize>oldSize);var PAGE_MULTIPLE=65536;var LIMIT=2147483648-PAGE_MULTIPLE;if(requestedSize>LIMIT){err("Cannot enlarge memory, asked to go up to "+requestedSize+" bytes, but the limit is "+LIMIT+" bytes!");return false}var MIN_TOTAL_MEMORY=16777216;var newSize=Math.max(oldSize,MIN_TOTAL_MEMORY);while(newSize<requestedSize){if(newSize<=536870912){newSize=alignUp(2*newSize,PAGE_MULTIPLE)}else{newSize=Math.min(alignUp((3*newSize+2147483648)/4,PAGE_MULTIPLE),LIMIT)}if(newSize===oldSize){warnOnce("Cannot ask for more memory since we reached the practical limit in browsers (which is just below 2GB), so the request would have failed. Requesting only "+HEAP8.length)}}var replacement=emscripten_realloc_buffer(newSize);if(!replacement){err("Failed to grow the heap from "+oldSize+" bytes to "+newSize+" bytes, not enough memory!");return false}return true}function _exit(status){exit(status)}function _llvm_log2_f32(x){return Math.log(x)/Math.LN2}function _llvm_log2_f64(a0){return _llvm_log2_f32(a0)}function _llvm_trap(){abort("trap!")}function _emscripten_memcpy_big(dest,src,num){HEAPU8.set(HEAPU8.subarray(src,src+num),dest)}embind_init_charCodes();BindingError=Module["BindingError"]=extendError(Error,"BindingError");InternalError=Module["InternalError"]=extendError(Error,"InternalError");init_ClassHandle();init_RegisteredPointer();init_embind();UnboundTypeError=Module["UnboundTypeError"]=extendError(Error,"UnboundTypeError");init_emval();function nullFunc_i(x){abortFnPtrError(x,"i")}function nullFunc_ii(x){abortFnPtrError(x,"ii")}function nullFunc_iidiiii(x){abortFnPtrError(x,"iidiiii")}function nullFunc_iii(x){abortFnPtrError(x,"iii")}function nullFunc_iiii(x){abortFnPtrError(x,"iiii")}function nullFunc_iiiii(x){abortFnPtrError(x,"iiiii")}function nullFunc_jiji(x){abortFnPtrError(x,"jiji")}function nullFunc_v(x){abortFnPtrError(x,"v")}function nullFunc_vi(x){abortFnPtrError(x,"vi")}function nullFunc_vii(x){abortFnPtrError(x,"vii")}function nullFunc_viii(x){abortFnPtrError(x,"viii")}function nullFunc_viiii(x){abortFnPtrError(x,"viiii")}function nullFunc_viiiii(x){abortFnPtrError(x,"viiiii")}function nullFunc_viiiiii(x){abortFnPtrError(x,"viiiiii")}var asmGlobalArg={};var asmLibraryArg={"___assert_fail":___assert_fail,"___cxa_allocate_exception":___cxa_allocate_exception,"___cxa_throw":___cxa_throw,"___lock":___lock,"___unlock":___unlock,"___wasi_fd_close":___wasi_fd_close,"___wasi_fd_seek":___wasi_fd_seek,"___wasi_fd_write":___wasi_fd_write,"__embind_register_bool":__embind_register_bool,"__embind_register_class":__embind_register_class,"__embind_register_class_constructor":__embind_register_class_constructor,"__embind_register_class_function":__embind_register_class_function,"__embind_register_emval":__embind_register_emval,"__embind_register_float":__embind_register_float,"__embind_register_function":__embind_register_function,"__embind_register_integer":__embind_register_integer,"__embind_register_memory_view":__embind_register_memory_view,"__embind_register_std_string":__embind_register_std_string,"__embind_register_std_wstring":__embind_register_std_wstring,"__embind_register_void":__embind_register_void,"__emval_decref":__emval_decref,"__emval_incref":__emval_incref,"__emval_take_value":__emval_take_value,"__memory_base":1024,"__table_base":0,"_abort":_abort,"_emscripten_get_heap_size":_emscripten_get_heap_size,"_emscripten_memcpy_big":_emscripten_memcpy_big,"_emscripten_resize_heap":_emscripten_resize_heap,"_exit":_exit,"_llvm_log2_f64":_llvm_log2_f64,"_llvm_trap":_llvm_trap,"abortStackOverflow":abortStackOverflow,"memory":wasmMemory,"nullFunc_i":nullFunc_i,"nullFunc_ii":nullFunc_ii,"nullFunc_iidiiii":nullFunc_iidiiii,"nullFunc_iii":nullFunc_iii,"nullFunc_iiii":nullFunc_iiii,"nullFunc_iiiii":nullFunc_iiiii,"nullFunc_jiji":nullFunc_jiji,"nullFunc_v":nullFunc_v,"nullFunc_vi":nullFunc_vi,"nullFunc_vii":nullFunc_vii,"nullFunc_viii":nullFunc_viii,"nullFunc_viiii":nullFunc_viiii,"nullFunc_viiiii":nullFunc_viiiii,"nullFunc_viiiiii":nullFunc_viiiiii,"setTempRet0":setTempRet0,"table":wasmTable};var asm=Module["asm"](asmGlobalArg,asmLibraryArg,buffer);Module["asm"]=asm;var __ZSt18uncaught_exceptionv=Module["__ZSt18uncaught_exceptionv"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["__ZSt18uncaught_exceptionv"].apply(null,arguments)};var ___cxa_demangle=Module["___cxa_demangle"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["___cxa_demangle"].apply(null,arguments)};var ___embind_register_native_and_builtin_types=Module["___embind_register_native_and_builtin_types"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["___embind_register_native_and_builtin_types"].apply(null,arguments)};var ___getTypeName=Module["___getTypeName"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["___getTypeName"].apply(null,arguments)};var _fflush=Module["_fflush"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["_fflush"].apply(null,arguments)};var _free=Module["_free"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["_free"].apply(null,arguments)};var _malloc=Module["_malloc"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["_malloc"].apply(null,arguments)};var establishStackSpace=Module["establishStackSpace"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["establishStackSpace"].apply(null,arguments)};var globalCtors=Module["globalCtors"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["globalCtors"].apply(null,arguments)};var stackAlloc=Module["stackAlloc"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["stackAlloc"].apply(null,arguments)};var stackRestore=Module["stackRestore"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["stackRestore"].apply(null,arguments)};var stackSave=Module["stackSave"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["stackSave"].apply(null,arguments)};var dynCall_i=Module["dynCall_i"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_i"].apply(null,arguments)};var dynCall_ii=Module["dynCall_ii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_ii"].apply(null,arguments)};var dynCall_iidiiii=Module["dynCall_iidiiii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_iidiiii"].apply(null,arguments)};var dynCall_iii=Module["dynCall_iii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_iii"].apply(null,arguments)};var dynCall_iiii=Module["dynCall_iiii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_iiii"].apply(null,arguments)};var dynCall_iiiii=Module["dynCall_iiiii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_iiiii"].apply(null,arguments)};var dynCall_jiji=Module["dynCall_jiji"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_jiji"].apply(null,arguments)};var dynCall_v=Module["dynCall_v"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_v"].apply(null,arguments)};var dynCall_vi=Module["dynCall_vi"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_vi"].apply(null,arguments)};var dynCall_vii=Module["dynCall_vii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_vii"].apply(null,arguments)};var dynCall_viii=Module["dynCall_viii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_viii"].apply(null,arguments)};var dynCall_viiii=Module["dynCall_viiii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_viiii"].apply(null,arguments)};var dynCall_viiiii=Module["dynCall_viiiii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_viiiii"].apply(null,arguments)};var dynCall_viiiiii=Module["dynCall_viiiiii"]=function(){assert(runtimeInitialized,"you need to wait for the runtime to be ready (e.g. wait for main() to be called)");assert(!runtimeExited,"the runtime was exited (use NO_EXIT_RUNTIME to keep it alive after main() exits)");return Module["asm"]["dynCall_viiiiii"].apply(null,arguments)};Module["asm"]=asm;if(!Object.getOwnPropertyDescriptor(Module,"intArrayFromString"))Module["intArrayFromString"]=function(){abort("'intArrayFromString' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"intArrayToString"))Module["intArrayToString"]=function(){abort("'intArrayToString' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};Module["ccall"]=ccall;Module["cwrap"]=cwrap;if(!Object.getOwnPropertyDescriptor(Module,"setValue"))Module["setValue"]=function(){abort("'setValue' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"getValue"))Module["getValue"]=function(){abort("'getValue' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"allocate"))Module["allocate"]=function(){abort("'allocate' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"getMemory"))Module["getMemory"]=function(){abort("'getMemory' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"AsciiToString"))Module["AsciiToString"]=function(){abort("'AsciiToString' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"stringToAscii"))Module["stringToAscii"]=function(){abort("'stringToAscii' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"UTF8ArrayToString"))Module["UTF8ArrayToString"]=function(){abort("'UTF8ArrayToString' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"UTF8ToString"))Module["UTF8ToString"]=function(){abort("'UTF8ToString' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"stringToUTF8Array"))Module["stringToUTF8Array"]=function(){abort("'stringToUTF8Array' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};Module["stringToUTF8"]=stringToUTF8;if(!Object.getOwnPropertyDescriptor(Module,"lengthBytesUTF8"))Module["lengthBytesUTF8"]=function(){abort("'lengthBytesUTF8' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"UTF16ToString"))Module["UTF16ToString"]=function(){abort("'UTF16ToString' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"stringToUTF16"))Module["stringToUTF16"]=function(){abort("'stringToUTF16' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"lengthBytesUTF16"))Module["lengthBytesUTF16"]=function(){abort("'lengthBytesUTF16' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"UTF32ToString"))Module["UTF32ToString"]=function(){abort("'UTF32ToString' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"stringToUTF32"))Module["stringToUTF32"]=function(){abort("'stringToUTF32' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"lengthBytesUTF32"))Module["lengthBytesUTF32"]=function(){abort("'lengthBytesUTF32' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"allocateUTF8"))Module["allocateUTF8"]=function(){abort("'allocateUTF8' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"stackTrace"))Module["stackTrace"]=function(){abort("'stackTrace' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"addOnPreRun"))Module["addOnPreRun"]=function(){abort("'addOnPreRun' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"addOnInit"))Module["addOnInit"]=function(){abort("'addOnInit' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"addOnPreMain"))Module["addOnPreMain"]=function(){abort("'addOnPreMain' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"addOnExit"))Module["addOnExit"]=function(){abort("'addOnExit' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"addOnPostRun"))Module["addOnPostRun"]=function(){abort("'addOnPostRun' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"writeStringToMemory"))Module["writeStringToMemory"]=function(){abort("'writeStringToMemory' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"writeArrayToMemory"))Module["writeArrayToMemory"]=function(){abort("'writeArrayToMemory' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"writeAsciiToMemory"))Module["writeAsciiToMemory"]=function(){abort("'writeAsciiToMemory' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"addRunDependency"))Module["addRunDependency"]=function(){abort("'addRunDependency' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"removeRunDependency"))Module["removeRunDependency"]=function(){abort("'removeRunDependency' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"ENV"))Module["ENV"]=function(){abort("'ENV' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"FS"))Module["FS"]=function(){abort("'FS' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"FS_createFolder"))Module["FS_createFolder"]=function(){abort("'FS_createFolder' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"FS_createPath"))Module["FS_createPath"]=function(){abort("'FS_createPath' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"FS_createDataFile"))Module["FS_createDataFile"]=function(){abort("'FS_createDataFile' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"FS_createPreloadedFile"))Module["FS_createPreloadedFile"]=function(){abort("'FS_createPreloadedFile' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"FS_createLazyFile"))Module["FS_createLazyFile"]=function(){abort("'FS_createLazyFile' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"FS_createLink"))Module["FS_createLink"]=function(){abort("'FS_createLink' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"FS_createDevice"))Module["FS_createDevice"]=function(){abort("'FS_createDevice' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"FS_unlink"))Module["FS_unlink"]=function(){abort("'FS_unlink' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")};if(!Object.getOwnPropertyDescriptor(Module,"GL"))Module["GL"]=function(){abort("'GL' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"dynamicAlloc"))Module["dynamicAlloc"]=function(){abort("'dynamicAlloc' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"loadDynamicLibrary"))Module["loadDynamicLibrary"]=function(){abort("'loadDynamicLibrary' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"loadWebAssemblyModule"))Module["loadWebAssemblyModule"]=function(){abort("'loadWebAssemblyModule' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"getLEB"))Module["getLEB"]=function(){abort("'getLEB' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"getFunctionTables"))Module["getFunctionTables"]=function(){abort("'getFunctionTables' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"alignFunctionTables"))Module["alignFunctionTables"]=function(){abort("'alignFunctionTables' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"registerFunctions"))Module["registerFunctions"]=function(){abort("'registerFunctions' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"addFunction"))Module["addFunction"]=function(){abort("'addFunction' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"removeFunction"))Module["removeFunction"]=function(){abort("'removeFunction' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"getFuncWrapper"))Module["getFuncWrapper"]=function(){abort("'getFuncWrapper' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"prettyPrint"))Module["prettyPrint"]=function(){abort("'prettyPrint' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"makeBigInt"))Module["makeBigInt"]=function(){abort("'makeBigInt' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"dynCall"))Module["dynCall"]=function(){abort("'dynCall' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"getCompilerSetting"))Module["getCompilerSetting"]=function(){abort("'getCompilerSetting' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"stackSave"))Module["stackSave"]=function(){abort("'stackSave' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"stackRestore"))Module["stackRestore"]=function(){abort("'stackRestore' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"stackAlloc"))Module["stackAlloc"]=function(){abort("'stackAlloc' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"establishStackSpace"))Module["establishStackSpace"]=function(){abort("'establishStackSpace' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"print"))Module["print"]=function(){abort("'print' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"printErr"))Module["printErr"]=function(){abort("'printErr' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"getTempRet0"))Module["getTempRet0"]=function(){abort("'getTempRet0' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"setTempRet0"))Module["setTempRet0"]=function(){abort("'setTempRet0' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"callMain"))Module["callMain"]=function(){abort("'callMain' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"abort"))Module["abort"]=function(){abort("'abort' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"Pointer_stringify"))Module["Pointer_stringify"]=function(){abort("'Pointer_stringify' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};if(!Object.getOwnPropertyDescriptor(Module,"warnOnce"))Module["warnOnce"]=function(){abort("'warnOnce' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")};Module["writeStackCookie"]=writeStackCookie;Module["checkStackCookie"]=checkStackCookie;Module["abortStackOverflow"]=abortStackOverflow;if(!Object.getOwnPropertyDescriptor(Module,"ALLOC_NORMAL"))Object.defineProperty(Module,"ALLOC_NORMAL",{configurable:true,get:function(){abort("'ALLOC_NORMAL' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")}});if(!Object.getOwnPropertyDescriptor(Module,"ALLOC_STACK"))Object.defineProperty(Module,"ALLOC_STACK",{configurable:true,get:function(){abort("'ALLOC_STACK' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")}});if(!Object.getOwnPropertyDescriptor(Module,"ALLOC_DYNAMIC"))Object.defineProperty(Module,"ALLOC_DYNAMIC",{configurable:true,get:function(){abort("'ALLOC_DYNAMIC' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")}});if(!Object.getOwnPropertyDescriptor(Module,"ALLOC_NONE"))Object.defineProperty(Module,"ALLOC_NONE",{configurable:true,get:function(){abort("'ALLOC_NONE' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ)")}});if(!Object.getOwnPropertyDescriptor(Module,"calledRun"))Object.defineProperty(Module,"calledRun",{configurable:true,get:function(){abort("'calledRun' was not exported. add it to EXTRA_EXPORTED_RUNTIME_METHODS (see the FAQ). Alternatively, forcing filesystem support (-s FORCE_FILESYSTEM=1) can export this for you")}});var calledRun;Module["then"]=function(func){if(calledRun){func(Module)}else{var old=Module["onRuntimeInitialized"];Module["onRuntimeInitialized"]=function(){if(old)old();func(Module)}}return Module};function ExitStatus(status){this.name="ExitStatus";this.message="Program terminated with exit("+status+")";this.status=status}dependenciesFulfilled=function runCaller(){if(!calledRun)run();if(!calledRun)dependenciesFulfilled=runCaller};function run(args){args=args||arguments_;if(runDependencies>0){return}writeStackCookie();preRun();if(runDependencies>0)return;function doRun(){if(calledRun)return;calledRun=true;if(ABORT)return;initRuntime();preMain();if(Module["onRuntimeInitialized"])Module["onRuntimeInitialized"]();assert(!Module["_main"],'compiled without a main, but one is present. if you added it from JS, use Module["onRuntimeInitialized"]');postRun()}if(Module["setStatus"]){Module["setStatus"]("Running...");setTimeout(function(){setTimeout(function(){Module["setStatus"]("")},1);doRun()},1)}else{doRun()}checkStackCookie()}Module["run"]=run;function checkUnflushedContent(){var print=out;var printErr=err;var has=false;out=err=function(x){has=true};try{var flush=flush_NO_FILESYSTEM;if(flush)flush(0)}catch(e){}out=print;err=printErr;if(has){warnOnce("stdio streams had content in them that was not flushed. you should set EXIT_RUNTIME to 1 (see the FAQ), or make sure to emit a newline when you printf etc.");warnOnce("(this may also be due to not including full filesystem support - try building with -s FORCE_FILESYSTEM=1)")}}function exit(status,implicit){checkUnflushedContent();if(implicit&&noExitRuntime&&status===0){return}if(noExitRuntime){if(!implicit){err("program exited (with status: "+status+"), but EXIT_RUNTIME is not set, so halting execution but not exiting the runtime or preventing further async execution (build with EXIT_RUNTIME=1, if you want a true shutdown)")}}else{ABORT=true;EXITSTATUS=status;exitRuntime();if(Module["onExit"])Module["onExit"](status)}quit_(status,new ExitStatus(status))}if(Module["preInit"]){if(typeof Module["preInit"]=="function")Module["preInit"]=[Module["preInit"]];while(Module["preInit"].length>0){Module["preInit"].pop()()}}noExitRuntime=true;run();


  return Module
}
);
})();
if (true)
      module.exports = Module;
    else {}
    


/***/ }),
/* 112 */
/***/ ((module) => {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),
/* 113 */
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = 113;
module.exports = webpackEmptyContext;

/***/ }),
/* 114 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ woff2tottf),
/* harmony export */   "woff2tottfasync": () => (/* binding */ woff2tottfasync)
/* harmony export */ });
/* harmony import */ var _woff2_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(110);
/* harmony import */ var _woff2_index__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_woff2_index__WEBPACK_IMPORTED_MODULE_0__);
/**
 * @file woff2 to ttf
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * ttf格式转换成woff2字体格式
 *
 * @param {ArrayBuffer} woff2Buffer ttf缓冲数组
 * @param {Object} options 选项
 *
 * @return {ArrayBuffer} woff格式byte流
 */
// eslint-disable-next-line no-unused-vars
function woff2tottf(woff2Buffer, options = {}) {
    if (!_woff2_index__WEBPACK_IMPORTED_MODULE_0___default().isInited()) {
        throw new Error('use woff2.init() to init woff2 module!');
    }
    const result = _woff2_index__WEBPACK_IMPORTED_MODULE_0___default().decode(woff2Buffer);
    return result.buffer;
}

/**
 * ttf格式转换成woff2字体格式
 *
 * @param {ArrayBuffer} woff2Buffer ttf缓冲数组
 * @param {Object} options 选项
 *
 * @return {Promise.<ArrayBuffer>} woff格式byte流
 */
function woff2tottfasync(woff2Buffer, options = {}) {
    return _woff2_index__WEBPACK_IMPORTED_MODULE_0___default().init(options.wasmUrl).then(() => {
        const result = _woff2_index__WEBPACK_IMPORTED_MODULE_0___default().decode(woff2Buffer);
        return result.buffer;
    });
}


/***/ }),
/* 115 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ttf2base64)
/* harmony export */ });
/* harmony import */ var _util_bytes2base64__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(116);
/**
 * @file ttf数组转base64编码
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * ttf数组转base64编码
 *
 * @param {Array} arrayBuffer ArrayBuffer对象
 * @return {string} base64编码
 */
function ttf2base64(arrayBuffer) {
    return 'data:font/ttf;charset=utf-8;base64,' + (0,_util_bytes2base64__WEBPACK_IMPORTED_MODULE_0__.default)(arrayBuffer);
}


/***/ }),
/* 116 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ bytes2base64)
/* harmony export */ });
/**
 * @file 二进制byte流转base64编码
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * 二进制byte流转base64编码
 *
 * @param {ArrayBuffer|Array} buffer ArrayBuffer对象
 * @return {string} base64编码
 */
function bytes2base64(buffer) {
    let str = '';
    let length;
    let i;
    // ArrayBuffer
    if (buffer instanceof ArrayBuffer) {
        length = buffer.byteLength;
        const view = new DataView(buffer, 0, length);
        for (i = 0; i < length; i++) {
            str += String.fromCharCode(view.getUint8(i, false));
        }
    }
    // Array
    else if (buffer.length) {
        length = buffer.length;
        for (i = 0; i < length; i++) {
            str += String.fromCharCode(buffer[i]);
        }
    }

    if (!str) {
        return '';
    }
    return typeof btoa !== 'undefined'
        ? btoa(str)
        : Buffer.from(str, 'binary').toString('base64');
}


/***/ }),
/* 117 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ eot2base64)
/* harmony export */ });
/* harmony import */ var _util_bytes2base64__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(116);
/**
 * @file eot数组转base64编码
 * @author mengke01(kekee000@gmail.com)
 */


/**
 * eot数组转base64编码
 *
 * @param {Array} arrayBuffer ArrayBuffer对象
 * @return {string} base64编码
 */
function eot2base64(arrayBuffer) {
    return 'data:font/eot;charset=utf-8;base64,' + (0,_util_bytes2base64__WEBPACK_IMPORTED_MODULE_0__.default)(arrayBuffer);
}


/***/ }),
/* 118 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ woff2base64)
/* harmony export */ });
/* harmony import */ var _util_bytes2base64__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(116);
/**
 * @file woff数组转base64编码
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * woff数组转base64编码
 *
 * @param {Array} arrayBuffer ArrayBuffer对象
 * @return {string} base64编码
 */
function woff2base64(arrayBuffer) {
    return 'data:font/woff;charset=utf-8;base64,' + (0,_util_bytes2base64__WEBPACK_IMPORTED_MODULE_0__.default)(arrayBuffer);
}


/***/ }),
/* 119 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ svg2base64)
/* harmony export */ });
/**
 * @file svg字符串转base64编码
 * @author mengke01(kekee000@gmail.com)
 */

/**
 * svg字符串转base64编码
 *
 * @param {string} svg svg对象
 * @param {string} scheme  头部
 * @return {string} base64编码
 */
function svg2base64(svg, scheme = 'font/svg') {
    if (typeof btoa === 'undefined') {
        return 'data:' + scheme + ';charset=utf-8;base64,'
            + Buffer.from(svg, 'binary').toString('base64');
    }
    return 'data:' + scheme + ';charset=utf-8;base64,' + btoa(svg);
}


/***/ }),
/* 120 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ woff2tobase64)
/* harmony export */ });
/* harmony import */ var _util_bytes2base64__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(116);
/**
 * @file woff2数组转base64编码
 * @author mengke01(kekee000@gmail.com)
 */



/**
 * woff数组转base64编码
 *
 * @param {Array} arrayBuffer ArrayBuffer对象
 * @return {string} base64编码
 */
function woff2tobase64(arrayBuffer) {
    return 'data:font/woff2;charset=utf-8;base64,' + (0,_util_bytes2base64__WEBPACK_IMPORTED_MODULE_0__.default)(arrayBuffer);
}


/***/ }),
/* 121 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ttf2icon)
/* harmony export */ });
/* harmony import */ var _ttfreader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87);
/* harmony import */ var _error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29);
/* harmony import */ var _data_default__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(10);
/* harmony import */ var _ttf2symbol__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(108);
/**
 * @file ttf转icon
 * @author mengke01(kekee000@gmail.com)
 */






/**
 * listUnicode
 *
 * @param  {Array} unicode unicode
 * @return {string}         unicode string
 */
function listUnicode(unicode) {
    return unicode.map((u) => '\\' + u.toString(16)).join(',');
}

/**
 * ttf数据结构转icon数据结构
 *
 * @param {ttfObject} ttf ttfObject对象
 * @param {Object} options 选项
 * @param {Object} options.metadata 字体相关的信息
 * @param {Object} options.iconPrefix icon 前缀
 * @return {Object} icon obj
 */
function ttfobject2icon(ttf, options = {}) {

    const glyfList = [];

    // glyf 信息
    const filtered = ttf.glyf.filter((g) => g.name !== '.notdef'
            && g.name !== '.null'
            && g.name !== 'nonmarkingreturn'
            && g.unicode && g.unicode.length);

    filtered.forEach((g, i) => {
        glyfList.push({
            code: '&#x' + g.unicode[0].toString(16) + ';',
            codeName: listUnicode(g.unicode),
            name: g.name,
            id: (0,_ttf2symbol__WEBPACK_IMPORTED_MODULE_3__.getSymbolId)(g, i)
        });
    });

    return {
        fontFamily: ttf.name.fontFamily || _data_default__WEBPACK_IMPORTED_MODULE_2__.default.name.fontFamily,
        iconPrefix: options.iconPrefix || 'icon',
        glyfList
    };

}


/**
 * ttf格式转换成icon
 *
 * @param {ArrayBuffer|ttfObject} ttfBuffer ttf缓冲数组或者ttfObject对象
 * @param {Object} options 选项
 * @param {Object} options.metadata 字体相关的信息
 *
 * @return {Object} icon object
 */
function ttf2icon(ttfBuffer, options = {}) {
    // 读取ttf二进制流
    if (ttfBuffer instanceof ArrayBuffer) {
        const reader = new _ttfreader__WEBPACK_IMPORTED_MODULE_0__.default();
        const ttfObject = reader.read(ttfBuffer);
        reader.dispose();

        return ttfobject2icon(ttfObject, options);
    }
    // 读取ttfObject
    else if (ttfBuffer.version && ttfBuffer.glyf) {

        return ttfobject2icon(ttfBuffer, options);
    }

    _error__WEBPACK_IMPORTED_MODULE_1__.default.raise(10101);
}


/***/ }),
/* 122 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(124), __webpack_require__(125), __webpack_require__(126), __webpack_require__(127), __webpack_require__(128), __webpack_require__(129), __webpack_require__(130), __webpack_require__(131), __webpack_require__(132), __webpack_require__(133), __webpack_require__(134), __webpack_require__(135), __webpack_require__(136), __webpack_require__(137), __webpack_require__(138), __webpack_require__(139), __webpack_require__(140), __webpack_require__(141), __webpack_require__(142), __webpack_require__(143), __webpack_require__(144), __webpack_require__(145), __webpack_require__(146), __webpack_require__(147), __webpack_require__(148), __webpack_require__(149), __webpack_require__(150), __webpack_require__(151), __webpack_require__(152), __webpack_require__(153), __webpack_require__(154), __webpack_require__(155));
	}
	else {}
}(this, function (CryptoJS) {

	return CryptoJS;

}));

/***/ }),
/* 123 */
/***/ (function(module, exports) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory();
	}
	else {}
}(this, function () {

	/**
	 * CryptoJS core components.
	 */
	var CryptoJS = CryptoJS || (function (Math, undefined) {
	    /*
	     * Local polyfil of Object.create
	     */
	    var create = Object.create || (function () {
	        function F() {};

	        return function (obj) {
	            var subtype;

	            F.prototype = obj;

	            subtype = new F();

	            F.prototype = null;

	            return subtype;
	        };
	    }())

	    /**
	     * CryptoJS namespace.
	     */
	    var C = {};

	    /**
	     * Library namespace.
	     */
	    var C_lib = C.lib = {};

	    /**
	     * Base object for prototypal inheritance.
	     */
	    var Base = C_lib.Base = (function () {


	        return {
	            /**
	             * Creates a new object that inherits from this object.
	             *
	             * @param {Object} overrides Properties to copy into the new object.
	             *
	             * @return {Object} The new object.
	             *
	             * @static
	             *
	             * @example
	             *
	             *     var MyType = CryptoJS.lib.Base.extend({
	             *         field: 'value',
	             *
	             *         method: function () {
	             *         }
	             *     });
	             */
	            extend: function (overrides) {
	                // Spawn
	                var subtype = create(this);

	                // Augment
	                if (overrides) {
	                    subtype.mixIn(overrides);
	                }

	                // Create default initializer
	                if (!subtype.hasOwnProperty('init') || this.init === subtype.init) {
	                    subtype.init = function () {
	                        subtype.$super.init.apply(this, arguments);
	                    };
	                }

	                // Initializer's prototype is the subtype object
	                subtype.init.prototype = subtype;

	                // Reference supertype
	                subtype.$super = this;

	                return subtype;
	            },

	            /**
	             * Extends this object and runs the init method.
	             * Arguments to create() will be passed to init().
	             *
	             * @return {Object} The new object.
	             *
	             * @static
	             *
	             * @example
	             *
	             *     var instance = MyType.create();
	             */
	            create: function () {
	                var instance = this.extend();
	                instance.init.apply(instance, arguments);

	                return instance;
	            },

	            /**
	             * Initializes a newly created object.
	             * Override this method to add some logic when your objects are created.
	             *
	             * @example
	             *
	             *     var MyType = CryptoJS.lib.Base.extend({
	             *         init: function () {
	             *             // ...
	             *         }
	             *     });
	             */
	            init: function () {
	            },

	            /**
	             * Copies properties into this object.
	             *
	             * @param {Object} properties The properties to mix in.
	             *
	             * @example
	             *
	             *     MyType.mixIn({
	             *         field: 'value'
	             *     });
	             */
	            mixIn: function (properties) {
	                for (var propertyName in properties) {
	                    if (properties.hasOwnProperty(propertyName)) {
	                        this[propertyName] = properties[propertyName];
	                    }
	                }

	                // IE won't copy toString using the loop above
	                if (properties.hasOwnProperty('toString')) {
	                    this.toString = properties.toString;
	                }
	            },

	            /**
	             * Creates a copy of this object.
	             *
	             * @return {Object} The clone.
	             *
	             * @example
	             *
	             *     var clone = instance.clone();
	             */
	            clone: function () {
	                return this.init.prototype.extend(this);
	            }
	        };
	    }());

	    /**
	     * An array of 32-bit words.
	     *
	     * @property {Array} words The array of 32-bit words.
	     * @property {number} sigBytes The number of significant bytes in this word array.
	     */
	    var WordArray = C_lib.WordArray = Base.extend({
	        /**
	         * Initializes a newly created word array.
	         *
	         * @param {Array} words (Optional) An array of 32-bit words.
	         * @param {number} sigBytes (Optional) The number of significant bytes in the words.
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.lib.WordArray.create();
	         *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607]);
	         *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607], 6);
	         */
	        init: function (words, sigBytes) {
	            words = this.words = words || [];

	            if (sigBytes != undefined) {
	                this.sigBytes = sigBytes;
	            } else {
	                this.sigBytes = words.length * 4;
	            }
	        },

	        /**
	         * Converts this word array to a string.
	         *
	         * @param {Encoder} encoder (Optional) The encoding strategy to use. Default: CryptoJS.enc.Hex
	         *
	         * @return {string} The stringified word array.
	         *
	         * @example
	         *
	         *     var string = wordArray + '';
	         *     var string = wordArray.toString();
	         *     var string = wordArray.toString(CryptoJS.enc.Utf8);
	         */
	        toString: function (encoder) {
	            return (encoder || Hex).stringify(this);
	        },

	        /**
	         * Concatenates a word array to this word array.
	         *
	         * @param {WordArray} wordArray The word array to append.
	         *
	         * @return {WordArray} This word array.
	         *
	         * @example
	         *
	         *     wordArray1.concat(wordArray2);
	         */
	        concat: function (wordArray) {
	            // Shortcuts
	            var thisWords = this.words;
	            var thatWords = wordArray.words;
	            var thisSigBytes = this.sigBytes;
	            var thatSigBytes = wordArray.sigBytes;

	            // Clamp excess bits
	            this.clamp();

	            // Concat
	            if (thisSigBytes % 4) {
	                // Copy one byte at a time
	                for (var i = 0; i < thatSigBytes; i++) {
	                    var thatByte = (thatWords[i >>> 2] >>> (24 - (i % 4) * 8)) & 0xff;
	                    thisWords[(thisSigBytes + i) >>> 2] |= thatByte << (24 - ((thisSigBytes + i) % 4) * 8);
	                }
	            } else {
	                // Copy one word at a time
	                for (var i = 0; i < thatSigBytes; i += 4) {
	                    thisWords[(thisSigBytes + i) >>> 2] = thatWords[i >>> 2];
	                }
	            }
	            this.sigBytes += thatSigBytes;

	            // Chainable
	            return this;
	        },

	        /**
	         * Removes insignificant bits.
	         *
	         * @example
	         *
	         *     wordArray.clamp();
	         */
	        clamp: function () {
	            // Shortcuts
	            var words = this.words;
	            var sigBytes = this.sigBytes;

	            // Clamp
	            words[sigBytes >>> 2] &= 0xffffffff << (32 - (sigBytes % 4) * 8);
	            words.length = Math.ceil(sigBytes / 4);
	        },

	        /**
	         * Creates a copy of this word array.
	         *
	         * @return {WordArray} The clone.
	         *
	         * @example
	         *
	         *     var clone = wordArray.clone();
	         */
	        clone: function () {
	            var clone = Base.clone.call(this);
	            clone.words = this.words.slice(0);

	            return clone;
	        },

	        /**
	         * Creates a word array filled with random bytes.
	         *
	         * @param {number} nBytes The number of random bytes to generate.
	         *
	         * @return {WordArray} The random word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.lib.WordArray.random(16);
	         */
	        random: function (nBytes) {
	            var words = [];

	            var r = (function (m_w) {
	                var m_w = m_w;
	                var m_z = 0x3ade68b1;
	                var mask = 0xffffffff;

	                return function () {
	                    m_z = (0x9069 * (m_z & 0xFFFF) + (m_z >> 0x10)) & mask;
	                    m_w = (0x4650 * (m_w & 0xFFFF) + (m_w >> 0x10)) & mask;
	                    var result = ((m_z << 0x10) + m_w) & mask;
	                    result /= 0x100000000;
	                    result += 0.5;
	                    return result * (Math.random() > .5 ? 1 : -1);
	                }
	            });

	            for (var i = 0, rcache; i < nBytes; i += 4) {
	                var _r = r((rcache || Math.random()) * 0x100000000);

	                rcache = _r() * 0x3ade67b7;
	                words.push((_r() * 0x100000000) | 0);
	            }

	            return new WordArray.init(words, nBytes);
	        }
	    });

	    /**
	     * Encoder namespace.
	     */
	    var C_enc = C.enc = {};

	    /**
	     * Hex encoding strategy.
	     */
	    var Hex = C_enc.Hex = {
	        /**
	         * Converts a word array to a hex string.
	         *
	         * @param {WordArray} wordArray The word array.
	         *
	         * @return {string} The hex string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var hexString = CryptoJS.enc.Hex.stringify(wordArray);
	         */
	        stringify: function (wordArray) {
	            // Shortcuts
	            var words = wordArray.words;
	            var sigBytes = wordArray.sigBytes;

	            // Convert
	            var hexChars = [];
	            for (var i = 0; i < sigBytes; i++) {
	                var bite = (words[i >>> 2] >>> (24 - (i % 4) * 8)) & 0xff;
	                hexChars.push((bite >>> 4).toString(16));
	                hexChars.push((bite & 0x0f).toString(16));
	            }

	            return hexChars.join('');
	        },

	        /**
	         * Converts a hex string to a word array.
	         *
	         * @param {string} hexStr The hex string.
	         *
	         * @return {WordArray} The word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.enc.Hex.parse(hexString);
	         */
	        parse: function (hexStr) {
	            // Shortcut
	            var hexStrLength = hexStr.length;

	            // Convert
	            var words = [];
	            for (var i = 0; i < hexStrLength; i += 2) {
	                words[i >>> 3] |= parseInt(hexStr.substr(i, 2), 16) << (24 - (i % 8) * 4);
	            }

	            return new WordArray.init(words, hexStrLength / 2);
	        }
	    };

	    /**
	     * Latin1 encoding strategy.
	     */
	    var Latin1 = C_enc.Latin1 = {
	        /**
	         * Converts a word array to a Latin1 string.
	         *
	         * @param {WordArray} wordArray The word array.
	         *
	         * @return {string} The Latin1 string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var latin1String = CryptoJS.enc.Latin1.stringify(wordArray);
	         */
	        stringify: function (wordArray) {
	            // Shortcuts
	            var words = wordArray.words;
	            var sigBytes = wordArray.sigBytes;

	            // Convert
	            var latin1Chars = [];
	            for (var i = 0; i < sigBytes; i++) {
	                var bite = (words[i >>> 2] >>> (24 - (i % 4) * 8)) & 0xff;
	                latin1Chars.push(String.fromCharCode(bite));
	            }

	            return latin1Chars.join('');
	        },

	        /**
	         * Converts a Latin1 string to a word array.
	         *
	         * @param {string} latin1Str The Latin1 string.
	         *
	         * @return {WordArray} The word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.enc.Latin1.parse(latin1String);
	         */
	        parse: function (latin1Str) {
	            // Shortcut
	            var latin1StrLength = latin1Str.length;

	            // Convert
	            var words = [];
	            for (var i = 0; i < latin1StrLength; i++) {
	                words[i >>> 2] |= (latin1Str.charCodeAt(i) & 0xff) << (24 - (i % 4) * 8);
	            }

	            return new WordArray.init(words, latin1StrLength);
	        }
	    };

	    /**
	     * UTF-8 encoding strategy.
	     */
	    var Utf8 = C_enc.Utf8 = {
	        /**
	         * Converts a word array to a UTF-8 string.
	         *
	         * @param {WordArray} wordArray The word array.
	         *
	         * @return {string} The UTF-8 string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var utf8String = CryptoJS.enc.Utf8.stringify(wordArray);
	         */
	        stringify: function (wordArray) {
	            try {
	                return decodeURIComponent(escape(Latin1.stringify(wordArray)));
	            } catch (e) {
	                throw new Error('Malformed UTF-8 data');
	            }
	        },

	        /**
	         * Converts a UTF-8 string to a word array.
	         *
	         * @param {string} utf8Str The UTF-8 string.
	         *
	         * @return {WordArray} The word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.enc.Utf8.parse(utf8String);
	         */
	        parse: function (utf8Str) {
	            return Latin1.parse(unescape(encodeURIComponent(utf8Str)));
	        }
	    };

	    /**
	     * Abstract buffered block algorithm template.
	     *
	     * The property blockSize must be implemented in a concrete subtype.
	     *
	     * @property {number} _minBufferSize The number of blocks that should be kept unprocessed in the buffer. Default: 0
	     */
	    var BufferedBlockAlgorithm = C_lib.BufferedBlockAlgorithm = Base.extend({
	        /**
	         * Resets this block algorithm's data buffer to its initial state.
	         *
	         * @example
	         *
	         *     bufferedBlockAlgorithm.reset();
	         */
	        reset: function () {
	            // Initial values
	            this._data = new WordArray.init();
	            this._nDataBytes = 0;
	        },

	        /**
	         * Adds new data to this block algorithm's buffer.
	         *
	         * @param {WordArray|string} data The data to append. Strings are converted to a WordArray using UTF-8.
	         *
	         * @example
	         *
	         *     bufferedBlockAlgorithm._append('data');
	         *     bufferedBlockAlgorithm._append(wordArray);
	         */
	        _append: function (data) {
	            // Convert string to WordArray, else assume WordArray already
	            if (typeof data == 'string') {
	                data = Utf8.parse(data);
	            }

	            // Append
	            this._data.concat(data);
	            this._nDataBytes += data.sigBytes;
	        },

	        /**
	         * Processes available data blocks.
	         *
	         * This method invokes _doProcessBlock(offset), which must be implemented by a concrete subtype.
	         *
	         * @param {boolean} doFlush Whether all blocks and partial blocks should be processed.
	         *
	         * @return {WordArray} The processed data.
	         *
	         * @example
	         *
	         *     var processedData = bufferedBlockAlgorithm._process();
	         *     var processedData = bufferedBlockAlgorithm._process(!!'flush');
	         */
	        _process: function (doFlush) {
	            // Shortcuts
	            var data = this._data;
	            var dataWords = data.words;
	            var dataSigBytes = data.sigBytes;
	            var blockSize = this.blockSize;
	            var blockSizeBytes = blockSize * 4;

	            // Count blocks ready
	            var nBlocksReady = dataSigBytes / blockSizeBytes;
	            if (doFlush) {
	                // Round up to include partial blocks
	                nBlocksReady = Math.ceil(nBlocksReady);
	            } else {
	                // Round down to include only full blocks,
	                // less the number of blocks that must remain in the buffer
	                nBlocksReady = Math.max((nBlocksReady | 0) - this._minBufferSize, 0);
	            }

	            // Count words ready
	            var nWordsReady = nBlocksReady * blockSize;

	            // Count bytes ready
	            var nBytesReady = Math.min(nWordsReady * 4, dataSigBytes);

	            // Process blocks
	            if (nWordsReady) {
	                for (var offset = 0; offset < nWordsReady; offset += blockSize) {
	                    // Perform concrete-algorithm logic
	                    this._doProcessBlock(dataWords, offset);
	                }

	                // Remove processed words
	                var processedWords = dataWords.splice(0, nWordsReady);
	                data.sigBytes -= nBytesReady;
	            }

	            // Return processed words
	            return new WordArray.init(processedWords, nBytesReady);
	        },

	        /**
	         * Creates a copy of this object.
	         *
	         * @return {Object} The clone.
	         *
	         * @example
	         *
	         *     var clone = bufferedBlockAlgorithm.clone();
	         */
	        clone: function () {
	            var clone = Base.clone.call(this);
	            clone._data = this._data.clone();

	            return clone;
	        },

	        _minBufferSize: 0
	    });

	    /**
	     * Abstract hasher template.
	     *
	     * @property {number} blockSize The number of 32-bit words this hasher operates on. Default: 16 (512 bits)
	     */
	    var Hasher = C_lib.Hasher = BufferedBlockAlgorithm.extend({
	        /**
	         * Configuration options.
	         */
	        cfg: Base.extend(),

	        /**
	         * Initializes a newly created hasher.
	         *
	         * @param {Object} cfg (Optional) The configuration options to use for this hash computation.
	         *
	         * @example
	         *
	         *     var hasher = CryptoJS.algo.SHA256.create();
	         */
	        init: function (cfg) {
	            // Apply config defaults
	            this.cfg = this.cfg.extend(cfg);

	            // Set initial values
	            this.reset();
	        },

	        /**
	         * Resets this hasher to its initial state.
	         *
	         * @example
	         *
	         *     hasher.reset();
	         */
	        reset: function () {
	            // Reset data buffer
	            BufferedBlockAlgorithm.reset.call(this);

	            // Perform concrete-hasher logic
	            this._doReset();
	        },

	        /**
	         * Updates this hasher with a message.
	         *
	         * @param {WordArray|string} messageUpdate The message to append.
	         *
	         * @return {Hasher} This hasher.
	         *
	         * @example
	         *
	         *     hasher.update('message');
	         *     hasher.update(wordArray);
	         */
	        update: function (messageUpdate) {
	            // Append
	            this._append(messageUpdate);

	            // Update the hash
	            this._process();

	            // Chainable
	            return this;
	        },

	        /**
	         * Finalizes the hash computation.
	         * Note that the finalize operation is effectively a destructive, read-once operation.
	         *
	         * @param {WordArray|string} messageUpdate (Optional) A final message update.
	         *
	         * @return {WordArray} The hash.
	         *
	         * @example
	         *
	         *     var hash = hasher.finalize();
	         *     var hash = hasher.finalize('message');
	         *     var hash = hasher.finalize(wordArray);
	         */
	        finalize: function (messageUpdate) {
	            // Final message update
	            if (messageUpdate) {
	                this._append(messageUpdate);
	            }

	            // Perform concrete-hasher logic
	            var hash = this._doFinalize();

	            return hash;
	        },

	        blockSize: 512/32,

	        /**
	         * Creates a shortcut function to a hasher's object interface.
	         *
	         * @param {Hasher} hasher The hasher to create a helper for.
	         *
	         * @return {Function} The shortcut function.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var SHA256 = CryptoJS.lib.Hasher._createHelper(CryptoJS.algo.SHA256);
	         */
	        _createHelper: function (hasher) {
	            return function (message, cfg) {
	                return new hasher.init(cfg).finalize(message);
	            };
	        },

	        /**
	         * Creates a shortcut function to the HMAC's object interface.
	         *
	         * @param {Hasher} hasher The hasher to use in this HMAC helper.
	         *
	         * @return {Function} The shortcut function.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var HmacSHA256 = CryptoJS.lib.Hasher._createHmacHelper(CryptoJS.algo.SHA256);
	         */
	        _createHmacHelper: function (hasher) {
	            return function (message, key) {
	                return new C_algo.HMAC.init(hasher, key).finalize(message);
	            };
	        }
	    });

	    /**
	     * Algorithm namespace.
	     */
	    var C_algo = C.algo = {};

	    return C;
	}(Math));


	return CryptoJS;

}));

/***/ }),
/* 124 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123));
	}
	else {}
}(this, function (CryptoJS) {

	(function (undefined) {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var Base = C_lib.Base;
	    var X32WordArray = C_lib.WordArray;

	    /**
	     * x64 namespace.
	     */
	    var C_x64 = C.x64 = {};

	    /**
	     * A 64-bit word.
	     */
	    var X64Word = C_x64.Word = Base.extend({
	        /**
	         * Initializes a newly created 64-bit word.
	         *
	         * @param {number} high The high 32 bits.
	         * @param {number} low The low 32 bits.
	         *
	         * @example
	         *
	         *     var x64Word = CryptoJS.x64.Word.create(0x00010203, 0x04050607);
	         */
	        init: function (high, low) {
	            this.high = high;
	            this.low = low;
	        }

	        /**
	         * Bitwise NOTs this word.
	         *
	         * @return {X64Word} A new x64-Word object after negating.
	         *
	         * @example
	         *
	         *     var negated = x64Word.not();
	         */
	        // not: function () {
	            // var high = ~this.high;
	            // var low = ~this.low;

	            // return X64Word.create(high, low);
	        // },

	        /**
	         * Bitwise ANDs this word with the passed word.
	         *
	         * @param {X64Word} word The x64-Word to AND with this word.
	         *
	         * @return {X64Word} A new x64-Word object after ANDing.
	         *
	         * @example
	         *
	         *     var anded = x64Word.and(anotherX64Word);
	         */
	        // and: function (word) {
	            // var high = this.high & word.high;
	            // var low = this.low & word.low;

	            // return X64Word.create(high, low);
	        // },

	        /**
	         * Bitwise ORs this word with the passed word.
	         *
	         * @param {X64Word} word The x64-Word to OR with this word.
	         *
	         * @return {X64Word} A new x64-Word object after ORing.
	         *
	         * @example
	         *
	         *     var ored = x64Word.or(anotherX64Word);
	         */
	        // or: function (word) {
	            // var high = this.high | word.high;
	            // var low = this.low | word.low;

	            // return X64Word.create(high, low);
	        // },

	        /**
	         * Bitwise XORs this word with the passed word.
	         *
	         * @param {X64Word} word The x64-Word to XOR with this word.
	         *
	         * @return {X64Word} A new x64-Word object after XORing.
	         *
	         * @example
	         *
	         *     var xored = x64Word.xor(anotherX64Word);
	         */
	        // xor: function (word) {
	            // var high = this.high ^ word.high;
	            // var low = this.low ^ word.low;

	            // return X64Word.create(high, low);
	        // },

	        /**
	         * Shifts this word n bits to the left.
	         *
	         * @param {number} n The number of bits to shift.
	         *
	         * @return {X64Word} A new x64-Word object after shifting.
	         *
	         * @example
	         *
	         *     var shifted = x64Word.shiftL(25);
	         */
	        // shiftL: function (n) {
	            // if (n < 32) {
	                // var high = (this.high << n) | (this.low >>> (32 - n));
	                // var low = this.low << n;
	            // } else {
	                // var high = this.low << (n - 32);
	                // var low = 0;
	            // }

	            // return X64Word.create(high, low);
	        // },

	        /**
	         * Shifts this word n bits to the right.
	         *
	         * @param {number} n The number of bits to shift.
	         *
	         * @return {X64Word} A new x64-Word object after shifting.
	         *
	         * @example
	         *
	         *     var shifted = x64Word.shiftR(7);
	         */
	        // shiftR: function (n) {
	            // if (n < 32) {
	                // var low = (this.low >>> n) | (this.high << (32 - n));
	                // var high = this.high >>> n;
	            // } else {
	                // var low = this.high >>> (n - 32);
	                // var high = 0;
	            // }

	            // return X64Word.create(high, low);
	        // },

	        /**
	         * Rotates this word n bits to the left.
	         *
	         * @param {number} n The number of bits to rotate.
	         *
	         * @return {X64Word} A new x64-Word object after rotating.
	         *
	         * @example
	         *
	         *     var rotated = x64Word.rotL(25);
	         */
	        // rotL: function (n) {
	            // return this.shiftL(n).or(this.shiftR(64 - n));
	        // },

	        /**
	         * Rotates this word n bits to the right.
	         *
	         * @param {number} n The number of bits to rotate.
	         *
	         * @return {X64Word} A new x64-Word object after rotating.
	         *
	         * @example
	         *
	         *     var rotated = x64Word.rotR(7);
	         */
	        // rotR: function (n) {
	            // return this.shiftR(n).or(this.shiftL(64 - n));
	        // },

	        /**
	         * Adds this word with the passed word.
	         *
	         * @param {X64Word} word The x64-Word to add with this word.
	         *
	         * @return {X64Word} A new x64-Word object after adding.
	         *
	         * @example
	         *
	         *     var added = x64Word.add(anotherX64Word);
	         */
	        // add: function (word) {
	            // var low = (this.low + word.low) | 0;
	            // var carry = (low >>> 0) < (this.low >>> 0) ? 1 : 0;
	            // var high = (this.high + word.high + carry) | 0;

	            // return X64Word.create(high, low);
	        // }
	    });

	    /**
	     * An array of 64-bit words.
	     *
	     * @property {Array} words The array of CryptoJS.x64.Word objects.
	     * @property {number} sigBytes The number of significant bytes in this word array.
	     */
	    var X64WordArray = C_x64.WordArray = Base.extend({
	        /**
	         * Initializes a newly created word array.
	         *
	         * @param {Array} words (Optional) An array of CryptoJS.x64.Word objects.
	         * @param {number} sigBytes (Optional) The number of significant bytes in the words.
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.x64.WordArray.create();
	         *
	         *     var wordArray = CryptoJS.x64.WordArray.create([
	         *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
	         *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
	         *     ]);
	         *
	         *     var wordArray = CryptoJS.x64.WordArray.create([
	         *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
	         *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
	         *     ], 10);
	         */
	        init: function (words, sigBytes) {
	            words = this.words = words || [];

	            if (sigBytes != undefined) {
	                this.sigBytes = sigBytes;
	            } else {
	                this.sigBytes = words.length * 8;
	            }
	        },

	        /**
	         * Converts this 64-bit word array to a 32-bit word array.
	         *
	         * @return {CryptoJS.lib.WordArray} This word array's data as a 32-bit word array.
	         *
	         * @example
	         *
	         *     var x32WordArray = x64WordArray.toX32();
	         */
	        toX32: function () {
	            // Shortcuts
	            var x64Words = this.words;
	            var x64WordsLength = x64Words.length;

	            // Convert
	            var x32Words = [];
	            for (var i = 0; i < x64WordsLength; i++) {
	                var x64Word = x64Words[i];
	                x32Words.push(x64Word.high);
	                x32Words.push(x64Word.low);
	            }

	            return X32WordArray.create(x32Words, this.sigBytes);
	        },

	        /**
	         * Creates a copy of this word array.
	         *
	         * @return {X64WordArray} The clone.
	         *
	         * @example
	         *
	         *     var clone = x64WordArray.clone();
	         */
	        clone: function () {
	            var clone = Base.clone.call(this);

	            // Clone "words" array
	            var words = clone.words = this.words.slice(0);

	            // Clone each X64Word object
	            var wordsLength = words.length;
	            for (var i = 0; i < wordsLength; i++) {
	                words[i] = words[i].clone();
	            }

	            return clone;
	        }
	    });
	}());


	return CryptoJS;

}));

/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Check if typed arrays are supported
	    if (typeof ArrayBuffer != 'function') {
	        return;
	    }

	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;

	    // Reference original init
	    var superInit = WordArray.init;

	    // Augment WordArray.init to handle typed arrays
	    var subInit = WordArray.init = function (typedArray) {
	        // Convert buffers to uint8
	        if (typedArray instanceof ArrayBuffer) {
	            typedArray = new Uint8Array(typedArray);
	        }

	        // Convert other array views to uint8
	        if (
	            typedArray instanceof Int8Array ||
	            (typeof Uint8ClampedArray !== "undefined" && typedArray instanceof Uint8ClampedArray) ||
	            typedArray instanceof Int16Array ||
	            typedArray instanceof Uint16Array ||
	            typedArray instanceof Int32Array ||
	            typedArray instanceof Uint32Array ||
	            typedArray instanceof Float32Array ||
	            typedArray instanceof Float64Array
	        ) {
	            typedArray = new Uint8Array(typedArray.buffer, typedArray.byteOffset, typedArray.byteLength);
	        }

	        // Handle Uint8Array
	        if (typedArray instanceof Uint8Array) {
	            // Shortcut
	            var typedArrayByteLength = typedArray.byteLength;

	            // Extract bytes
	            var words = [];
	            for (var i = 0; i < typedArrayByteLength; i++) {
	                words[i >>> 2] |= typedArray[i] << (24 - (i % 4) * 8);
	            }

	            // Initialize this word array
	            superInit.call(this, words, typedArrayByteLength);
	        } else {
	            // Else call normal init
	            superInit.apply(this, arguments);
	        }
	    };

	    subInit.prototype = WordArray;
	}());


	return CryptoJS.lib.WordArray;

}));

/***/ }),
/* 126 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;
	    var C_enc = C.enc;

	    /**
	     * UTF-16 BE encoding strategy.
	     */
	    var Utf16BE = C_enc.Utf16 = C_enc.Utf16BE = {
	        /**
	         * Converts a word array to a UTF-16 BE string.
	         *
	         * @param {WordArray} wordArray The word array.
	         *
	         * @return {string} The UTF-16 BE string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var utf16String = CryptoJS.enc.Utf16.stringify(wordArray);
	         */
	        stringify: function (wordArray) {
	            // Shortcuts
	            var words = wordArray.words;
	            var sigBytes = wordArray.sigBytes;

	            // Convert
	            var utf16Chars = [];
	            for (var i = 0; i < sigBytes; i += 2) {
	                var codePoint = (words[i >>> 2] >>> (16 - (i % 4) * 8)) & 0xffff;
	                utf16Chars.push(String.fromCharCode(codePoint));
	            }

	            return utf16Chars.join('');
	        },

	        /**
	         * Converts a UTF-16 BE string to a word array.
	         *
	         * @param {string} utf16Str The UTF-16 BE string.
	         *
	         * @return {WordArray} The word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.enc.Utf16.parse(utf16String);
	         */
	        parse: function (utf16Str) {
	            // Shortcut
	            var utf16StrLength = utf16Str.length;

	            // Convert
	            var words = [];
	            for (var i = 0; i < utf16StrLength; i++) {
	                words[i >>> 1] |= utf16Str.charCodeAt(i) << (16 - (i % 2) * 16);
	            }

	            return WordArray.create(words, utf16StrLength * 2);
	        }
	    };

	    /**
	     * UTF-16 LE encoding strategy.
	     */
	    C_enc.Utf16LE = {
	        /**
	         * Converts a word array to a UTF-16 LE string.
	         *
	         * @param {WordArray} wordArray The word array.
	         *
	         * @return {string} The UTF-16 LE string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var utf16Str = CryptoJS.enc.Utf16LE.stringify(wordArray);
	         */
	        stringify: function (wordArray) {
	            // Shortcuts
	            var words = wordArray.words;
	            var sigBytes = wordArray.sigBytes;

	            // Convert
	            var utf16Chars = [];
	            for (var i = 0; i < sigBytes; i += 2) {
	                var codePoint = swapEndian((words[i >>> 2] >>> (16 - (i % 4) * 8)) & 0xffff);
	                utf16Chars.push(String.fromCharCode(codePoint));
	            }

	            return utf16Chars.join('');
	        },

	        /**
	         * Converts a UTF-16 LE string to a word array.
	         *
	         * @param {string} utf16Str The UTF-16 LE string.
	         *
	         * @return {WordArray} The word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.enc.Utf16LE.parse(utf16Str);
	         */
	        parse: function (utf16Str) {
	            // Shortcut
	            var utf16StrLength = utf16Str.length;

	            // Convert
	            var words = [];
	            for (var i = 0; i < utf16StrLength; i++) {
	                words[i >>> 1] |= swapEndian(utf16Str.charCodeAt(i) << (16 - (i % 2) * 16));
	            }

	            return WordArray.create(words, utf16StrLength * 2);
	        }
	    };

	    function swapEndian(word) {
	        return ((word << 8) & 0xff00ff00) | ((word >>> 8) & 0x00ff00ff);
	    }
	}());


	return CryptoJS.enc.Utf16;

}));

/***/ }),
/* 127 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;
	    var C_enc = C.enc;

	    /**
	     * Base64 encoding strategy.
	     */
	    var Base64 = C_enc.Base64 = {
	        /**
	         * Converts a word array to a Base64 string.
	         *
	         * @param {WordArray} wordArray The word array.
	         *
	         * @return {string} The Base64 string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var base64String = CryptoJS.enc.Base64.stringify(wordArray);
	         */
	        stringify: function (wordArray) {
	            // Shortcuts
	            var words = wordArray.words;
	            var sigBytes = wordArray.sigBytes;
	            var map = this._map;

	            // Clamp excess bits
	            wordArray.clamp();

	            // Convert
	            var base64Chars = [];
	            for (var i = 0; i < sigBytes; i += 3) {
	                var byte1 = (words[i >>> 2]       >>> (24 - (i % 4) * 8))       & 0xff;
	                var byte2 = (words[(i + 1) >>> 2] >>> (24 - ((i + 1) % 4) * 8)) & 0xff;
	                var byte3 = (words[(i + 2) >>> 2] >>> (24 - ((i + 2) % 4) * 8)) & 0xff;

	                var triplet = (byte1 << 16) | (byte2 << 8) | byte3;

	                for (var j = 0; (j < 4) && (i + j * 0.75 < sigBytes); j++) {
	                    base64Chars.push(map.charAt((triplet >>> (6 * (3 - j))) & 0x3f));
	                }
	            }

	            // Add padding
	            var paddingChar = map.charAt(64);
	            if (paddingChar) {
	                while (base64Chars.length % 4) {
	                    base64Chars.push(paddingChar);
	                }
	            }

	            return base64Chars.join('');
	        },

	        /**
	         * Converts a Base64 string to a word array.
	         *
	         * @param {string} base64Str The Base64 string.
	         *
	         * @return {WordArray} The word array.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var wordArray = CryptoJS.enc.Base64.parse(base64String);
	         */
	        parse: function (base64Str) {
	            // Shortcuts
	            var base64StrLength = base64Str.length;
	            var map = this._map;
	            var reverseMap = this._reverseMap;

	            if (!reverseMap) {
	                    reverseMap = this._reverseMap = [];
	                    for (var j = 0; j < map.length; j++) {
	                        reverseMap[map.charCodeAt(j)] = j;
	                    }
	            }

	            // Ignore padding
	            var paddingChar = map.charAt(64);
	            if (paddingChar) {
	                var paddingIndex = base64Str.indexOf(paddingChar);
	                if (paddingIndex !== -1) {
	                    base64StrLength = paddingIndex;
	                }
	            }

	            // Convert
	            return parseLoop(base64Str, base64StrLength, reverseMap);

	        },

	        _map: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
	    };

	    function parseLoop(base64Str, base64StrLength, reverseMap) {
	      var words = [];
	      var nBytes = 0;
	      for (var i = 0; i < base64StrLength; i++) {
	          if (i % 4) {
	              var bits1 = reverseMap[base64Str.charCodeAt(i - 1)] << ((i % 4) * 2);
	              var bits2 = reverseMap[base64Str.charCodeAt(i)] >>> (6 - (i % 4) * 2);
	              words[nBytes >>> 2] |= (bits1 | bits2) << (24 - (nBytes % 4) * 8);
	              nBytes++;
	          }
	      }
	      return WordArray.create(words, nBytes);
	    }
	}());


	return CryptoJS.enc.Base64;

}));

/***/ }),
/* 128 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123));
	}
	else {}
}(this, function (CryptoJS) {

	(function (Math) {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;
	    var Hasher = C_lib.Hasher;
	    var C_algo = C.algo;

	    // Constants table
	    var T = [];

	    // Compute constants
	    (function () {
	        for (var i = 0; i < 64; i++) {
	            T[i] = (Math.abs(Math.sin(i + 1)) * 0x100000000) | 0;
	        }
	    }());

	    /**
	     * MD5 hash algorithm.
	     */
	    var MD5 = C_algo.MD5 = Hasher.extend({
	        _doReset: function () {
	            this._hash = new WordArray.init([
	                0x67452301, 0xefcdab89,
	                0x98badcfe, 0x10325476
	            ]);
	        },

	        _doProcessBlock: function (M, offset) {
	            // Swap endian
	            for (var i = 0; i < 16; i++) {
	                // Shortcuts
	                var offset_i = offset + i;
	                var M_offset_i = M[offset_i];

	                M[offset_i] = (
	                    (((M_offset_i << 8)  | (M_offset_i >>> 24)) & 0x00ff00ff) |
	                    (((M_offset_i << 24) | (M_offset_i >>> 8))  & 0xff00ff00)
	                );
	            }

	            // Shortcuts
	            var H = this._hash.words;

	            var M_offset_0  = M[offset + 0];
	            var M_offset_1  = M[offset + 1];
	            var M_offset_2  = M[offset + 2];
	            var M_offset_3  = M[offset + 3];
	            var M_offset_4  = M[offset + 4];
	            var M_offset_5  = M[offset + 5];
	            var M_offset_6  = M[offset + 6];
	            var M_offset_7  = M[offset + 7];
	            var M_offset_8  = M[offset + 8];
	            var M_offset_9  = M[offset + 9];
	            var M_offset_10 = M[offset + 10];
	            var M_offset_11 = M[offset + 11];
	            var M_offset_12 = M[offset + 12];
	            var M_offset_13 = M[offset + 13];
	            var M_offset_14 = M[offset + 14];
	            var M_offset_15 = M[offset + 15];

	            // Working varialbes
	            var a = H[0];
	            var b = H[1];
	            var c = H[2];
	            var d = H[3];

	            // Computation
	            a = FF(a, b, c, d, M_offset_0,  7,  T[0]);
	            d = FF(d, a, b, c, M_offset_1,  12, T[1]);
	            c = FF(c, d, a, b, M_offset_2,  17, T[2]);
	            b = FF(b, c, d, a, M_offset_3,  22, T[3]);
	            a = FF(a, b, c, d, M_offset_4,  7,  T[4]);
	            d = FF(d, a, b, c, M_offset_5,  12, T[5]);
	            c = FF(c, d, a, b, M_offset_6,  17, T[6]);
	            b = FF(b, c, d, a, M_offset_7,  22, T[7]);
	            a = FF(a, b, c, d, M_offset_8,  7,  T[8]);
	            d = FF(d, a, b, c, M_offset_9,  12, T[9]);
	            c = FF(c, d, a, b, M_offset_10, 17, T[10]);
	            b = FF(b, c, d, a, M_offset_11, 22, T[11]);
	            a = FF(a, b, c, d, M_offset_12, 7,  T[12]);
	            d = FF(d, a, b, c, M_offset_13, 12, T[13]);
	            c = FF(c, d, a, b, M_offset_14, 17, T[14]);
	            b = FF(b, c, d, a, M_offset_15, 22, T[15]);

	            a = GG(a, b, c, d, M_offset_1,  5,  T[16]);
	            d = GG(d, a, b, c, M_offset_6,  9,  T[17]);
	            c = GG(c, d, a, b, M_offset_11, 14, T[18]);
	            b = GG(b, c, d, a, M_offset_0,  20, T[19]);
	            a = GG(a, b, c, d, M_offset_5,  5,  T[20]);
	            d = GG(d, a, b, c, M_offset_10, 9,  T[21]);
	            c = GG(c, d, a, b, M_offset_15, 14, T[22]);
	            b = GG(b, c, d, a, M_offset_4,  20, T[23]);
	            a = GG(a, b, c, d, M_offset_9,  5,  T[24]);
	            d = GG(d, a, b, c, M_offset_14, 9,  T[25]);
	            c = GG(c, d, a, b, M_offset_3,  14, T[26]);
	            b = GG(b, c, d, a, M_offset_8,  20, T[27]);
	            a = GG(a, b, c, d, M_offset_13, 5,  T[28]);
	            d = GG(d, a, b, c, M_offset_2,  9,  T[29]);
	            c = GG(c, d, a, b, M_offset_7,  14, T[30]);
	            b = GG(b, c, d, a, M_offset_12, 20, T[31]);

	            a = HH(a, b, c, d, M_offset_5,  4,  T[32]);
	            d = HH(d, a, b, c, M_offset_8,  11, T[33]);
	            c = HH(c, d, a, b, M_offset_11, 16, T[34]);
	            b = HH(b, c, d, a, M_offset_14, 23, T[35]);
	            a = HH(a, b, c, d, M_offset_1,  4,  T[36]);
	            d = HH(d, a, b, c, M_offset_4,  11, T[37]);
	            c = HH(c, d, a, b, M_offset_7,  16, T[38]);
	            b = HH(b, c, d, a, M_offset_10, 23, T[39]);
	            a = HH(a, b, c, d, M_offset_13, 4,  T[40]);
	            d = HH(d, a, b, c, M_offset_0,  11, T[41]);
	            c = HH(c, d, a, b, M_offset_3,  16, T[42]);
	            b = HH(b, c, d, a, M_offset_6,  23, T[43]);
	            a = HH(a, b, c, d, M_offset_9,  4,  T[44]);
	            d = HH(d, a, b, c, M_offset_12, 11, T[45]);
	            c = HH(c, d, a, b, M_offset_15, 16, T[46]);
	            b = HH(b, c, d, a, M_offset_2,  23, T[47]);

	            a = II(a, b, c, d, M_offset_0,  6,  T[48]);
	            d = II(d, a, b, c, M_offset_7,  10, T[49]);
	            c = II(c, d, a, b, M_offset_14, 15, T[50]);
	            b = II(b, c, d, a, M_offset_5,  21, T[51]);
	            a = II(a, b, c, d, M_offset_12, 6,  T[52]);
	            d = II(d, a, b, c, M_offset_3,  10, T[53]);
	            c = II(c, d, a, b, M_offset_10, 15, T[54]);
	            b = II(b, c, d, a, M_offset_1,  21, T[55]);
	            a = II(a, b, c, d, M_offset_8,  6,  T[56]);
	            d = II(d, a, b, c, M_offset_15, 10, T[57]);
	            c = II(c, d, a, b, M_offset_6,  15, T[58]);
	            b = II(b, c, d, a, M_offset_13, 21, T[59]);
	            a = II(a, b, c, d, M_offset_4,  6,  T[60]);
	            d = II(d, a, b, c, M_offset_11, 10, T[61]);
	            c = II(c, d, a, b, M_offset_2,  15, T[62]);
	            b = II(b, c, d, a, M_offset_9,  21, T[63]);

	            // Intermediate hash value
	            H[0] = (H[0] + a) | 0;
	            H[1] = (H[1] + b) | 0;
	            H[2] = (H[2] + c) | 0;
	            H[3] = (H[3] + d) | 0;
	        },

	        _doFinalize: function () {
	            // Shortcuts
	            var data = this._data;
	            var dataWords = data.words;

	            var nBitsTotal = this._nDataBytes * 8;
	            var nBitsLeft = data.sigBytes * 8;

	            // Add padding
	            dataWords[nBitsLeft >>> 5] |= 0x80 << (24 - nBitsLeft % 32);

	            var nBitsTotalH = Math.floor(nBitsTotal / 0x100000000);
	            var nBitsTotalL = nBitsTotal;
	            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 15] = (
	                (((nBitsTotalH << 8)  | (nBitsTotalH >>> 24)) & 0x00ff00ff) |
	                (((nBitsTotalH << 24) | (nBitsTotalH >>> 8))  & 0xff00ff00)
	            );
	            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 14] = (
	                (((nBitsTotalL << 8)  | (nBitsTotalL >>> 24)) & 0x00ff00ff) |
	                (((nBitsTotalL << 24) | (nBitsTotalL >>> 8))  & 0xff00ff00)
	            );

	            data.sigBytes = (dataWords.length + 1) * 4;

	            // Hash final blocks
	            this._process();

	            // Shortcuts
	            var hash = this._hash;
	            var H = hash.words;

	            // Swap endian
	            for (var i = 0; i < 4; i++) {
	                // Shortcut
	                var H_i = H[i];

	                H[i] = (((H_i << 8)  | (H_i >>> 24)) & 0x00ff00ff) |
	                       (((H_i << 24) | (H_i >>> 8))  & 0xff00ff00);
	            }

	            // Return final computed hash
	            return hash;
	        },

	        clone: function () {
	            var clone = Hasher.clone.call(this);
	            clone._hash = this._hash.clone();

	            return clone;
	        }
	    });

	    function FF(a, b, c, d, x, s, t) {
	        var n = a + ((b & c) | (~b & d)) + x + t;
	        return ((n << s) | (n >>> (32 - s))) + b;
	    }

	    function GG(a, b, c, d, x, s, t) {
	        var n = a + ((b & d) | (c & ~d)) + x + t;
	        return ((n << s) | (n >>> (32 - s))) + b;
	    }

	    function HH(a, b, c, d, x, s, t) {
	        var n = a + (b ^ c ^ d) + x + t;
	        return ((n << s) | (n >>> (32 - s))) + b;
	    }

	    function II(a, b, c, d, x, s, t) {
	        var n = a + (c ^ (b | ~d)) + x + t;
	        return ((n << s) | (n >>> (32 - s))) + b;
	    }

	    /**
	     * Shortcut function to the hasher's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     *
	     * @return {WordArray} The hash.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hash = CryptoJS.MD5('message');
	     *     var hash = CryptoJS.MD5(wordArray);
	     */
	    C.MD5 = Hasher._createHelper(MD5);

	    /**
	     * Shortcut function to the HMAC's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     * @param {WordArray|string} key The secret key.
	     *
	     * @return {WordArray} The HMAC.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hmac = CryptoJS.HmacMD5(message, key);
	     */
	    C.HmacMD5 = Hasher._createHmacHelper(MD5);
	}(Math));


	return CryptoJS.MD5;

}));

/***/ }),
/* 129 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;
	    var Hasher = C_lib.Hasher;
	    var C_algo = C.algo;

	    // Reusable object
	    var W = [];

	    /**
	     * SHA-1 hash algorithm.
	     */
	    var SHA1 = C_algo.SHA1 = Hasher.extend({
	        _doReset: function () {
	            this._hash = new WordArray.init([
	                0x67452301, 0xefcdab89,
	                0x98badcfe, 0x10325476,
	                0xc3d2e1f0
	            ]);
	        },

	        _doProcessBlock: function (M, offset) {
	            // Shortcut
	            var H = this._hash.words;

	            // Working variables
	            var a = H[0];
	            var b = H[1];
	            var c = H[2];
	            var d = H[3];
	            var e = H[4];

	            // Computation
	            for (var i = 0; i < 80; i++) {
	                if (i < 16) {
	                    W[i] = M[offset + i] | 0;
	                } else {
	                    var n = W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16];
	                    W[i] = (n << 1) | (n >>> 31);
	                }

	                var t = ((a << 5) | (a >>> 27)) + e + W[i];
	                if (i < 20) {
	                    t += ((b & c) | (~b & d)) + 0x5a827999;
	                } else if (i < 40) {
	                    t += (b ^ c ^ d) + 0x6ed9eba1;
	                } else if (i < 60) {
	                    t += ((b & c) | (b & d) | (c & d)) - 0x70e44324;
	                } else /* if (i < 80) */ {
	                    t += (b ^ c ^ d) - 0x359d3e2a;
	                }

	                e = d;
	                d = c;
	                c = (b << 30) | (b >>> 2);
	                b = a;
	                a = t;
	            }

	            // Intermediate hash value
	            H[0] = (H[0] + a) | 0;
	            H[1] = (H[1] + b) | 0;
	            H[2] = (H[2] + c) | 0;
	            H[3] = (H[3] + d) | 0;
	            H[4] = (H[4] + e) | 0;
	        },

	        _doFinalize: function () {
	            // Shortcuts
	            var data = this._data;
	            var dataWords = data.words;

	            var nBitsTotal = this._nDataBytes * 8;
	            var nBitsLeft = data.sigBytes * 8;

	            // Add padding
	            dataWords[nBitsLeft >>> 5] |= 0x80 << (24 - nBitsLeft % 32);
	            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 14] = Math.floor(nBitsTotal / 0x100000000);
	            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 15] = nBitsTotal;
	            data.sigBytes = dataWords.length * 4;

	            // Hash final blocks
	            this._process();

	            // Return final computed hash
	            return this._hash;
	        },

	        clone: function () {
	            var clone = Hasher.clone.call(this);
	            clone._hash = this._hash.clone();

	            return clone;
	        }
	    });

	    /**
	     * Shortcut function to the hasher's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     *
	     * @return {WordArray} The hash.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hash = CryptoJS.SHA1('message');
	     *     var hash = CryptoJS.SHA1(wordArray);
	     */
	    C.SHA1 = Hasher._createHelper(SHA1);

	    /**
	     * Shortcut function to the HMAC's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     * @param {WordArray|string} key The secret key.
	     *
	     * @return {WordArray} The HMAC.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hmac = CryptoJS.HmacSHA1(message, key);
	     */
	    C.HmacSHA1 = Hasher._createHmacHelper(SHA1);
	}());


	return CryptoJS.SHA1;

}));

/***/ }),
/* 130 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123));
	}
	else {}
}(this, function (CryptoJS) {

	(function (Math) {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;
	    var Hasher = C_lib.Hasher;
	    var C_algo = C.algo;

	    // Initialization and round constants tables
	    var H = [];
	    var K = [];

	    // Compute constants
	    (function () {
	        function isPrime(n) {
	            var sqrtN = Math.sqrt(n);
	            for (var factor = 2; factor <= sqrtN; factor++) {
	                if (!(n % factor)) {
	                    return false;
	                }
	            }

	            return true;
	        }

	        function getFractionalBits(n) {
	            return ((n - (n | 0)) * 0x100000000) | 0;
	        }

	        var n = 2;
	        var nPrime = 0;
	        while (nPrime < 64) {
	            if (isPrime(n)) {
	                if (nPrime < 8) {
	                    H[nPrime] = getFractionalBits(Math.pow(n, 1 / 2));
	                }
	                K[nPrime] = getFractionalBits(Math.pow(n, 1 / 3));

	                nPrime++;
	            }

	            n++;
	        }
	    }());

	    // Reusable object
	    var W = [];

	    /**
	     * SHA-256 hash algorithm.
	     */
	    var SHA256 = C_algo.SHA256 = Hasher.extend({
	        _doReset: function () {
	            this._hash = new WordArray.init(H.slice(0));
	        },

	        _doProcessBlock: function (M, offset) {
	            // Shortcut
	            var H = this._hash.words;

	            // Working variables
	            var a = H[0];
	            var b = H[1];
	            var c = H[2];
	            var d = H[3];
	            var e = H[4];
	            var f = H[5];
	            var g = H[6];
	            var h = H[7];

	            // Computation
	            for (var i = 0; i < 64; i++) {
	                if (i < 16) {
	                    W[i] = M[offset + i] | 0;
	                } else {
	                    var gamma0x = W[i - 15];
	                    var gamma0  = ((gamma0x << 25) | (gamma0x >>> 7))  ^
	                                  ((gamma0x << 14) | (gamma0x >>> 18)) ^
	                                   (gamma0x >>> 3);

	                    var gamma1x = W[i - 2];
	                    var gamma1  = ((gamma1x << 15) | (gamma1x >>> 17)) ^
	                                  ((gamma1x << 13) | (gamma1x >>> 19)) ^
	                                   (gamma1x >>> 10);

	                    W[i] = gamma0 + W[i - 7] + gamma1 + W[i - 16];
	                }

	                var ch  = (e & f) ^ (~e & g);
	                var maj = (a & b) ^ (a & c) ^ (b & c);

	                var sigma0 = ((a << 30) | (a >>> 2)) ^ ((a << 19) | (a >>> 13)) ^ ((a << 10) | (a >>> 22));
	                var sigma1 = ((e << 26) | (e >>> 6)) ^ ((e << 21) | (e >>> 11)) ^ ((e << 7)  | (e >>> 25));

	                var t1 = h + sigma1 + ch + K[i] + W[i];
	                var t2 = sigma0 + maj;

	                h = g;
	                g = f;
	                f = e;
	                e = (d + t1) | 0;
	                d = c;
	                c = b;
	                b = a;
	                a = (t1 + t2) | 0;
	            }

	            // Intermediate hash value
	            H[0] = (H[0] + a) | 0;
	            H[1] = (H[1] + b) | 0;
	            H[2] = (H[2] + c) | 0;
	            H[3] = (H[3] + d) | 0;
	            H[4] = (H[4] + e) | 0;
	            H[5] = (H[5] + f) | 0;
	            H[6] = (H[6] + g) | 0;
	            H[7] = (H[7] + h) | 0;
	        },

	        _doFinalize: function () {
	            // Shortcuts
	            var data = this._data;
	            var dataWords = data.words;

	            var nBitsTotal = this._nDataBytes * 8;
	            var nBitsLeft = data.sigBytes * 8;

	            // Add padding
	            dataWords[nBitsLeft >>> 5] |= 0x80 << (24 - nBitsLeft % 32);
	            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 14] = Math.floor(nBitsTotal / 0x100000000);
	            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 15] = nBitsTotal;
	            data.sigBytes = dataWords.length * 4;

	            // Hash final blocks
	            this._process();

	            // Return final computed hash
	            return this._hash;
	        },

	        clone: function () {
	            var clone = Hasher.clone.call(this);
	            clone._hash = this._hash.clone();

	            return clone;
	        }
	    });

	    /**
	     * Shortcut function to the hasher's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     *
	     * @return {WordArray} The hash.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hash = CryptoJS.SHA256('message');
	     *     var hash = CryptoJS.SHA256(wordArray);
	     */
	    C.SHA256 = Hasher._createHelper(SHA256);

	    /**
	     * Shortcut function to the HMAC's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     * @param {WordArray|string} key The secret key.
	     *
	     * @return {WordArray} The HMAC.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hmac = CryptoJS.HmacSHA256(message, key);
	     */
	    C.HmacSHA256 = Hasher._createHmacHelper(SHA256);
	}(Math));


	return CryptoJS.SHA256;

}));

/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(130));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;
	    var C_algo = C.algo;
	    var SHA256 = C_algo.SHA256;

	    /**
	     * SHA-224 hash algorithm.
	     */
	    var SHA224 = C_algo.SHA224 = SHA256.extend({
	        _doReset: function () {
	            this._hash = new WordArray.init([
	                0xc1059ed8, 0x367cd507, 0x3070dd17, 0xf70e5939,
	                0xffc00b31, 0x68581511, 0x64f98fa7, 0xbefa4fa4
	            ]);
	        },

	        _doFinalize: function () {
	            var hash = SHA256._doFinalize.call(this);

	            hash.sigBytes -= 4;

	            return hash;
	        }
	    });

	    /**
	     * Shortcut function to the hasher's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     *
	     * @return {WordArray} The hash.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hash = CryptoJS.SHA224('message');
	     *     var hash = CryptoJS.SHA224(wordArray);
	     */
	    C.SHA224 = SHA256._createHelper(SHA224);

	    /**
	     * Shortcut function to the HMAC's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     * @param {WordArray|string} key The secret key.
	     *
	     * @return {WordArray} The HMAC.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hmac = CryptoJS.HmacSHA224(message, key);
	     */
	    C.HmacSHA224 = SHA256._createHmacHelper(SHA224);
	}());


	return CryptoJS.SHA224;

}));

/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(124));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var Hasher = C_lib.Hasher;
	    var C_x64 = C.x64;
	    var X64Word = C_x64.Word;
	    var X64WordArray = C_x64.WordArray;
	    var C_algo = C.algo;

	    function X64Word_create() {
	        return X64Word.create.apply(X64Word, arguments);
	    }

	    // Constants
	    var K = [
	        X64Word_create(0x428a2f98, 0xd728ae22), X64Word_create(0x71374491, 0x23ef65cd),
	        X64Word_create(0xb5c0fbcf, 0xec4d3b2f), X64Word_create(0xe9b5dba5, 0x8189dbbc),
	        X64Word_create(0x3956c25b, 0xf348b538), X64Word_create(0x59f111f1, 0xb605d019),
	        X64Word_create(0x923f82a4, 0xaf194f9b), X64Word_create(0xab1c5ed5, 0xda6d8118),
	        X64Word_create(0xd807aa98, 0xa3030242), X64Word_create(0x12835b01, 0x45706fbe),
	        X64Word_create(0x243185be, 0x4ee4b28c), X64Word_create(0x550c7dc3, 0xd5ffb4e2),
	        X64Word_create(0x72be5d74, 0xf27b896f), X64Word_create(0x80deb1fe, 0x3b1696b1),
	        X64Word_create(0x9bdc06a7, 0x25c71235), X64Word_create(0xc19bf174, 0xcf692694),
	        X64Word_create(0xe49b69c1, 0x9ef14ad2), X64Word_create(0xefbe4786, 0x384f25e3),
	        X64Word_create(0x0fc19dc6, 0x8b8cd5b5), X64Word_create(0x240ca1cc, 0x77ac9c65),
	        X64Word_create(0x2de92c6f, 0x592b0275), X64Word_create(0x4a7484aa, 0x6ea6e483),
	        X64Word_create(0x5cb0a9dc, 0xbd41fbd4), X64Word_create(0x76f988da, 0x831153b5),
	        X64Word_create(0x983e5152, 0xee66dfab), X64Word_create(0xa831c66d, 0x2db43210),
	        X64Word_create(0xb00327c8, 0x98fb213f), X64Word_create(0xbf597fc7, 0xbeef0ee4),
	        X64Word_create(0xc6e00bf3, 0x3da88fc2), X64Word_create(0xd5a79147, 0x930aa725),
	        X64Word_create(0x06ca6351, 0xe003826f), X64Word_create(0x14292967, 0x0a0e6e70),
	        X64Word_create(0x27b70a85, 0x46d22ffc), X64Word_create(0x2e1b2138, 0x5c26c926),
	        X64Word_create(0x4d2c6dfc, 0x5ac42aed), X64Word_create(0x53380d13, 0x9d95b3df),
	        X64Word_create(0x650a7354, 0x8baf63de), X64Word_create(0x766a0abb, 0x3c77b2a8),
	        X64Word_create(0x81c2c92e, 0x47edaee6), X64Word_create(0x92722c85, 0x1482353b),
	        X64Word_create(0xa2bfe8a1, 0x4cf10364), X64Word_create(0xa81a664b, 0xbc423001),
	        X64Word_create(0xc24b8b70, 0xd0f89791), X64Word_create(0xc76c51a3, 0x0654be30),
	        X64Word_create(0xd192e819, 0xd6ef5218), X64Word_create(0xd6990624, 0x5565a910),
	        X64Word_create(0xf40e3585, 0x5771202a), X64Word_create(0x106aa070, 0x32bbd1b8),
	        X64Word_create(0x19a4c116, 0xb8d2d0c8), X64Word_create(0x1e376c08, 0x5141ab53),
	        X64Word_create(0x2748774c, 0xdf8eeb99), X64Word_create(0x34b0bcb5, 0xe19b48a8),
	        X64Word_create(0x391c0cb3, 0xc5c95a63), X64Word_create(0x4ed8aa4a, 0xe3418acb),
	        X64Word_create(0x5b9cca4f, 0x7763e373), X64Word_create(0x682e6ff3, 0xd6b2b8a3),
	        X64Word_create(0x748f82ee, 0x5defb2fc), X64Word_create(0x78a5636f, 0x43172f60),
	        X64Word_create(0x84c87814, 0xa1f0ab72), X64Word_create(0x8cc70208, 0x1a6439ec),
	        X64Word_create(0x90befffa, 0x23631e28), X64Word_create(0xa4506ceb, 0xde82bde9),
	        X64Word_create(0xbef9a3f7, 0xb2c67915), X64Word_create(0xc67178f2, 0xe372532b),
	        X64Word_create(0xca273ece, 0xea26619c), X64Word_create(0xd186b8c7, 0x21c0c207),
	        X64Word_create(0xeada7dd6, 0xcde0eb1e), X64Word_create(0xf57d4f7f, 0xee6ed178),
	        X64Word_create(0x06f067aa, 0x72176fba), X64Word_create(0x0a637dc5, 0xa2c898a6),
	        X64Word_create(0x113f9804, 0xbef90dae), X64Word_create(0x1b710b35, 0x131c471b),
	        X64Word_create(0x28db77f5, 0x23047d84), X64Word_create(0x32caab7b, 0x40c72493),
	        X64Word_create(0x3c9ebe0a, 0x15c9bebc), X64Word_create(0x431d67c4, 0x9c100d4c),
	        X64Word_create(0x4cc5d4be, 0xcb3e42b6), X64Word_create(0x597f299c, 0xfc657e2a),
	        X64Word_create(0x5fcb6fab, 0x3ad6faec), X64Word_create(0x6c44198c, 0x4a475817)
	    ];

	    // Reusable objects
	    var W = [];
	    (function () {
	        for (var i = 0; i < 80; i++) {
	            W[i] = X64Word_create();
	        }
	    }());

	    /**
	     * SHA-512 hash algorithm.
	     */
	    var SHA512 = C_algo.SHA512 = Hasher.extend({
	        _doReset: function () {
	            this._hash = new X64WordArray.init([
	                new X64Word.init(0x6a09e667, 0xf3bcc908), new X64Word.init(0xbb67ae85, 0x84caa73b),
	                new X64Word.init(0x3c6ef372, 0xfe94f82b), new X64Word.init(0xa54ff53a, 0x5f1d36f1),
	                new X64Word.init(0x510e527f, 0xade682d1), new X64Word.init(0x9b05688c, 0x2b3e6c1f),
	                new X64Word.init(0x1f83d9ab, 0xfb41bd6b), new X64Word.init(0x5be0cd19, 0x137e2179)
	            ]);
	        },

	        _doProcessBlock: function (M, offset) {
	            // Shortcuts
	            var H = this._hash.words;

	            var H0 = H[0];
	            var H1 = H[1];
	            var H2 = H[2];
	            var H3 = H[3];
	            var H4 = H[4];
	            var H5 = H[5];
	            var H6 = H[6];
	            var H7 = H[7];

	            var H0h = H0.high;
	            var H0l = H0.low;
	            var H1h = H1.high;
	            var H1l = H1.low;
	            var H2h = H2.high;
	            var H2l = H2.low;
	            var H3h = H3.high;
	            var H3l = H3.low;
	            var H4h = H4.high;
	            var H4l = H4.low;
	            var H5h = H5.high;
	            var H5l = H5.low;
	            var H6h = H6.high;
	            var H6l = H6.low;
	            var H7h = H7.high;
	            var H7l = H7.low;

	            // Working variables
	            var ah = H0h;
	            var al = H0l;
	            var bh = H1h;
	            var bl = H1l;
	            var ch = H2h;
	            var cl = H2l;
	            var dh = H3h;
	            var dl = H3l;
	            var eh = H4h;
	            var el = H4l;
	            var fh = H5h;
	            var fl = H5l;
	            var gh = H6h;
	            var gl = H6l;
	            var hh = H7h;
	            var hl = H7l;

	            // Rounds
	            for (var i = 0; i < 80; i++) {
	                // Shortcut
	                var Wi = W[i];

	                // Extend message
	                if (i < 16) {
	                    var Wih = Wi.high = M[offset + i * 2]     | 0;
	                    var Wil = Wi.low  = M[offset + i * 2 + 1] | 0;
	                } else {
	                    // Gamma0
	                    var gamma0x  = W[i - 15];
	                    var gamma0xh = gamma0x.high;
	                    var gamma0xl = gamma0x.low;
	                    var gamma0h  = ((gamma0xh >>> 1) | (gamma0xl << 31)) ^ ((gamma0xh >>> 8) | (gamma0xl << 24)) ^ (gamma0xh >>> 7);
	                    var gamma0l  = ((gamma0xl >>> 1) | (gamma0xh << 31)) ^ ((gamma0xl >>> 8) | (gamma0xh << 24)) ^ ((gamma0xl >>> 7) | (gamma0xh << 25));

	                    // Gamma1
	                    var gamma1x  = W[i - 2];
	                    var gamma1xh = gamma1x.high;
	                    var gamma1xl = gamma1x.low;
	                    var gamma1h  = ((gamma1xh >>> 19) | (gamma1xl << 13)) ^ ((gamma1xh << 3) | (gamma1xl >>> 29)) ^ (gamma1xh >>> 6);
	                    var gamma1l  = ((gamma1xl >>> 19) | (gamma1xh << 13)) ^ ((gamma1xl << 3) | (gamma1xh >>> 29)) ^ ((gamma1xl >>> 6) | (gamma1xh << 26));

	                    // W[i] = gamma0 + W[i - 7] + gamma1 + W[i - 16]
	                    var Wi7  = W[i - 7];
	                    var Wi7h = Wi7.high;
	                    var Wi7l = Wi7.low;

	                    var Wi16  = W[i - 16];
	                    var Wi16h = Wi16.high;
	                    var Wi16l = Wi16.low;

	                    var Wil = gamma0l + Wi7l;
	                    var Wih = gamma0h + Wi7h + ((Wil >>> 0) < (gamma0l >>> 0) ? 1 : 0);
	                    var Wil = Wil + gamma1l;
	                    var Wih = Wih + gamma1h + ((Wil >>> 0) < (gamma1l >>> 0) ? 1 : 0);
	                    var Wil = Wil + Wi16l;
	                    var Wih = Wih + Wi16h + ((Wil >>> 0) < (Wi16l >>> 0) ? 1 : 0);

	                    Wi.high = Wih;
	                    Wi.low  = Wil;
	                }

	                var chh  = (eh & fh) ^ (~eh & gh);
	                var chl  = (el & fl) ^ (~el & gl);
	                var majh = (ah & bh) ^ (ah & ch) ^ (bh & ch);
	                var majl = (al & bl) ^ (al & cl) ^ (bl & cl);

	                var sigma0h = ((ah >>> 28) | (al << 4))  ^ ((ah << 30)  | (al >>> 2)) ^ ((ah << 25) | (al >>> 7));
	                var sigma0l = ((al >>> 28) | (ah << 4))  ^ ((al << 30)  | (ah >>> 2)) ^ ((al << 25) | (ah >>> 7));
	                var sigma1h = ((eh >>> 14) | (el << 18)) ^ ((eh >>> 18) | (el << 14)) ^ ((eh << 23) | (el >>> 9));
	                var sigma1l = ((el >>> 14) | (eh << 18)) ^ ((el >>> 18) | (eh << 14)) ^ ((el << 23) | (eh >>> 9));

	                // t1 = h + sigma1 + ch + K[i] + W[i]
	                var Ki  = K[i];
	                var Kih = Ki.high;
	                var Kil = Ki.low;

	                var t1l = hl + sigma1l;
	                var t1h = hh + sigma1h + ((t1l >>> 0) < (hl >>> 0) ? 1 : 0);
	                var t1l = t1l + chl;
	                var t1h = t1h + chh + ((t1l >>> 0) < (chl >>> 0) ? 1 : 0);
	                var t1l = t1l + Kil;
	                var t1h = t1h + Kih + ((t1l >>> 0) < (Kil >>> 0) ? 1 : 0);
	                var t1l = t1l + Wil;
	                var t1h = t1h + Wih + ((t1l >>> 0) < (Wil >>> 0) ? 1 : 0);

	                // t2 = sigma0 + maj
	                var t2l = sigma0l + majl;
	                var t2h = sigma0h + majh + ((t2l >>> 0) < (sigma0l >>> 0) ? 1 : 0);

	                // Update working variables
	                hh = gh;
	                hl = gl;
	                gh = fh;
	                gl = fl;
	                fh = eh;
	                fl = el;
	                el = (dl + t1l) | 0;
	                eh = (dh + t1h + ((el >>> 0) < (dl >>> 0) ? 1 : 0)) | 0;
	                dh = ch;
	                dl = cl;
	                ch = bh;
	                cl = bl;
	                bh = ah;
	                bl = al;
	                al = (t1l + t2l) | 0;
	                ah = (t1h + t2h + ((al >>> 0) < (t1l >>> 0) ? 1 : 0)) | 0;
	            }

	            // Intermediate hash value
	            H0l = H0.low  = (H0l + al);
	            H0.high = (H0h + ah + ((H0l >>> 0) < (al >>> 0) ? 1 : 0));
	            H1l = H1.low  = (H1l + bl);
	            H1.high = (H1h + bh + ((H1l >>> 0) < (bl >>> 0) ? 1 : 0));
	            H2l = H2.low  = (H2l + cl);
	            H2.high = (H2h + ch + ((H2l >>> 0) < (cl >>> 0) ? 1 : 0));
	            H3l = H3.low  = (H3l + dl);
	            H3.high = (H3h + dh + ((H3l >>> 0) < (dl >>> 0) ? 1 : 0));
	            H4l = H4.low  = (H4l + el);
	            H4.high = (H4h + eh + ((H4l >>> 0) < (el >>> 0) ? 1 : 0));
	            H5l = H5.low  = (H5l + fl);
	            H5.high = (H5h + fh + ((H5l >>> 0) < (fl >>> 0) ? 1 : 0));
	            H6l = H6.low  = (H6l + gl);
	            H6.high = (H6h + gh + ((H6l >>> 0) < (gl >>> 0) ? 1 : 0));
	            H7l = H7.low  = (H7l + hl);
	            H7.high = (H7h + hh + ((H7l >>> 0) < (hl >>> 0) ? 1 : 0));
	        },

	        _doFinalize: function () {
	            // Shortcuts
	            var data = this._data;
	            var dataWords = data.words;

	            var nBitsTotal = this._nDataBytes * 8;
	            var nBitsLeft = data.sigBytes * 8;

	            // Add padding
	            dataWords[nBitsLeft >>> 5] |= 0x80 << (24 - nBitsLeft % 32);
	            dataWords[(((nBitsLeft + 128) >>> 10) << 5) + 30] = Math.floor(nBitsTotal / 0x100000000);
	            dataWords[(((nBitsLeft + 128) >>> 10) << 5) + 31] = nBitsTotal;
	            data.sigBytes = dataWords.length * 4;

	            // Hash final blocks
	            this._process();

	            // Convert hash to 32-bit word array before returning
	            var hash = this._hash.toX32();

	            // Return final computed hash
	            return hash;
	        },

	        clone: function () {
	            var clone = Hasher.clone.call(this);
	            clone._hash = this._hash.clone();

	            return clone;
	        },

	        blockSize: 1024/32
	    });

	    /**
	     * Shortcut function to the hasher's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     *
	     * @return {WordArray} The hash.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hash = CryptoJS.SHA512('message');
	     *     var hash = CryptoJS.SHA512(wordArray);
	     */
	    C.SHA512 = Hasher._createHelper(SHA512);

	    /**
	     * Shortcut function to the HMAC's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     * @param {WordArray|string} key The secret key.
	     *
	     * @return {WordArray} The HMAC.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hmac = CryptoJS.HmacSHA512(message, key);
	     */
	    C.HmacSHA512 = Hasher._createHmacHelper(SHA512);
	}());


	return CryptoJS.SHA512;

}));

/***/ }),
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(124), __webpack_require__(132));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_x64 = C.x64;
	    var X64Word = C_x64.Word;
	    var X64WordArray = C_x64.WordArray;
	    var C_algo = C.algo;
	    var SHA512 = C_algo.SHA512;

	    /**
	     * SHA-384 hash algorithm.
	     */
	    var SHA384 = C_algo.SHA384 = SHA512.extend({
	        _doReset: function () {
	            this._hash = new X64WordArray.init([
	                new X64Word.init(0xcbbb9d5d, 0xc1059ed8), new X64Word.init(0x629a292a, 0x367cd507),
	                new X64Word.init(0x9159015a, 0x3070dd17), new X64Word.init(0x152fecd8, 0xf70e5939),
	                new X64Word.init(0x67332667, 0xffc00b31), new X64Word.init(0x8eb44a87, 0x68581511),
	                new X64Word.init(0xdb0c2e0d, 0x64f98fa7), new X64Word.init(0x47b5481d, 0xbefa4fa4)
	            ]);
	        },

	        _doFinalize: function () {
	            var hash = SHA512._doFinalize.call(this);

	            hash.sigBytes -= 16;

	            return hash;
	        }
	    });

	    /**
	     * Shortcut function to the hasher's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     *
	     * @return {WordArray} The hash.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hash = CryptoJS.SHA384('message');
	     *     var hash = CryptoJS.SHA384(wordArray);
	     */
	    C.SHA384 = SHA512._createHelper(SHA384);

	    /**
	     * Shortcut function to the HMAC's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     * @param {WordArray|string} key The secret key.
	     *
	     * @return {WordArray} The HMAC.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hmac = CryptoJS.HmacSHA384(message, key);
	     */
	    C.HmacSHA384 = SHA512._createHmacHelper(SHA384);
	}());


	return CryptoJS.SHA384;

}));

/***/ }),
/* 134 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(124));
	}
	else {}
}(this, function (CryptoJS) {

	(function (Math) {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;
	    var Hasher = C_lib.Hasher;
	    var C_x64 = C.x64;
	    var X64Word = C_x64.Word;
	    var C_algo = C.algo;

	    // Constants tables
	    var RHO_OFFSETS = [];
	    var PI_INDEXES  = [];
	    var ROUND_CONSTANTS = [];

	    // Compute Constants
	    (function () {
	        // Compute rho offset constants
	        var x = 1, y = 0;
	        for (var t = 0; t < 24; t++) {
	            RHO_OFFSETS[x + 5 * y] = ((t + 1) * (t + 2) / 2) % 64;

	            var newX = y % 5;
	            var newY = (2 * x + 3 * y) % 5;
	            x = newX;
	            y = newY;
	        }

	        // Compute pi index constants
	        for (var x = 0; x < 5; x++) {
	            for (var y = 0; y < 5; y++) {
	                PI_INDEXES[x + 5 * y] = y + ((2 * x + 3 * y) % 5) * 5;
	            }
	        }

	        // Compute round constants
	        var LFSR = 0x01;
	        for (var i = 0; i < 24; i++) {
	            var roundConstantMsw = 0;
	            var roundConstantLsw = 0;

	            for (var j = 0; j < 7; j++) {
	                if (LFSR & 0x01) {
	                    var bitPosition = (1 << j) - 1;
	                    if (bitPosition < 32) {
	                        roundConstantLsw ^= 1 << bitPosition;
	                    } else /* if (bitPosition >= 32) */ {
	                        roundConstantMsw ^= 1 << (bitPosition - 32);
	                    }
	                }

	                // Compute next LFSR
	                if (LFSR & 0x80) {
	                    // Primitive polynomial over GF(2): x^8 + x^6 + x^5 + x^4 + 1
	                    LFSR = (LFSR << 1) ^ 0x71;
	                } else {
	                    LFSR <<= 1;
	                }
	            }

	            ROUND_CONSTANTS[i] = X64Word.create(roundConstantMsw, roundConstantLsw);
	        }
	    }());

	    // Reusable objects for temporary values
	    var T = [];
	    (function () {
	        for (var i = 0; i < 25; i++) {
	            T[i] = X64Word.create();
	        }
	    }());

	    /**
	     * SHA-3 hash algorithm.
	     */
	    var SHA3 = C_algo.SHA3 = Hasher.extend({
	        /**
	         * Configuration options.
	         *
	         * @property {number} outputLength
	         *   The desired number of bits in the output hash.
	         *   Only values permitted are: 224, 256, 384, 512.
	         *   Default: 512
	         */
	        cfg: Hasher.cfg.extend({
	            outputLength: 512
	        }),

	        _doReset: function () {
	            var state = this._state = []
	            for (var i = 0; i < 25; i++) {
	                state[i] = new X64Word.init();
	            }

	            this.blockSize = (1600 - 2 * this.cfg.outputLength) / 32;
	        },

	        _doProcessBlock: function (M, offset) {
	            // Shortcuts
	            var state = this._state;
	            var nBlockSizeLanes = this.blockSize / 2;

	            // Absorb
	            for (var i = 0; i < nBlockSizeLanes; i++) {
	                // Shortcuts
	                var M2i  = M[offset + 2 * i];
	                var M2i1 = M[offset + 2 * i + 1];

	                // Swap endian
	                M2i = (
	                    (((M2i << 8)  | (M2i >>> 24)) & 0x00ff00ff) |
	                    (((M2i << 24) | (M2i >>> 8))  & 0xff00ff00)
	                );
	                M2i1 = (
	                    (((M2i1 << 8)  | (M2i1 >>> 24)) & 0x00ff00ff) |
	                    (((M2i1 << 24) | (M2i1 >>> 8))  & 0xff00ff00)
	                );

	                // Absorb message into state
	                var lane = state[i];
	                lane.high ^= M2i1;
	                lane.low  ^= M2i;
	            }

	            // Rounds
	            for (var round = 0; round < 24; round++) {
	                // Theta
	                for (var x = 0; x < 5; x++) {
	                    // Mix column lanes
	                    var tMsw = 0, tLsw = 0;
	                    for (var y = 0; y < 5; y++) {
	                        var lane = state[x + 5 * y];
	                        tMsw ^= lane.high;
	                        tLsw ^= lane.low;
	                    }

	                    // Temporary values
	                    var Tx = T[x];
	                    Tx.high = tMsw;
	                    Tx.low  = tLsw;
	                }
	                for (var x = 0; x < 5; x++) {
	                    // Shortcuts
	                    var Tx4 = T[(x + 4) % 5];
	                    var Tx1 = T[(x + 1) % 5];
	                    var Tx1Msw = Tx1.high;
	                    var Tx1Lsw = Tx1.low;

	                    // Mix surrounding columns
	                    var tMsw = Tx4.high ^ ((Tx1Msw << 1) | (Tx1Lsw >>> 31));
	                    var tLsw = Tx4.low  ^ ((Tx1Lsw << 1) | (Tx1Msw >>> 31));
	                    for (var y = 0; y < 5; y++) {
	                        var lane = state[x + 5 * y];
	                        lane.high ^= tMsw;
	                        lane.low  ^= tLsw;
	                    }
	                }

	                // Rho Pi
	                for (var laneIndex = 1; laneIndex < 25; laneIndex++) {
	                    // Shortcuts
	                    var lane = state[laneIndex];
	                    var laneMsw = lane.high;
	                    var laneLsw = lane.low;
	                    var rhoOffset = RHO_OFFSETS[laneIndex];

	                    // Rotate lanes
	                    if (rhoOffset < 32) {
	                        var tMsw = (laneMsw << rhoOffset) | (laneLsw >>> (32 - rhoOffset));
	                        var tLsw = (laneLsw << rhoOffset) | (laneMsw >>> (32 - rhoOffset));
	                    } else /* if (rhoOffset >= 32) */ {
	                        var tMsw = (laneLsw << (rhoOffset - 32)) | (laneMsw >>> (64 - rhoOffset));
	                        var tLsw = (laneMsw << (rhoOffset - 32)) | (laneLsw >>> (64 - rhoOffset));
	                    }

	                    // Transpose lanes
	                    var TPiLane = T[PI_INDEXES[laneIndex]];
	                    TPiLane.high = tMsw;
	                    TPiLane.low  = tLsw;
	                }

	                // Rho pi at x = y = 0
	                var T0 = T[0];
	                var state0 = state[0];
	                T0.high = state0.high;
	                T0.low  = state0.low;

	                // Chi
	                for (var x = 0; x < 5; x++) {
	                    for (var y = 0; y < 5; y++) {
	                        // Shortcuts
	                        var laneIndex = x + 5 * y;
	                        var lane = state[laneIndex];
	                        var TLane = T[laneIndex];
	                        var Tx1Lane = T[((x + 1) % 5) + 5 * y];
	                        var Tx2Lane = T[((x + 2) % 5) + 5 * y];

	                        // Mix rows
	                        lane.high = TLane.high ^ (~Tx1Lane.high & Tx2Lane.high);
	                        lane.low  = TLane.low  ^ (~Tx1Lane.low  & Tx2Lane.low);
	                    }
	                }

	                // Iota
	                var lane = state[0];
	                var roundConstant = ROUND_CONSTANTS[round];
	                lane.high ^= roundConstant.high;
	                lane.low  ^= roundConstant.low;;
	            }
	        },

	        _doFinalize: function () {
	            // Shortcuts
	            var data = this._data;
	            var dataWords = data.words;
	            var nBitsTotal = this._nDataBytes * 8;
	            var nBitsLeft = data.sigBytes * 8;
	            var blockSizeBits = this.blockSize * 32;

	            // Add padding
	            dataWords[nBitsLeft >>> 5] |= 0x1 << (24 - nBitsLeft % 32);
	            dataWords[((Math.ceil((nBitsLeft + 1) / blockSizeBits) * blockSizeBits) >>> 5) - 1] |= 0x80;
	            data.sigBytes = dataWords.length * 4;

	            // Hash final blocks
	            this._process();

	            // Shortcuts
	            var state = this._state;
	            var outputLengthBytes = this.cfg.outputLength / 8;
	            var outputLengthLanes = outputLengthBytes / 8;

	            // Squeeze
	            var hashWords = [];
	            for (var i = 0; i < outputLengthLanes; i++) {
	                // Shortcuts
	                var lane = state[i];
	                var laneMsw = lane.high;
	                var laneLsw = lane.low;

	                // Swap endian
	                laneMsw = (
	                    (((laneMsw << 8)  | (laneMsw >>> 24)) & 0x00ff00ff) |
	                    (((laneMsw << 24) | (laneMsw >>> 8))  & 0xff00ff00)
	                );
	                laneLsw = (
	                    (((laneLsw << 8)  | (laneLsw >>> 24)) & 0x00ff00ff) |
	                    (((laneLsw << 24) | (laneLsw >>> 8))  & 0xff00ff00)
	                );

	                // Squeeze state to retrieve hash
	                hashWords.push(laneLsw);
	                hashWords.push(laneMsw);
	            }

	            // Return final computed hash
	            return new WordArray.init(hashWords, outputLengthBytes);
	        },

	        clone: function () {
	            var clone = Hasher.clone.call(this);

	            var state = clone._state = this._state.slice(0);
	            for (var i = 0; i < 25; i++) {
	                state[i] = state[i].clone();
	            }

	            return clone;
	        }
	    });

	    /**
	     * Shortcut function to the hasher's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     *
	     * @return {WordArray} The hash.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hash = CryptoJS.SHA3('message');
	     *     var hash = CryptoJS.SHA3(wordArray);
	     */
	    C.SHA3 = Hasher._createHelper(SHA3);

	    /**
	     * Shortcut function to the HMAC's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     * @param {WordArray|string} key The secret key.
	     *
	     * @return {WordArray} The HMAC.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hmac = CryptoJS.HmacSHA3(message, key);
	     */
	    C.HmacSHA3 = Hasher._createHmacHelper(SHA3);
	}(Math));


	return CryptoJS.SHA3;

}));

/***/ }),
/* 135 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123));
	}
	else {}
}(this, function (CryptoJS) {

	/** @preserve
	(c) 2012 by Cédric Mesnil. All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

	    - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
	    - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	*/

	(function (Math) {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;
	    var Hasher = C_lib.Hasher;
	    var C_algo = C.algo;

	    // Constants table
	    var _zl = WordArray.create([
	        0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15,
	        7,  4, 13,  1, 10,  6, 15,  3, 12,  0,  9,  5,  2, 14, 11,  8,
	        3, 10, 14,  4,  9, 15,  8,  1,  2,  7,  0,  6, 13, 11,  5, 12,
	        1,  9, 11, 10,  0,  8, 12,  4, 13,  3,  7, 15, 14,  5,  6,  2,
	        4,  0,  5,  9,  7, 12,  2, 10, 14,  1,  3,  8, 11,  6, 15, 13]);
	    var _zr = WordArray.create([
	        5, 14,  7,  0,  9,  2, 11,  4, 13,  6, 15,  8,  1, 10,  3, 12,
	        6, 11,  3,  7,  0, 13,  5, 10, 14, 15,  8, 12,  4,  9,  1,  2,
	        15,  5,  1,  3,  7, 14,  6,  9, 11,  8, 12,  2, 10,  0,  4, 13,
	        8,  6,  4,  1,  3, 11, 15,  0,  5, 12,  2, 13,  9,  7, 10, 14,
	        12, 15, 10,  4,  1,  5,  8,  7,  6,  2, 13, 14,  0,  3,  9, 11]);
	    var _sl = WordArray.create([
	         11, 14, 15, 12,  5,  8,  7,  9, 11, 13, 14, 15,  6,  7,  9,  8,
	        7, 6,   8, 13, 11,  9,  7, 15,  7, 12, 15,  9, 11,  7, 13, 12,
	        11, 13,  6,  7, 14,  9, 13, 15, 14,  8, 13,  6,  5, 12,  7,  5,
	          11, 12, 14, 15, 14, 15,  9,  8,  9, 14,  5,  6,  8,  6,  5, 12,
	        9, 15,  5, 11,  6,  8, 13, 12,  5, 12, 13, 14, 11,  8,  5,  6 ]);
	    var _sr = WordArray.create([
	        8,  9,  9, 11, 13, 15, 15,  5,  7,  7,  8, 11, 14, 14, 12,  6,
	        9, 13, 15,  7, 12,  8,  9, 11,  7,  7, 12,  7,  6, 15, 13, 11,
	        9,  7, 15, 11,  8,  6,  6, 14, 12, 13,  5, 14, 13, 13,  7,  5,
	        15,  5,  8, 11, 14, 14,  6, 14,  6,  9, 12,  9, 12,  5, 15,  8,
	        8,  5, 12,  9, 12,  5, 14,  6,  8, 13,  6,  5, 15, 13, 11, 11 ]);

	    var _hl =  WordArray.create([ 0x00000000, 0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xA953FD4E]);
	    var _hr =  WordArray.create([ 0x50A28BE6, 0x5C4DD124, 0x6D703EF3, 0x7A6D76E9, 0x00000000]);

	    /**
	     * RIPEMD160 hash algorithm.
	     */
	    var RIPEMD160 = C_algo.RIPEMD160 = Hasher.extend({
	        _doReset: function () {
	            this._hash  = WordArray.create([0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0]);
	        },

	        _doProcessBlock: function (M, offset) {

	            // Swap endian
	            for (var i = 0; i < 16; i++) {
	                // Shortcuts
	                var offset_i = offset + i;
	                var M_offset_i = M[offset_i];

	                // Swap
	                M[offset_i] = (
	                    (((M_offset_i << 8)  | (M_offset_i >>> 24)) & 0x00ff00ff) |
	                    (((M_offset_i << 24) | (M_offset_i >>> 8))  & 0xff00ff00)
	                );
	            }
	            // Shortcut
	            var H  = this._hash.words;
	            var hl = _hl.words;
	            var hr = _hr.words;
	            var zl = _zl.words;
	            var zr = _zr.words;
	            var sl = _sl.words;
	            var sr = _sr.words;

	            // Working variables
	            var al, bl, cl, dl, el;
	            var ar, br, cr, dr, er;

	            ar = al = H[0];
	            br = bl = H[1];
	            cr = cl = H[2];
	            dr = dl = H[3];
	            er = el = H[4];
	            // Computation
	            var t;
	            for (var i = 0; i < 80; i += 1) {
	                t = (al +  M[offset+zl[i]])|0;
	                if (i<16){
		            t +=  f1(bl,cl,dl) + hl[0];
	                } else if (i<32) {
		            t +=  f2(bl,cl,dl) + hl[1];
	                } else if (i<48) {
		            t +=  f3(bl,cl,dl) + hl[2];
	                } else if (i<64) {
		            t +=  f4(bl,cl,dl) + hl[3];
	                } else {// if (i<80) {
		            t +=  f5(bl,cl,dl) + hl[4];
	                }
	                t = t|0;
	                t =  rotl(t,sl[i]);
	                t = (t+el)|0;
	                al = el;
	                el = dl;
	                dl = rotl(cl, 10);
	                cl = bl;
	                bl = t;

	                t = (ar + M[offset+zr[i]])|0;
	                if (i<16){
		            t +=  f5(br,cr,dr) + hr[0];
	                } else if (i<32) {
		            t +=  f4(br,cr,dr) + hr[1];
	                } else if (i<48) {
		            t +=  f3(br,cr,dr) + hr[2];
	                } else if (i<64) {
		            t +=  f2(br,cr,dr) + hr[3];
	                } else {// if (i<80) {
		            t +=  f1(br,cr,dr) + hr[4];
	                }
	                t = t|0;
	                t =  rotl(t,sr[i]) ;
	                t = (t+er)|0;
	                ar = er;
	                er = dr;
	                dr = rotl(cr, 10);
	                cr = br;
	                br = t;
	            }
	            // Intermediate hash value
	            t    = (H[1] + cl + dr)|0;
	            H[1] = (H[2] + dl + er)|0;
	            H[2] = (H[3] + el + ar)|0;
	            H[3] = (H[4] + al + br)|0;
	            H[4] = (H[0] + bl + cr)|0;
	            H[0] =  t;
	        },

	        _doFinalize: function () {
	            // Shortcuts
	            var data = this._data;
	            var dataWords = data.words;

	            var nBitsTotal = this._nDataBytes * 8;
	            var nBitsLeft = data.sigBytes * 8;

	            // Add padding
	            dataWords[nBitsLeft >>> 5] |= 0x80 << (24 - nBitsLeft % 32);
	            dataWords[(((nBitsLeft + 64) >>> 9) << 4) + 14] = (
	                (((nBitsTotal << 8)  | (nBitsTotal >>> 24)) & 0x00ff00ff) |
	                (((nBitsTotal << 24) | (nBitsTotal >>> 8))  & 0xff00ff00)
	            );
	            data.sigBytes = (dataWords.length + 1) * 4;

	            // Hash final blocks
	            this._process();

	            // Shortcuts
	            var hash = this._hash;
	            var H = hash.words;

	            // Swap endian
	            for (var i = 0; i < 5; i++) {
	                // Shortcut
	                var H_i = H[i];

	                // Swap
	                H[i] = (((H_i << 8)  | (H_i >>> 24)) & 0x00ff00ff) |
	                       (((H_i << 24) | (H_i >>> 8))  & 0xff00ff00);
	            }

	            // Return final computed hash
	            return hash;
	        },

	        clone: function () {
	            var clone = Hasher.clone.call(this);
	            clone._hash = this._hash.clone();

	            return clone;
	        }
	    });


	    function f1(x, y, z) {
	        return ((x) ^ (y) ^ (z));

	    }

	    function f2(x, y, z) {
	        return (((x)&(y)) | ((~x)&(z)));
	    }

	    function f3(x, y, z) {
	        return (((x) | (~(y))) ^ (z));
	    }

	    function f4(x, y, z) {
	        return (((x) & (z)) | ((y)&(~(z))));
	    }

	    function f5(x, y, z) {
	        return ((x) ^ ((y) |(~(z))));

	    }

	    function rotl(x,n) {
	        return (x<<n) | (x>>>(32-n));
	    }


	    /**
	     * Shortcut function to the hasher's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     *
	     * @return {WordArray} The hash.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hash = CryptoJS.RIPEMD160('message');
	     *     var hash = CryptoJS.RIPEMD160(wordArray);
	     */
	    C.RIPEMD160 = Hasher._createHelper(RIPEMD160);

	    /**
	     * Shortcut function to the HMAC's object interface.
	     *
	     * @param {WordArray|string} message The message to hash.
	     * @param {WordArray|string} key The secret key.
	     *
	     * @return {WordArray} The HMAC.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var hmac = CryptoJS.HmacRIPEMD160(message, key);
	     */
	    C.HmacRIPEMD160 = Hasher._createHmacHelper(RIPEMD160);
	}(Math));


	return CryptoJS.RIPEMD160;

}));

/***/ }),
/* 136 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var Base = C_lib.Base;
	    var C_enc = C.enc;
	    var Utf8 = C_enc.Utf8;
	    var C_algo = C.algo;

	    /**
	     * HMAC algorithm.
	     */
	    var HMAC = C_algo.HMAC = Base.extend({
	        /**
	         * Initializes a newly created HMAC.
	         *
	         * @param {Hasher} hasher The hash algorithm to use.
	         * @param {WordArray|string} key The secret key.
	         *
	         * @example
	         *
	         *     var hmacHasher = CryptoJS.algo.HMAC.create(CryptoJS.algo.SHA256, key);
	         */
	        init: function (hasher, key) {
	            // Init hasher
	            hasher = this._hasher = new hasher.init();

	            // Convert string to WordArray, else assume WordArray already
	            if (typeof key == 'string') {
	                key = Utf8.parse(key);
	            }

	            // Shortcuts
	            var hasherBlockSize = hasher.blockSize;
	            var hasherBlockSizeBytes = hasherBlockSize * 4;

	            // Allow arbitrary length keys
	            if (key.sigBytes > hasherBlockSizeBytes) {
	                key = hasher.finalize(key);
	            }

	            // Clamp excess bits
	            key.clamp();

	            // Clone key for inner and outer pads
	            var oKey = this._oKey = key.clone();
	            var iKey = this._iKey = key.clone();

	            // Shortcuts
	            var oKeyWords = oKey.words;
	            var iKeyWords = iKey.words;

	            // XOR keys with pad constants
	            for (var i = 0; i < hasherBlockSize; i++) {
	                oKeyWords[i] ^= 0x5c5c5c5c;
	                iKeyWords[i] ^= 0x36363636;
	            }
	            oKey.sigBytes = iKey.sigBytes = hasherBlockSizeBytes;

	            // Set initial values
	            this.reset();
	        },

	        /**
	         * Resets this HMAC to its initial state.
	         *
	         * @example
	         *
	         *     hmacHasher.reset();
	         */
	        reset: function () {
	            // Shortcut
	            var hasher = this._hasher;

	            // Reset
	            hasher.reset();
	            hasher.update(this._iKey);
	        },

	        /**
	         * Updates this HMAC with a message.
	         *
	         * @param {WordArray|string} messageUpdate The message to append.
	         *
	         * @return {HMAC} This HMAC instance.
	         *
	         * @example
	         *
	         *     hmacHasher.update('message');
	         *     hmacHasher.update(wordArray);
	         */
	        update: function (messageUpdate) {
	            this._hasher.update(messageUpdate);

	            // Chainable
	            return this;
	        },

	        /**
	         * Finalizes the HMAC computation.
	         * Note that the finalize operation is effectively a destructive, read-once operation.
	         *
	         * @param {WordArray|string} messageUpdate (Optional) A final message update.
	         *
	         * @return {WordArray} The HMAC.
	         *
	         * @example
	         *
	         *     var hmac = hmacHasher.finalize();
	         *     var hmac = hmacHasher.finalize('message');
	         *     var hmac = hmacHasher.finalize(wordArray);
	         */
	        finalize: function (messageUpdate) {
	            // Shortcut
	            var hasher = this._hasher;

	            // Compute HMAC
	            var innerHash = hasher.finalize(messageUpdate);
	            hasher.reset();
	            var hmac = hasher.finalize(this._oKey.clone().concat(innerHash));

	            return hmac;
	        }
	    });
	}());


}));

/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(129), __webpack_require__(136));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var Base = C_lib.Base;
	    var WordArray = C_lib.WordArray;
	    var C_algo = C.algo;
	    var SHA1 = C_algo.SHA1;
	    var HMAC = C_algo.HMAC;

	    /**
	     * Password-Based Key Derivation Function 2 algorithm.
	     */
	    var PBKDF2 = C_algo.PBKDF2 = Base.extend({
	        /**
	         * Configuration options.
	         *
	         * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
	         * @property {Hasher} hasher The hasher to use. Default: SHA1
	         * @property {number} iterations The number of iterations to perform. Default: 1
	         */
	        cfg: Base.extend({
	            keySize: 128/32,
	            hasher: SHA1,
	            iterations: 1
	        }),

	        /**
	         * Initializes a newly created key derivation function.
	         *
	         * @param {Object} cfg (Optional) The configuration options to use for the derivation.
	         *
	         * @example
	         *
	         *     var kdf = CryptoJS.algo.PBKDF2.create();
	         *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8 });
	         *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8, iterations: 1000 });
	         */
	        init: function (cfg) {
	            this.cfg = this.cfg.extend(cfg);
	        },

	        /**
	         * Computes the Password-Based Key Derivation Function 2.
	         *
	         * @param {WordArray|string} password The password.
	         * @param {WordArray|string} salt A salt.
	         *
	         * @return {WordArray} The derived key.
	         *
	         * @example
	         *
	         *     var key = kdf.compute(password, salt);
	         */
	        compute: function (password, salt) {
	            // Shortcut
	            var cfg = this.cfg;

	            // Init HMAC
	            var hmac = HMAC.create(cfg.hasher, password);

	            // Initial values
	            var derivedKey = WordArray.create();
	            var blockIndex = WordArray.create([0x00000001]);

	            // Shortcuts
	            var derivedKeyWords = derivedKey.words;
	            var blockIndexWords = blockIndex.words;
	            var keySize = cfg.keySize;
	            var iterations = cfg.iterations;

	            // Generate key
	            while (derivedKeyWords.length < keySize) {
	                var block = hmac.update(salt).finalize(blockIndex);
	                hmac.reset();

	                // Shortcuts
	                var blockWords = block.words;
	                var blockWordsLength = blockWords.length;

	                // Iterations
	                var intermediate = block;
	                for (var i = 1; i < iterations; i++) {
	                    intermediate = hmac.finalize(intermediate);
	                    hmac.reset();

	                    // Shortcut
	                    var intermediateWords = intermediate.words;

	                    // XOR intermediate with block
	                    for (var j = 0; j < blockWordsLength; j++) {
	                        blockWords[j] ^= intermediateWords[j];
	                    }
	                }

	                derivedKey.concat(block);
	                blockIndexWords[0]++;
	            }
	            derivedKey.sigBytes = keySize * 4;

	            return derivedKey;
	        }
	    });

	    /**
	     * Computes the Password-Based Key Derivation Function 2.
	     *
	     * @param {WordArray|string} password The password.
	     * @param {WordArray|string} salt A salt.
	     * @param {Object} cfg (Optional) The configuration options to use for this computation.
	     *
	     * @return {WordArray} The derived key.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var key = CryptoJS.PBKDF2(password, salt);
	     *     var key = CryptoJS.PBKDF2(password, salt, { keySize: 8 });
	     *     var key = CryptoJS.PBKDF2(password, salt, { keySize: 8, iterations: 1000 });
	     */
	    C.PBKDF2 = function (password, salt, cfg) {
	        return PBKDF2.create(cfg).compute(password, salt);
	    };
	}());


	return CryptoJS.PBKDF2;

}));

/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(129), __webpack_require__(136));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var Base = C_lib.Base;
	    var WordArray = C_lib.WordArray;
	    var C_algo = C.algo;
	    var MD5 = C_algo.MD5;

	    /**
	     * This key derivation function is meant to conform with EVP_BytesToKey.
	     * www.openssl.org/docs/crypto/EVP_BytesToKey.html
	     */
	    var EvpKDF = C_algo.EvpKDF = Base.extend({
	        /**
	         * Configuration options.
	         *
	         * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
	         * @property {Hasher} hasher The hash algorithm to use. Default: MD5
	         * @property {number} iterations The number of iterations to perform. Default: 1
	         */
	        cfg: Base.extend({
	            keySize: 128/32,
	            hasher: MD5,
	            iterations: 1
	        }),

	        /**
	         * Initializes a newly created key derivation function.
	         *
	         * @param {Object} cfg (Optional) The configuration options to use for the derivation.
	         *
	         * @example
	         *
	         *     var kdf = CryptoJS.algo.EvpKDF.create();
	         *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8 });
	         *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8, iterations: 1000 });
	         */
	        init: function (cfg) {
	            this.cfg = this.cfg.extend(cfg);
	        },

	        /**
	         * Derives a key from a password.
	         *
	         * @param {WordArray|string} password The password.
	         * @param {WordArray|string} salt A salt.
	         *
	         * @return {WordArray} The derived key.
	         *
	         * @example
	         *
	         *     var key = kdf.compute(password, salt);
	         */
	        compute: function (password, salt) {
	            // Shortcut
	            var cfg = this.cfg;

	            // Init hasher
	            var hasher = cfg.hasher.create();

	            // Initial values
	            var derivedKey = WordArray.create();

	            // Shortcuts
	            var derivedKeyWords = derivedKey.words;
	            var keySize = cfg.keySize;
	            var iterations = cfg.iterations;

	            // Generate key
	            while (derivedKeyWords.length < keySize) {
	                if (block) {
	                    hasher.update(block);
	                }
	                var block = hasher.update(password).finalize(salt);
	                hasher.reset();

	                // Iterations
	                for (var i = 1; i < iterations; i++) {
	                    block = hasher.finalize(block);
	                    hasher.reset();
	                }

	                derivedKey.concat(block);
	            }
	            derivedKey.sigBytes = keySize * 4;

	            return derivedKey;
	        }
	    });

	    /**
	     * Derives a key from a password.
	     *
	     * @param {WordArray|string} password The password.
	     * @param {WordArray|string} salt A salt.
	     * @param {Object} cfg (Optional) The configuration options to use for this computation.
	     *
	     * @return {WordArray} The derived key.
	     *
	     * @static
	     *
	     * @example
	     *
	     *     var key = CryptoJS.EvpKDF(password, salt);
	     *     var key = CryptoJS.EvpKDF(password, salt, { keySize: 8 });
	     *     var key = CryptoJS.EvpKDF(password, salt, { keySize: 8, iterations: 1000 });
	     */
	    C.EvpKDF = function (password, salt, cfg) {
	        return EvpKDF.create(cfg).compute(password, salt);
	    };
	}());


	return CryptoJS.EvpKDF;

}));

/***/ }),
/* 139 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(138));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * Cipher core components.
	 */
	CryptoJS.lib.Cipher || (function (undefined) {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var Base = C_lib.Base;
	    var WordArray = C_lib.WordArray;
	    var BufferedBlockAlgorithm = C_lib.BufferedBlockAlgorithm;
	    var C_enc = C.enc;
	    var Utf8 = C_enc.Utf8;
	    var Base64 = C_enc.Base64;
	    var C_algo = C.algo;
	    var EvpKDF = C_algo.EvpKDF;

	    /**
	     * Abstract base cipher template.
	     *
	     * @property {number} keySize This cipher's key size. Default: 4 (128 bits)
	     * @property {number} ivSize This cipher's IV size. Default: 4 (128 bits)
	     * @property {number} _ENC_XFORM_MODE A constant representing encryption mode.
	     * @property {number} _DEC_XFORM_MODE A constant representing decryption mode.
	     */
	    var Cipher = C_lib.Cipher = BufferedBlockAlgorithm.extend({
	        /**
	         * Configuration options.
	         *
	         * @property {WordArray} iv The IV to use for this operation.
	         */
	        cfg: Base.extend(),

	        /**
	         * Creates this cipher in encryption mode.
	         *
	         * @param {WordArray} key The key.
	         * @param {Object} cfg (Optional) The configuration options to use for this operation.
	         *
	         * @return {Cipher} A cipher instance.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var cipher = CryptoJS.algo.AES.createEncryptor(keyWordArray, { iv: ivWordArray });
	         */
	        createEncryptor: function (key, cfg) {
	            return this.create(this._ENC_XFORM_MODE, key, cfg);
	        },

	        /**
	         * Creates this cipher in decryption mode.
	         *
	         * @param {WordArray} key The key.
	         * @param {Object} cfg (Optional) The configuration options to use for this operation.
	         *
	         * @return {Cipher} A cipher instance.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var cipher = CryptoJS.algo.AES.createDecryptor(keyWordArray, { iv: ivWordArray });
	         */
	        createDecryptor: function (key, cfg) {
	            return this.create(this._DEC_XFORM_MODE, key, cfg);
	        },

	        /**
	         * Initializes a newly created cipher.
	         *
	         * @param {number} xformMode Either the encryption or decryption transormation mode constant.
	         * @param {WordArray} key The key.
	         * @param {Object} cfg (Optional) The configuration options to use for this operation.
	         *
	         * @example
	         *
	         *     var cipher = CryptoJS.algo.AES.create(CryptoJS.algo.AES._ENC_XFORM_MODE, keyWordArray, { iv: ivWordArray });
	         */
	        init: function (xformMode, key, cfg) {
	            // Apply config defaults
	            this.cfg = this.cfg.extend(cfg);

	            // Store transform mode and key
	            this._xformMode = xformMode;
	            this._key = key;

	            // Set initial values
	            this.reset();
	        },

	        /**
	         * Resets this cipher to its initial state.
	         *
	         * @example
	         *
	         *     cipher.reset();
	         */
	        reset: function () {
	            // Reset data buffer
	            BufferedBlockAlgorithm.reset.call(this);

	            // Perform concrete-cipher logic
	            this._doReset();
	        },

	        /**
	         * Adds data to be encrypted or decrypted.
	         *
	         * @param {WordArray|string} dataUpdate The data to encrypt or decrypt.
	         *
	         * @return {WordArray} The data after processing.
	         *
	         * @example
	         *
	         *     var encrypted = cipher.process('data');
	         *     var encrypted = cipher.process(wordArray);
	         */
	        process: function (dataUpdate) {
	            // Append
	            this._append(dataUpdate);

	            // Process available blocks
	            return this._process();
	        },

	        /**
	         * Finalizes the encryption or decryption process.
	         * Note that the finalize operation is effectively a destructive, read-once operation.
	         *
	         * @param {WordArray|string} dataUpdate The final data to encrypt or decrypt.
	         *
	         * @return {WordArray} The data after final processing.
	         *
	         * @example
	         *
	         *     var encrypted = cipher.finalize();
	         *     var encrypted = cipher.finalize('data');
	         *     var encrypted = cipher.finalize(wordArray);
	         */
	        finalize: function (dataUpdate) {
	            // Final data update
	            if (dataUpdate) {
	                this._append(dataUpdate);
	            }

	            // Perform concrete-cipher logic
	            var finalProcessedData = this._doFinalize();

	            return finalProcessedData;
	        },

	        keySize: 128/32,

	        ivSize: 128/32,

	        _ENC_XFORM_MODE: 1,

	        _DEC_XFORM_MODE: 2,

	        /**
	         * Creates shortcut functions to a cipher's object interface.
	         *
	         * @param {Cipher} cipher The cipher to create a helper for.
	         *
	         * @return {Object} An object with encrypt and decrypt shortcut functions.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var AES = CryptoJS.lib.Cipher._createHelper(CryptoJS.algo.AES);
	         */
	        _createHelper: (function () {
	            function selectCipherStrategy(key) {
	                if (typeof key == 'string') {
	                    return PasswordBasedCipher;
	                } else {
	                    return SerializableCipher;
	                }
	            }

	            return function (cipher) {
	                return {
	                    encrypt: function (message, key, cfg) {
	                        return selectCipherStrategy(key).encrypt(cipher, message, key, cfg);
	                    },

	                    decrypt: function (ciphertext, key, cfg) {
	                        return selectCipherStrategy(key).decrypt(cipher, ciphertext, key, cfg);
	                    }
	                };
	            };
	        }())
	    });

	    /**
	     * Abstract base stream cipher template.
	     *
	     * @property {number} blockSize The number of 32-bit words this cipher operates on. Default: 1 (32 bits)
	     */
	    var StreamCipher = C_lib.StreamCipher = Cipher.extend({
	        _doFinalize: function () {
	            // Process partial blocks
	            var finalProcessedBlocks = this._process(!!'flush');

	            return finalProcessedBlocks;
	        },

	        blockSize: 1
	    });

	    /**
	     * Mode namespace.
	     */
	    var C_mode = C.mode = {};

	    /**
	     * Abstract base block cipher mode template.
	     */
	    var BlockCipherMode = C_lib.BlockCipherMode = Base.extend({
	        /**
	         * Creates this mode for encryption.
	         *
	         * @param {Cipher} cipher A block cipher instance.
	         * @param {Array} iv The IV words.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var mode = CryptoJS.mode.CBC.createEncryptor(cipher, iv.words);
	         */
	        createEncryptor: function (cipher, iv) {
	            return this.Encryptor.create(cipher, iv);
	        },

	        /**
	         * Creates this mode for decryption.
	         *
	         * @param {Cipher} cipher A block cipher instance.
	         * @param {Array} iv The IV words.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var mode = CryptoJS.mode.CBC.createDecryptor(cipher, iv.words);
	         */
	        createDecryptor: function (cipher, iv) {
	            return this.Decryptor.create(cipher, iv);
	        },

	        /**
	         * Initializes a newly created mode.
	         *
	         * @param {Cipher} cipher A block cipher instance.
	         * @param {Array} iv The IV words.
	         *
	         * @example
	         *
	         *     var mode = CryptoJS.mode.CBC.Encryptor.create(cipher, iv.words);
	         */
	        init: function (cipher, iv) {
	            this._cipher = cipher;
	            this._iv = iv;
	        }
	    });

	    /**
	     * Cipher Block Chaining mode.
	     */
	    var CBC = C_mode.CBC = (function () {
	        /**
	         * Abstract base CBC mode.
	         */
	        var CBC = BlockCipherMode.extend();

	        /**
	         * CBC encryptor.
	         */
	        CBC.Encryptor = CBC.extend({
	            /**
	             * Processes the data block at offset.
	             *
	             * @param {Array} words The data words to operate on.
	             * @param {number} offset The offset where the block starts.
	             *
	             * @example
	             *
	             *     mode.processBlock(data.words, offset);
	             */
	            processBlock: function (words, offset) {
	                // Shortcuts
	                var cipher = this._cipher;
	                var blockSize = cipher.blockSize;

	                // XOR and encrypt
	                xorBlock.call(this, words, offset, blockSize);
	                cipher.encryptBlock(words, offset);

	                // Remember this block to use with next block
	                this._prevBlock = words.slice(offset, offset + blockSize);
	            }
	        });

	        /**
	         * CBC decryptor.
	         */
	        CBC.Decryptor = CBC.extend({
	            /**
	             * Processes the data block at offset.
	             *
	             * @param {Array} words The data words to operate on.
	             * @param {number} offset The offset where the block starts.
	             *
	             * @example
	             *
	             *     mode.processBlock(data.words, offset);
	             */
	            processBlock: function (words, offset) {
	                // Shortcuts
	                var cipher = this._cipher;
	                var blockSize = cipher.blockSize;

	                // Remember this block to use with next block
	                var thisBlock = words.slice(offset, offset + blockSize);

	                // Decrypt and XOR
	                cipher.decryptBlock(words, offset);
	                xorBlock.call(this, words, offset, blockSize);

	                // This block becomes the previous block
	                this._prevBlock = thisBlock;
	            }
	        });

	        function xorBlock(words, offset, blockSize) {
	            // Shortcut
	            var iv = this._iv;

	            // Choose mixing block
	            if (iv) {
	                var block = iv;

	                // Remove IV for subsequent blocks
	                this._iv = undefined;
	            } else {
	                var block = this._prevBlock;
	            }

	            // XOR blocks
	            for (var i = 0; i < blockSize; i++) {
	                words[offset + i] ^= block[i];
	            }
	        }

	        return CBC;
	    }());

	    /**
	     * Padding namespace.
	     */
	    var C_pad = C.pad = {};

	    /**
	     * PKCS #5/7 padding strategy.
	     */
	    var Pkcs7 = C_pad.Pkcs7 = {
	        /**
	         * Pads data using the algorithm defined in PKCS #5/7.
	         *
	         * @param {WordArray} data The data to pad.
	         * @param {number} blockSize The multiple that the data should be padded to.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     CryptoJS.pad.Pkcs7.pad(wordArray, 4);
	         */
	        pad: function (data, blockSize) {
	            // Shortcut
	            var blockSizeBytes = blockSize * 4;

	            // Count padding bytes
	            var nPaddingBytes = blockSizeBytes - data.sigBytes % blockSizeBytes;

	            // Create padding word
	            var paddingWord = (nPaddingBytes << 24) | (nPaddingBytes << 16) | (nPaddingBytes << 8) | nPaddingBytes;

	            // Create padding
	            var paddingWords = [];
	            for (var i = 0; i < nPaddingBytes; i += 4) {
	                paddingWords.push(paddingWord);
	            }
	            var padding = WordArray.create(paddingWords, nPaddingBytes);

	            // Add padding
	            data.concat(padding);
	        },

	        /**
	         * Unpads data that had been padded using the algorithm defined in PKCS #5/7.
	         *
	         * @param {WordArray} data The data to unpad.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     CryptoJS.pad.Pkcs7.unpad(wordArray);
	         */
	        unpad: function (data) {
	            // Get number of padding bytes from last byte
	            var nPaddingBytes = data.words[(data.sigBytes - 1) >>> 2] & 0xff;

	            // Remove padding
	            data.sigBytes -= nPaddingBytes;
	        }
	    };

	    /**
	     * Abstract base block cipher template.
	     *
	     * @property {number} blockSize The number of 32-bit words this cipher operates on. Default: 4 (128 bits)
	     */
	    var BlockCipher = C_lib.BlockCipher = Cipher.extend({
	        /**
	         * Configuration options.
	         *
	         * @property {Mode} mode The block mode to use. Default: CBC
	         * @property {Padding} padding The padding strategy to use. Default: Pkcs7
	         */
	        cfg: Cipher.cfg.extend({
	            mode: CBC,
	            padding: Pkcs7
	        }),

	        reset: function () {
	            // Reset cipher
	            Cipher.reset.call(this);

	            // Shortcuts
	            var cfg = this.cfg;
	            var iv = cfg.iv;
	            var mode = cfg.mode;

	            // Reset block mode
	            if (this._xformMode == this._ENC_XFORM_MODE) {
	                var modeCreator = mode.createEncryptor;
	            } else /* if (this._xformMode == this._DEC_XFORM_MODE) */ {
	                var modeCreator = mode.createDecryptor;
	                // Keep at least one block in the buffer for unpadding
	                this._minBufferSize = 1;
	            }

	            if (this._mode && this._mode.__creator == modeCreator) {
	                this._mode.init(this, iv && iv.words);
	            } else {
	                this._mode = modeCreator.call(mode, this, iv && iv.words);
	                this._mode.__creator = modeCreator;
	            }
	        },

	        _doProcessBlock: function (words, offset) {
	            this._mode.processBlock(words, offset);
	        },

	        _doFinalize: function () {
	            // Shortcut
	            var padding = this.cfg.padding;

	            // Finalize
	            if (this._xformMode == this._ENC_XFORM_MODE) {
	                // Pad data
	                padding.pad(this._data, this.blockSize);

	                // Process final blocks
	                var finalProcessedBlocks = this._process(!!'flush');
	            } else /* if (this._xformMode == this._DEC_XFORM_MODE) */ {
	                // Process final blocks
	                var finalProcessedBlocks = this._process(!!'flush');

	                // Unpad data
	                padding.unpad(finalProcessedBlocks);
	            }

	            return finalProcessedBlocks;
	        },

	        blockSize: 128/32
	    });

	    /**
	     * A collection of cipher parameters.
	     *
	     * @property {WordArray} ciphertext The raw ciphertext.
	     * @property {WordArray} key The key to this ciphertext.
	     * @property {WordArray} iv The IV used in the ciphering operation.
	     * @property {WordArray} salt The salt used with a key derivation function.
	     * @property {Cipher} algorithm The cipher algorithm.
	     * @property {Mode} mode The block mode used in the ciphering operation.
	     * @property {Padding} padding The padding scheme used in the ciphering operation.
	     * @property {number} blockSize The block size of the cipher.
	     * @property {Format} formatter The default formatting strategy to convert this cipher params object to a string.
	     */
	    var CipherParams = C_lib.CipherParams = Base.extend({
	        /**
	         * Initializes a newly created cipher params object.
	         *
	         * @param {Object} cipherParams An object with any of the possible cipher parameters.
	         *
	         * @example
	         *
	         *     var cipherParams = CryptoJS.lib.CipherParams.create({
	         *         ciphertext: ciphertextWordArray,
	         *         key: keyWordArray,
	         *         iv: ivWordArray,
	         *         salt: saltWordArray,
	         *         algorithm: CryptoJS.algo.AES,
	         *         mode: CryptoJS.mode.CBC,
	         *         padding: CryptoJS.pad.PKCS7,
	         *         blockSize: 4,
	         *         formatter: CryptoJS.format.OpenSSL
	         *     });
	         */
	        init: function (cipherParams) {
	            this.mixIn(cipherParams);
	        },

	        /**
	         * Converts this cipher params object to a string.
	         *
	         * @param {Format} formatter (Optional) The formatting strategy to use.
	         *
	         * @return {string} The stringified cipher params.
	         *
	         * @throws Error If neither the formatter nor the default formatter is set.
	         *
	         * @example
	         *
	         *     var string = cipherParams + '';
	         *     var string = cipherParams.toString();
	         *     var string = cipherParams.toString(CryptoJS.format.OpenSSL);
	         */
	        toString: function (formatter) {
	            return (formatter || this.formatter).stringify(this);
	        }
	    });

	    /**
	     * Format namespace.
	     */
	    var C_format = C.format = {};

	    /**
	     * OpenSSL formatting strategy.
	     */
	    var OpenSSLFormatter = C_format.OpenSSL = {
	        /**
	         * Converts a cipher params object to an OpenSSL-compatible string.
	         *
	         * @param {CipherParams} cipherParams The cipher params object.
	         *
	         * @return {string} The OpenSSL-compatible string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var openSSLString = CryptoJS.format.OpenSSL.stringify(cipherParams);
	         */
	        stringify: function (cipherParams) {
	            // Shortcuts
	            var ciphertext = cipherParams.ciphertext;
	            var salt = cipherParams.salt;

	            // Format
	            if (salt) {
	                var wordArray = WordArray.create([0x53616c74, 0x65645f5f]).concat(salt).concat(ciphertext);
	            } else {
	                var wordArray = ciphertext;
	            }

	            return wordArray.toString(Base64);
	        },

	        /**
	         * Converts an OpenSSL-compatible string to a cipher params object.
	         *
	         * @param {string} openSSLStr The OpenSSL-compatible string.
	         *
	         * @return {CipherParams} The cipher params object.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var cipherParams = CryptoJS.format.OpenSSL.parse(openSSLString);
	         */
	        parse: function (openSSLStr) {
	            // Parse base64
	            var ciphertext = Base64.parse(openSSLStr);

	            // Shortcut
	            var ciphertextWords = ciphertext.words;

	            // Test for salt
	            if (ciphertextWords[0] == 0x53616c74 && ciphertextWords[1] == 0x65645f5f) {
	                // Extract salt
	                var salt = WordArray.create(ciphertextWords.slice(2, 4));

	                // Remove salt from ciphertext
	                ciphertextWords.splice(0, 4);
	                ciphertext.sigBytes -= 16;
	            }

	            return CipherParams.create({ ciphertext: ciphertext, salt: salt });
	        }
	    };

	    /**
	     * A cipher wrapper that returns ciphertext as a serializable cipher params object.
	     */
	    var SerializableCipher = C_lib.SerializableCipher = Base.extend({
	        /**
	         * Configuration options.
	         *
	         * @property {Formatter} format The formatting strategy to convert cipher param objects to and from a string. Default: OpenSSL
	         */
	        cfg: Base.extend({
	            format: OpenSSLFormatter
	        }),

	        /**
	         * Encrypts a message.
	         *
	         * @param {Cipher} cipher The cipher algorithm to use.
	         * @param {WordArray|string} message The message to encrypt.
	         * @param {WordArray} key The key.
	         * @param {Object} cfg (Optional) The configuration options to use for this operation.
	         *
	         * @return {CipherParams} A cipher params object.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key);
	         *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv });
	         *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv, format: CryptoJS.format.OpenSSL });
	         */
	        encrypt: function (cipher, message, key, cfg) {
	            // Apply config defaults
	            cfg = this.cfg.extend(cfg);

	            // Encrypt
	            var encryptor = cipher.createEncryptor(key, cfg);
	            var ciphertext = encryptor.finalize(message);

	            // Shortcut
	            var cipherCfg = encryptor.cfg;

	            // Create and return serializable cipher params
	            return CipherParams.create({
	                ciphertext: ciphertext,
	                key: key,
	                iv: cipherCfg.iv,
	                algorithm: cipher,
	                mode: cipherCfg.mode,
	                padding: cipherCfg.padding,
	                blockSize: cipher.blockSize,
	                formatter: cfg.format
	            });
	        },

	        /**
	         * Decrypts serialized ciphertext.
	         *
	         * @param {Cipher} cipher The cipher algorithm to use.
	         * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
	         * @param {WordArray} key The key.
	         * @param {Object} cfg (Optional) The configuration options to use for this operation.
	         *
	         * @return {WordArray} The plaintext.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, key, { iv: iv, format: CryptoJS.format.OpenSSL });
	         *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, key, { iv: iv, format: CryptoJS.format.OpenSSL });
	         */
	        decrypt: function (cipher, ciphertext, key, cfg) {
	            // Apply config defaults
	            cfg = this.cfg.extend(cfg);

	            // Convert string to CipherParams
	            ciphertext = this._parse(ciphertext, cfg.format);

	            // Decrypt
	            var plaintext = cipher.createDecryptor(key, cfg).finalize(ciphertext.ciphertext);

	            return plaintext;
	        },

	        /**
	         * Converts serialized ciphertext to CipherParams,
	         * else assumed CipherParams already and returns ciphertext unchanged.
	         *
	         * @param {CipherParams|string} ciphertext The ciphertext.
	         * @param {Formatter} format The formatting strategy to use to parse serialized ciphertext.
	         *
	         * @return {CipherParams} The unserialized ciphertext.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var ciphertextParams = CryptoJS.lib.SerializableCipher._parse(ciphertextStringOrParams, format);
	         */
	        _parse: function (ciphertext, format) {
	            if (typeof ciphertext == 'string') {
	                return format.parse(ciphertext, this);
	            } else {
	                return ciphertext;
	            }
	        }
	    });

	    /**
	     * Key derivation function namespace.
	     */
	    var C_kdf = C.kdf = {};

	    /**
	     * OpenSSL key derivation function.
	     */
	    var OpenSSLKdf = C_kdf.OpenSSL = {
	        /**
	         * Derives a key and IV from a password.
	         *
	         * @param {string} password The password to derive from.
	         * @param {number} keySize The size in words of the key to generate.
	         * @param {number} ivSize The size in words of the IV to generate.
	         * @param {WordArray|string} salt (Optional) A 64-bit salt to use. If omitted, a salt will be generated randomly.
	         *
	         * @return {CipherParams} A cipher params object with the key, IV, and salt.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32);
	         *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32, 'saltsalt');
	         */
	        execute: function (password, keySize, ivSize, salt) {
	            // Generate random salt
	            if (!salt) {
	                salt = WordArray.random(64/8);
	            }

	            // Derive key and IV
	            var key = EvpKDF.create({ keySize: keySize + ivSize }).compute(password, salt);

	            // Separate key and IV
	            var iv = WordArray.create(key.words.slice(keySize), ivSize * 4);
	            key.sigBytes = keySize * 4;

	            // Return params
	            return CipherParams.create({ key: key, iv: iv, salt: salt });
	        }
	    };

	    /**
	     * A serializable cipher wrapper that derives the key from a password,
	     * and returns ciphertext as a serializable cipher params object.
	     */
	    var PasswordBasedCipher = C_lib.PasswordBasedCipher = SerializableCipher.extend({
	        /**
	         * Configuration options.
	         *
	         * @property {KDF} kdf The key derivation function to use to generate a key and IV from a password. Default: OpenSSL
	         */
	        cfg: SerializableCipher.cfg.extend({
	            kdf: OpenSSLKdf
	        }),

	        /**
	         * Encrypts a message using a password.
	         *
	         * @param {Cipher} cipher The cipher algorithm to use.
	         * @param {WordArray|string} message The message to encrypt.
	         * @param {string} password The password.
	         * @param {Object} cfg (Optional) The configuration options to use for this operation.
	         *
	         * @return {CipherParams} A cipher params object.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password');
	         *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password', { format: CryptoJS.format.OpenSSL });
	         */
	        encrypt: function (cipher, message, password, cfg) {
	            // Apply config defaults
	            cfg = this.cfg.extend(cfg);

	            // Derive key and other params
	            var derivedParams = cfg.kdf.execute(password, cipher.keySize, cipher.ivSize);

	            // Add IV to config
	            cfg.iv = derivedParams.iv;

	            // Encrypt
	            var ciphertext = SerializableCipher.encrypt.call(this, cipher, message, derivedParams.key, cfg);

	            // Mix in derived params
	            ciphertext.mixIn(derivedParams);

	            return ciphertext;
	        },

	        /**
	         * Decrypts serialized ciphertext using a password.
	         *
	         * @param {Cipher} cipher The cipher algorithm to use.
	         * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
	         * @param {string} password The password.
	         * @param {Object} cfg (Optional) The configuration options to use for this operation.
	         *
	         * @return {WordArray} The plaintext.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, 'password', { format: CryptoJS.format.OpenSSL });
	         *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, 'password', { format: CryptoJS.format.OpenSSL });
	         */
	        decrypt: function (cipher, ciphertext, password, cfg) {
	            // Apply config defaults
	            cfg = this.cfg.extend(cfg);

	            // Convert string to CipherParams
	            ciphertext = this._parse(ciphertext, cfg.format);

	            // Derive key and other params
	            var derivedParams = cfg.kdf.execute(password, cipher.keySize, cipher.ivSize, ciphertext.salt);

	            // Add IV to config
	            cfg.iv = derivedParams.iv;

	            // Decrypt
	            var plaintext = SerializableCipher.decrypt.call(this, cipher, ciphertext, derivedParams.key, cfg);

	            return plaintext;
	        }
	    });
	}());


}));

/***/ }),
/* 140 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * Cipher Feedback block mode.
	 */
	CryptoJS.mode.CFB = (function () {
	    var CFB = CryptoJS.lib.BlockCipherMode.extend();

	    CFB.Encryptor = CFB.extend({
	        processBlock: function (words, offset) {
	            // Shortcuts
	            var cipher = this._cipher;
	            var blockSize = cipher.blockSize;

	            generateKeystreamAndEncrypt.call(this, words, offset, blockSize, cipher);

	            // Remember this block to use with next block
	            this._prevBlock = words.slice(offset, offset + blockSize);
	        }
	    });

	    CFB.Decryptor = CFB.extend({
	        processBlock: function (words, offset) {
	            // Shortcuts
	            var cipher = this._cipher;
	            var blockSize = cipher.blockSize;

	            // Remember this block to use with next block
	            var thisBlock = words.slice(offset, offset + blockSize);

	            generateKeystreamAndEncrypt.call(this, words, offset, blockSize, cipher);

	            // This block becomes the previous block
	            this._prevBlock = thisBlock;
	        }
	    });

	    function generateKeystreamAndEncrypt(words, offset, blockSize, cipher) {
	        // Shortcut
	        var iv = this._iv;

	        // Generate keystream
	        if (iv) {
	            var keystream = iv.slice(0);

	            // Remove IV for subsequent blocks
	            this._iv = undefined;
	        } else {
	            var keystream = this._prevBlock;
	        }
	        cipher.encryptBlock(keystream, 0);

	        // Encrypt
	        for (var i = 0; i < blockSize; i++) {
	            words[offset + i] ^= keystream[i];
	        }
	    }

	    return CFB;
	}());


	return CryptoJS.mode.CFB;

}));

/***/ }),
/* 141 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * Counter block mode.
	 */
	CryptoJS.mode.CTR = (function () {
	    var CTR = CryptoJS.lib.BlockCipherMode.extend();

	    var Encryptor = CTR.Encryptor = CTR.extend({
	        processBlock: function (words, offset) {
	            // Shortcuts
	            var cipher = this._cipher
	            var blockSize = cipher.blockSize;
	            var iv = this._iv;
	            var counter = this._counter;

	            // Generate keystream
	            if (iv) {
	                counter = this._counter = iv.slice(0);

	                // Remove IV for subsequent blocks
	                this._iv = undefined;
	            }
	            var keystream = counter.slice(0);
	            cipher.encryptBlock(keystream, 0);

	            // Increment counter
	            counter[blockSize - 1] = (counter[blockSize - 1] + 1) | 0

	            // Encrypt
	            for (var i = 0; i < blockSize; i++) {
	                words[offset + i] ^= keystream[i];
	            }
	        }
	    });

	    CTR.Decryptor = Encryptor;

	    return CTR;
	}());


	return CryptoJS.mode.CTR;

}));

/***/ }),
/* 142 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/** @preserve
	 * Counter block mode compatible with  Dr Brian Gladman fileenc.c
	 * derived from CryptoJS.mode.CTR
	 * Jan Hruby jhruby.web@gmail.com
	 */
	CryptoJS.mode.CTRGladman = (function () {
	    var CTRGladman = CryptoJS.lib.BlockCipherMode.extend();

		function incWord(word)
		{
			if (((word >> 24) & 0xff) === 0xff) { //overflow
			var b1 = (word >> 16)&0xff;
			var b2 = (word >> 8)&0xff;
			var b3 = word & 0xff;

			if (b1 === 0xff) // overflow b1
			{
			b1 = 0;
			if (b2 === 0xff)
			{
				b2 = 0;
				if (b3 === 0xff)
				{
					b3 = 0;
				}
				else
				{
					++b3;
				}
			}
			else
			{
				++b2;
			}
			}
			else
			{
			++b1;
			}

			word = 0;
			word += (b1 << 16);
			word += (b2 << 8);
			word += b3;
			}
			else
			{
			word += (0x01 << 24);
			}
			return word;
		}

		function incCounter(counter)
		{
			if ((counter[0] = incWord(counter[0])) === 0)
			{
				// encr_data in fileenc.c from  Dr Brian Gladman's counts only with DWORD j < 8
				counter[1] = incWord(counter[1]);
			}
			return counter;
		}

	    var Encryptor = CTRGladman.Encryptor = CTRGladman.extend({
	        processBlock: function (words, offset) {
	            // Shortcuts
	            var cipher = this._cipher
	            var blockSize = cipher.blockSize;
	            var iv = this._iv;
	            var counter = this._counter;

	            // Generate keystream
	            if (iv) {
	                counter = this._counter = iv.slice(0);

	                // Remove IV for subsequent blocks
	                this._iv = undefined;
	            }

				incCounter(counter);

				var keystream = counter.slice(0);
	            cipher.encryptBlock(keystream, 0);

	            // Encrypt
	            for (var i = 0; i < blockSize; i++) {
	                words[offset + i] ^= keystream[i];
	            }
	        }
	    });

	    CTRGladman.Decryptor = Encryptor;

	    return CTRGladman;
	}());




	return CryptoJS.mode.CTRGladman;

}));

/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * Output Feedback block mode.
	 */
	CryptoJS.mode.OFB = (function () {
	    var OFB = CryptoJS.lib.BlockCipherMode.extend();

	    var Encryptor = OFB.Encryptor = OFB.extend({
	        processBlock: function (words, offset) {
	            // Shortcuts
	            var cipher = this._cipher
	            var blockSize = cipher.blockSize;
	            var iv = this._iv;
	            var keystream = this._keystream;

	            // Generate keystream
	            if (iv) {
	                keystream = this._keystream = iv.slice(0);

	                // Remove IV for subsequent blocks
	                this._iv = undefined;
	            }
	            cipher.encryptBlock(keystream, 0);

	            // Encrypt
	            for (var i = 0; i < blockSize; i++) {
	                words[offset + i] ^= keystream[i];
	            }
	        }
	    });

	    OFB.Decryptor = Encryptor;

	    return OFB;
	}());


	return CryptoJS.mode.OFB;

}));

/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * Electronic Codebook block mode.
	 */
	CryptoJS.mode.ECB = (function () {
	    var ECB = CryptoJS.lib.BlockCipherMode.extend();

	    ECB.Encryptor = ECB.extend({
	        processBlock: function (words, offset) {
	            this._cipher.encryptBlock(words, offset);
	        }
	    });

	    ECB.Decryptor = ECB.extend({
	        processBlock: function (words, offset) {
	            this._cipher.decryptBlock(words, offset);
	        }
	    });

	    return ECB;
	}());


	return CryptoJS.mode.ECB;

}));

/***/ }),
/* 145 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * ANSI X.923 padding strategy.
	 */
	CryptoJS.pad.AnsiX923 = {
	    pad: function (data, blockSize) {
	        // Shortcuts
	        var dataSigBytes = data.sigBytes;
	        var blockSizeBytes = blockSize * 4;

	        // Count padding bytes
	        var nPaddingBytes = blockSizeBytes - dataSigBytes % blockSizeBytes;

	        // Compute last byte position
	        var lastBytePos = dataSigBytes + nPaddingBytes - 1;

	        // Pad
	        data.clamp();
	        data.words[lastBytePos >>> 2] |= nPaddingBytes << (24 - (lastBytePos % 4) * 8);
	        data.sigBytes += nPaddingBytes;
	    },

	    unpad: function (data) {
	        // Get number of padding bytes from last byte
	        var nPaddingBytes = data.words[(data.sigBytes - 1) >>> 2] & 0xff;

	        // Remove padding
	        data.sigBytes -= nPaddingBytes;
	    }
	};


	return CryptoJS.pad.Ansix923;

}));

/***/ }),
/* 146 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * ISO 10126 padding strategy.
	 */
	CryptoJS.pad.Iso10126 = {
	    pad: function (data, blockSize) {
	        // Shortcut
	        var blockSizeBytes = blockSize * 4;

	        // Count padding bytes
	        var nPaddingBytes = blockSizeBytes - data.sigBytes % blockSizeBytes;

	        // Pad
	        data.concat(CryptoJS.lib.WordArray.random(nPaddingBytes - 1)).
	             concat(CryptoJS.lib.WordArray.create([nPaddingBytes << 24], 1));
	    },

	    unpad: function (data) {
	        // Get number of padding bytes from last byte
	        var nPaddingBytes = data.words[(data.sigBytes - 1) >>> 2] & 0xff;

	        // Remove padding
	        data.sigBytes -= nPaddingBytes;
	    }
	};


	return CryptoJS.pad.Iso10126;

}));

/***/ }),
/* 147 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * ISO/IEC 9797-1 Padding Method 2.
	 */
	CryptoJS.pad.Iso97971 = {
	    pad: function (data, blockSize) {
	        // Add 0x80 byte
	        data.concat(CryptoJS.lib.WordArray.create([0x80000000], 1));

	        // Zero pad the rest
	        CryptoJS.pad.ZeroPadding.pad(data, blockSize);
	    },

	    unpad: function (data) {
	        // Remove zero padding
	        CryptoJS.pad.ZeroPadding.unpad(data);

	        // Remove one more byte -- the 0x80 byte
	        data.sigBytes--;
	    }
	};


	return CryptoJS.pad.Iso97971;

}));

/***/ }),
/* 148 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * Zero padding strategy.
	 */
	CryptoJS.pad.ZeroPadding = {
	    pad: function (data, blockSize) {
	        // Shortcut
	        var blockSizeBytes = blockSize * 4;

	        // Pad
	        data.clamp();
	        data.sigBytes += blockSizeBytes - ((data.sigBytes % blockSizeBytes) || blockSizeBytes);
	    },

	    unpad: function (data) {
	        // Shortcut
	        var dataWords = data.words;

	        // Unpad
	        var i = data.sigBytes - 1;
	        while (!((dataWords[i >>> 2] >>> (24 - (i % 4) * 8)) & 0xff)) {
	            i--;
	        }
	        data.sigBytes = i + 1;
	    }
	};


	return CryptoJS.pad.ZeroPadding;

}));

/***/ }),
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	/**
	 * A noop padding strategy.
	 */
	CryptoJS.pad.NoPadding = {
	    pad: function () {
	    },

	    unpad: function () {
	    }
	};


	return CryptoJS.pad.NoPadding;

}));

/***/ }),
/* 150 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	(function (undefined) {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var CipherParams = C_lib.CipherParams;
	    var C_enc = C.enc;
	    var Hex = C_enc.Hex;
	    var C_format = C.format;

	    var HexFormatter = C_format.Hex = {
	        /**
	         * Converts the ciphertext of a cipher params object to a hexadecimally encoded string.
	         *
	         * @param {CipherParams} cipherParams The cipher params object.
	         *
	         * @return {string} The hexadecimally encoded string.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var hexString = CryptoJS.format.Hex.stringify(cipherParams);
	         */
	        stringify: function (cipherParams) {
	            return cipherParams.ciphertext.toString(Hex);
	        },

	        /**
	         * Converts a hexadecimally encoded ciphertext string to a cipher params object.
	         *
	         * @param {string} input The hexadecimally encoded string.
	         *
	         * @return {CipherParams} The cipher params object.
	         *
	         * @static
	         *
	         * @example
	         *
	         *     var cipherParams = CryptoJS.format.Hex.parse(hexString);
	         */
	        parse: function (input) {
	            var ciphertext = Hex.parse(input);
	            return CipherParams.create({ ciphertext: ciphertext });
	        }
	    };
	}());


	return CryptoJS.format.Hex;

}));

/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(127), __webpack_require__(128), __webpack_require__(138), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var BlockCipher = C_lib.BlockCipher;
	    var C_algo = C.algo;

	    // Lookup tables
	    var SBOX = [];
	    var INV_SBOX = [];
	    var SUB_MIX_0 = [];
	    var SUB_MIX_1 = [];
	    var SUB_MIX_2 = [];
	    var SUB_MIX_3 = [];
	    var INV_SUB_MIX_0 = [];
	    var INV_SUB_MIX_1 = [];
	    var INV_SUB_MIX_2 = [];
	    var INV_SUB_MIX_3 = [];

	    // Compute lookup tables
	    (function () {
	        // Compute double table
	        var d = [];
	        for (var i = 0; i < 256; i++) {
	            if (i < 128) {
	                d[i] = i << 1;
	            } else {
	                d[i] = (i << 1) ^ 0x11b;
	            }
	        }

	        // Walk GF(2^8)
	        var x = 0;
	        var xi = 0;
	        for (var i = 0; i < 256; i++) {
	            // Compute sbox
	            var sx = xi ^ (xi << 1) ^ (xi << 2) ^ (xi << 3) ^ (xi << 4);
	            sx = (sx >>> 8) ^ (sx & 0xff) ^ 0x63;
	            SBOX[x] = sx;
	            INV_SBOX[sx] = x;

	            // Compute multiplication
	            var x2 = d[x];
	            var x4 = d[x2];
	            var x8 = d[x4];

	            // Compute sub bytes, mix columns tables
	            var t = (d[sx] * 0x101) ^ (sx * 0x1010100);
	            SUB_MIX_0[x] = (t << 24) | (t >>> 8);
	            SUB_MIX_1[x] = (t << 16) | (t >>> 16);
	            SUB_MIX_2[x] = (t << 8)  | (t >>> 24);
	            SUB_MIX_3[x] = t;

	            // Compute inv sub bytes, inv mix columns tables
	            var t = (x8 * 0x1010101) ^ (x4 * 0x10001) ^ (x2 * 0x101) ^ (x * 0x1010100);
	            INV_SUB_MIX_0[sx] = (t << 24) | (t >>> 8);
	            INV_SUB_MIX_1[sx] = (t << 16) | (t >>> 16);
	            INV_SUB_MIX_2[sx] = (t << 8)  | (t >>> 24);
	            INV_SUB_MIX_3[sx] = t;

	            // Compute next counter
	            if (!x) {
	                x = xi = 1;
	            } else {
	                x = x2 ^ d[d[d[x8 ^ x2]]];
	                xi ^= d[d[xi]];
	            }
	        }
	    }());

	    // Precomputed Rcon lookup
	    var RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36];

	    /**
	     * AES block cipher algorithm.
	     */
	    var AES = C_algo.AES = BlockCipher.extend({
	        _doReset: function () {
	            // Skip reset of nRounds has been set before and key did not change
	            if (this._nRounds && this._keyPriorReset === this._key) {
	                return;
	            }

	            // Shortcuts
	            var key = this._keyPriorReset = this._key;
	            var keyWords = key.words;
	            var keySize = key.sigBytes / 4;

	            // Compute number of rounds
	            var nRounds = this._nRounds = keySize + 6;

	            // Compute number of key schedule rows
	            var ksRows = (nRounds + 1) * 4;

	            // Compute key schedule
	            var keySchedule = this._keySchedule = [];
	            for (var ksRow = 0; ksRow < ksRows; ksRow++) {
	                if (ksRow < keySize) {
	                    keySchedule[ksRow] = keyWords[ksRow];
	                } else {
	                    var t = keySchedule[ksRow - 1];

	                    if (!(ksRow % keySize)) {
	                        // Rot word
	                        t = (t << 8) | (t >>> 24);

	                        // Sub word
	                        t = (SBOX[t >>> 24] << 24) | (SBOX[(t >>> 16) & 0xff] << 16) | (SBOX[(t >>> 8) & 0xff] << 8) | SBOX[t & 0xff];

	                        // Mix Rcon
	                        t ^= RCON[(ksRow / keySize) | 0] << 24;
	                    } else if (keySize > 6 && ksRow % keySize == 4) {
	                        // Sub word
	                        t = (SBOX[t >>> 24] << 24) | (SBOX[(t >>> 16) & 0xff] << 16) | (SBOX[(t >>> 8) & 0xff] << 8) | SBOX[t & 0xff];
	                    }

	                    keySchedule[ksRow] = keySchedule[ksRow - keySize] ^ t;
	                }
	            }

	            // Compute inv key schedule
	            var invKeySchedule = this._invKeySchedule = [];
	            for (var invKsRow = 0; invKsRow < ksRows; invKsRow++) {
	                var ksRow = ksRows - invKsRow;

	                if (invKsRow % 4) {
	                    var t = keySchedule[ksRow];
	                } else {
	                    var t = keySchedule[ksRow - 4];
	                }

	                if (invKsRow < 4 || ksRow <= 4) {
	                    invKeySchedule[invKsRow] = t;
	                } else {
	                    invKeySchedule[invKsRow] = INV_SUB_MIX_0[SBOX[t >>> 24]] ^ INV_SUB_MIX_1[SBOX[(t >>> 16) & 0xff]] ^
	                                               INV_SUB_MIX_2[SBOX[(t >>> 8) & 0xff]] ^ INV_SUB_MIX_3[SBOX[t & 0xff]];
	                }
	            }
	        },

	        encryptBlock: function (M, offset) {
	            this._doCryptBlock(M, offset, this._keySchedule, SUB_MIX_0, SUB_MIX_1, SUB_MIX_2, SUB_MIX_3, SBOX);
	        },

	        decryptBlock: function (M, offset) {
	            // Swap 2nd and 4th rows
	            var t = M[offset + 1];
	            M[offset + 1] = M[offset + 3];
	            M[offset + 3] = t;

	            this._doCryptBlock(M, offset, this._invKeySchedule, INV_SUB_MIX_0, INV_SUB_MIX_1, INV_SUB_MIX_2, INV_SUB_MIX_3, INV_SBOX);

	            // Inv swap 2nd and 4th rows
	            var t = M[offset + 1];
	            M[offset + 1] = M[offset + 3];
	            M[offset + 3] = t;
	        },

	        _doCryptBlock: function (M, offset, keySchedule, SUB_MIX_0, SUB_MIX_1, SUB_MIX_2, SUB_MIX_3, SBOX) {
	            // Shortcut
	            var nRounds = this._nRounds;

	            // Get input, add round key
	            var s0 = M[offset]     ^ keySchedule[0];
	            var s1 = M[offset + 1] ^ keySchedule[1];
	            var s2 = M[offset + 2] ^ keySchedule[2];
	            var s3 = M[offset + 3] ^ keySchedule[3];

	            // Key schedule row counter
	            var ksRow = 4;

	            // Rounds
	            for (var round = 1; round < nRounds; round++) {
	                // Shift rows, sub bytes, mix columns, add round key
	                var t0 = SUB_MIX_0[s0 >>> 24] ^ SUB_MIX_1[(s1 >>> 16) & 0xff] ^ SUB_MIX_2[(s2 >>> 8) & 0xff] ^ SUB_MIX_3[s3 & 0xff] ^ keySchedule[ksRow++];
	                var t1 = SUB_MIX_0[s1 >>> 24] ^ SUB_MIX_1[(s2 >>> 16) & 0xff] ^ SUB_MIX_2[(s3 >>> 8) & 0xff] ^ SUB_MIX_3[s0 & 0xff] ^ keySchedule[ksRow++];
	                var t2 = SUB_MIX_0[s2 >>> 24] ^ SUB_MIX_1[(s3 >>> 16) & 0xff] ^ SUB_MIX_2[(s0 >>> 8) & 0xff] ^ SUB_MIX_3[s1 & 0xff] ^ keySchedule[ksRow++];
	                var t3 = SUB_MIX_0[s3 >>> 24] ^ SUB_MIX_1[(s0 >>> 16) & 0xff] ^ SUB_MIX_2[(s1 >>> 8) & 0xff] ^ SUB_MIX_3[s2 & 0xff] ^ keySchedule[ksRow++];

	                // Update state
	                s0 = t0;
	                s1 = t1;
	                s2 = t2;
	                s3 = t3;
	            }

	            // Shift rows, sub bytes, add round key
	            var t0 = ((SBOX[s0 >>> 24] << 24) | (SBOX[(s1 >>> 16) & 0xff] << 16) | (SBOX[(s2 >>> 8) & 0xff] << 8) | SBOX[s3 & 0xff]) ^ keySchedule[ksRow++];
	            var t1 = ((SBOX[s1 >>> 24] << 24) | (SBOX[(s2 >>> 16) & 0xff] << 16) | (SBOX[(s3 >>> 8) & 0xff] << 8) | SBOX[s0 & 0xff]) ^ keySchedule[ksRow++];
	            var t2 = ((SBOX[s2 >>> 24] << 24) | (SBOX[(s3 >>> 16) & 0xff] << 16) | (SBOX[(s0 >>> 8) & 0xff] << 8) | SBOX[s1 & 0xff]) ^ keySchedule[ksRow++];
	            var t3 = ((SBOX[s3 >>> 24] << 24) | (SBOX[(s0 >>> 16) & 0xff] << 16) | (SBOX[(s1 >>> 8) & 0xff] << 8) | SBOX[s2 & 0xff]) ^ keySchedule[ksRow++];

	            // Set output
	            M[offset]     = t0;
	            M[offset + 1] = t1;
	            M[offset + 2] = t2;
	            M[offset + 3] = t3;
	        },

	        keySize: 256/32
	    });

	    /**
	     * Shortcut functions to the cipher's object interface.
	     *
	     * @example
	     *
	     *     var ciphertext = CryptoJS.AES.encrypt(message, key, cfg);
	     *     var plaintext  = CryptoJS.AES.decrypt(ciphertext, key, cfg);
	     */
	    C.AES = BlockCipher._createHelper(AES);
	}());


	return CryptoJS.AES;

}));

/***/ }),
/* 152 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(127), __webpack_require__(128), __webpack_require__(138), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var WordArray = C_lib.WordArray;
	    var BlockCipher = C_lib.BlockCipher;
	    var C_algo = C.algo;

	    // Permuted Choice 1 constants
	    var PC1 = [
	        57, 49, 41, 33, 25, 17, 9,  1,
	        58, 50, 42, 34, 26, 18, 10, 2,
	        59, 51, 43, 35, 27, 19, 11, 3,
	        60, 52, 44, 36, 63, 55, 47, 39,
	        31, 23, 15, 7,  62, 54, 46, 38,
	        30, 22, 14, 6,  61, 53, 45, 37,
	        29, 21, 13, 5,  28, 20, 12, 4
	    ];

	    // Permuted Choice 2 constants
	    var PC2 = [
	        14, 17, 11, 24, 1,  5,
	        3,  28, 15, 6,  21, 10,
	        23, 19, 12, 4,  26, 8,
	        16, 7,  27, 20, 13, 2,
	        41, 52, 31, 37, 47, 55,
	        30, 40, 51, 45, 33, 48,
	        44, 49, 39, 56, 34, 53,
	        46, 42, 50, 36, 29, 32
	    ];

	    // Cumulative bit shift constants
	    var BIT_SHIFTS = [1,  2,  4,  6,  8,  10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 28];

	    // SBOXes and round permutation constants
	    var SBOX_P = [
	        {
	            0x0: 0x808200,
	            0x10000000: 0x8000,
	            0x20000000: 0x808002,
	            0x30000000: 0x2,
	            0x40000000: 0x200,
	            0x50000000: 0x808202,
	            0x60000000: 0x800202,
	            0x70000000: 0x800000,
	            0x80000000: 0x202,
	            0x90000000: 0x800200,
	            0xa0000000: 0x8200,
	            0xb0000000: 0x808000,
	            0xc0000000: 0x8002,
	            0xd0000000: 0x800002,
	            0xe0000000: 0x0,
	            0xf0000000: 0x8202,
	            0x8000000: 0x0,
	            0x18000000: 0x808202,
	            0x28000000: 0x8202,
	            0x38000000: 0x8000,
	            0x48000000: 0x808200,
	            0x58000000: 0x200,
	            0x68000000: 0x808002,
	            0x78000000: 0x2,
	            0x88000000: 0x800200,
	            0x98000000: 0x8200,
	            0xa8000000: 0x808000,
	            0xb8000000: 0x800202,
	            0xc8000000: 0x800002,
	            0xd8000000: 0x8002,
	            0xe8000000: 0x202,
	            0xf8000000: 0x800000,
	            0x1: 0x8000,
	            0x10000001: 0x2,
	            0x20000001: 0x808200,
	            0x30000001: 0x800000,
	            0x40000001: 0x808002,
	            0x50000001: 0x8200,
	            0x60000001: 0x200,
	            0x70000001: 0x800202,
	            0x80000001: 0x808202,
	            0x90000001: 0x808000,
	            0xa0000001: 0x800002,
	            0xb0000001: 0x8202,
	            0xc0000001: 0x202,
	            0xd0000001: 0x800200,
	            0xe0000001: 0x8002,
	            0xf0000001: 0x0,
	            0x8000001: 0x808202,
	            0x18000001: 0x808000,
	            0x28000001: 0x800000,
	            0x38000001: 0x200,
	            0x48000001: 0x8000,
	            0x58000001: 0x800002,
	            0x68000001: 0x2,
	            0x78000001: 0x8202,
	            0x88000001: 0x8002,
	            0x98000001: 0x800202,
	            0xa8000001: 0x202,
	            0xb8000001: 0x808200,
	            0xc8000001: 0x800200,
	            0xd8000001: 0x0,
	            0xe8000001: 0x8200,
	            0xf8000001: 0x808002
	        },
	        {
	            0x0: 0x40084010,
	            0x1000000: 0x4000,
	            0x2000000: 0x80000,
	            0x3000000: 0x40080010,
	            0x4000000: 0x40000010,
	            0x5000000: 0x40084000,
	            0x6000000: 0x40004000,
	            0x7000000: 0x10,
	            0x8000000: 0x84000,
	            0x9000000: 0x40004010,
	            0xa000000: 0x40000000,
	            0xb000000: 0x84010,
	            0xc000000: 0x80010,
	            0xd000000: 0x0,
	            0xe000000: 0x4010,
	            0xf000000: 0x40080000,
	            0x800000: 0x40004000,
	            0x1800000: 0x84010,
	            0x2800000: 0x10,
	            0x3800000: 0x40004010,
	            0x4800000: 0x40084010,
	            0x5800000: 0x40000000,
	            0x6800000: 0x80000,
	            0x7800000: 0x40080010,
	            0x8800000: 0x80010,
	            0x9800000: 0x0,
	            0xa800000: 0x4000,
	            0xb800000: 0x40080000,
	            0xc800000: 0x40000010,
	            0xd800000: 0x84000,
	            0xe800000: 0x40084000,
	            0xf800000: 0x4010,
	            0x10000000: 0x0,
	            0x11000000: 0x40080010,
	            0x12000000: 0x40004010,
	            0x13000000: 0x40084000,
	            0x14000000: 0x40080000,
	            0x15000000: 0x10,
	            0x16000000: 0x84010,
	            0x17000000: 0x4000,
	            0x18000000: 0x4010,
	            0x19000000: 0x80000,
	            0x1a000000: 0x80010,
	            0x1b000000: 0x40000010,
	            0x1c000000: 0x84000,
	            0x1d000000: 0x40004000,
	            0x1e000000: 0x40000000,
	            0x1f000000: 0x40084010,
	            0x10800000: 0x84010,
	            0x11800000: 0x80000,
	            0x12800000: 0x40080000,
	            0x13800000: 0x4000,
	            0x14800000: 0x40004000,
	            0x15800000: 0x40084010,
	            0x16800000: 0x10,
	            0x17800000: 0x40000000,
	            0x18800000: 0x40084000,
	            0x19800000: 0x40000010,
	            0x1a800000: 0x40004010,
	            0x1b800000: 0x80010,
	            0x1c800000: 0x0,
	            0x1d800000: 0x4010,
	            0x1e800000: 0x40080010,
	            0x1f800000: 0x84000
	        },
	        {
	            0x0: 0x104,
	            0x100000: 0x0,
	            0x200000: 0x4000100,
	            0x300000: 0x10104,
	            0x400000: 0x10004,
	            0x500000: 0x4000004,
	            0x600000: 0x4010104,
	            0x700000: 0x4010000,
	            0x800000: 0x4000000,
	            0x900000: 0x4010100,
	            0xa00000: 0x10100,
	            0xb00000: 0x4010004,
	            0xc00000: 0x4000104,
	            0xd00000: 0x10000,
	            0xe00000: 0x4,
	            0xf00000: 0x100,
	            0x80000: 0x4010100,
	            0x180000: 0x4010004,
	            0x280000: 0x0,
	            0x380000: 0x4000100,
	            0x480000: 0x4000004,
	            0x580000: 0x10000,
	            0x680000: 0x10004,
	            0x780000: 0x104,
	            0x880000: 0x4,
	            0x980000: 0x100,
	            0xa80000: 0x4010000,
	            0xb80000: 0x10104,
	            0xc80000: 0x10100,
	            0xd80000: 0x4000104,
	            0xe80000: 0x4010104,
	            0xf80000: 0x4000000,
	            0x1000000: 0x4010100,
	            0x1100000: 0x10004,
	            0x1200000: 0x10000,
	            0x1300000: 0x4000100,
	            0x1400000: 0x100,
	            0x1500000: 0x4010104,
	            0x1600000: 0x4000004,
	            0x1700000: 0x0,
	            0x1800000: 0x4000104,
	            0x1900000: 0x4000000,
	            0x1a00000: 0x4,
	            0x1b00000: 0x10100,
	            0x1c00000: 0x4010000,
	            0x1d00000: 0x104,
	            0x1e00000: 0x10104,
	            0x1f00000: 0x4010004,
	            0x1080000: 0x4000000,
	            0x1180000: 0x104,
	            0x1280000: 0x4010100,
	            0x1380000: 0x0,
	            0x1480000: 0x10004,
	            0x1580000: 0x4000100,
	            0x1680000: 0x100,
	            0x1780000: 0x4010004,
	            0x1880000: 0x10000,
	            0x1980000: 0x4010104,
	            0x1a80000: 0x10104,
	            0x1b80000: 0x4000004,
	            0x1c80000: 0x4000104,
	            0x1d80000: 0x4010000,
	            0x1e80000: 0x4,
	            0x1f80000: 0x10100
	        },
	        {
	            0x0: 0x80401000,
	            0x10000: 0x80001040,
	            0x20000: 0x401040,
	            0x30000: 0x80400000,
	            0x40000: 0x0,
	            0x50000: 0x401000,
	            0x60000: 0x80000040,
	            0x70000: 0x400040,
	            0x80000: 0x80000000,
	            0x90000: 0x400000,
	            0xa0000: 0x40,
	            0xb0000: 0x80001000,
	            0xc0000: 0x80400040,
	            0xd0000: 0x1040,
	            0xe0000: 0x1000,
	            0xf0000: 0x80401040,
	            0x8000: 0x80001040,
	            0x18000: 0x40,
	            0x28000: 0x80400040,
	            0x38000: 0x80001000,
	            0x48000: 0x401000,
	            0x58000: 0x80401040,
	            0x68000: 0x0,
	            0x78000: 0x80400000,
	            0x88000: 0x1000,
	            0x98000: 0x80401000,
	            0xa8000: 0x400000,
	            0xb8000: 0x1040,
	            0xc8000: 0x80000000,
	            0xd8000: 0x400040,
	            0xe8000: 0x401040,
	            0xf8000: 0x80000040,
	            0x100000: 0x400040,
	            0x110000: 0x401000,
	            0x120000: 0x80000040,
	            0x130000: 0x0,
	            0x140000: 0x1040,
	            0x150000: 0x80400040,
	            0x160000: 0x80401000,
	            0x170000: 0x80001040,
	            0x180000: 0x80401040,
	            0x190000: 0x80000000,
	            0x1a0000: 0x80400000,
	            0x1b0000: 0x401040,
	            0x1c0000: 0x80001000,
	            0x1d0000: 0x400000,
	            0x1e0000: 0x40,
	            0x1f0000: 0x1000,
	            0x108000: 0x80400000,
	            0x118000: 0x80401040,
	            0x128000: 0x0,
	            0x138000: 0x401000,
	            0x148000: 0x400040,
	            0x158000: 0x80000000,
	            0x168000: 0x80001040,
	            0x178000: 0x40,
	            0x188000: 0x80000040,
	            0x198000: 0x1000,
	            0x1a8000: 0x80001000,
	            0x1b8000: 0x80400040,
	            0x1c8000: 0x1040,
	            0x1d8000: 0x80401000,
	            0x1e8000: 0x400000,
	            0x1f8000: 0x401040
	        },
	        {
	            0x0: 0x80,
	            0x1000: 0x1040000,
	            0x2000: 0x40000,
	            0x3000: 0x20000000,
	            0x4000: 0x20040080,
	            0x5000: 0x1000080,
	            0x6000: 0x21000080,
	            0x7000: 0x40080,
	            0x8000: 0x1000000,
	            0x9000: 0x20040000,
	            0xa000: 0x20000080,
	            0xb000: 0x21040080,
	            0xc000: 0x21040000,
	            0xd000: 0x0,
	            0xe000: 0x1040080,
	            0xf000: 0x21000000,
	            0x800: 0x1040080,
	            0x1800: 0x21000080,
	            0x2800: 0x80,
	            0x3800: 0x1040000,
	            0x4800: 0x40000,
	            0x5800: 0x20040080,
	            0x6800: 0x21040000,
	            0x7800: 0x20000000,
	            0x8800: 0x20040000,
	            0x9800: 0x0,
	            0xa800: 0x21040080,
	            0xb800: 0x1000080,
	            0xc800: 0x20000080,
	            0xd800: 0x21000000,
	            0xe800: 0x1000000,
	            0xf800: 0x40080,
	            0x10000: 0x40000,
	            0x11000: 0x80,
	            0x12000: 0x20000000,
	            0x13000: 0x21000080,
	            0x14000: 0x1000080,
	            0x15000: 0x21040000,
	            0x16000: 0x20040080,
	            0x17000: 0x1000000,
	            0x18000: 0x21040080,
	            0x19000: 0x21000000,
	            0x1a000: 0x1040000,
	            0x1b000: 0x20040000,
	            0x1c000: 0x40080,
	            0x1d000: 0x20000080,
	            0x1e000: 0x0,
	            0x1f000: 0x1040080,
	            0x10800: 0x21000080,
	            0x11800: 0x1000000,
	            0x12800: 0x1040000,
	            0x13800: 0x20040080,
	            0x14800: 0x20000000,
	            0x15800: 0x1040080,
	            0x16800: 0x80,
	            0x17800: 0x21040000,
	            0x18800: 0x40080,
	            0x19800: 0x21040080,
	            0x1a800: 0x0,
	            0x1b800: 0x21000000,
	            0x1c800: 0x1000080,
	            0x1d800: 0x40000,
	            0x1e800: 0x20040000,
	            0x1f800: 0x20000080
	        },
	        {
	            0x0: 0x10000008,
	            0x100: 0x2000,
	            0x200: 0x10200000,
	            0x300: 0x10202008,
	            0x400: 0x10002000,
	            0x500: 0x200000,
	            0x600: 0x200008,
	            0x700: 0x10000000,
	            0x800: 0x0,
	            0x900: 0x10002008,
	            0xa00: 0x202000,
	            0xb00: 0x8,
	            0xc00: 0x10200008,
	            0xd00: 0x202008,
	            0xe00: 0x2008,
	            0xf00: 0x10202000,
	            0x80: 0x10200000,
	            0x180: 0x10202008,
	            0x280: 0x8,
	            0x380: 0x200000,
	            0x480: 0x202008,
	            0x580: 0x10000008,
	            0x680: 0x10002000,
	            0x780: 0x2008,
	            0x880: 0x200008,
	            0x980: 0x2000,
	            0xa80: 0x10002008,
	            0xb80: 0x10200008,
	            0xc80: 0x0,
	            0xd80: 0x10202000,
	            0xe80: 0x202000,
	            0xf80: 0x10000000,
	            0x1000: 0x10002000,
	            0x1100: 0x10200008,
	            0x1200: 0x10202008,
	            0x1300: 0x2008,
	            0x1400: 0x200000,
	            0x1500: 0x10000000,
	            0x1600: 0x10000008,
	            0x1700: 0x202000,
	            0x1800: 0x202008,
	            0x1900: 0x0,
	            0x1a00: 0x8,
	            0x1b00: 0x10200000,
	            0x1c00: 0x2000,
	            0x1d00: 0x10002008,
	            0x1e00: 0x10202000,
	            0x1f00: 0x200008,
	            0x1080: 0x8,
	            0x1180: 0x202000,
	            0x1280: 0x200000,
	            0x1380: 0x10000008,
	            0x1480: 0x10002000,
	            0x1580: 0x2008,
	            0x1680: 0x10202008,
	            0x1780: 0x10200000,
	            0x1880: 0x10202000,
	            0x1980: 0x10200008,
	            0x1a80: 0x2000,
	            0x1b80: 0x202008,
	            0x1c80: 0x200008,
	            0x1d80: 0x0,
	            0x1e80: 0x10000000,
	            0x1f80: 0x10002008
	        },
	        {
	            0x0: 0x100000,
	            0x10: 0x2000401,
	            0x20: 0x400,
	            0x30: 0x100401,
	            0x40: 0x2100401,
	            0x50: 0x0,
	            0x60: 0x1,
	            0x70: 0x2100001,
	            0x80: 0x2000400,
	            0x90: 0x100001,
	            0xa0: 0x2000001,
	            0xb0: 0x2100400,
	            0xc0: 0x2100000,
	            0xd0: 0x401,
	            0xe0: 0x100400,
	            0xf0: 0x2000000,
	            0x8: 0x2100001,
	            0x18: 0x0,
	            0x28: 0x2000401,
	            0x38: 0x2100400,
	            0x48: 0x100000,
	            0x58: 0x2000001,
	            0x68: 0x2000000,
	            0x78: 0x401,
	            0x88: 0x100401,
	            0x98: 0x2000400,
	            0xa8: 0x2100000,
	            0xb8: 0x100001,
	            0xc8: 0x400,
	            0xd8: 0x2100401,
	            0xe8: 0x1,
	            0xf8: 0x100400,
	            0x100: 0x2000000,
	            0x110: 0x100000,
	            0x120: 0x2000401,
	            0x130: 0x2100001,
	            0x140: 0x100001,
	            0x150: 0x2000400,
	            0x160: 0x2100400,
	            0x170: 0x100401,
	            0x180: 0x401,
	            0x190: 0x2100401,
	            0x1a0: 0x100400,
	            0x1b0: 0x1,
	            0x1c0: 0x0,
	            0x1d0: 0x2100000,
	            0x1e0: 0x2000001,
	            0x1f0: 0x400,
	            0x108: 0x100400,
	            0x118: 0x2000401,
	            0x128: 0x2100001,
	            0x138: 0x1,
	            0x148: 0x2000000,
	            0x158: 0x100000,
	            0x168: 0x401,
	            0x178: 0x2100400,
	            0x188: 0x2000001,
	            0x198: 0x2100000,
	            0x1a8: 0x0,
	            0x1b8: 0x2100401,
	            0x1c8: 0x100401,
	            0x1d8: 0x400,
	            0x1e8: 0x2000400,
	            0x1f8: 0x100001
	        },
	        {
	            0x0: 0x8000820,
	            0x1: 0x20000,
	            0x2: 0x8000000,
	            0x3: 0x20,
	            0x4: 0x20020,
	            0x5: 0x8020820,
	            0x6: 0x8020800,
	            0x7: 0x800,
	            0x8: 0x8020000,
	            0x9: 0x8000800,
	            0xa: 0x20800,
	            0xb: 0x8020020,
	            0xc: 0x820,
	            0xd: 0x0,
	            0xe: 0x8000020,
	            0xf: 0x20820,
	            0x80000000: 0x800,
	            0x80000001: 0x8020820,
	            0x80000002: 0x8000820,
	            0x80000003: 0x8000000,
	            0x80000004: 0x8020000,
	            0x80000005: 0x20800,
	            0x80000006: 0x20820,
	            0x80000007: 0x20,
	            0x80000008: 0x8000020,
	            0x80000009: 0x820,
	            0x8000000a: 0x20020,
	            0x8000000b: 0x8020800,
	            0x8000000c: 0x0,
	            0x8000000d: 0x8020020,
	            0x8000000e: 0x8000800,
	            0x8000000f: 0x20000,
	            0x10: 0x20820,
	            0x11: 0x8020800,
	            0x12: 0x20,
	            0x13: 0x800,
	            0x14: 0x8000800,
	            0x15: 0x8000020,
	            0x16: 0x8020020,
	            0x17: 0x20000,
	            0x18: 0x0,
	            0x19: 0x20020,
	            0x1a: 0x8020000,
	            0x1b: 0x8000820,
	            0x1c: 0x8020820,
	            0x1d: 0x20800,
	            0x1e: 0x820,
	            0x1f: 0x8000000,
	            0x80000010: 0x20000,
	            0x80000011: 0x800,
	            0x80000012: 0x8020020,
	            0x80000013: 0x20820,
	            0x80000014: 0x20,
	            0x80000015: 0x8020000,
	            0x80000016: 0x8000000,
	            0x80000017: 0x8000820,
	            0x80000018: 0x8020820,
	            0x80000019: 0x8000020,
	            0x8000001a: 0x8000800,
	            0x8000001b: 0x0,
	            0x8000001c: 0x20800,
	            0x8000001d: 0x820,
	            0x8000001e: 0x20020,
	            0x8000001f: 0x8020800
	        }
	    ];

	    // Masks that select the SBOX input
	    var SBOX_MASK = [
	        0xf8000001, 0x1f800000, 0x01f80000, 0x001f8000,
	        0x0001f800, 0x00001f80, 0x000001f8, 0x8000001f
	    ];

	    /**
	     * DES block cipher algorithm.
	     */
	    var DES = C_algo.DES = BlockCipher.extend({
	        _doReset: function () {
	            // Shortcuts
	            var key = this._key;
	            var keyWords = key.words;

	            // Select 56 bits according to PC1
	            var keyBits = [];
	            for (var i = 0; i < 56; i++) {
	                var keyBitPos = PC1[i] - 1;
	                keyBits[i] = (keyWords[keyBitPos >>> 5] >>> (31 - keyBitPos % 32)) & 1;
	            }

	            // Assemble 16 subkeys
	            var subKeys = this._subKeys = [];
	            for (var nSubKey = 0; nSubKey < 16; nSubKey++) {
	                // Create subkey
	                var subKey = subKeys[nSubKey] = [];

	                // Shortcut
	                var bitShift = BIT_SHIFTS[nSubKey];

	                // Select 48 bits according to PC2
	                for (var i = 0; i < 24; i++) {
	                    // Select from the left 28 key bits
	                    subKey[(i / 6) | 0] |= keyBits[((PC2[i] - 1) + bitShift) % 28] << (31 - i % 6);

	                    // Select from the right 28 key bits
	                    subKey[4 + ((i / 6) | 0)] |= keyBits[28 + (((PC2[i + 24] - 1) + bitShift) % 28)] << (31 - i % 6);
	                }

	                // Since each subkey is applied to an expanded 32-bit input,
	                // the subkey can be broken into 8 values scaled to 32-bits,
	                // which allows the key to be used without expansion
	                subKey[0] = (subKey[0] << 1) | (subKey[0] >>> 31);
	                for (var i = 1; i < 7; i++) {
	                    subKey[i] = subKey[i] >>> ((i - 1) * 4 + 3);
	                }
	                subKey[7] = (subKey[7] << 5) | (subKey[7] >>> 27);
	            }

	            // Compute inverse subkeys
	            var invSubKeys = this._invSubKeys = [];
	            for (var i = 0; i < 16; i++) {
	                invSubKeys[i] = subKeys[15 - i];
	            }
	        },

	        encryptBlock: function (M, offset) {
	            this._doCryptBlock(M, offset, this._subKeys);
	        },

	        decryptBlock: function (M, offset) {
	            this._doCryptBlock(M, offset, this._invSubKeys);
	        },

	        _doCryptBlock: function (M, offset, subKeys) {
	            // Get input
	            this._lBlock = M[offset];
	            this._rBlock = M[offset + 1];

	            // Initial permutation
	            exchangeLR.call(this, 4,  0x0f0f0f0f);
	            exchangeLR.call(this, 16, 0x0000ffff);
	            exchangeRL.call(this, 2,  0x33333333);
	            exchangeRL.call(this, 8,  0x00ff00ff);
	            exchangeLR.call(this, 1,  0x55555555);

	            // Rounds
	            for (var round = 0; round < 16; round++) {
	                // Shortcuts
	                var subKey = subKeys[round];
	                var lBlock = this._lBlock;
	                var rBlock = this._rBlock;

	                // Feistel function
	                var f = 0;
	                for (var i = 0; i < 8; i++) {
	                    f |= SBOX_P[i][((rBlock ^ subKey[i]) & SBOX_MASK[i]) >>> 0];
	                }
	                this._lBlock = rBlock;
	                this._rBlock = lBlock ^ f;
	            }

	            // Undo swap from last round
	            var t = this._lBlock;
	            this._lBlock = this._rBlock;
	            this._rBlock = t;

	            // Final permutation
	            exchangeLR.call(this, 1,  0x55555555);
	            exchangeRL.call(this, 8,  0x00ff00ff);
	            exchangeRL.call(this, 2,  0x33333333);
	            exchangeLR.call(this, 16, 0x0000ffff);
	            exchangeLR.call(this, 4,  0x0f0f0f0f);

	            // Set output
	            M[offset] = this._lBlock;
	            M[offset + 1] = this._rBlock;
	        },

	        keySize: 64/32,

	        ivSize: 64/32,

	        blockSize: 64/32
	    });

	    // Swap bits across the left and right words
	    function exchangeLR(offset, mask) {
	        var t = ((this._lBlock >>> offset) ^ this._rBlock) & mask;
	        this._rBlock ^= t;
	        this._lBlock ^= t << offset;
	    }

	    function exchangeRL(offset, mask) {
	        var t = ((this._rBlock >>> offset) ^ this._lBlock) & mask;
	        this._lBlock ^= t;
	        this._rBlock ^= t << offset;
	    }

	    /**
	     * Shortcut functions to the cipher's object interface.
	     *
	     * @example
	     *
	     *     var ciphertext = CryptoJS.DES.encrypt(message, key, cfg);
	     *     var plaintext  = CryptoJS.DES.decrypt(ciphertext, key, cfg);
	     */
	    C.DES = BlockCipher._createHelper(DES);

	    /**
	     * Triple-DES block cipher algorithm.
	     */
	    var TripleDES = C_algo.TripleDES = BlockCipher.extend({
	        _doReset: function () {
	            // Shortcuts
	            var key = this._key;
	            var keyWords = key.words;

	            // Create DES instances
	            this._des1 = DES.createEncryptor(WordArray.create(keyWords.slice(0, 2)));
	            this._des2 = DES.createEncryptor(WordArray.create(keyWords.slice(2, 4)));
	            this._des3 = DES.createEncryptor(WordArray.create(keyWords.slice(4, 6)));
	        },

	        encryptBlock: function (M, offset) {
	            this._des1.encryptBlock(M, offset);
	            this._des2.decryptBlock(M, offset);
	            this._des3.encryptBlock(M, offset);
	        },

	        decryptBlock: function (M, offset) {
	            this._des3.decryptBlock(M, offset);
	            this._des2.encryptBlock(M, offset);
	            this._des1.decryptBlock(M, offset);
	        },

	        keySize: 192/32,

	        ivSize: 64/32,

	        blockSize: 64/32
	    });

	    /**
	     * Shortcut functions to the cipher's object interface.
	     *
	     * @example
	     *
	     *     var ciphertext = CryptoJS.TripleDES.encrypt(message, key, cfg);
	     *     var plaintext  = CryptoJS.TripleDES.decrypt(ciphertext, key, cfg);
	     */
	    C.TripleDES = BlockCipher._createHelper(TripleDES);
	}());


	return CryptoJS.TripleDES;

}));

/***/ }),
/* 153 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(127), __webpack_require__(128), __webpack_require__(138), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var StreamCipher = C_lib.StreamCipher;
	    var C_algo = C.algo;

	    /**
	     * RC4 stream cipher algorithm.
	     */
	    var RC4 = C_algo.RC4 = StreamCipher.extend({
	        _doReset: function () {
	            // Shortcuts
	            var key = this._key;
	            var keyWords = key.words;
	            var keySigBytes = key.sigBytes;

	            // Init sbox
	            var S = this._S = [];
	            for (var i = 0; i < 256; i++) {
	                S[i] = i;
	            }

	            // Key setup
	            for (var i = 0, j = 0; i < 256; i++) {
	                var keyByteIndex = i % keySigBytes;
	                var keyByte = (keyWords[keyByteIndex >>> 2] >>> (24 - (keyByteIndex % 4) * 8)) & 0xff;

	                j = (j + S[i] + keyByte) % 256;

	                // Swap
	                var t = S[i];
	                S[i] = S[j];
	                S[j] = t;
	            }

	            // Counters
	            this._i = this._j = 0;
	        },

	        _doProcessBlock: function (M, offset) {
	            M[offset] ^= generateKeystreamWord.call(this);
	        },

	        keySize: 256/32,

	        ivSize: 0
	    });

	    function generateKeystreamWord() {
	        // Shortcuts
	        var S = this._S;
	        var i = this._i;
	        var j = this._j;

	        // Generate keystream word
	        var keystreamWord = 0;
	        for (var n = 0; n < 4; n++) {
	            i = (i + 1) % 256;
	            j = (j + S[i]) % 256;

	            // Swap
	            var t = S[i];
	            S[i] = S[j];
	            S[j] = t;

	            keystreamWord |= S[(S[i] + S[j]) % 256] << (24 - n * 8);
	        }

	        // Update counters
	        this._i = i;
	        this._j = j;

	        return keystreamWord;
	    }

	    /**
	     * Shortcut functions to the cipher's object interface.
	     *
	     * @example
	     *
	     *     var ciphertext = CryptoJS.RC4.encrypt(message, key, cfg);
	     *     var plaintext  = CryptoJS.RC4.decrypt(ciphertext, key, cfg);
	     */
	    C.RC4 = StreamCipher._createHelper(RC4);

	    /**
	     * Modified RC4 stream cipher algorithm.
	     */
	    var RC4Drop = C_algo.RC4Drop = RC4.extend({
	        /**
	         * Configuration options.
	         *
	         * @property {number} drop The number of keystream words to drop. Default 192
	         */
	        cfg: RC4.cfg.extend({
	            drop: 192
	        }),

	        _doReset: function () {
	            RC4._doReset.call(this);

	            // Drop
	            for (var i = this.cfg.drop; i > 0; i--) {
	                generateKeystreamWord.call(this);
	            }
	        }
	    });

	    /**
	     * Shortcut functions to the cipher's object interface.
	     *
	     * @example
	     *
	     *     var ciphertext = CryptoJS.RC4Drop.encrypt(message, key, cfg);
	     *     var plaintext  = CryptoJS.RC4Drop.decrypt(ciphertext, key, cfg);
	     */
	    C.RC4Drop = StreamCipher._createHelper(RC4Drop);
	}());


	return CryptoJS.RC4;

}));

/***/ }),
/* 154 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(127), __webpack_require__(128), __webpack_require__(138), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var StreamCipher = C_lib.StreamCipher;
	    var C_algo = C.algo;

	    // Reusable objects
	    var S  = [];
	    var C_ = [];
	    var G  = [];

	    /**
	     * Rabbit stream cipher algorithm
	     */
	    var Rabbit = C_algo.Rabbit = StreamCipher.extend({
	        _doReset: function () {
	            // Shortcuts
	            var K = this._key.words;
	            var iv = this.cfg.iv;

	            // Swap endian
	            for (var i = 0; i < 4; i++) {
	                K[i] = (((K[i] << 8)  | (K[i] >>> 24)) & 0x00ff00ff) |
	                       (((K[i] << 24) | (K[i] >>> 8))  & 0xff00ff00);
	            }

	            // Generate initial state values
	            var X = this._X = [
	                K[0], (K[3] << 16) | (K[2] >>> 16),
	                K[1], (K[0] << 16) | (K[3] >>> 16),
	                K[2], (K[1] << 16) | (K[0] >>> 16),
	                K[3], (K[2] << 16) | (K[1] >>> 16)
	            ];

	            // Generate initial counter values
	            var C = this._C = [
	                (K[2] << 16) | (K[2] >>> 16), (K[0] & 0xffff0000) | (K[1] & 0x0000ffff),
	                (K[3] << 16) | (K[3] >>> 16), (K[1] & 0xffff0000) | (K[2] & 0x0000ffff),
	                (K[0] << 16) | (K[0] >>> 16), (K[2] & 0xffff0000) | (K[3] & 0x0000ffff),
	                (K[1] << 16) | (K[1] >>> 16), (K[3] & 0xffff0000) | (K[0] & 0x0000ffff)
	            ];

	            // Carry bit
	            this._b = 0;

	            // Iterate the system four times
	            for (var i = 0; i < 4; i++) {
	                nextState.call(this);
	            }

	            // Modify the counters
	            for (var i = 0; i < 8; i++) {
	                C[i] ^= X[(i + 4) & 7];
	            }

	            // IV setup
	            if (iv) {
	                // Shortcuts
	                var IV = iv.words;
	                var IV_0 = IV[0];
	                var IV_1 = IV[1];

	                // Generate four subvectors
	                var i0 = (((IV_0 << 8) | (IV_0 >>> 24)) & 0x00ff00ff) | (((IV_0 << 24) | (IV_0 >>> 8)) & 0xff00ff00);
	                var i2 = (((IV_1 << 8) | (IV_1 >>> 24)) & 0x00ff00ff) | (((IV_1 << 24) | (IV_1 >>> 8)) & 0xff00ff00);
	                var i1 = (i0 >>> 16) | (i2 & 0xffff0000);
	                var i3 = (i2 << 16)  | (i0 & 0x0000ffff);

	                // Modify counter values
	                C[0] ^= i0;
	                C[1] ^= i1;
	                C[2] ^= i2;
	                C[3] ^= i3;
	                C[4] ^= i0;
	                C[5] ^= i1;
	                C[6] ^= i2;
	                C[7] ^= i3;

	                // Iterate the system four times
	                for (var i = 0; i < 4; i++) {
	                    nextState.call(this);
	                }
	            }
	        },

	        _doProcessBlock: function (M, offset) {
	            // Shortcut
	            var X = this._X;

	            // Iterate the system
	            nextState.call(this);

	            // Generate four keystream words
	            S[0] = X[0] ^ (X[5] >>> 16) ^ (X[3] << 16);
	            S[1] = X[2] ^ (X[7] >>> 16) ^ (X[5] << 16);
	            S[2] = X[4] ^ (X[1] >>> 16) ^ (X[7] << 16);
	            S[3] = X[6] ^ (X[3] >>> 16) ^ (X[1] << 16);

	            for (var i = 0; i < 4; i++) {
	                // Swap endian
	                S[i] = (((S[i] << 8)  | (S[i] >>> 24)) & 0x00ff00ff) |
	                       (((S[i] << 24) | (S[i] >>> 8))  & 0xff00ff00);

	                // Encrypt
	                M[offset + i] ^= S[i];
	            }
	        },

	        blockSize: 128/32,

	        ivSize: 64/32
	    });

	    function nextState() {
	        // Shortcuts
	        var X = this._X;
	        var C = this._C;

	        // Save old counter values
	        for (var i = 0; i < 8; i++) {
	            C_[i] = C[i];
	        }

	        // Calculate new counter values
	        C[0] = (C[0] + 0x4d34d34d + this._b) | 0;
	        C[1] = (C[1] + 0xd34d34d3 + ((C[0] >>> 0) < (C_[0] >>> 0) ? 1 : 0)) | 0;
	        C[2] = (C[2] + 0x34d34d34 + ((C[1] >>> 0) < (C_[1] >>> 0) ? 1 : 0)) | 0;
	        C[3] = (C[3] + 0x4d34d34d + ((C[2] >>> 0) < (C_[2] >>> 0) ? 1 : 0)) | 0;
	        C[4] = (C[4] + 0xd34d34d3 + ((C[3] >>> 0) < (C_[3] >>> 0) ? 1 : 0)) | 0;
	        C[5] = (C[5] + 0x34d34d34 + ((C[4] >>> 0) < (C_[4] >>> 0) ? 1 : 0)) | 0;
	        C[6] = (C[6] + 0x4d34d34d + ((C[5] >>> 0) < (C_[5] >>> 0) ? 1 : 0)) | 0;
	        C[7] = (C[7] + 0xd34d34d3 + ((C[6] >>> 0) < (C_[6] >>> 0) ? 1 : 0)) | 0;
	        this._b = (C[7] >>> 0) < (C_[7] >>> 0) ? 1 : 0;

	        // Calculate the g-values
	        for (var i = 0; i < 8; i++) {
	            var gx = X[i] + C[i];

	            // Construct high and low argument for squaring
	            var ga = gx & 0xffff;
	            var gb = gx >>> 16;

	            // Calculate high and low result of squaring
	            var gh = ((((ga * ga) >>> 17) + ga * gb) >>> 15) + gb * gb;
	            var gl = (((gx & 0xffff0000) * gx) | 0) + (((gx & 0x0000ffff) * gx) | 0);

	            // High XOR low
	            G[i] = gh ^ gl;
	        }

	        // Calculate new state values
	        X[0] = (G[0] + ((G[7] << 16) | (G[7] >>> 16)) + ((G[6] << 16) | (G[6] >>> 16))) | 0;
	        X[1] = (G[1] + ((G[0] << 8)  | (G[0] >>> 24)) + G[7]) | 0;
	        X[2] = (G[2] + ((G[1] << 16) | (G[1] >>> 16)) + ((G[0] << 16) | (G[0] >>> 16))) | 0;
	        X[3] = (G[3] + ((G[2] << 8)  | (G[2] >>> 24)) + G[1]) | 0;
	        X[4] = (G[4] + ((G[3] << 16) | (G[3] >>> 16)) + ((G[2] << 16) | (G[2] >>> 16))) | 0;
	        X[5] = (G[5] + ((G[4] << 8)  | (G[4] >>> 24)) + G[3]) | 0;
	        X[6] = (G[6] + ((G[5] << 16) | (G[5] >>> 16)) + ((G[4] << 16) | (G[4] >>> 16))) | 0;
	        X[7] = (G[7] + ((G[6] << 8)  | (G[6] >>> 24)) + G[5]) | 0;
	    }

	    /**
	     * Shortcut functions to the cipher's object interface.
	     *
	     * @example
	     *
	     *     var ciphertext = CryptoJS.Rabbit.encrypt(message, key, cfg);
	     *     var plaintext  = CryptoJS.Rabbit.decrypt(ciphertext, key, cfg);
	     */
	    C.Rabbit = StreamCipher._createHelper(Rabbit);
	}());


	return CryptoJS.Rabbit;

}));

/***/ }),
/* 155 */
/***/ (function(module, exports, __webpack_require__) {

;(function (root, factory, undef) {
	if (true) {
		// CommonJS
		module.exports = exports = factory(__webpack_require__(123), __webpack_require__(127), __webpack_require__(128), __webpack_require__(138), __webpack_require__(139));
	}
	else {}
}(this, function (CryptoJS) {

	(function () {
	    // Shortcuts
	    var C = CryptoJS;
	    var C_lib = C.lib;
	    var StreamCipher = C_lib.StreamCipher;
	    var C_algo = C.algo;

	    // Reusable objects
	    var S  = [];
	    var C_ = [];
	    var G  = [];

	    /**
	     * Rabbit stream cipher algorithm.
	     *
	     * This is a legacy version that neglected to convert the key to little-endian.
	     * This error doesn't affect the cipher's security,
	     * but it does affect its compatibility with other implementations.
	     */
	    var RabbitLegacy = C_algo.RabbitLegacy = StreamCipher.extend({
	        _doReset: function () {
	            // Shortcuts
	            var K = this._key.words;
	            var iv = this.cfg.iv;

	            // Generate initial state values
	            var X = this._X = [
	                K[0], (K[3] << 16) | (K[2] >>> 16),
	                K[1], (K[0] << 16) | (K[3] >>> 16),
	                K[2], (K[1] << 16) | (K[0] >>> 16),
	                K[3], (K[2] << 16) | (K[1] >>> 16)
	            ];

	            // Generate initial counter values
	            var C = this._C = [
	                (K[2] << 16) | (K[2] >>> 16), (K[0] & 0xffff0000) | (K[1] & 0x0000ffff),
	                (K[3] << 16) | (K[3] >>> 16), (K[1] & 0xffff0000) | (K[2] & 0x0000ffff),
	                (K[0] << 16) | (K[0] >>> 16), (K[2] & 0xffff0000) | (K[3] & 0x0000ffff),
	                (K[1] << 16) | (K[1] >>> 16), (K[3] & 0xffff0000) | (K[0] & 0x0000ffff)
	            ];

	            // Carry bit
	            this._b = 0;

	            // Iterate the system four times
	            for (var i = 0; i < 4; i++) {
	                nextState.call(this);
	            }

	            // Modify the counters
	            for (var i = 0; i < 8; i++) {
	                C[i] ^= X[(i + 4) & 7];
	            }

	            // IV setup
	            if (iv) {
	                // Shortcuts
	                var IV = iv.words;
	                var IV_0 = IV[0];
	                var IV_1 = IV[1];

	                // Generate four subvectors
	                var i0 = (((IV_0 << 8) | (IV_0 >>> 24)) & 0x00ff00ff) | (((IV_0 << 24) | (IV_0 >>> 8)) & 0xff00ff00);
	                var i2 = (((IV_1 << 8) | (IV_1 >>> 24)) & 0x00ff00ff) | (((IV_1 << 24) | (IV_1 >>> 8)) & 0xff00ff00);
	                var i1 = (i0 >>> 16) | (i2 & 0xffff0000);
	                var i3 = (i2 << 16)  | (i0 & 0x0000ffff);

	                // Modify counter values
	                C[0] ^= i0;
	                C[1] ^= i1;
	                C[2] ^= i2;
	                C[3] ^= i3;
	                C[4] ^= i0;
	                C[5] ^= i1;
	                C[6] ^= i2;
	                C[7] ^= i3;

	                // Iterate the system four times
	                for (var i = 0; i < 4; i++) {
	                    nextState.call(this);
	                }
	            }
	        },

	        _doProcessBlock: function (M, offset) {
	            // Shortcut
	            var X = this._X;

	            // Iterate the system
	            nextState.call(this);

	            // Generate four keystream words
	            S[0] = X[0] ^ (X[5] >>> 16) ^ (X[3] << 16);
	            S[1] = X[2] ^ (X[7] >>> 16) ^ (X[5] << 16);
	            S[2] = X[4] ^ (X[1] >>> 16) ^ (X[7] << 16);
	            S[3] = X[6] ^ (X[3] >>> 16) ^ (X[1] << 16);

	            for (var i = 0; i < 4; i++) {
	                // Swap endian
	                S[i] = (((S[i] << 8)  | (S[i] >>> 24)) & 0x00ff00ff) |
	                       (((S[i] << 24) | (S[i] >>> 8))  & 0xff00ff00);

	                // Encrypt
	                M[offset + i] ^= S[i];
	            }
	        },

	        blockSize: 128/32,

	        ivSize: 64/32
	    });

	    function nextState() {
	        // Shortcuts
	        var X = this._X;
	        var C = this._C;

	        // Save old counter values
	        for (var i = 0; i < 8; i++) {
	            C_[i] = C[i];
	        }

	        // Calculate new counter values
	        C[0] = (C[0] + 0x4d34d34d + this._b) | 0;
	        C[1] = (C[1] + 0xd34d34d3 + ((C[0] >>> 0) < (C_[0] >>> 0) ? 1 : 0)) | 0;
	        C[2] = (C[2] + 0x34d34d34 + ((C[1] >>> 0) < (C_[1] >>> 0) ? 1 : 0)) | 0;
	        C[3] = (C[3] + 0x4d34d34d + ((C[2] >>> 0) < (C_[2] >>> 0) ? 1 : 0)) | 0;
	        C[4] = (C[4] + 0xd34d34d3 + ((C[3] >>> 0) < (C_[3] >>> 0) ? 1 : 0)) | 0;
	        C[5] = (C[5] + 0x34d34d34 + ((C[4] >>> 0) < (C_[4] >>> 0) ? 1 : 0)) | 0;
	        C[6] = (C[6] + 0x4d34d34d + ((C[5] >>> 0) < (C_[5] >>> 0) ? 1 : 0)) | 0;
	        C[7] = (C[7] + 0xd34d34d3 + ((C[6] >>> 0) < (C_[6] >>> 0) ? 1 : 0)) | 0;
	        this._b = (C[7] >>> 0) < (C_[7] >>> 0) ? 1 : 0;

	        // Calculate the g-values
	        for (var i = 0; i < 8; i++) {
	            var gx = X[i] + C[i];

	            // Construct high and low argument for squaring
	            var ga = gx & 0xffff;
	            var gb = gx >>> 16;

	            // Calculate high and low result of squaring
	            var gh = ((((ga * ga) >>> 17) + ga * gb) >>> 15) + gb * gb;
	            var gl = (((gx & 0xffff0000) * gx) | 0) + (((gx & 0x0000ffff) * gx) | 0);

	            // High XOR low
	            G[i] = gh ^ gl;
	        }

	        // Calculate new state values
	        X[0] = (G[0] + ((G[7] << 16) | (G[7] >>> 16)) + ((G[6] << 16) | (G[6] >>> 16))) | 0;
	        X[1] = (G[1] + ((G[0] << 8)  | (G[0] >>> 24)) + G[7]) | 0;
	        X[2] = (G[2] + ((G[1] << 16) | (G[1] >>> 16)) + ((G[0] << 16) | (G[0] >>> 16))) | 0;
	        X[3] = (G[3] + ((G[2] << 8)  | (G[2] >>> 24)) + G[1]) | 0;
	        X[4] = (G[4] + ((G[3] << 16) | (G[3] >>> 16)) + ((G[2] << 16) | (G[2] >>> 16))) | 0;
	        X[5] = (G[5] + ((G[4] << 8)  | (G[4] >>> 24)) + G[3]) | 0;
	        X[6] = (G[6] + ((G[5] << 16) | (G[5] >>> 16)) + ((G[4] << 16) | (G[4] >>> 16))) | 0;
	        X[7] = (G[7] + ((G[6] << 8)  | (G[6] >>> 24)) + G[5]) | 0;
	    }

	    /**
	     * Shortcut functions to the cipher's object interface.
	     *
	     * @example
	     *
	     *     var ciphertext = CryptoJS.RabbitLegacy.encrypt(message, key, cfg);
	     *     var plaintext  = CryptoJS.RabbitLegacy.decrypt(ciphertext, key, cfg);
	     */
	    C.RabbitLegacy = StreamCipher._createHelper(RabbitLegacy);
	}());


	return CryptoJS.RabbitLegacy;

}));

/***/ }),
/* 156 */
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.8.0 - Tue Apr 20 2021 11:27:38 */

  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */

  /* vim: set sts=2 sw=2 et tw=80: */

  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (typeof browser === "undefined" || Object.getPrototypeOf(browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
    const SEND_RESPONSE_DEPRECATION_WARNING = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)"; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.

    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */


      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }

      }
      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */


      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */


      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */


      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.

                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */


      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }

        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */

      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },

          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,

                get() {
                  return target[prop];
                },

                set(value) {
                  target[prop] = value;
                }

              });
              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }

            return true;
          },

          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }

        }; // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.

        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */


      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }

      });

      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */


        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {}
          /* wrappers */
          , {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      }); // Keep track if the deprecation warning has been logged at least once.

      let loggedSendResponseDeprecationWarning = false;
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */


        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              if (!loggedSendResponseDeprecationWarning) {
                console.warn(SEND_RESPONSE_DEPRECATION_WARNING, new Error().stack);
                loggedSendResponseDeprecationWarning = true;
              }

              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;

          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }

          const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.

          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          } // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).


          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;

              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }

              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          }; // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.


          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          } // Let Chrome know that the listener is replying.


          return true;
        };
      });

      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };

      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }

        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }

        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };

      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };

    if (typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
      throw new Error("This script should only be loaded in a browser extension.");
    } // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.


    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ }),
/* 157 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MessageType": () => (/* binding */ MessageType)
/* harmony export */ });
const MessageType = {
    GET_CHAPTER: "Get chapter",
    GET_METADATA: "Get metadata",
    GET_CHAPTERLIST: "Get chapterlist",
    FINISHED: "Finished"
}


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/harmony module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.hmd = (module) => {
/******/ 			module = Object.create(module);
/******/ 			if (!module.children) module.children = [];
/******/ 			Object.defineProperty(module, 'exports', {
/******/ 				enumerable: true,
/******/ 				set: () => {
/******/ 					throw new Error('ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: ' + module.id);
/******/ 				}
/******/ 			});
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _sites_jjwxc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/*** IMPORTS FROM imports-loader ***/


// Put all the javascript code here, that you want to execute after page load.
var browser = __webpack_require__(156);
var MESSAGE_TYPE = __webpack_require__(157);
//import {SiteLogic} from './sites/generic';

const MessageType = MESSAGE_TYPE.MessageType;

class ContentScript {
    constructor() {
        this.logic = new _sites_jjwxc__WEBPACK_IMPORTED_MODULE_0__.JJWXCLogic();
        this.overlay = document.createElement("div");
        let baseSize = Number(window.getComputedStyle(document.body).getPropertyValue('font-size').match(/\d+/)[0]);
        let width = (document.body.clientWidth - (35 * baseSize)) / 2;
        this.overlay.style = `display: block;width: 35em;background-color: white;height: 10em;z-index: 1000;position: fixed;top: 100px;left: ${width}px;border: 2px solid black;`;
        this.msgArea = document.createElement("div");
        this.msgArea.style = "padding: 2em;text-align: center;font-family: sans-serif;";

        this.overlay.appendChild(this.msgArea);
    }
    setup() {
        browser.runtime.onMessage.addListener( (message, sender) => {this.messageHandler(sender, message)});
        this.injectOverlay();
        this.updateOverlay("Fetching metadata....");
        let metadata = this.logic.processMetadata(document.body);

        this.messageDispatcher(metadata, MessageType.GET_METADATA);
    }
    messageHandler(sender, message) {
        switch (message.type) {
            case MessageType.GET_METADATA:
                this.updateOverlay("Fetching metadata....");
                let metadata = this.logic.processMetadata(document);
                console.debug(metadata);
                if (metadata) {
                    this.messageDispatcher(metadata, MessageType.GET_METADATA);
                }
                else {
                    this.updateOverlay("ERROR - couldn't metadata! Make sure you're the novel index page (not a chapter) and try again");
                }
                break;
            case MessageType.GET_CHAPTERLIST:
                let chapterlist = this.logic.getChapterlist(document);
                this.updateOverlay("Fetching chapterlist....");
                this.messageDispatcher(chapterlist, MessageType.GET_CHAPTERLIST);
                break;
            case MessageType.GET_CHAPTER:
                if (message.content.good) {
                    this.updateOverlay(`Got chapter ${message.content.current} of ${message.content.total}`);
                } else {
                    this.updateOverlay(`ERROR couldn't get chapter ${message.content.current} of ${message.content.total}`);
                }
                break;
            case MessageType.FINISHED:
                this.updateOverlay("Finished! Waiting 10sec for font downloads to finish, then generating epub.");
                setTimeout(() => { this.removeOverlay() }, 10000);
                break;

        }
    }

    messageDispatcher(message, type){
        browser.runtime.sendMessage({
            type: type,
            content: message
        });
    }

    injectOverlay() {

        document.body.appendChild(this.overlay);
    }

    updateOverlay(message) {
        this.msgArea.innerHTML = message;
    }

    removeOverlay() {
        this.overlay.remove();
    }
}

const contentScript = new ContentScript();
contentScript.setup();

})();

/******/ })()
;