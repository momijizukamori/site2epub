export const MessageType = {
    GET_CHAPTER: "Get chapter",
    GET_METADATA: "Get metadata",
    GET_CHAPTERLIST: "Get chapterlist",
    FINISHED: "Finished"
}
