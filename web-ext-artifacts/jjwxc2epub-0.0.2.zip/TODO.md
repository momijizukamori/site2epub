* Deal with missing latest chapter (JJWXC)
* Add cover images
* Nice status progress bar for chapter fetches
* Solve anti-piracy font problem (JJWXC)
