const WebExtPlugin = require('web-ext-plugin');
const path = require("path");
const webpack = require("webpack");

const replace = {
    'JJWXC': {
        '{URL}': 'jjwxc.net',
        '{NAME}': 'JJWXC',
        '{ADD_PERMS}': '',
        '{LC_NAME}': 'jjwxc'
    },
    'CHANGPEI': {
        'URL': 'gongzicp.com',
        'NAME': 'Changpei',
        'ADD_PERMS': ''
    },
};

module.exports = {
    // module: {
    //     rules: [
    //         {
    //             test: [/background\.js$/, /content_script\.js$/],
    //             use: [
    //                 {
    //                     loader: "imports-loader",
    //                     options: {
    //                         imports: [
    //                             "named ./sites/jjwxc LoadUrl",
    //                             "named ./sites/jjwxc JJWXCLogic SiteLogic"
    //                         ]
    //                     }
    //                 }
    //             ]
    //         }
    //     ]
    // },
    mode: "production",
    resolve:
        {
            fallback: { "path": require.resolve("path-browserify"), "zlib": require.resolve("browserify-zlib"), "fs": false,  "buffer": false,  "stream": require.resolve("stream-browserify") }
        },
    entry: {
        content_script: "./src/content_script.js",
        background: "./src/background.js",
        chapter_script: "./src/chapter_script.js"
    },
    output: {
        path: path.resolve(__dirname, "addon"),
        filename: "[name].js"
    },
    experiments: {
        syncWebAssembly: true
    },
    plugins: [
        new webpack.DefinePlugin(replace['JJWXC']), new webpack.ProvidePlugin({
        process: 'process/browser.js',
    }), new WebExtPlugin({ sourceDir: 'extension-dist' })],
};
